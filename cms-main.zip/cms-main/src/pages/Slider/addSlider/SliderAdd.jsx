import React, { useState } from 'react';
import { Button, Modal, ModalHeader, ModalBody, ModalFooter, Card, CardBody, CardTitle, CardSubtitle, Label, Input, Container, Row, Col, Form } from 'reactstrap';
import { GoogleApiWrapper, InfoWindow, Map, Marker } from "google-maps-react";
import { connect } from "react-redux";
import withRouter from 'components/Common/withRouter';
import { useEffect } from 'react';
import Breadcrumbs from 'components/Common/Breadcrumb';
import { boolean } from 'yup';
import Select from 'react-select';
import { v4 as uuidv4 } from 'uuid';
import moment from "moment";
import { useLocation, useNavigate } from 'react-router-dom';

const LoadingContainer = () => <div>Loading...</div>;

function SliderAdd(props) {

    return (

        <React.Fragment>

            <div className="page-content">
                <Container fluid>
                    {/* Render Breadcrumbs */}
                    <Breadcrumbs maintitle="Foodi" title="SLider" breadcrumbItem="Slider Image" />

                    <Row>
                        <Col className="col-12">
                            <Card style={{ border: "none" }}>
                                <CardBody>
                                    <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "10px", marginTop: "20px", backgroundColor: "#1E417D", padding: "15px" }}>
                                        <CardTitle className="h4" style={{ color: "#FFFFFF" }}>Add Slider Image</CardTitle>

                                    </div>
                                    {/* {props.get_all_restaurant_data ? props.get_all_restaurant_data.length > 0 ? <DatatableTablesWorking products={props.get_all_restaurant_data}
                                    columnData={activeData} defaultSorted={defaultSorted} key={props.get_all_restaurant_data?._id} /> : null : null} */}

                                </CardBody>
                            </Card>
                        </Col>
                    </Row>
                    <Row>
                        <Col className="col-10 mx-auto">

                        </Col>
                    </Row>
                </Container>
            </div>
        </React.Fragment>
    );
}

//export default AddBranch;

const mapStateToProps = state => {
    const {

    } = state.Restaurant;

    return {

    };
};

export default withRouter(
    connect(mapStateToProps,
        {

        })(SliderAdd)
);