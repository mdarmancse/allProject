<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Lservice
{

    //Retrieve  service List	
    public function service_list()
    {
        $CI = &get_instance();
        $CI->load->model('Service');
        $service_list = $CI->Service->service_list();  //It will get only  services

        $data = array(
            'title'        => display('manage_service'),
            'service_list' => $service_list,
        );
        $serviceList = $CI->parser->parse('service/service', $data, true);
        return $serviceList;
    }

    //Sub service Add
    public function service_category_add_form()
    {
        $CI = &get_instance();
        $CI->load->model('Service');

        $data = array(
            'title'    => display('add_service_category'),
        );
        $serviceCategoryForm = $CI->parser->parse('service/add_service_category_form', $data, true);
        return $serviceCategoryForm;
    }

    public function service_category_list()
    {
        $CI = &get_instance();
        $CI->load->model('Service');
        $category_list = $CI->Service->service_category_list();  //It will get only  services

        $i = 0;
        if (!empty($category_list)) {
            foreach ($category_list as $k => $v) {
                $i++;
                $category_list[$k]['sl'] = $i + $CI->uri->segment(3);
            }
        }
        $data = array(
            'title'        => display('service_category'),
            'category_list' => $category_list,

        );
        $categoryList = $CI->parser->parse('service/service_category', $data, true);
        return $categoryList;
    }

    //Sub service Add
    public function service_add_form()
    {
        $CI = &get_instance();
        $CI->load->model('Service');

        $service_detail = $CI->Service->service_category_list2();


        $data = array(
            'title'    => display('add_service'),
            'service_category_list' => $service_detail
        );
        // print_r($data);
        // exit();
        $serviceForm = $CI->parser->parse('service/add_service_form', $data, true);
        return $serviceForm;
    }

    //service Edit Data
    public function service_edit_data($service_id)
    {
        $CI = &get_instance();
        $CI->load->model('Service');
        $service_detail = $CI->Service->retrieve_service_editdata($service_id);

        $service_category_list = $CI->Service->service_category_list2();


        $data['title']         = display('service_edit');
        $data['service_id']    = $service_detail[0]['service_id'];
        $data['charge']        = $service_detail[0]['charge'];
        $data['service_name']  = $service_detail[0]['service_name'];
        $data['service_category_id']  = $service_detail[0]['service_category_id'];
        $data['description']   = $service_detail[0]['description'];
        $data['servicedetails'] = $service_detail;
        $data['service_category_list'] = $service_category_list;

        $chapterList = $CI->parser->parse('service/edit_service_form', $data, true);
        return $chapterList;
    }

    //service category Edit Data
    public function service_category_edit_data($category_id)
    {
        $CI = &get_instance();
        $CI->load->model('Service');
        $service_detail = $CI->Service->retrieve_service_category_editdata($category_id);


        $data['title']         = display('edit_service_category');
        $data['id']    = $service_detail[0]['id'];
        $data['category_name']  = $service_detail[0]['category_name'];
        // $data['servicedetails'] = $service_detail;

        $chapterList = $CI->parser->parse('service/edit_service_category_form', $data, true);
        return $chapterList;
    }

    public function service_invoice_add_form()
    {
        $CI = &get_instance();
        $CI->load->model('Service');
        $CI->load->model('Web_settings');
        $employee_list    = $CI->Service->employee_list();
        $currency_details = $CI->Web_settings->retrieve_setting_editdata();
        $bank_list        = $CI->Web_settings->bank_list();
        $bkash_list        = $CI->Web_settings->bkash_list();
        $taxfield = $CI->db->select('tax_name,default_value')
            ->from('tax_settings')
            ->get()
            ->result_array();
        $data = array(
            'title'         => display('service_invoice'),
            'employee_list' => $employee_list,
            'bank_list'     => $bank_list,
            'bkash_list'     => $bkash_list,
            'discount_type' => $currency_details[0]['discount_type'],
            'taxes'         => $taxfield,
        );
        $invoiceForm = $CI->parser->parse('service/add_invoice_form', $data, true);
        return $invoiceForm;
    }


    public function service_invoice_pos_add_form()
    {
        $CI = &get_instance();
        $CI->load->model('Invoices');
        $CI->load->model('Web_settings');
        $CI->load->model('Courier');
        $CI->load->model('Service');
        $CI->load->model('Settings');
        $CI->load->model('Warehouse');
        $CI->load->model('Aggre');
        $customer_details = $CI->Invoices->pos_customer_setup();
        $employee_list    = $CI->Service->employee_list();
        $service_list    = $CI->Service->get_service_list();
        $card_list = $CI->Settings->get_real_card_data();
        $vat   = $CI->Settings->read_all_pos_setting('vat')[0]['value'];
        $delivery_charge   = $CI->Settings->read_all_pos_setting('delivery_charge')[0]['value'];
        $service_charge   = $CI->Settings->read_all_pos_setting('service_charge')[0]['value'];
        $tax   = $CI->Settings->read_all_pos_setting('tax')[0]['value'];
        $sale_discount   = $CI->Settings->read_all_pos_setting('total_sale_flat_discount')[0]['value'];
        $sale_discount_percent   = $CI->Settings->read_all_pos_setting('total_sale_percentage_discount')[0]['value'];
        $item_wise_flat_discount   = $CI->Settings->read_all_pos_setting('item_wise_flat_discount')[0]['value'];
        // echo "<pre>";
        // print_r($setting);
        // exit();

        $bank_list          = $CI->Web_settings->bank_list();
        $bkash_list        = $CI->Web_settings->bkash_list();
        $nagad_list        = $CI->Web_settings->nagad_list();
        $rocket_list        = $CI->Web_settings->rocket_list();
        $courier_list        = $CI->Courier->get_courier_list();
        $branch_list        = $CI->Courier->get_branch_list();
        $outlet_user        = $CI->Warehouse->get_outlet_user();
        $receiver_list        = $CI->Courier->get_receiver_list();

        // $outlet_list = $CI->Warehouse->branch_list_product();

        $outlet_id = $CI->session->userdata('outlet_id');
        $outlet_list = $CI->Warehouse->get_outlet($outlet_id);
        $tech_list = $CI->Warehouse->get_outlet_tech($outlet_id);
        // echo "<pre>";
        // print_r($tech_list);
        // exit();



        $cw = $CI->Warehouse->central_warehouse();
        $aggre_list = $CI->Aggre->aggre_list_product();

        $currency_details = $CI->Web_settings->retrieve_setting_editdata();


        $data = array(
            'title'         => display('add_new_service_invoice'),
            'employee_list' => $employee_list,
            'service_list' => $service_list,
            'discount_type' => $currency_details[0]['discount_type'],
            'customer_name' => $customer_details[0]['customer_name'],
            'customer_id'   => $customer_details[0]['customer_id'],
            'customer_id_two'   => $customer_details[0]['customer_id_two'],
            'tech_list'     => $tech_list,
            'card_list'     => $card_list,
            'bank_list'     => $bank_list,
            'bkash_list'     => $bkash_list,
            'nagad_list'     => $nagad_list,
            'rocket_list'     => $rocket_list,
            'courier_list'     => $courier_list,
            'branch_list'     => $branch_list,
            // 'outlet_list'     => $outlet_user,
            'outlet_list'     => $outlet_list,
            'outlet_id' => $outlet_id,
            'receiver_list'    => $receiver_list,
            'aggre_list'    => $aggre_list,
            'cw'            => $cw,
            'vat'           => $vat,
            'tax'     => $tax,
            'service_charge' => $service_charge,
            'delivery_charge' => $delivery_charge,
            'sale_discount'           => $sale_discount,
            'sale_discount_percent'     => $sale_discount_percent,
            'item_wise_flat_discount' => $item_wise_flat_discount
        );

        // echo '<pre>';print_r($data);exit();
        $invoiceForm = $CI->parser->parse('service/add_service_invoice_pos_form_new', $data, true);
        return $invoiceForm;
    }

    public function service_invoice_edit_data($invoice_id)
    {

        $CI = &get_instance();
        $CI->load->model('Service');
        $CI->load->model('Web_settings');
        $bank_list        = $CI->Web_settings->bank_list();
        $bkash_list        = $CI->Web_settings->bkash_list();
        $employee_list    = $CI->Service->employee_list();
        $currency_details = $CI->Web_settings->retrieve_setting_editdata();
        $service_inv_main = $CI->Service->service_invoice_updata($invoice_id);
        $customer_info    =  $CI->Service->customer_info($service_inv_main[0]['customer_id']);
        $taxinfo  = $CI->Service->service_invoice_taxinfo($invoice_id);
        $taxfield = $CI->db->select('tax_name,default_value')
            ->from('tax_settings')
            ->get()
            ->result_array();
        $data = array(
            'title'         => display('update_service_invoice'),
            'employee_list' => $employee_list,
            'invoice_id'    => $service_inv_main[0]['voucher_no'],
            'date'          => $service_inv_main[0]['date'],
            'customer_id'   => $service_inv_main[0]['customer_id'],
            'customer_name' => $customer_info->customer_name,
            'details'       => $service_inv_main[0]['details'],
            'total_amount'  => $service_inv_main[0]['total_amount'],
            'total_discount' => $service_inv_main[0]['total_discount'],
            'invoice_discount' => $service_inv_main[0]['invoice_discount'],
            'total_tax'     => $service_inv_main[0]['total_tax'],
            'paid_amount'   => $service_inv_main[0]['paid_amount'],
            'due_amount'    => $service_inv_main[0]['due_amount'],
            'shipping_cost' => $service_inv_main[0]['shipping_cost'],
            'invoice_detail' => $service_inv_main,
            'taxvalu'       => $taxinfo,
            'discount_type' => $currency_details[0]['discount_type'],
            'taxes'         => $taxfield,
            'stotal'        => $service_inv_main[0]['total_amount'] - $service_inv_main[0]['previous'],
            'employees'    => $service_inv_main[0]['employee_id'],
            'previous'     => $service_inv_main[0]['previous'],
            'paytype'     => $service_inv_main[0]['paytype'],
            'bkash_id'     => $service_inv_main[0]['bkash_id'],
            'bkash_no'     => $service_inv_main[0]['bkash_no'],
            'ac_name'     => $service_inv_main[0]['ac_name'],
            'bank_id'     => $service_inv_main[0]['bank_id'],
            'bank_name'     => $service_inv_main[0]['bank_name'],
            'bank_list'     => $bank_list,
            'bkash_list'     => $bkash_list,


        );

        // echo '<pre>';print_r($data);exit();
        $invoiceForm = $CI->parser->parse('service/update_invoice_form', $data, true);
        return $invoiceForm;
    }

    public function service_invoice_view_data($invoice_id)
    {

        $CI = &get_instance();
        $CI->load->model('Service');
        $CI->load->model('Web_settings');
        $CI->load->model('Invoices');
        $CI->load->library('occational');
        $employee_list = $CI->Service->employee_list();
        $currency_details = $CI->Web_settings->retrieve_setting_editdata();
        $service_inv_main = $CI->Service->service_invoice_updata($invoice_id);
        $customer_info =  $CI->Service->customer_info($service_inv_main[0]['customer_id']);
        $taxinfo = $CI->Service->service_invoice_taxinfo($invoice_id);
        $taxfield = $CI->db->select('tax_name,default_value')
            ->from('tax_settings')
            ->get()
            ->result_array();

        $taxreg = $CI->db->select('*')
            ->from('tax_settings')
            ->where('is_show', 1)
            ->get()
            ->result_array();
        $txregname = '';
        foreach ($taxreg as $txrgname) {
            $regname = $txrgname['tax_name'] . ' Reg No  - ' . $txrgname['reg_no'] . ', ';
            $txregname .= $regname;
        }
        $company_info = $CI->Invoices->retrieve_company();

        $subTotal_quantity = 0;
        $subTotal_discount = 0;
        $subTotal_ammount = 0;

        if (!empty($service_inv_main)) {
            foreach ($service_inv_main as $k => $v) {
                $service_inv_main[$k]['final_date'] = $CI->occational->dateConvert($service_inv_main[$k]['date']);
                $subTotal_quantity = $subTotal_quantity + $service_inv_main[$k]['qty'];
                $subTotal_ammount = $subTotal_ammount + $service_inv_main[$k]['total'];
            }

            $i = 0;
            foreach ($service_inv_main as $k => $v) {
                $i++;
                $service_inv_main[$k]['sl'] = $i;
            }
        }
        $data = array(
            'title'         => display('service_details'),
            'employee_list' => $employee_list,
            'invoice_id'    => $service_inv_main[0]['voucher_no'],
            'final_date'    => $service_inv_main[0]['final_date'],
            'customer_id'   => $service_inv_main[0]['customer_id'],
            'customer_name' => $customer_info->customer_name,
            'customer_address' => $customer_info->customer_address,
            'customer_mobile' => $customer_info->customer_mobile,
            'customer_email' => $customer_info->customer_email,
            'details'       => $service_inv_main[0]['details'],
            'total_amount'  => number_format($service_inv_main[0]['total_amount'], 2, '.', ','),
            'total_discount' => number_format($service_inv_main[0]['total_discount'], 2, '.', ','),
            'invoice_discount' => number_format($service_inv_main[0]['invoice_discount'], 2, '.', ','),
            'subTotal_ammount' => number_format($subTotal_ammount, 2, '.', ','),
            'subTotal_quantity' => number_format($subTotal_quantity, 2, '.', ','),
            'total_tax'     => number_format($service_inv_main[0]['total_tax'], 2, '.', ','),
            'paid_amount'   => number_format($service_inv_main[0]['paid_amount'], 2, '.', ','),
            'due_amount'    => number_format($service_inv_main[0]['due_amount'], 2, '.', ','),
            'shipping_cost' => number_format($service_inv_main[0]['shipping_cost'], 2, '.', ','),
            'invoice_detail' => $service_inv_main,
            'taxvalu'       => $taxinfo,
            'discount_type' => $currency_details[0]['discount_type'],
            'currency'      => $currency_details[0]['currency'],
            'position'      => $currency_details[0]['currency_position'],
            'taxes'         => $taxfield,
            'stotal'        => $service_inv_main[0]['total_amount'] - $service_inv_main[0]['previous'],
            'employees'     => $service_inv_main[0]['employee_id'],
            'previous'      => number_format($service_inv_main[0]['previous'], 2, '.', ','),
            'company_info'  => $company_info,
            'tax_regno'     => $txregname,

        );
        $invoiceForm = $CI->parser->parse('service/invoice_html', $data, true);
        return $invoiceForm;
    }

    //Retrieve  Invoice List
    public function service_invoice_list()
    {

        $CI = &get_instance();
        $CI->load->model('Invoices');
        $CI->load->model('Web_settings');

        $company_info = $CI->Invoices->retrieve_company();
        $currency_details = $CI->Web_settings->retrieve_setting_editdata();
        $data = array(
            'title'         => display('manage_service_invoice'),
            'total_invoice' => $CI->Invoices->count_invoice(),
            'currency'      => $currency_details[0]['currency'],
            'company_info'  => $company_info,
            'bank_list'        => $CI->Web_settings->bank_list(),
            'bkash_list'        => $CI->Web_settings->bkash_list(),
            'nagad_list'        =>  $CI->Web_settings->nagad_list(),
            'rocket_list'        =>  $CI->Web_settings->rocket_list(),
        );
        // echo "<pre>";
        // print_r($company_info);
        // exit();
        $invoiceList = $CI->parser->parse('service/manage_service_pos', $data, true);
        return $invoiceList;
    }




    //Service Invoice html Data manual
    public function service_invoice_html_data_manual($invoice_id, $manage = null)
    {
        $CI = &get_instance();
        $CI->load->model('Invoices');
        $CI->load->model('Web_settings');
        $CI->load->library('occational');
        $CI->load->library('numbertowords');
        $CI->load->library('converter');
        $CI->load->model('Warehouse');

        $redirect_url = $_SESSION['redirect_uri'];

        $invoice_detail = $CI->Invoices->retrieve_invoice_html_data($invoice_id);
        $payment_info = $CI->Invoices->payment_details_total($invoice_id);
        $invoice_setting_data = $CI->Invoices->getSettingData();

        // echo '<pre>';
        // print_r($invoice_detail);
        // exit();

        $cus_id = $invoice_detail[0]['customer_id'];
        $agg_id = $invoice_detail[0]['agg_id'];

        if (!empty($agg_id)) {
            $agg_name = $CI->db->select('aggre_name')->from('aggre_list')->where('id', $agg_id)->get()->row()->aggre_name;
        }
        $customer_balance = $CI->Invoices->customer_balance($cus_id);
        $taxfield = $CI->db->select('*')
            ->from('tax_settings')
            ->where('is_show', 1)
            ->get()
            ->result_array();
        $txregname = '';
        foreach ($taxfield as $txrgname) {
            $regname = $txrgname['tax_name'] . ' Reg No  - ' . $txrgname['reg_no'] . ', ';
            $txregname .= $regname;
        }
        $subTotal_quantity = 0;
        $subTotal_cartoon = 0;
        $subTotal_discount = 0;
        $subTotal_ammount = 0;
        $subTotal_ammount_wd = 0;
        $discount_per = 0;
        $descript = 0;
        $isserial = 0;
        $isunit = 0;
        $total_discount = 0;
        $total_vat = 0;
        $total_tax = 0;
        if (!empty($invoice_detail)) {
            foreach ($invoice_detail as $k => $v) {
                $invoice_detail[$k]['final_date'] = $CI->occational->dateConvert($invoice_detail[$k]['date']);
                $subTotal_quantity = $subTotal_quantity + $invoice_detail[$k]['quantity'];
                $subTotal_ammount = $subTotal_ammount + $invoice_detail[$k]['total_price'];
                // if ($invoice_detail[$k]['total_price_wd'] > 0) {
                //     $subTotal_ammount_wd = $subTotal_ammount_wd + $invoice_detail[$k]['total_price_wd'];
                // }

                $subTotal_ammount_wd = $subTotal_ammount_wd + $invoice_detail[$k]['total_price_wd'];
                $discount_per = $discount_per + $invoice_detail[$k]['discount_per'];
                $total_discount = $total_discount + $invoice_detail[$k]['item_total_discount'];
                $total_vat = $total_vat + $invoice_detail[$k]['vat'];
                $total_tax = $total_tax + $invoice_detail[$k]['tax'];
            }

            $i = 0;
            foreach ($invoice_detail as $k => $v) {
                $i++;
                $invoice_detail[$k]['sl'] = $i;
                if (!empty($invoice_detail[$k]['description'])) {
                    $descript = $descript + 1;
                }
                if (!empty($invoice_detail[$k]['serial_no'])) {
                    $isserial = $isserial + 1;
                }
                if (!empty($invoice_detail[$k]['unit'])) {
                    $isunit = $isunit + 1;
                }
            }
        }

        $outlet = $CI->Warehouse->branch_search_item($invoice_detail[0]['outlet_id']);
        // echo '<pre>';
        // print_r($outlet);
        // exit();

        $inwords = $CI->numbertowords->convert_number($invoice_detail[0]['total_amount']);

        $currency_details = $CI->Web_settings->retrieve_setting_editdata();
        $company_info = $CI->Invoices->retrieve_company();
        // $totalbal = $invoice_detail[0]['total_amount']+$invoice_detail[0]['prevous_due'];
        $totalbal = $invoice_detail[0]['total_amount'];
        $amount_inword = $CI->numbertowords->convert_number($totalbal);
        $user_id = $invoice_detail[0]['sales_by'];
        $users = $CI->Invoices->user_invoice_data($user_id);


        //        $bangla_amount = $CI->converter->en2bn(10203);
        //
        //        echo $bangla_amount;
        //        exit();

        if (
            $invoice_detail[0]['delivery_type'] == 1
        ) {
            $dt = 'Pick Up';
        }
        if ($invoice_detail[0]['delivery_type'] == 2) {
            $dt = 'Courier';
        }

        if ($invoice_detail[0]['payment_type'] == 1) {
            $pt = 'Cash';
        }

        if ($invoice_detail[0]['payment_type'] == 4) {
            $pt = 'Bank';
        }
        if ($invoice_detail[0]['payment_type'] == 3) {
            $pt = 'Bkash';
        }
        if ($invoice_detail[0]['payment_type'] == 6) {
            $pt = 'Card';
        }
        if ($invoice_detail[0]['payment_type'] == 2) {
            $pt = 'Cheque';
        }

        if ($invoice_detail[0]['sale_type'] == 1) {
            $st = 'Whole Sale';
        }
        if ($invoice_detail[0]['sale_type'] == 3) {
            $st = 'Aggregators Sale';
        }

        if (
            $invoice_detail[0]['courier_condtion'] == 1
        ) {
            $con = 'Conditional';
        }
        if (
            $invoice_detail[0]['courier_condtion'] == 2
        ) {
            $con = 'Partial';
        }
        if (
            $invoice_detail[0]['courier_condtion'] == 3
        ) {
            $con = 'No Condition';
        }

        $price = $invoice_detail[0]['total_amount'] + $invoice_detail[0]['prevous_due'];
        $round_price = round($price);
        // $rounding = $round_price - $price;
        $rounding = $invoice_detail[0]['rounding'];

        // echo "<pre>";
        // print_r($invoice_detail[0]['changeamount']);
        // exit();



        $data = array(
            'title'             => $invoice_detail[0]['invoice'] . '-' . $outlet[0]['outlet_name'] . '-' . date('Y-m-d'),
            'balance'        => $customer_balance[0]['balance'],
            'pay_type' => $invoice_detail[0]['payment_type'],
            'is_pre' => $invoice_detail[0]['is_pre'],
            'delivery_type'        => $invoice_detail[0]['delivery_type'],
            'invoice_id'        => $invoice_detail[0]['invoice_id'],
            'dt'        => $dt,
            'pt'        => $pt,
            'st'        => $st,
            'con'        => $con,
            'condition_cost'        => $invoice_detail[0]['condition_cost'],
            'invoice_no'        => $invoice_detail[0]['invoice'],
            'outlet_name'        => $outlet[0]['outlet_name'],
            'outlet_address'        => $outlet[0]['address'],
            'outlet_logo'        => $outlet[0]['image'],
            'outlet_bin'        => $outlet[0]['bin'],
            'outlet_mushak'        => $outlet[0]['mushak'],
            'outlet_serial_id'        => $outlet[0]['id'],
            'outlet_phn_no'        => $outlet[0]['phn_no'],
            'sale_type'     => $invoice_detail[0]['sale_type'],
            'agg_name'     => $agg_name,
            'time'     => $invoice_detail[0]['time'],
            'date'     => $invoice_detail[0]['date'],
            'customer_name'     => $invoice_detail[0]['customer_name'],
            'service_charge'     => $invoice_detail[0]['service_charge'],
            'customer_name_bn'     => $invoice_detail[0]['customer_name_bn'],
            'customer_id_two'     => $invoice_detail[0]['customer_id_two'],
            'friend_card'     => $invoice_detail[0]['friend_card'],
            'shop_name'  => $invoice_detail[0]['shop_name'],
            'customer_address'  => $invoice_detail[0]['customer_address'],
            'customer_mobile'   => $invoice_detail[0]['customer_mobile'],
            'customer_email'    => $invoice_detail[0]['customer_email'],
            'courier_status'    => $invoice_detail[0]['courier_status'],
            'final_date'        => $invoice_detail[0]['final_date'],
            'inv_date'        => $invoice_detail[0]['date'],
            'invoice_details'   => $invoice_detail[0]['invoice_details'],
            'rounding' => number_format($rounding, 2),
            // 'total_amount'      => number_format(round($invoice_detail[0]['total_amount'] + $invoice_detail[0]['prevous_due']), 2, '.', ','),
            'total_amount'      => number_format(round($invoice_detail[0]['total_amount']), 2, '.', ','),
            // 'total_amount'      => $invoice_detail[0]['total_amount'],
            'net_total'      => number_format(round($invoice_detail[0]['net_total']), 2, '.', ','),
            'total'      => number_format($invoice_detail[0]['total_amount'], 2, '.', ','),
            'subTotal_quantity' => $subTotal_quantity,
            'previous_paid'    => number_format($invoice_detail[0]['previous_paid'], 2, '.', ','),
            'invoice_discount'    => number_format($invoice_detail[0]['invoice_discount'], 2, '.', ','),
            //'total_discount'    => number_format(($invoice_detail[0]['total_discount'] + $discount_per), 2, '.', ','),

            'total_discount'    => number_format(($invoice_detail[0]['total_discount']), 2, '.', ','),
            //            'sub_total'    => number_format($invoice_detail[0]['total_discount']+$invoice_detail[0]['total_amount'], 2, '.', ','),
            'sub_total'    => number_format($subTotal_ammount_wd, 2, '.', ','),
            'total_tax'         => number_format($total_tax, 2, '.', ','),
            'total_vat'         => number_format($total_vat, 2, '.', ','),
            'subTotal_ammount'  => number_format($subTotal_ammount, 2, '.', ','),
            'paid_amount'       => number_format(round($invoice_detail[0]['paid_amount']), 2, '.', ','),
            'due_amount'        => number_format(round($invoice_detail[0]['due_amount']), 2, '.', ','),
            'sales_return'        => number_format(round($invoice_detail[0]['sales_return']), 2, '.', ','),
            'cash_refund'        => number_format(round($invoice_detail[0]['cash_refund']), 2, '.', ','),
            // 'customer_ac'        => number_format(round($invoice_detail[0]['customer_ac']), 2, '.', ','),
            'customer_ac'        => number_format(round(abs($invoice_detail[0]['customer_ac'])), 2, '.', ','),
            'changeamount'        => number_format($invoice_detail[0]['changeamount'], 2, '.', ','),
            'previous'          => number_format($invoice_detail[0]['prevous_due'], 2, '.', ','),
            'shipping_cost'     => number_format($invoice_detail[0]['shipping_cost'], 2, '.', ','),
            'total_commission'     => number_format($invoice_detail[0]['total_commission'] + $invoice_detail[0]['commission'], 2, '.', ','),
            'paid_amount_2'     => number_format($invoice_detail[0]['paid_amount'] - $invoice_detail[0]['changeamount'], 2, '.', ','),
            'invoice_all_data'  => $invoice_detail,
            'company_info'      => $company_info,
            'currency'          => $currency_details[0]['currency'],
            'position'          => $currency_details[0]['currency_position'],
            'discount_type'     => $currency_details[0]['discount_type'],
            'inv_logo'          => $currency_details[0]['invoice_logo'],
            'am_inword'         => $amount_inword,
            'is_discount'       => $invoice_detail[0]['total_discount'] - $invoice_detail[0]['invoice_discount'],
            'users_name'        => $users->first_name . ' ' . $users->last_name,
            'tax_regno'         => $txregname,
            'is_desc'           => $descript,
            'is_serial'         => $isserial,
            'is_unit'           => $isunit,
            'inwords'           => $inwords,
            'manage'            => $manage,
            'payment_info'            => $payment_info,
            'red_url'           => isset($redirect_url) ? $redirect_url : null,
            // 'invoice_setting_data' => $invoice_setting_data

        );
        foreach ($invoice_setting_data as $key => $invoice_setting) {
            $data[$invoice_setting->OptionSlug] = $invoice_setting->status;
        }
        $pay_type = $invoice_detail[0]['sale_type'];
        // echo '<pre>';
        // print_r($data);
        // exit();
        // if ($pay_type == 2) {
        //     //            $chapterList = $CI->parser->parse('invoice/pos_dell_arte_invoice_html_manual', $data, true);
        //     $chapterList = $CI->parser->parse('invoice/invoice_html_manual_a5', $data, true);
        // } else {
        //     $chapterList = $CI->parser->parse('invoice/invoice_html_manual_new', $data, true);
        // }
        if ($invoice_setting_data[0]->status == "A4") {
            $chapterList = $CI->parser->parse('invoice/invoice_html_manual_a5', $data, true);
        }
        if ($invoice_setting_data[0]->status == "A5") {
            $chapterList = $CI->parser->parse('invoice/pos_dell_arte_invoice_html_manual', $data, true);
        }
        if ($invoice_setting_data[0]->status == "80") {
            $chapterList = $CI->parser->parse('invoice/pos_invoice_80mm', $data, true);
        }
        if ($invoice_setting_data[0]->status == "55") {
            $chapterList = $CI->parser->parse('invoice/pos_invoice_55mm', $data, true);
        }
        //        $chapterList = $CI->parser->parse('invoice/invoice_html_manual', $data, true);
        return $chapterList;
    }
}
