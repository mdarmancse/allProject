<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Service extends CI_Model
{

    public function __construct()
    {
        parent::__construct();
        $this->load->library('auth');
        $this->load->library('lservice');
        $this->load->library('Smsgateway');
        $this->load->library('session');
        $this->load->model('Service');
        $this->auth->check_admin_auth();
    }

    //Service List
    public function service_list()
    {
        $this->db->select('*');
        $this->db->from('product_service');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return false;
    }

    public function get_service_list()
    {
        return $list = $this->db->select('*')->from('product_service')->get()->result_array();
    }

    //Service category List
    public function service_category_list()
    {
        $this->db->select('*');
        $this->db->from('service_categories');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return false;
    }

    // Service category List
    public function service_category_list2()
    {
        return $list = $this->db->select('*')->from('service_categories')->get()->result_array();
    }



    //customer List
    public function service_list_product()
    {
        $this->db->select('*');
        $this->db->from('product_service');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return false;
    }

    //customer List
    public function service_list_count()
    {
        $this->db->select('*');
        $this->db->from('product_service');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->num_rows();
        }
        return false;
    }

    //service Search Item
    public function service_search_item($service_id)
    {
        $this->db->select('*');
        $this->db->from('product_service');
        $this->db->where('service_id', $service_id);
        $this->db->limit('500');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return false;
    }

    //Count customer
    public function service_entry($data)
    {
        $this->db->select('*');
        $this->db->from('product_service');
        $this->db->where('service_name', $data['service_name']);
        $this->db->where('service_category_id', $data['service_category_id']);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return FALSE;
        } else {
            $this->db->insert('product_service', $data);
            return TRUE;
        }
    }

    public function service_category_entry($data)
    {
        $this->db->select('*');
        $this->db->from('service_categories');
        $this->db->where('category_name', $data['category_name']);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return FALSE;
        } else {
            $this->db->insert('service_categories', $data);
            return TRUE;
        }


        $this->db->select('*');
        $this->db->from('service_categories');
        $this->db->where('status', 1);
        $this->db->where('unit_name', $data['unit_name']);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return FALSE;
        } else {
            $this->db->insert('units', $data);
            return TRUE;
        }
    }

    //Retrieve customer Edit Data
    public function retrieve_service_editdata($service_id)
    {
        $this->db->select('*');
        $this->db->from('product_service');
        $this->db->where('service_id', $service_id);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return false;
    }

    //service category edit Data
    public function retrieve_service_category_editdata($category_id)
    {
        $this->db->select('*');
        $this->db->from('service_categories');
        $this->db->where('id', $category_id);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return false;
    }

    //Update Categories
    public function update_service($data, $service_id)
    {
        $this->db->where('service_id', $service_id);
        $this->db->update('product_service', $data);
        return true;
    }

    //Update Service Categories
    public function update_service_category($data, $id)
    {
        $this->db->where('id', $id);
        $this->db->update('service_categories', $data);
        return true;
    }

    // Delete customer Item
    public function delete_service($service_id)
    {
        $this->db->where('service_id', $service_id);
        $this->db->delete('product_service');
        $this->db->select('*');
        $this->db->from('product_service');
        $query = $this->db->get();
        foreach ($query->result() as $row) {
            $json_service[] = array('label' => $row->service_name, 'value' => $row->service_id);
        }
        $cache_file = './my-assets/js/admin_js/json/service.json';
        $serviceList = json_encode($json_service);
        file_put_contents($cache_file, $serviceList);
        return true;
    }

    // Delete service_category
    public function delete_service_category($category_id)
    {
        $this->db->where('id', $category_id);
        $this->db->delete('service_categories');

        return true;
    }

    public function get_total_service_invoic($service_id)
    {

        $this->db->select('*');
        $this->db->from('product_service');
        $this->db->where(array('service_id' => $service_id));
        $serviceinfo = $this->db->get()->row();

        $CI = &get_instance();
        $CI->load->model('Web_settings');
        $currency_details = $CI->Web_settings->retrieve_setting_editdata();
        $tablecolumn = $this->db->list_fields('product_service');
        $num_column = count($tablecolumn) - 4;
        $taxfield = '';
        $taxvar = [];
        for ($i = 0; $i < $num_column; $i++) {
            $taxfield = 'tax' . $i;
            $data2[$taxfield] = $serviceinfo->$taxfield;
            $taxvar[$i] = $serviceinfo->$taxfield;
            $data2['taxdta'] = $taxvar;
            //
        }
        $data2['txnmber'] = $num_column;
        $data2['price'] = $serviceinfo->charge;
        $data2['discount_type'] = $currency_details[0]['discount_type'];

        return $data2;
    }
    // Employee list
    public function employee_list()
    {
        return $list = $this->db->select('*')->from('employee_history')->get()->result_array();
    }

    //This function is used to Generate Key
    public function generator($lenth)
    {
        $number = array("1", "2", "3", "4", "5", "6", "7", "8", "9");

        for ($i = 0; $i < $lenth; $i++) {
            $rand_value = rand(0, 8);
            $rand_number = $number["$rand_value"];

            if (empty($con)) {
                $con = $rand_number;
            } else {
                $con = "$con" . "$rand_number";
            }
        }
        return $con;
    }

    //Count invoice
    public function service_pos_entry()
    {

        // echo "<pre>";
        // print_r($_POST);
        // exit();


        $CI = &get_instance();
        $CI->auth->check_admin_auth();
        $CI->load->library('lproduct');
        $CI->load->model('Web_settings');
        $CI->load->model('Settings');
        $CI->load->model('Products');
        $CI->load->model('Rqsn');
        $CI->load->model('Reports');
        $CI->load->model('Invoices');

        $invoice_id = $this->generator(10);
        $invoice_id = strtoupper($invoice_id);
        $outlet_id = $this->input->post('outlet_name', TRUE);

        $createby = $this->session->userdata('user_id');
        $createdate = date('Y-m-d H:i:s');

        $invoice_no_generated = $this->Invoices->number_generator($outlet_id);


        $Vdate = (!empty($this->input->post('invoice_date', TRUE)) ? $this->input->post('invoice_date', TRUE) : date('Y-m-d'));

        $customer_id = $this->input->post('customer_id', TRUE);
        $warranty_date = $this->input->post('warranty_date', TRUE);
        $delivery_date = $this->input->post('delivery_date', TRUE);
        $technician_id = $this->input->post('technician_id', TRUE);
        $service_id = $this->input->post('service_id', TRUE);

        $pay_type = $this->input->post('paytype', TRUE);
        $paid = $this->input->post('p_amount', TRUE);


        $service_price = $this->input->post('service_price', TRUE);
        $flat_discount = $this->input->post('flat_discount', TRUE);
        $perc_discount = $this->input->post('perc_discount', TRUE);
        $total_discount_amount = $this->input->post('total_discount_amount', TRUE);
        $total_price_with_total_discount = $this->input->post('total_price_with_total_discount', TRUE);

        $vat_type = $this->input->post('vat_type', TRUE);
        $total_vat_perc = $this->input->post('total_vat_perc', TRUE);
        $total_vat_amount = $this->input->post('total_vat_amount', TRUE);

        $tax_type = $this->input->post('tax_type', TRUE);
        $total_tax_perc = $this->input->post('total_tax_perc', TRUE);
        $total_tax_amount = $this->input->post('total_tax_amount', TRUE);

        $grand_total = $this->input->post('grand_total', TRUE);
        $previous = $this->input->post('previous', TRUE);
        $rounding = $this->input->post('rounding', TRUE);
        $net_total = $this->input->post('net_total', TRUE);
        $paid_amount = $this->input->post('paid_amount', TRUE);
        $due_amount = $this->input->post('due_amount', TRUE);
        $change = $this->input->post('change', TRUE);

        if ($change > 0) {
            $paid_amount = $net_total;
        } else {
            $paid_amount = $paid_amount;
        }

        $bank_id = $this->input->post('bank_id_m', TRUE);

        $bkash_id = $this->input->post('bkash_id', TRUE);
        $bkashname = '';
        $card_id = $this->input->post('card_id', TRUE);
        $nagad_id = $this->input->post('nagad_id', TRUE);
        $rocket_id = $this->input->post('rocket_id', TRUE);

        $product_id_array = $this->input->post('product_id', TRUE);
        $available_quantity_array = $this->input->post('available_quantity', TRUE);
        $quantity_array = $this->input->post('product_quantity', TRUE);


        $result = array();
        foreach ($available_quantity_array as $k => $v) {
            if ($v < $quantity_array[$k]) {
                $this->session->set_userdata(array('error_message' => display('you_can_not_buy_greater_than_available_qnty')));
                redirect('Cservice/service_invoice_pos_form');
            }
        }


        // if ($product_id_array == null) {
        //     $this->session->set_userdata(array('error_message' => display('please_select_product')));
        //     redirect('Cservice/service_invoice_pos_form');
        // }
        //Data inserting into invoice table


        $cheque_date = $this->input->post('cheque_date', TRUE);
        $cheque_no = $this->input->post('cheque_no', TRUE);
        $cheque_type = $this->input->post('cheque_type', TRUE);
        $bank_name = $this->input->post('bank_id', TRUE);
        $amount = $this->input->post('amount', TRUE);

        $this->load->library('upload');
        $image = array();

        if ($_FILES['image']['name']) {
            $ImageCount = count($_FILES['image']['name']);
            for ($i = 0; $i < $ImageCount; $i++) {
                $_FILES['file']['name']       = $_FILES['image']['name'][$i];
                $_FILES['file']['type']       = $_FILES['image']['type'][$i];
                $_FILES['file']['tmp_name']   = $_FILES['image']['tmp_name'][$i];
                $_FILES['file']['error']      = $_FILES['image']['error'][$i];
                $_FILES['file']['size']       = $_FILES['image']['size'][$i];

                // File upload configuration
                $uploadPath = 'my-assets/image/cheque/';
                $config['upload_path'] = $uploadPath;
                $config['allowed_types'] = 'gif|jpg|png|jpeg|JPEG|GIF|JPG|PNG';
                $config['encrypt_name']  = TRUE;

                // Load and initialize upload library
                $this->load->library('upload', $config);
                $this->upload->initialize($config);

                // Upload file to server
                if ($this->upload->do_upload('file')) {
                    // Uploaded file data

                    $imageData = $this->upload->data();
                    $uploadImgData[$i]['image'] = $config['upload_path'] . $imageData['file_name'];
                    $image_url = base_url() . $uploadImgData[$i]['image'];
                }
            }
        }

        if (!empty($cheque_no) && !empty($cheque_date)) {

            foreach ($cheque_no as $key => $value) {


                $data['cheque_no'] = $value;
                $data['invoice_id'] = $invoice_id;
                $data['cheque_id'] = $this->generator(10);
                $data['cheque_type'] = $cheque_type[$key];
                $data['bank_name'] = $bank_name;
                $data['cheque_date'] = $cheque_date[$key];
                $data['amount'] = $amount[$key];
                $data['image'] = (!empty($image_url) ? $image_url : base_url('my-assets/image/product.png'));
                $data['status'] = 2;
                if (!empty($data)) {
                    $this->db->insert('cus_cheque', $data);
                }
            }
        }

        $datainv = array(
            'invoice_id'      => $invoice_id,
            'customer_id'     => $customer_id,
            'service_id'     => $service_id,
            'technician_id'     => $technician_id,
            'outlet_id'     => $outlet_id,

            'work_status'       =>  1,
            'date'            => $Vdate,
            'time'    => date("h:i A"),
            'delivery_date' => $delivery_date,
            'warranty_date' => $warranty_date,

            'invoice'         => $invoice_no_generated,

            'service_price' => $service_price,
            'flat_discount' => $flat_discount,
            'perc_discount' => $perc_discount,
            'total_discount_amount'  => $total_discount_amount,
            'total_price_with_total_discount' => $total_price_with_total_discount,

            'vat_type' => $vat_type,
            'total_vat_perc'   => $total_vat_perc,
            'total_vat_amount'   => $total_vat_amount,

            'tax_type' => $tax_type,
            'total_tax_perc'   => $total_tax_perc,
            'total_tax_amount'   => $total_tax_amount,

            'grand_total'    => $grand_total,
            'previous_due'     => $previous,
            'rounding'    => $rounding,
            'net_total'    => $net_total,

            'paid_amount'     => $paid_amount,
            'due_amount'      => $due_amount,
            'change_amount'       =>  $change,

            'sales_by'        => $createby,
            'status'          => $paid_amount <= 0 ? 2 : 1,

        );

        $this->db->insert('service_invoice_pos', $datainv);

        for ($i = 0, $n = count($product_id_array); $i < $n; $i++) {
            $product_quantity = $quantity_array[$i];

            $product_id = $product_id_array[$i];


            if ($outlet_id == 'HK7TGDT69VFMXB7') {
                $stock_details = $this->Reports->getExpiryCheckList($product_id)['aaData'];
            } else {
                $stock_details = $this->Rqsn->expiry_outlet_stock($product_id)['aaData'];
            }

            $product_quantity_new = $product_quantity;
            $inv_details_arr = array();

            foreach ($stock_details as $stock) {
                if ($product_quantity_new < 1 || $stock['stok_quantity'] < 1) {
                    break;
                } else {

                    $rest = ($product_quantity_new >= $stock['stok_quantity']) ? $stock['stok_quantity'] :  $product_quantity_new;
                    $new_array = array(
                        'invoice_details_id' => $this->generator(15),
                        'invoice_id'         => $invoice_id,
                        'purchase_id'         => $stock['purchase_id'],
                        'product_id'         => $product_id,
                        'quantity'           => $rest,
                        'description'        => 'Manual Sales Service',
                        'supplier_rate'      => $this->Invoices->supplier_purchase_price($product_id, $stock['purchase_id']),

                    );
                    $product_quantity_new = $product_quantity_new - $rest;

                    array_push($inv_details_arr, $new_array);
                }
            }


            foreach ($inv_details_arr as $ar) {

                if ($ar['quantity'] > 0) {
                    $result = $this->db->insert('service_invoice_pos_details', $ar);
                }
            }
        }


        $prinfo  = $this->db->select('product_id,Avg(rate) as product_rate')->from('product_purchase_details')->where_in('product_id', $product_id_array)->group_by('product_id')->get()->result();

        $pr_open_price = $this->db->select('supplier_price')
            ->from('supplier_product')
            ->where_in('product_id', $product_id_array)
            ->group_by('product_id')
            ->get()
            ->result();

        $purchase_ave = [];
        $i = 0;
        if ($prinfo) {
            foreach ($prinfo as $avg) {
                $purchase_ave[] =  $avg->product_rate * $quantity_array[$i];
                $i++;
            }
        } else {
            foreach ($pr_open_price as $avg) {
                $purchase_ave[] =  $avg->supplier_price * $quantity_array[$i];
                $i++;
            }
        }

        $cusifo = $this->db->select('*')->from('customer_information')->where('customer_id', $customer_id)->get()->row();
        $headn = $customer_id . '-' . $cusifo->customer_name;
        $coainfo = $this->db->select('*')->from('acc_coa')->where('HeadName', $headn)->get()->row();
        $customer_headcode = $coainfo->HeadCode;
        $cs_name = $cusifo->customer_name;

        $new_amount_debit = $service_price;
        if ($vat_type == "ex") {
            $new_amount_debit += $total_vat_amount;
        }
        if ($tax_type == "ex") {
            $new_amount_debit += $total_tax_amount;
        }

        $new_amount_credit = $service_price;
        if ($vat_type == "in") {
            $new_amount_debit -= $total_vat_amount;
        }
        if ($tax_type == "in") {
            $new_amount_debit -= $total_tax_amount;
        }


        $cosdr = array(
            'VNo' => $invoice_id,
            'Vtype' => 'INV-CC',
            'VDate' => $Vdate,
            'COAID' => $customer_headcode,
            'Narration' => 'Customer debit for Service Invoice No -  ' . $invoice_no_generated . ' Customer ' . $cs_name,
            // 'Debit' => $grand_total_wtd - $this->input->post('shipping_cost', TRUE),
            'Debit' => $new_amount_debit,
            'Credit' => 0,
            'IsPosted' => 1,
            'CreateBy' => $createby,
            'CreateDate' => $createdate,
            'IsAppove' => 1
        );
        $this->db->insert('acc_transaction', $cosdr);



        $pro_sale_income = array(
            'VNo'            =>  $invoice_id,
            'Vtype'          =>  'INVOICE',
            'VDate'          =>  $Vdate,
            'COAID'          =>  304,
            'Narration'      =>  'Service sale income for Service Invoice ID - ' . $invoice_id . ' Customer ' . $cs_name,
            'Debit'          =>  0,
            'Credit'         => $new_amount_credit,
            'IsPosted'       => 1,
            'CreateBy'       => $createby,
            'CreateDate'     => $createdate,
            'IsAppove'       => 1
        );
        $this->db->insert('acc_transaction', $pro_sale_income);


        if ($total_discount_amount > 0) {
            $dis_transaction = array(

                'VNo' => $invoice_id,
                'Vtype' => 'INVOICE',
                'VDate' => $Vdate,
                'COAID' => 406,
                'Narration' => 'Servcie sales discount for Service Invoice ID - ' . $invoice_id,
                'Credit' => 0,
                'Debit' => $total_discount_amount,
                'IsPosted' => 1,
                'CreateBy' => $createby,
                'CreateDate' => $createdate,
                'IsAppove' => 1,

            );

            $this->db->insert('acc_transaction', $dis_transaction);

            $dis_transaction_2 = array(

                'VNo' => $invoice_id,
                'Vtype' => 'INVOICE',
                'VDate' => $Vdate,
                'COAID' => $customer_headcode,
                'Narration'      =>  'Customer discount for Service Invoice No -  ' . $invoice_no_generated . ' Customer  ' . $cs_name,
                'Credit' => $total_discount_amount,
                'Debit' => 0,
                'IsPosted' => 1,
                'CreateBy' => $createby,
                'CreateDate' => $createdate,
                'IsAppove' => 1,

            );

            $this->db->insert('acc_transaction', $dis_transaction_2);
        }


        if ($total_vat_amount > 0) {
            $com_transaction = array(

                'VNo' => $invoice_id,
                'Vtype' => 'INVOICE',
                'VDate' => $Vdate,
                'COAID' => 50203,
                'Narration' => 'Total vat for Service Invoice ID - ' . $invoice_id,
                'Credit' => $total_vat_amount,
                'Debit' => 0,
                'IsPosted' => 1,
                'CreateBy' => $createby,
                'CreateDate' => $createdate,
                'IsAppove' => 1,

            );

            $this->db->insert('acc_transaction', $com_transaction);
        }

        if ($total_tax_amount > 0) {
            $com_transaction = array(

                'VNo' => $invoice_id,
                'Vtype' => 'INVOICE',
                'VDate' => $Vdate,
                'COAID' => 50204,
                'Narration' => 'Total tax for Service Invoice ID - ' . $invoice_id,
                'Credit' => $total_tax_amount,
                'Debit' => 0,
                'IsPosted' => 1,
                'CreateBy' => $createby,
                'CreateDate' => $createdate,
                'IsAppove' => 1,

            );

            $this->db->insert('acc_transaction', $com_transaction);
        }

        ///Customer credit for Paid Amount

        if (count($paid) > 0) {
            for ($i = 0; $i < count($pay_type); $i++) {

                if ($paid[$i] > 0) {
                    if ($pay_type[$i] == 1) {

                        if ($change > 0) {
                            $new_cash_amount = $paid[$i] - $change;
                        } else {
                            $new_cash_amount = $paid[$i];
                        }

                        $cc = array(
                            'VNo'            =>  $invoice_id,
                            'Vtype'          =>  'INV',
                            'VDate'          =>  $Vdate,
                            'COAID'          =>  1020101,
                            'Narration'      =>  'Cash in hand in Sale for Service Invoice ID - ' . $invoice_id . ' customer- ' . $cs_name,
                            'Debit'          =>  $new_cash_amount,
                            'Credit'         =>  0,
                            'IsPosted'       =>  1,
                            'CreateBy'       =>  $createby,
                            'CreateDate'     =>  $createdate,
                            'IsAppove'       =>  1,

                        );
                        $this->db->insert('acc_transaction', $cc);

                        $coscr = array(
                            'VNo' => $invoice_id,
                            'Vtype' => 'INV-CC',
                            'VDate' => $Vdate,
                            'COAID' => $customer_headcode,
                            'Narration' => 'Customer credit for Service Invoice No -  ' . $invoice_no_generated . ' Customer ' . $cs_name,
                            'Debit' => 0,
                            'Credit' => $new_cash_amount,
                            // 'Credit' =>  $paid[$i] + $total_discount,
                            'IsPosted' => 1,
                            'CreateBy' => $createby,
                            'CreateDate' => $createdate,
                            'IsAppove' => 1
                        );
                        $this->db->insert('acc_transaction', $coscr);


                        $data = array(
                            'invoice_id'    => $invoice_id,
                            'pay_type'      => $pay_type[$i],
                            'amount'        => $new_cash_amount,
                            'pay_date'      =>  $Vdate,
                            'status'        =>  1,
                            'account'       => '',
                            'COAID'         => 1020101
                        );


                        $this->db->insert('paid_amount', $data);
                    }
                    if ($pay_type[$i] == 4) {
                        if (!empty($bank_id)) {
                            $bankname = $this->db->select('bank_name')->from('bank_add')->where('bank_id', $bank_id[$i])->get()->row()->bank_name;

                            $bankcoaid = $this->db->select('HeadCode')->from('acc_coa')->where('HeadName', $bankname)->get()->row()->HeadCode;
                        } else {
                            $bankcoaid = '';
                        }
                        $bankc = array(
                            'VNo'            =>  $invoice_id,
                            'Vtype'          =>  'INVOICE',
                            'VDate'          =>  $Vdate,
                            'COAID'          =>  $bankcoaid,
                            'Narration'      =>  'Paid amount for customer Service Invoice ID - ' . $invoice_id . ' customer -' . $cs_name,
                            'Debit'          =>  $paid[$i],
                            'Credit'         =>  0,
                            'IsPosted'       =>  1,
                            'CreateBy'       =>  $createby,
                            'CreateDate'     =>  $createdate,
                            'IsAppove'       =>  1,

                        );
                        $cuscredit = array(
                            'VNo'            =>  $invoice_id,
                            'Vtype'          =>  'INV',
                            'VDate'          =>  $Vdate,
                            'COAID'          =>  $customer_headcode,
                            'Narration'      =>  'Customer credit (cash in hand) for paid amount for customer Service Invoice ID - ' . $invoice_id . ' Customer- ' . $cs_name,
                            'Debit'          =>  0,
                            'Credit'         =>  $paid[$i],
                            'IsPosted'       => 1,
                            'CreateBy'       => $createby,
                            'CreateDate'     => $createdate,
                            'IsAppove'       => 1
                        );
                        $this->db->insert('acc_transaction', $cuscredit);

                        $this->db->insert('acc_transaction', $cc);
                        $data = array(
                            'invoice_id'    => $invoice_id,
                            'pay_type'      => $pay_type[$i],
                            'amount'        => $paid[$i],
                            'account'       => $bankname,
                            'COAID'         => $bankcoaid,
                            'pay_date'       =>  $Vdate,
                            'status'        =>  1
                        );

                        $this->db->insert('paid_amount', $data);


                        $this->db->insert('acc_transaction', $bankc);
                    }
                    if ($pay_type[$i] == 3) {
                        if (!empty($bkash_id)) {
                            $bkashname = $this->db->select('bkash_no')->from('bkash_add')->where('bkash_id', $bkash_id[$i])->get()->row()->bkash_no;

                            $bkashcoaid = $this->db->select('HeadCode')->from('acc_coa')->where('HeadName', 'BK-' . $bkashname)->get()->row()->HeadCode;
                        } else {
                            $bkashcoaid = '';
                        }
                        $bkashc = array(
                            'VNo'            =>  $invoice_id,
                            'Vtype'          =>  'INVOICE',
                            'VDate'          =>  $Vdate,
                            'COAID'          =>  $bkashcoaid,
                            'Narration'      =>  'Cash in bkash paid amount for customer Service Invoice ID - ' . $invoice_id . ' customer -' . $cs_name,
                            'Debit'          =>  $paid[$i],
                            'Credit'         =>  0,
                            'IsPosted'       =>  1,
                            'CreateBy'       =>  $createby,
                            'CreateDate'     =>  $createdate,
                            'IsAppove'       =>  1,

                        );

                        $coscr = array(
                            'VNo' => $invoice_id,
                            'Vtype' => 'INV-CC',
                            'VDate' => $Vdate,
                            'COAID' => $customer_headcode,
                            'Narration' => 'Customer credit for Service Invoice No -  ' . $invoice_no_generated . ' Customer ' . $cs_name,
                            'Debit' => 0,
                            'Credit' =>  $paid[$i],
                            'IsPosted' => 1,
                            'CreateBy' => $createby,
                            'CreateDate' => $createdate,
                            'IsAppove' => 1
                        );
                        $this->db->insert('acc_transaction', $coscr);

                        $data = array(
                            'invoice_id'    => $invoice_id,
                            'pay_type'      => $pay_type[$i],
                            'amount'        => $paid[$i],
                            'account'       => $bkashname,
                            'pay_date'       =>  $Vdate,
                            'COAID'         => $bkashcoaid,
                            'status'        =>  1,
                        );

                        $this->db->insert('paid_amount', $data);
                        $this->db->insert('acc_transaction', $bkashc);
                    }
                    if ($pay_type[$i] == 5) {

                        if (!empty($nagad_id)) {
                            $nagadname = $this->db->select('nagad_no')->from('nagad_add')->where('nagad_id', $nagad_id[$i])->get()->row()->nagad_no;

                            $nagadcoaid = $this->db->select('HeadCode')->from('acc_coa')->where('HeadName', 'NG-' . $nagadname)->get()->row()->HeadCode;
                        } else {
                            $nagadcoaid = '';
                        }

                        $nagadc = array(
                            'VNo'            =>  $invoice_id,
                            'Vtype'          =>  'INVOICE',
                            'VDate'          =>  $Vdate,
                            'COAID'          =>  $nagadcoaid,
                            'Narration'      =>  'Cash in nagad paid amount for customer Service Invoice ID - ' . $invoice_id . ' customer -' . $cusifo->customer_name,
                            'Debit'          =>  $paid[$i],
                            'Credit'         =>  0,
                            'IsPosted'       =>  1,
                            'CreateBy'       =>  $createby,
                            'CreateDate'     =>  $createdate,
                            'IsAppove'       =>  1,

                        );
                        $coscr = array(
                            'VNo' => $invoice_id,
                            'Vtype' => 'INV-CC',
                            'VDate' => $Vdate,
                            'COAID' => $customer_headcode,
                            'Narration' => 'Customer credit for Service Invoice No -  ' . $invoice_no_generated . ' Customer ' . $cs_name,
                            'Debit' => 0,
                            'Credit' =>  $paid[$i],
                            'IsPosted' => 1,
                            'CreateBy' => $createby,
                            'CreateDate' => $createdate,
                            'IsAppove' => 1
                        );
                        $this->db->insert('acc_transaction', $coscr);

                        $data = array(
                            'invoice_id'    => $invoice_id,
                            'pay_type'      => $pay_type[$i],
                            'amount'        => $paid[$i],
                            'pay_date'       =>  $Vdate,
                            'account'       => $nagadname,
                            'COAID'         => $nagadcoaid,
                            'status'        =>  1,
                        );

                        $this->db->insert('paid_amount', $data);

                        $this->db->insert('acc_transaction', $nagadc);
                    }
                    if ($pay_type[$i] == 7) {

                        if (!empty($rocket_id)) {
                            $rocketname = $this->db->select('rocket_no')->from('rocket_add')->where('rocket_id', $rocket_id[$i])->get()->row()->rocket_no;

                            $rocketcoaid = $this->db->select('HeadCode')->from('acc_coa')->where('HeadName', 'RK-' . $rocketname)->get()->row()->HeadCode;
                        } else {
                            $rocketcoaid = '';
                        }

                        $rocketc = array(
                            'VNo'            =>  $invoice_id,
                            'Vtype'          =>  'INVOICE',
                            'VDate'          =>  $Vdate,
                            'COAID'          =>  $rocketcoaid,
                            'Narration'      =>  'Cash in rocket paid amount for customer Service Invoice ID - ' . $invoice_id . ' customer -' . $cusifo->customer_name,
                            'Debit'          =>  $paid[$i],
                            'Credit'         =>  0,
                            'IsPosted'       =>  1,
                            'CreateBy'       =>  $createby,
                            'CreateDate'     =>  $createdate,
                            'IsAppove'       =>  1,

                        );
                        $coscr = array(
                            'VNo' => $invoice_id,
                            'Vtype' => 'INV-CC',
                            'VDate' => $Vdate,
                            'COAID' => $customer_headcode,
                            'Narration' => 'Customer credit for Service Invoice No -  ' . $invoice_no_generated . ' Customer ' . $cs_name,
                            'Debit' => 0,
                            'Credit' =>  $paid[$i],
                            'IsPosted' => 1,
                            'CreateBy' => $createby,
                            'CreateDate' => $createdate,
                            'IsAppove' => 1
                        );
                        $this->db->insert('acc_transaction', $coscr);

                        $data = array(
                            'invoice_id'    => $invoice_id,
                            'pay_type'      => $pay_type[$i],
                            'amount'        => $paid[$i],
                            'pay_date'       =>  $Vdate,
                            'account'       => $rocketname,
                            'COAID'         => $rocketcoaid,
                            'status'        =>  1,
                        );

                        $this->db->insert('paid_amount', $data);

                        $this->db->insert('acc_transaction', $rocketc);
                    }
                    if ($pay_type[$i] == 6) {

                        $card_info = $CI->Settings->get_real_card_data($card_id[$i]);

                        if (!empty($card_id)) {
                            $bankname = $this->db->select('bank_name')->from('bank_add')->where('bank_id', $card_info[0]['bank_id'])->get()->row()->bank_name;

                            $bankcoaid = $this->db->select('HeadCode')->from('acc_coa')->where('HeadName', $bankname)->get()->row()->HeadCode;
                        } else {
                            $bankcoaid = '';
                        }
                        $bankc = array(
                            'VNo'            =>  $invoice_id,
                            'Vtype'          =>  'INVOICE',
                            'VDate'          =>  $Vdate,
                            'COAID'          =>  $bankcoaid,
                            'Narration'      =>  'Paid amount for customer in card - ' . $card_info[0]['card_no'] . ' Service Invoice ID - ' . $invoice_id . ' customer -' . $cusifo->customer_name,
                            'Debit'          => ($paid[$i]) - ($paid[$i] * ($card_info[0]['percentage'] / 100)),
                            'Credit'         =>  0,
                            'IsPosted'       =>  1,
                            'CreateBy'       =>  $createby,
                            'CreateDate'     =>  $createdate,
                            'IsAppove'       =>  1,

                        );
                        $coscr = array(
                            'VNo' => $invoice_id,
                            'Vtype' => 'INV-CC',
                            'VDate' => $Vdate,
                            'COAID' => $customer_headcode,
                            'Narration' => 'Customer credit For Service Invoice No -  ' . $invoice_no_generated . ' Customer ' . $cs_name,
                            'Debit' => 0,
                            'Credit' =>  $paid[$i],
                            'IsPosted' => 1,
                            'CreateBy' => $createby,
                            'CreateDate' => $createdate,
                            'IsAppove' => 1
                        );
                        $this->db->insert('acc_transaction', $coscr);

                        $data = array(
                            'invoice_id'    => $invoice_id,
                            'pay_type'      => $pay_type[$i],
                            'amount'        => $paid[$i],
                            'account'       => $bankname,
                            'pay_date'       =>  $Vdate,
                            'COAID'         => $bankcoaid,
                            'status'        =>  1,
                        );

                        $this->db->insert('paid_amount', $data);

                        $carddebit = array(
                            'VNo'            =>  $invoice_id,
                            'Vtype'          =>  'INV',
                            'VDate'          =>  $Vdate,
                            'COAID'          =>  '40404',
                            'Narration'      =>  'Expense debit for card no. ' . $card_info[0]['card_no'] . ' Service Invoice NO- ' . $invoice_no_generated,
                            'Debit'          =>  $paid[$i] * ($card_info[0]['percentage'] / 100),
                            'Credit'         =>  0,
                            'IsPosted'       => 1,
                            'CreateBy'       => $createby,
                            'CreateDate'     => $createdate,
                            'IsAppove'       => 1
                        );
                        $this->db->insert('acc_transaction', $carddebit);
                        $this->db->insert('acc_transaction', $bankc);
                    }
                }
            }
        }



        //Send Otp To Customer
        $cusifo = $this->db->select('*')->from('customer_information')->where('customer_id', $customer_id)->get()->row();
        $mobile_number = $cusifo->customer_mobile;
        $this->Invoices->sendotp($mobile_number, $net_total);

        return $invoice_id;
    }

    public function getServiceInvoiceList($postData = null)
    {

        $this->load->library('occational');
        $this->load->model('Warehouse');
        $this->load->model('Invoices');
        $response = array();
        $usertype = $this->session->userdata('user_type');

        $user_id = $this->session->userdata('user_id');

        $userRole = $this->Invoices->get_user_role($user_id);

        $outlet_id = $this->Invoices->get_user_outlet($user_id);

        //        echo strstr($userRole,"warehouse");
        //        exit();
        //        if (str_contains($userRole, 'Warehouse')) {
        //            echo 'true';
        //        }

        // echo '<pre>';
        // print_r($this->session->userdata('outlet_id'));
        // exit();
        $fromdate = $this->input->post(
            'fromdate',
            TRUE
        );
        $todate   = $this->input->post('todate', TRUE);
        if (!empty($fromdate)) {
            $datbetween = "(a.date BETWEEN '$fromdate' AND '$todate')";
        } else {
            $datbetween = "";
        }
        ## Read value
        $draw = $postData['draw'];
        $start = $postData['start'];
        $rowperpage = $postData['length']; // Rows display per page
        $columnIndex = $postData['order'][0]['column']; // Column index
        $columnName = $postData['columns'][$columnIndex]['data']; // Column name
        $columnSortOrder = $postData['order'][0]['dir']; // asc or desc
        $searchValue = $postData['search']['value']; // Search value

        ## Search
        $searchQuery = "";
        if ($searchValue != '') {
            $searchQuery = " (b.customer_name like '%" . $searchValue . "%' or x.outlet_name like '%" . $searchValue . "%' or a.invoice like '%" . $searchValue . "%' or a.date like'%" . $searchValue . "%' or a.invoice_id like'%" . $searchValue . "%' or u.first_name like'%" . $searchValue . "%'or u.last_name like'%" . $searchValue . "%')";
        }

        ## Total number of records without filtering
        $this->db->select('count(*) as allcount');
        $this->db->from('invoice a');
        $this->db->where('a.is_pre', 1);
        $this->db->join('customer_information b', 'b.customer_id = a.customer_id', 'left');
        $this->db->join('users u', 'u.user_id = a.sales_by', 'left');
        $this->db->join('outlet_warehouse x', 'x.outlet_id = a.outlet_id', 'left');

        $this->db->order_by(
            'a.invoice',
            'desc'
        );
        if ($usertype == 2) {
            // $this->db->where('a.sales_by', $this->session->userdata('user_id'));
            $this->db->where('a.outlet_id', $this->session->userdata('outlet_id'));
        }
        if (!empty($fromdate) && !empty($todate)) {
            $this->db->where($datbetween);
        }
        if ($searchValue != '')
            $this->db->where($searchQuery);

        $records = $this->db->get()->result();
        $totalRecords = $records[0]->allcount;

        // echo "<pre>";
        // print_r($records);
        // exit();

        ## Total number of record with filtering
        $this->db->select('count(*) as allcount');
        $this->db->from('invoice a');
        $this->db->where('a.is_pre', 1);
        $this->db->join('customer_information b', 'b.customer_id = a.customer_id', 'left');
        $this->db->join('users u', 'u.user_id = a.sales_by', 'left');
        $this->db->join('outlet_warehouse x', 'x.outlet_id = a.outlet_id', 'left');

        $this->db->order_by('a.invoice', 'desc');
        if ($usertype == 2) {
            // $this->db->where('a.sales_by', $this->session->userdata('user_id'));
            $this->db->where('a.outlet_id', $this->session->userdata('outlet_id'));
        }
        if (!empty($fromdate) && !empty($todate)) {
            $this->db->where($datbetween);
        }
        if ($searchValue != '')
            $this->db->where($searchQuery);

        $records = $this->db->get()->result();
        $totalRecordwithFilter = $records[0]->allcount;

        $cw_name = $this->Warehouse->central_warehouse()[0]['central_warehouse'];

        ## Fetch records
        $this->db->select("a.*,b.customer_name,u.first_name,u.last_name, x.*, a.outlet_id as outlt");
        $this->db->from('invoice a');
        $this->db->where('a.is_pre', 1);
        $this->db->join('customer_information b', 'b.customer_id = a.customer_id', 'left');
        $this->db->join('users u', 'u.user_id = a.sales_by', 'left');
        $this->db->join('outlet_warehouse x', 'x.outlet_id = a.outlet_id', 'left');
        $this->db->order_by('a.invoice', 'desc');
        if ($usertype == 2) {
            if ($userRole == 'Warehouse Admin') {
                $this->db->where('a.sale_type', 1);
                $this->db->or_where('a.sale_type', 4);
                $this->db->or_where('a.sale_type', 3);
            } else {
                $this->db->where('a.outlet_id', $this->session->userdata('outlet_id'));
                // $this->db->where('a.sales_by', $this->session->userdata('user_id'));
            }
        }
        if (!empty($fromdate) && !empty($todate)) {
            $this->db->where($datbetween);
        }
        if ($searchValue != '')
            $this->db->where($searchQuery);

        $this->db->order_by($columnName, $columnSortOrder);
        $this->db->limit($rowperpage, $start);
        // echo '<pre>'; print_r($this->db->get()->result_array());exit();
        $records = $this->db->get()->result();
        $data = array();
        $sl = 1;

        // echo "<pre>";
        // print_r($records);
        // exit();

        foreach ($records as $record) {

            if (($record->paid_amount - $record->net_total) >= 0) {
                $due_amount = 0;
            } else {
                $due_amount = $record->net_total - $record->paid_amount;
            }
            $button = '';
            $base_url = base_url();
            $jsaction = "return confirm('Are You Sure ?')";

            $button .= '  <a href="' . $base_url . 'Cinvoice/invoice_inserted_data/' . $record->invoice_id . '" class="btn btn-success btn-sm" data-toggle="tooltip" data-placement="left" title="' . display('invoice') . '"><i class="fa fa-window-restore" aria-hidden="true"></i></a>';

            // if ($this->permission1->method('manage_invoice', 'update')->access()) {
            //     $button .= ' <a href="' . $base_url . 'Cinvoice/invoice_update_form/' . $record->invoice_id . '" class="btn btn-info btn-sm" data-toggle="tooltip" data-placement="left" title="' . display('update') . '"><i class="fa fa-pencil" aria-hidden="true"></i></a> ';
            // }
            $button .= ' <a href="' . $base_url . 'Cretrun_m/invoice_return_form_c/' . $record->invoice_id . '" class="btn btn-danger btn-sm" data-toggle="tooltip" data-placement="left" title="Return"><i class="fa fa-retweet" aria-hidden="true"></i></a> ';
            $button .= ' <a  class="btn btn-black btn-sm" data-toggle="tooltip" data-placement="left" title="Payment" onclick="payment_modal(' . $record->invoice_id . ',' . $record->net_total . ',' . $record->paid_amount . ',' . $due_amount . ')"><i class="fa fa-money" aria-hidden="true"></i></a> ';



            $details = '  <a href="' . $base_url . 'Cinvoice/invoice_inserted_data/' . $record->invoice_id . '" class="" >' . $record->invoice . '</a>';
            $details_i = '  <a href="' . $base_url . 'Cinvoice/invoice_inserted_data/' . $record->invoice_id . '" class="" >' . $record->invoice_id . '</a>';

            if ($record->outlt == 'HK7TGDT69VFMXB7') {
                $out = $cw_name;
            } else {
                if ($record->sale_type == 4) {
                    $out = 'Online Order';
                } else {
                    $out =   $record->outlet_name;
                }
            }

            //            $out = (($record->outlt == 'HK7TGDT69VFMXB7') ? $cw_name : $record->outlet_name);


            $agg_id = $record->agg_id;

            // echo "<pre>";
            // print_r($agg_id);
            // exit();



            if (!empty($agg_id)) {
                $agg_name = $this->db->select('aggre_name')->from('aggre_list')->where('id', $agg_id)->get()->row()->aggre_name;
            }

            if ($record->agg_id == 3) {
                $customer_name = $agg_name;
            } else {
                $customer_name = $record->customer_name;
            }

            $customer_name = $record->customer_name;

            // if ($record->due_amount > 0) {
            //     $payment_status = '<span class="label label-danger ">Due</span>';
            // } else {
            //     $payment_status = '<span class="label label-success ">Paid</span>';
            // }

            if (($record->paid_amount - $record->net_total) >= 0) {
                $payment_status = '<span class="label label-success ">Paid</span>';
            } else {
                $payment_status = '<span class="label label-danger ">Due</span>';
            }



            // $outlet = ($this->Warehouse->branch_search_item($record->outlet_id)) ? $this->Warehouse->branch_search_item($record->outlet_id)[0]['outlet_name'] : '';
            if ($record->sale_type == 1) {
                $st = 'Whole Sale';
            }
            if ($record->sale_type == 2) {
                $st = 'Retail';
            }
            if ($record->sale_type == 3) {
                $st = 'Aggregators Sale';
            }
            if ($record->sale_type == 4) {
                $st = 'Online Retail';
            }

            if ($record->sale_type  == null) {

                $st = '';
            }

            if ($record->courier_status  == 1) {
                $courier_status = 'Processing';
            }

            if (
                $record->courier_status == 2
            ) {
                $courier_status = 'Shipped';
            }
            if (
                $record->courier_status  == 3
            ) {

                $courier_status = 'Delivered';
            }
            if ($record->courier_status  == 4) {

                $courier_status = 'Cancelled';
            }
            if (
                $record->courier_status  == 5
            ) {
                $courier_status = 'Returned';
            }
            if ($record->courier_status  == 6) {

                $courier_status = 'Exchanged';
            }
            if (
                $record->courier_status  == 0
            ) {

                $courier_status = 'N/A';
            }
            $data[] = array(
                'sl'               => $sl,
                'invoice_id'       => $details_i,
                'invoice'          => $details,
                'outlet_name'      => $out,
                'delivery_type'      => ($record->delivery_type == '1') ? 'Pick Up' : (($record->delivery_type == '2') ? 'Courier' : 'Nothing Selected'),
                'courier_status'      => $courier_status,
                'payment_status'      => $payment_status,
                'paid_amount'      => $record->paid_amount,
                // 'due_amount'      => $record->due_amount,
                'due_amount'      => $due_amount,
                'sale_type'      => $st,
                'salesman'         => $record->first_name . ' ' . $record->last_name,
                'customer_name'    => $customer_name,
                'final_date'       => $this->occational->dateConvert($record->date) . " " . $record->time,
                'total_amount'     => $record->net_total,
                'button'           => $button,
            );
            $sl++;
        }

        // echo '<pre>';
        // print_r($data);
        // exit();
        ## Response
        $response = array(
            "draw" => intval($draw),
            "iTotalRecords" => $totalRecordwithFilter,
            "iTotalDisplayRecords" => $totalRecords,
            "aaData" => $data
        );

        return $response;
    }



    public function invoice_entry()
    {
        $this->load->model('Web_settings');
        $currency_details = $this->Web_settings->retrieve_setting_editdata();
        $tablecolumn = $this->db->list_fields('tax_collection');
        $num_column = count($tablecolumn) - 4;
        $employee = $this->input->post('employee_id');
        $employee_id = implode(',', $employee);
        $invoice_id  = 'serv-' . date('Ymdhis');
        $createby = $this->session->userdata('user_id');
        $createdate = date('Y-m-d H:i:s');

        $bank_id = $this->input->post('bank_id_m', TRUE);
        if (!empty($bank_id)) {
            $bankname = $this->db->select('bank_name')->from('bank_add')->where('bank_id', $bank_id)->get()->row()->bank_name;

            $bankcoaid = $this->db->select('HeadCode')->from('acc_coa')->where('HeadName', $bankname)->get()->row()->HeadCode;
        } else {
            $bankcoaid = '';
        }

        $bkash_id = $this->input->post('bkash_id', TRUE);
        if (!empty($bkash_id)) {
            $bkashname = $this->db->select('bkash_no')->from('bkash_add')->where('bkash_id', $bkash_id)->get()->row()->bkash_no;

            $bkashcoaid = $this->db->select('HeadCode')->from('acc_coa')->where('HeadName', $bkashname)->get()->row()->HeadCode;
        } else {
            $bkashcoaid = '';
        }

        if (($this->input->post('customer_name_others') == null) && ($this->input->post('customer_id') == null) && ($this->input->post('customer_name') == null)) {
            $this->session->set_userdata(array('error_message' => display('please_select_customer')));
            redirect(base_url() . 'Cservice/service_invoice_form');
        }
        if ($this->input->post('employee_id') == null) {
            $this->session->set_userdata(array('error_message' => display('please_select_employee')));
            redirect(base_url() . 'Cservice/service_invoice_form');
        }


        if (($this->input->post('customer_id') == null) && ($this->input->post('customer_name') == null)) {
            $customer_id = $this->auth->generator(15);
            //Customer  basic information adding.
            $coa = $this->headcode();
            if ($coa->HeadCode != NULL) {
                $headcode = $coa->HeadCode + 1;
            } else {
                $headcode = "102030101";
            }
            $c_acc = $customer_id . '-' . $this->input->post('customer_name_others', true);
            $createby = $this->session->userdata('user_id');
            $createdate = date('Y-m-d H:i:s');
            $data = array(
                'customer_id'      => $customer_id,
                'customer_name'    => $this->input->post('customer_name_others', true),
                'customer_address' => $this->input->post('customer_name_others_address', true),
                'customer_mobile'  => $this->input->post('customer_mobile', true),
                'customer_email'   => "",
                'status'           => 2
            );
            $customer_coa = [
                'HeadCode'         => $headcode,
                'HeadName'         => $c_acc,
                'PHeadName'        => 'Customer Receivable',
                'HeadLevel'        => '4',
                'IsActive'         => '1',
                'IsTransaction'    => '1',
                'IsGL'             => '0',
                'HeadType'         => 'A',
                'IsBudget'         => '0',
                'IsDepreciation'   => '0',
                'DepreciationRate' => '0',
                'CreateBy'         => $createby,
                'CreateDate'       => $createdate,
            ];

            $this->db->insert('customer_information', $data);
            $this->db->insert('acc_coa', $customer_coa);
            $this->db->select('*');
            $this->db->from('customer_information');
            $query = $this->db->get();
            foreach ($query->result() as $row) {
                $json_customer[] = array('label' => $row->customer_name, 'value' => $row->customer_id);
            }
            $cache_file = './my-assets/js/admin_js/json/customer.json';
            $customerList = json_encode($json_customer);
            file_put_contents($cache_file, $customerList);


            //Previous balance adding -> Sending to customer model to adjust the data.
            $this->Customers->previous_balance_add(0, $customer_id);
        } else {
            $customer_id = $this->input->post('customer_id', true);
        }


        //Full or partial Payment record.
        $paid_amount = $this->input->post('paid_amount', true);
        if ($this->input->post('paid_amount') >= 0) {

            $this->db->set('status', '1');
            $this->db->where('customer_id', $customer_id);

            $this->db->update('customer_information');

            $transection_id = $this->auth->generator(15);



            // Inserting for Accounts adjustment.
            ############ default table :: customer_payment :: inflow_92mizdldrv #################
        }

        //Data inserting into invoice table
        $datainv = array(
            'employee_id'     => $employee_id,
            'customer_id'     => $customer_id,
            'date'            => (!empty($this->input->post('invoice_date', true)) ? $this->input->post('invoice_date', true) : date('Y-m-d')),
            'total_amount'    => $this->input->post('grand_total_price', true),
            'total_tax'       => $this->input->post('total_tax_amount', true),
            'voucher_no'      => $invoice_id,
            'details'         => (!empty($this->input->post('inva_details', true)) ? $this->input->post('inva_details', true) : 'Service Invoice'),
            'invoice_discount' => $this->input->post('invoice_discount', true),
            'total_discount'  => $this->input->post('total_discount', true),
            'shipping_cost'   => $this->input->post('shipping_cost', true),
            'paid_amount'     => $this->input->post('paid_amount', true),
            'due_amount'      => $this->input->post('due_amount', true),
            'previous'        => $this->input->post('previous', true),
            'paytype'        => $this->input->post('paytype', true),
            'bank_id'        => $this->input->post('bank_id_m', true),
            'bkash_id'        => $this->input->post('bkash_id', true),

        );

        $this->db->insert('service_invoice', $datainv);


        $cusifo = $this->db->select('*')->from('customer_information')->where('customer_id', $customer_id)->get()->row();
        $headn = $customer_id . '-' . $cusifo->customer_name;
        $coainfo = $this->db->select('*')->from('acc_coa')->where('HeadName', $headn)->get()->row();
        $customer_headcode = $coainfo->HeadCode;
        // Cash in Hand debit
        $cc = array(
            'VNo'            =>  $invoice_id,
            'Vtype'          =>  'SERVICE',
            'VDate'          =>  $createdate,
            'COAID'          =>  1020101,
            'Narration'      =>  'Cash in Hand For SERVICE No ' . $invoice_id,
            'Debit'          =>  $this->input->post('paid_amount', true),
            'Credit'         =>  0,
            'IsPosted'       =>  1,
            'CreateBy'       =>  $createby,
            'CreateDate'     =>  $createdate,
            'IsAppove'       =>  1
        );

        $bankc = array(
            'VNo'            =>  $invoice_id,
            'Vtype'          =>  'SERVICE',
            'VDate'          =>  $createdate,
            'COAID'          =>  $bankcoaid,
            'Narration'      =>  'Cash in bank For SERVICE No ' . $invoice_id,
            'Debit'          =>  $this->input->post('paid_amount', true),
            'Credit'         =>  0,
            'IsPosted'       =>  1,
            'CreateBy'       =>  $createby,
            'CreateDate'     =>  $createdate,
            'IsAppove'       =>  1,

        );

        $bkashc = array(
            'VNo'            =>  $invoice_id,
            'Vtype'          =>  'INVOICE',
            'VDate'          =>  $createdate,
            'COAID'          =>  $bkashcoaid,
            'Narration'      =>   'Cash in bkash For SERVICE No ' . $invoice_id,
            'Debit'          =>  $this->input->post('paid_amount', true),
            'Credit'         =>  0,
            'IsPosted'       =>  1,
            'CreateBy'       =>  $createby,
            'CreateDate'     =>  $createdate,
            'IsAppove'       =>  1,

        );

        //service income
        $service_income = array(
            'VNo'            =>  $invoice_id,
            'Vtype'          =>  'SERVICE',
            'VDate'          =>  $createdate,
            'COAID'          =>  304,
            'Narration'      =>  'Service Income For SERVICE No ' . $invoice_id,
            'Debit'          =>  0,
            'Credit'         =>  $this->input->post('grand_total_price', true),
            'IsPosted'       =>  1,
            'CreateBy'       =>  $createby,
            'CreateDate'     =>  $createdate,
            'IsAppove'       =>  1
        );

        $this->db->insert('acc_transaction', $service_income);
        //Customer debit for service Value
        $cosdr = array(
            'VNo'            =>  $invoice_id,
            'Vtype'          =>  'SERVICE',
            'VDate'          =>  $createdate,
            'COAID'          =>  $customer_headcode,
            'Narration'      =>  'Customer debit For service No ' . $invoice_id,
            'Debit'          =>  $this->input->post('grand_total_price', true),
            'Credit'         =>  0,
            'IsPosted'       => 1,
            'CreateBy'       => $createby,
            'CreateDate'     => $createdate,
            'IsAppove'       => 1
        );
        $this->db->insert('acc_transaction', $cosdr);

        ///Customer credit for Paid Amount
        $coscr = array(
            'VNo'            =>  $invoice_id,
            'Vtype'          =>  'SERVICE',
            'VDate'          =>  $createdate,
            'COAID'          =>  $customer_headcode,
            'Narration'      =>  'Customer credit for Paid Amount For Service No ' . $invoice_id,
            'Debit'          =>  0,
            'Credit'         =>  $this->input->post('paid_amount', true),
            'IsPosted'       => 1,
            'CreateBy'       => $createby,
            'CreateDate'     => $createdate,
            'IsAppove'       => 1
        );

        if (!empty($this->input->post('paid_amount', true))) {
            $this->db->insert('acc_transaction', $coscr);
            if ($this->input->post('paytype', TRUE) == 1) {
                $this->db->insert('acc_transaction', $cc);
            }
            if ($this->input->post('paytype', TRUE) == 4) {
                $this->db->insert('acc_transaction', $bankc);
            }
            if ($this->input->post('paytype', TRUE) == 3) {
                $this->db->insert('acc_transaction', $bkashc);
            }
        }

        $quantity            = $this->input->post('product_quantity', true);
        $rate                = $this->input->post('product_rate', true);
        $serv_id             = $this->input->post('service_id', true);
        $total_amount        = $this->input->post('total_price', true);
        $discount_rate       = $this->input->post('discount_amount', true);
        $discount_per        = $this->input->post('discount', true);
        $tax_amount          = $this->input->post('tax', true);
        $invoice_description = $this->input->post('desc', true);

        for ($i = 0, $n   = count($serv_id); $i < $n; $i++) {
            $service_qty  = $quantity[$i];
            $product_rate = $rate[$i];
            $service_id   = $serv_id[$i];
            $total_price  = $total_amount[$i];
            $disper       = $discount_per[$i];
            $disamnt      = $discount_rate[$i];

            $service_details = array(
                'service_inv_id'     => $invoice_id,
                'service_id'         => $service_id,
                'qty'                => $service_qty,
                'charge'             => $product_rate,
                'discount'           => $disper,
                'discount_amount'    => $disamnt,
                'total'              => $total_price,
            );
            if (!empty($quantity)) {
                $this->db->insert('service_invoice_details', $service_details);
            }
        }
        for ($j = 0; $j < $num_column; $j++) {
            $taxfield = 'tax' . $j;
            $taxvalue = 'total_tax' . $j;
            $taxdata[$taxfield] = $this->input->post($taxvalue);
        }
        $taxdata['customer_id'] = $customer_id;
        $taxdata['date']        = (!empty($this->input->post('invoice_date', true)) ? $this->input->post('invoice_date', true) : date('Y-m-d'));
        $taxdata['relation_id'] = $invoice_id;
        $this->db->insert('tax_collection', $taxdata);

        $message = 'Mr.' . $cusifo->customer_name . ',
        ' . 'Your Service Charge ' . $this->input->post('grand_total_price', true) . ' ' . $currency_details[0]['currency'] . ' You have paid .' . $this->input->post('paid_amount') . ' ' . $currency_details[0]['currency'];
        $config_data = $this->db->select('*')->from('sms_settings')->get()->row();
        if ($config_data->isservice == 1) {
            $this->smsgateway->send([
                'apiProvider' => 'nexmo',
                'username'    => $config_data->api_key,
                'password'    => $config_data->api_secret,
                'from'        => $config_data->from,
                'to'          => $cusifo->customer_mobile,
                'message'     => $message
            ]);
        }
        return $invoice_id;
    }

    public function number_generator()
    {
        $this->db->select_max('voucher_no', 'voucher_no');
        $query = $this->db->get('service_invoice');
        $result = $query->result_array();
        $voucher_no = $result[0]['voucher_no'];
        if ($voucher_no != '') {
            $voucher_no = $voucher_no + 1;
        } else {
            $voucher_no = 1000;
        }
        return $voucher_no;
    }
    // Service invoice list
    public function service_invoice_list($limit = null, $start = null)
    {
        return $this->db->select('a.*,b.customer_name')
            ->from('service_invoice a')
            ->join('customer_information b', 'b.customer_id=a.customer_id', 'left')
            ->order_by('a.id', 'desc')
            ->limit($limit, $start)
            ->get()
            ->result_array();
    }

    // Service Invoice Delete
    public function delete_service_invoice($invoice_id)
    {
        //service invoice delete
        $this->db->where('voucher_no', $invoice_id);
        $this->db->delete('service_invoice');
        //service invoice details delete
        $this->db->where('service_inv_id', $invoice_id);
        $this->db->delete('service_invoice_details');
        //acc transaction delete
        $this->db->where('VNo', $invoice_id);
        $this->db->delete('acc_transaction');
    }
    // Service Invoice Update Information
    public function service_invoice_updata($invoice_id)
    {
        return $this->db->select('a.*,b.*,c.service_name,d.*,e.*')
            ->from('service_invoice a')
            ->join('service_invoice_details b', 'b.service_inv_id=a.voucher_no', 'left')
            ->join('product_service c', 'c.service_id=b.service_id', 'left')
            ->join('bank_add d', 'd.bank_id=a.bank_id', 'left')
            ->join('bkash_add e', 'e.bkash_id=a.bkash_id', 'left')
            ->where('a.voucher_no', $invoice_id)
            ->order_by('b.id', 'asc')
            ->get()
            ->result_array();
    }

    // customer information 
    public function customer_info($customer_id)
    {
        return $this->db->select('*')
            ->from('customer_information')
            ->where('customer_id', $customer_id)
            ->get()
            ->row();
    }

    // tax for service information
    public function service_invoice_taxinfo($invoice_id)
    {
        return $this->db->select('*')
            ->from('tax_collection')
            ->where('relation_id', $invoice_id)
            ->get()
            ->result_array();
    }

    public function invoice_update()
    {


        $tablecolumn = $this->db->list_fields('tax_collection');
        $num_column = count($tablecolumn) - 4;
        $invoice_id = $this->input->post('invoice_id', true);
        $employee = $this->input->post('employee_id', true);
        $employee_id = implode(',', $employee);
        $createby = $this->session->userdata('user_id');
        $createdate = date('Y-m-d H:i:s');
        $bank_id = $this->input->post('bank_id_m', TRUE);
        if (!empty($bank_id)) {
            $bankname = $this->db->select('bank_name')->from('bank_add')->where('bank_id', $bank_id)->get()->row()->bank_name;

            $bankcoaid = $this->db->select('HeadCode')->from('acc_coa')->where('HeadName', $bankname)->get()->row()->HeadCode;
        } else {
            $bankcoaid = '';
        }

        $bkash_id = $this->input->post('bkash_id', TRUE);
        if (!empty($bkash_id)) {
            $bkashname = $this->db->select('bkash_no')->from('bkash_add')->where('bkash_id', $bkash_id)->get()->row()->bkash_no;

            $bkashcoaid = $this->db->select('HeadCode')->from('acc_coa')->where('HeadName', $bkashname)->get()->row()->HeadCode;
        } else {
            $bkashcoaid = '';
        }
        if (!empty($invoice_id)) {
            //Customer Ledger
            // Account Transaction
            $this->db->where('VNo', $invoice_id);
            $this->db->delete('acc_transaction');
            //Service Invoice Details

            $this->db->where('service_inv_id', $invoice_id);
            $this->db->delete('service_invoice_details');
            //tax_collection
            $this->db->where('relation_id', $invoice_id);
            $this->db->delete('tax_collection');
        }

        if (($this->input->post('customer_name_others', true) == null) && ($this->input->post('customer_id', true) == null) && ($this->input->post('customer_name', true) == null)) {
            $this->session->set_userdata(array('error_message' => display('please_select_customer')));
            redirect(base_url() . 'Cservice/service_invoice_form');
        }
        if ($this->input->post('employee_id') == null) {
            $this->session->set_userdata(array('error_message' => display('please_select_employee')));
            redirect(base_url() . 'Cservice/service_invoice_form');
        }


        if (($this->input->post('customer_id') == null) && ($this->input->post('customer_name') == null)) {
            $customer_id = $this->auth->generator(15);
            //Customer  basic information adding.
            $coa = $this->headcode();
            if ($coa->HeadCode != NULL) {
                $headcode = $coa->HeadCode + 1;
            } else {
                $headcode = "102030101";
            }
            $c_acc = $customer_id . '-' . $this->input->post('customer_name_others', true);
            $createby = $this->session->userdata('user_id');
            $createdate = date('Y-m-d H:i:s');
            $data = array(
                'customer_id'      => $customer_id,
                'customer_name'    => $this->input->post('customer_name_others', true),
                'customer_address' => $this->input->post('customer_name_others_address', true),
                'customer_mobile'  => $this->input->post('customer_mobile', true),
                'customer_email'   => "",
                'status'           => 2
            );
            $customer_coa = [
                'HeadCode'         => $headcode,
                'HeadName'         => $c_acc,
                'PHeadName'        => 'Customer Receivable',
                'HeadLevel'        => '4',
                'IsActive'         => '1',
                'IsTransaction'    => '1',
                'IsGL'             => '0',
                'HeadType'         => 'A',
                'IsBudget'         => '0',
                'IsDepreciation'   => '0',
                'DepreciationRate' => '0',
                'CreateBy'         => $createby,
                'CreateDate'       => $createdate,
            ];

            $this->db->insert('customer_information', $data);
            $this->db->insert('acc_coa', $customer_coa);
            $this->db->select('*');
            $this->db->from('customer_information');
            $query = $this->db->get();
            foreach ($query->result() as $row) {
                $json_customer[] = array('label' => $row->customer_name, 'value' => $row->customer_id);
            }
            $cache_file = './my-assets/js/admin_js/json/customer.json';
            $customerList = json_encode($json_customer);
            file_put_contents($cache_file, $customerList);


            //Previous balance adding -> Sending to customer model to adjust the data.
            $this->Customers->previous_balance_add(0, $customer_id);
        } else {
            $customer_id = $this->input->post('customer_id');
        }


        //Full or partial Payment record.
        $paid_amount = $this->input->post('paid_amount', true);
        if ($this->input->post('paid_amount', true) >= 0) {

            $this->db->set('status', '1');
            $this->db->where('customer_id', $customer_id);

            $this->db->update('customer_information');

            $transection_id = $this->auth->generator(15);





            // Inserting for Accounts adjustment.
            ############ default table :: customer_payment :: inflow_92mizdldrv #################
        }

        //Data inserting into invoice table
        $datainv = array(
            'employee_id'     => $employee_id,
            'customer_id'     => $customer_id,
            'date'            => (!empty($this->input->post('invoice_date', true)) ? $this->input->post('invoice_date', true) : date('Y-m-d')),
            'total_amount'    => $this->input->post('grand_total_price', true),
            'total_tax'       => $this->input->post('total_tax_amount', true),
            'voucher_no'      => $invoice_id,
            'details'         => (!empty($this->input->post('inva_details', true)) ? $this->input->post('inva_details', true) : 'Service Invoice'),
            'invoice_discount' => $this->input->post('invoice_discount', true),
            'total_discount'  => $this->input->post('total_discount', true),
            'shipping_cost'   => $this->input->post('shipping_cost', true),
            'paid_amount'     => $this->input->post('paid_amount', true),
            'due_amount'      => $this->input->post('due_amount', true),
            'previous'        => $this->input->post('previous', true),
            'paytype'        => $this->input->post('paytype', true),
            'bank_id'        => $this->input->post('bank_id_m', true),
            'bkash_id'        => $this->input->post('bkash_id', true),


        );

        $this->db->where('voucher_no', $invoice_id);
        $this->db->update('service_invoice', $datainv);


        $cusifo = $this->db->select('*')->from('customer_information')->where('customer_id', $customer_id)->get()->row();
        $headn = $customer_id . '-' . $cusifo->customer_name;
        $coainfo = $this->db->select('*')->from('acc_coa')->where('HeadName', $headn)->get()->row();
        $customer_headcode = $coainfo->HeadCode;
        // Cash in Hand debit
        $cc = array(
            'VNo'            =>  $invoice_id,
            'Vtype'          =>  'SERVICE',
            'VDate'          =>  $createdate,
            'COAID'          =>  1020101,
            'Narration'      =>  'Cash in Hand For SERVICE No' . $invoice_id,
            'Debit'          =>  $this->input->post('paid_amount', true),
            'Credit'         =>  0,
            'IsPosted'       =>  1,
            'CreateBy'       =>  $createby,
            'CreateDate'     =>  $createdate,
            'IsAppove'       =>  1
        );
        $bankc = array(
            'VNo'            =>  $invoice_id,
            'Vtype'          =>  'SERVICE',
            'VDate'          =>  $createdate,
            'COAID'          =>  $bankcoaid,
            'Narration'      =>  'Cash in bank For SERVICE No ' . $invoice_id,
            'Debit'          =>  $this->input->post('paid_amount', true),
            'Credit'         =>  0,
            'IsPosted'       =>  1,
            'CreateBy'       =>  $createby,
            'CreateDate'     =>  $createdate,
            'IsAppove'       =>  1,

        );

        $bkashc = array(
            'VNo'            =>  $invoice_id,
            'Vtype'          =>  'INVOICE',
            'VDate'          =>  $createdate,
            'COAID'          =>  $bkashcoaid,
            'Narration'      =>   'Cash in bkash For SERVICE No ' . $invoice_id,
            'Debit'          =>  $this->input->post('paid_amount', true),
            'Credit'         =>  0,
            'IsPosted'       =>  1,
            'CreateBy'       =>  $createby,
            'CreateDate'     =>  $createdate,
            'IsAppove'       =>  1,

        );

        //service income
        $service_income = array(
            'VNo'            =>  $invoice_id,
            'Vtype'          =>  'SERVICE',
            'VDate'          =>  $createdate,
            'COAID'          =>  304,
            'Narration'      =>  'Service Income For SERVICE No' . $invoice_id,
            'Debit'          =>  0,
            'Credit'         =>  $this->input->post('grand_total_price', true),
            'IsPosted'       =>  1,
            'CreateBy'       =>  $createby,
            'CreateDate'     =>  $createdate,
            'IsAppove'       =>  1
        );

        $this->db->insert('acc_transaction', $service_income);

        //Customer debit for service Value
        $cosdr = array(
            'VNo'            =>  $invoice_id,
            'Vtype'          =>  'SERVICE',
            'VDate'          =>  $createdate,
            'COAID'          =>  $customer_headcode,
            'Narration'      =>  'Customer debit For service No' . $invoice_id,
            'Debit'          =>  $this->input->post('grand_total_price', true),
            'Credit'         =>  0,
            'IsPosted'       => 1,
            'CreateBy'       => $createby,
            'CreateDate'     => $createdate,
            'IsAppove'       => 1
        );
        $this->db->insert('acc_transaction', $cosdr);

        ///Customer credit for Paid Amount
        $coscr = array(
            'VNo'            =>  $invoice_id,
            'Vtype'          =>  'SERVICE',
            'VDate'          =>  $createdate,
            'COAID'          =>  $customer_headcode,
            'Narration'      =>  'Customer credit for Paid Amount For Service No' . $invoice_id,
            'Debit'          =>  0,
            'Credit'         =>  $this->input->post('paid_amount', true),
            'IsPosted'       => 1,
            'CreateBy'       => $createby,
            'CreateDate'     => $createdate,
            'IsAppove'       => 1
        );
        if (!empty($this->input->post('paid_amount', true))) {
            $this->db->insert('acc_transaction', $coscr);
            if ($this->input->post('paytype', TRUE) == 1) {
                $this->db->insert('acc_transaction', $cc);
            }
            if ($this->input->post('paytype', TRUE) == 4) {
                $this->db->insert('acc_transaction', $bankc);
            }
            if ($this->input->post('paytype', TRUE) == 3) {
                $this->db->insert('acc_transaction', $bkashc);
            }
        }

        $quantity            = $this->input->post('product_quantity', true);
        $rate                = $this->input->post('product_rate', true);
        $serv_id             = $this->input->post('service_id', true);
        $total_amount        = $this->input->post('total_price', true);
        $discount_rate       = $this->input->post('discount_amount', true);
        $discount_per        = $this->input->post('discount', true);
        $tax_amount          = $this->input->post('tax', true);
        $invoice_description = $this->input->post('desc', true);

        for ($i = 0, $n   = count($serv_id); $i < $n; $i++) {
            $service_qty  = $quantity[$i];
            $product_rate = $rate[$i];
            $service_id   = $serv_id[$i];
            $total_price  = $total_amount[$i];
            $disper       = $discount_per[$i];
            $disamnt      = $discount_rate[$i];

            $service_details = array(
                'service_inv_id'     => $invoice_id,
                'service_id'         => $service_id,
                'qty'                => $service_qty,
                'charge'             => $product_rate,
                'discount'           => $disper,
                'discount_amount'    => $disamnt,
                'total'              => $total_price,
            );
            if (!empty($quantity)) {
                $this->db->insert('service_invoice_details', $service_details);
            }
        }
        for ($j = 0; $j < $num_column; $j++) {
            $taxfield = 'tax' . $j;
            $taxvalue = 'total_tax' . $j;
            $taxdata[$taxfield] = $this->input->post($taxvalue);
        }
        $taxdata['customer_id'] = $customer_id;
        $taxdata['date']        = (!empty($this->input->post('invoice_date')) ? $this->input->post('invoice_date') : date('Y-m-d'));
        $taxdata['relation_id'] = $invoice_id;
        $this->db->insert('tax_collection', $taxdata);

        $message = 'Mr.' . $cusifo->customer_name . ',
        ' . 'Your Service Charge ' . $this->input->post('grand_total_price') . ' You have paid .' . $this->input->post('paid_amount');
        if ($config_data->isservice == 1) {
            $this->smsgateway->send([
                'apiProvider' => 'nexmo',
                'username'    => $config_data->api_key,
                'password'    => $config_data->api_secret,
                'from'        => $config_data->from,
                'to'          => $cusifo->customer_mobile,
                'message'     => $message
            ]);
        }
        return $invoice_id;
    }



    public function employees()
    {
        $this->db->select('*');
        $this->db->from('employee_history');
        $query = $this->db->get();
        $data = $query->result();

        $list[''] = 'Select Employee';
        if (!empty($data)) {
            foreach ($data as $value) {
                $list[$value->id] = $value->first_name . ' ' . $value->last_name;
            }
        }
        return $list;
    }
}
