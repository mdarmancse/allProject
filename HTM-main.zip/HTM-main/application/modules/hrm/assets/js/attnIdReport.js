'use strict';
$("#start_date").datepicker({ dateFormat:'Y-m-d' });
$("#end_date").datepicker({ dateFormat:'yy-mm-dd' });