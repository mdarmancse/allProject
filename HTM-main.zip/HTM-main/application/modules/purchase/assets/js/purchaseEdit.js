'use strict';
var row = $("#purchaseTable tbody tr").length;
var count = row+1;
var limits = 500;