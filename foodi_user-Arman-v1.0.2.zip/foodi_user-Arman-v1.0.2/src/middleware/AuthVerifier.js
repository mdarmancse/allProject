import jwt from "jsonwebtoken";
import { isTokenRevoked } from "../utility/functions";

const optional_routes = [
  "/api/v1/user/subscriptionType/get",
  "/api/v1/user/check_login",
];

export default async (req, res, next) => {
  try {
    console.log("req :", req.originalUrl);
    console.log("reqa :", optional_routes.includes(req.originalUrl));

    const bearerHeader = req.headers["authorization"];
    let token_status = false;
    if (typeof bearerHeader !== "undefined") {
      const bearer = bearerHeader.split(" ");
      const bearerToken = bearer[1];

      // Decode the token to access its payload
      const decodedToken = jwt.decode(bearerToken);

      if (decodedToken && decodedToken.exp) {
        // Calculate the remaining days until the token expires
        const expiryTimestamp = decodedToken.exp;
        const currentTimestamp = Math.floor(Date.now() / 1000);
        const remainingSeconds = expiryTimestamp - currentTimestamp;
        const remainingDays = Math.ceil(remainingSeconds / (60 * 60 * 24));
        //const remainingDays = 0;
        token_status = remainingDays > 0;
      }

      try {
        const decoded = jwt.verify(bearerToken, "foodi@#$2020");
        const isRevoked = await isTokenRevoked(bearerToken);

        if (isRevoked) {
          return res.status(401).json({
            status: -1,
            msg: "Your session has expired. Please log in again.",
          });
        }

        const id = decoded.data.id;
        req.body.id = id;
        req.body.token_status = token_status;
        next();
      } catch (err) {
        res.status(401).json({ status: "Unauthorized" });
      }
    } else {
      if (optional_routes.includes(req.originalUrl)) {
        next();
      } else {
        res.status(403).json({ status: "Access Denied" });
      }
    }
  } catch (err) {
    res.status(500).json({ status: "Server Error" });
  }
};
