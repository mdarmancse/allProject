import mongoose from "mongoose";

const DataSchema = new mongoose.Schema(
  {
    _id: {
      type: String,
      //default: () => uuidv4().replace(/\-/g, ""),
    },
    name: { type: String },
    subscription_fee: { type: Number, default: 0 },
    subscribe_for_in_days: { type: Number, default: 0 },
    details: [],
    is_premium: { type: Boolean, default: false },
    is_active: { type: Boolean, default: true },
    created_at: { type: Date, default: null },
    created_by: { type: String, default: null },
    updated_at: { type: Date, default: null },
    updated_by: { type: String, default: null },
  },
  {
    collection: "subscription_types",
    //  timestamps: true,
    versionKey: false,
  }
);
DataSchema.statics.getSubscriptionType = async function () {
  try {
    const data = await this.aggregate([
      { $match: { is_premium: true } },

      {
        $project: {
          _id: 0,
          id: "$_id",
          name: "$name",
          price: "$subscription_fee",
          details: "$details",
        },
      },
    ]);
    return data;
  } catch (err) {
    console.log("err :", err);
    return false;
  }
};
const subscription_types = mongoose.model("subscription_types", DataSchema);
export default subscription_types;
