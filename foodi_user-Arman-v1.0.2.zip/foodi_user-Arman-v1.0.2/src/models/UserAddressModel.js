import mongoose from "mongoose";
import { v4 as uuidv4 } from "uuid";
import moment from "moment";
import { SYSTEM_TIMEZONE } from "../consts/defaults";
const UserAddressSchema = new mongoose.Schema(
  {
    _id: {
      type: String,
      default: () => uuidv4(),
    },
    user: {
      type: String,
      required: true,
    },
    label: {
      type: String,
      required: true,
    },
    lat_long: [
      {
        type: {
          type: String,
          default: "Point",
          enum: ["Point"],
        },
        coordinates: [],
      },
    ],
    street: {
      type: String,
      required: true,
    },
    apartment_name: {
      type: String,
      default: null,
    },
    delivery_instruction: {
      type: String,
    },
    is_active: { type: Boolean, default: true },
    created_at: {
      type: Date,
      default: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
    },
    created_by: { type: String, default: null },
    updated_at: {
      type: Date,
      default: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
    },
    updated_by: { type: String, default: null },
  },
  {
    collection: "user_addresses",
    //  timestamps: true,
    versionKey: false,
  }
);

const UserAddressModel = mongoose.model("user_addresses", UserAddressSchema);
export default UserAddressModel;
