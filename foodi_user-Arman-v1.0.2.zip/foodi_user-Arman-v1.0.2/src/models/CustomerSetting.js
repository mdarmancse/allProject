import mongoose from "mongoose";
import { v4 as uuidv4 } from "uuid";
import moment from "moment";
import { SYSTEM_TIMEZONE } from "../consts/defaults";
const CustomerSettingSchema = new mongoose.Schema(
  {
    _id: {
      type: String,
      default: () => uuidv4(),
    },
    customer_id: { type: String },
    language: { type: String, default: "en" },
    rcv_push_notification: { type: Boolean, default: true },
    rcv_offers_by_email: { type: Boolean, default: true },
    show_floating_icon: { type: Boolean, default: true },
    is_active: { type: Boolean, default: true },
    created_at: {
      type: Date,
      default: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
    },
    created_by: { type: String, default: null },
    updated_at: {
      type: Date,
      default: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
    },
    updated_by: { type: String, default: null },
  },
  {
    collection: "customer_settings",
    // timestamps: true,
    versionKey: false,
  }
);

const CustomerSetting = mongoose.model(
  "customer_settings",
  CustomerSettingSchema
);
export default CustomerSetting;
