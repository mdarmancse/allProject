import mongoose from "mongoose";

const DataSchema = new mongoose.Schema(
  {
    _id: {
      type: String,
    },
    customer_id: { type: String, default: null },
    notification_id: { type: String, default: null },
    device_id: { type: String, default: null },
    is_active: { type: Number, default: true },
    created_at: { type: Date, default: null },
    created_by: { type: String, default: null },
    updated_at: { type: Date, default: null },
    updated_by: { type: String, default: null },
  },
  {
    collection: "customer_notifications",
    //  timestamps: true,
    versionKey: false,
  }
);

const BrancAttributes = mongoose.model("customer_notifications", DataSchema);
export default BrancAttributes;
