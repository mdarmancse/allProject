import { Schema, model } from "mongoose";
import { v4 as uuidv4 } from "uuid";
const date_now = new Date();
// const user_id = uuidv4().replace(/\-/g, "");
const user_id = () => uuidv4();
import moment from "moment";
import { SYSTEM_TIMEZONE } from "../consts/defaults";
const DataSchema = Schema(
  {
    _id: {
      type: String,
      default: user_id,
    },
    firstName: { type: String, default: null },
    email: { type: String, default: null },
    lastName: { type: String, default: null },
    subscription_type_id: { type: String, default: null },
    mobile: { type: String, default: null },
    image: { type: String, default: null },
    reward_level: { type: String, default: null },
    subscription_expire_date_time: { type: Date, default: null },
    otp: { type: Number, default: null },
    otp_expire_time: { type: Date, default: null },
    device_id: { type: String, default: null },
    is_verified: { type: Number, default: 0 },
    is_new: { type: Number, default: 1 },
    is_active: { type: Boolean, default: true },
    created_at: {
      type: Date,
      default: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
    },
    created_by: { type: String, default: null },
    updated_at: {
      type: Date,
      default: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
    },
    updated_by: { type: String, default: null },
    signupBy: { type: String, default: null },
  },
  {
    versionKey: false,
  }
);

const UserModel = model("users", DataSchema);
export default UserModel;
