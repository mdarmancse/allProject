import mongoose from "mongoose";
import { v4 as uuidv4 } from "uuid";

const DataSchema = new mongoose.Schema(
  {
    _id: {
      type: String,
      default: () => uuidv4(),
    },
    subscription_type_id: { type: String, default: null },
    customer_id: { type: String, default: null },
    transaction_id: { type: String, default: null },
    amount: { type: Number, default: null },
    bkash_token: { type: String, default: null },
    bkash_payment_id: { type: String, default: null },
    is_active: { type: Boolean, default: true },
    created_at: { type: Date, default: Date.now() },
    created_by: { type: String, default: null },
    updated_at: { type: Date, default: Date.now() },
    updated_by: { type: String, default: null },
  },
  {
    collection: "subscription_payment",
    //  timestamps: true,
    versionKey: false,
  }
);

const SubscriptionPayment = mongoose.model("subscription_payment", DataSchema);
export default SubscriptionPayment;
