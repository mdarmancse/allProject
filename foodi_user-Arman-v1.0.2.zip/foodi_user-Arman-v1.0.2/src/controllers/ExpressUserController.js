import { config } from "dotenv";
import SubscriptionTypeModel from "../models/SubscriptionTypeModel";

config();

const cms_queue = process.env.CMS_QUEUE_NAME;

export async function getSubscriptionType(req, res, next) {
  try {
    let body = req.body;
    let returnData, cacheResults, mongoResults;
    let isCached = false;
    let isMongo = false;
    let isSql = false;
    const user_id = body.id;
    // cacheResults=await redis_get('user_addresses',user_id)
    if (cacheResults) {
      isCached = true;
      returnData = JSON.parse(cacheResults);
    } else {
      mongoResults = await SubscriptionTypeModel.getSubscriptionType();
      returnData = mongoResults;
      isMongo = true;
    }

    if (returnData.length > 0) {
      return res.json({
        status: 1,
        fromCache: isCached,
        fromMonngo: isMongo,
        fromSql: isSql,
        data: returnData,
      });
    } else {
      return res.json({
        status: -1,
        msg: "Data not found",
      });
    }
  } catch (err) {
    console.error(err);
    return res.status(500).json({ status: -1, msg: "Server error" });
  }
}
