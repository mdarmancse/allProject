import UserModel from "../models/UserModel";
import RevokedTokenModel from "../models/RevokedToken";
import { initOTP, generateToken } from "../utility/functions";
import { config } from "dotenv";
import UserAddressModel from "../models/UserAddressModel";
import CustomerSetting from "../models/CustomerSetting";
import crud_helper from "../helper/common/crud_helper";
import { Send_Central, Send_Queue } from "../helper/common/RMQ";
import {
  updateUserBasicRules,
  userBasicRules,
  validator,
} from "../helper/validator";
import moment from "moment/moment";
import ListService from "../helper/common/ListService";
import https from "http";
config();
import Validator from "validatorjs";
import SubscriptionTypeModel from "../models/SubscriptionTypeModel";

//cms_queu
const cms_queue = process.env.CMS_QUEUE_NAME;
const { v4: uuidv4 } = require("uuid");
import { OAuth2Client } from "google-auth-library";
const client = new OAuth2Client(process.env.GOOGLE_CLIENT_ID); // google login controller
//import { redis_delete, redis_get, redis_set } from "../helper/redis";

//Registration
export async function registration(req, res, next) {
  let rules = userBasicRules;
  let error;
  let body = req.body;
  await validator(body, rules, {}, (err) => {
    error = err;
  });
  if (error) {
    return res.json({
      status: -1,
      data: error,
      msg: "Validation error.",
    });
  }

  let results = {};
  // let id = body.id;
  // console.log("body",body);
  try {
    let user_data = {};
    let update = {
      is_new: 0,
      firstName: body.firstName,
      lastName: body.lastName,
      email: body.email,
    };
    user_data = await UserModel.findOneAndUpdate({ _id: body.id }, update, {
      returnOriginal: false,
    });
    if (user_data) {
      let sendQ = await Send_Queue(
        cms_queue,
        "user_queue",
        user_data,
        "customer",
        "edit"
      );

      console.log("sendQ", sendQ);
    }
    //  if (user_data) await Send_Central(user_data, "customer", "edit");

    // const redis_user_data = await redis_get('users', user_data._id);
    // if (redis_user_data) {
    //     let redis_user = JSON.parse(redis_user_data);
    //     if (!Array.isArray(redis_user)) {
    //         redis_user = [redis_user]; // convert non-array data to array
    //     }
    //     redis_user.push(user_data);
    //     await redis_set('users', user_data._id, redis_user);
    // } else {
    //     await redis_set('users', user_data._id, [user_data]); // create new array if no data exists
    // }

    //  await redis_set('users',user_data._id, user_data)

    let is_new = user_data.is_new;
    user_data = {
      id: user_data._id,
      mobile: user_data.mobile,
      firstName: user_data.firstName,
      lastName: user_data.lastName,
      email: user_data.email,
    };
    // let returnData = await UserModel.updateOne({ _id: body.id }, body);
    // let user_data = await DetailsByIDService(body,UserModel)
    //  let send_data=await Send_Central(body,'customer','edit')
    results = {
      status: 0,
      msg: "Successfully Updated",
      is_new: is_new,
      user_data: user_data,
      // send_data: send_data,
    };
    return res.status(200).json(results);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ status: -1, msg: "Server error" });
  }
}

//Login
export async function login(req, res, next) {
  try {
    // TODO: Fetch  subs type id
    let body = req.body;
    let subscription_details;
    const subscription_type_id = "3fa85f64-5717-4562-b3fc-2c963f66afa6";
    const rules = {
      mobile: "required|size:11",
    };
    const added_minute = 1;
    const plus_one_minute = moment(new Date()).add(added_minute, "m").toDate();

    let error;
    await validator(body, rules, {}, (err) => {
      error = err;
    });

    if (error) {
      return res.json({
        status: -1,
        data: error,
        msg: "Validation error.",
      });
    }

    let number = body.mobile;
    let otp = 0;
    while (!(otp > 100000 && otp < 999999)) {
      otp = Math.floor(Math.random() * 1000000);
      console.log("otp :", otp);
    }

    const sendOTP = await initOTP(number, otp);
    if (!sendOTP) {
      return res.json({
        msg: "Couldn't initiate otp",
        status: -1,
      });
    }
    const user_data = await UserModel.findOne({
      mobile: number,
    });
    if (!user_data) {
      const body = {
        mobile: number,
        otp: otp,
        otp_expire_time: plus_one_minute,
        subscription_type_id: subscription_type_id,
        is_active: true,
      };
      const new_user = await UserModel.create(body);
      if (new_user) {
        await Send_Queue(cms_queue, "user_queue", new_user, "customer", "add");
      }
      //   await Send_Central(new_user, "customer", "add");
      //   await redis_set('users', new_user._id, new_user);

      //console.log("send_data",send_data)

      if (new_user) {
        return res.json({
          msg: "Otp sent to phone number",
          data: {
            mobile: new_user.mobile,
            otp_expire_in_seconds: added_minute * 60,
            is_new: new_user.is_new,
            isVerified: new_user.isVerified ? new_user.isVerified : 0,
            status: new_user.is_active,
            //send_data: send_data,
          },
          status: 0,
        });
      }
    } else {
      const update_otp = await UserModel.findOneAndUpdate(
        {
          _id: user_data._id,
        },
        {
          $set: {
            otp: otp,
            otp_expire_time: plus_one_minute,
          },
        },
        {
          returnOriginal: false,
        }
      );
      // if (update_otp) {
      //
      //     await Send_Queue(
      //         cms_queue,
      //         "user_queue",
      //         update_otp,
      //         "customer",
      //         "edit"
      //     );
      // }
      //await Send_Central(update_otp, "customer", "edit");

      if (update_otp)
        return res.status(200).json({
          msg: "Otp sent to phone number",
          data: {
            mobile: user_data.mobile,
            otp_expire_in_seconds: added_minute * 60,
            is_new: user_data.is_new,
            isVerified: user_data.isVerified ? user_data.isVerified : 0,
            status: user_data.is_active,
          },
          status: 0,
        });
    }
  } catch (err) {
    console.error("ERROR", err.toString());
    return res
      .status(500)
      .json({ status: -1, msg: "Server error", error: err.toString() });
  }
}

export async function checkLogin(req, res, next) {
  try {
    let body = req.body;
    let subscription_details,
      subscription_type_id,
      subscription_type_name,
      is_premium_user;
    const rules = {
      mobile: "required|size:11",
    };
    let error;
    await validator(body, rules, {}, (err) => {
      error = err;
    });

    if (error) {
      return res.json({
        status: -1,
        data: error,
        msg: "Validation error.",
      });
    }

    let number = body.mobile;

    const user_data = await UserModel.findOne({
      mobile: number,
    });
    if (user_data) {
      if (user_data.subscription_type_id) {
        subscription_details = await SubscriptionTypeModel.findById(
          user_data.subscription_type_id,
          { _id: 1, name: 1, is_premium: 1 }
        );
        is_premium_user = subscription_details.is_premium;
        subscription_type_id = user_data.subscription_type_id;
        subscription_type_name = subscription_details.name;
      }

      return res.status(200).json({
        status: 1,
        data: {
          _id: user_data._id,
          active_status: user_data.is_active,
          token_session: body.token_status,
          subscription_type_id: subscription_type_id
            ? subscription_type_id
            : null,
          is_premium_user: is_premium_user ? is_premium_user : false,
          subscription_type_name: subscription_type_name
            ? subscription_type_name
            : "Not Found",
        },
      });
    } else {
      return res.status(200).json({
        status: -1,
        msg: "User not found",
      });
    }
  } catch (err) {
    console.error("ERROR", err.toString());
    return res
      .status(500)
      .json({ status: -1, msg: "Server error", error: err.toString() });
  }
}
//
// export async function login(req, res, next) {
//     try {
//         let body = req.body;
//         const subscription_type_id = "3fa85f64-5717-4562-b3fc-2c963f66afa6";
//         const rules = {
//             mobile: "required|size:11",
//         };
//         const added_minute = 1;
//         const plus_one_minute = moment(new Date()).add(added_minute, "m").toDate();
//
//         await validator(body, rules, {});
//
//         let number = body.mobile;
//         let otp = 0;
//         while (!(otp > 100000 && otp < 999999)) {
//             otp = Math.floor(Math.random() * 1000000);
//             console.log("otp :", otp);
//         }
//
//         const sendOTP = await initOTP(number, otp);
//         if (!sendOTP) {
//             return res.json({
//                 msg: "Couldn't initiate otp",
//                 status: -1,
//             });
//         }
//
//         const user_data = await getUserData(number);
//
//         if (!user_data) {
//             const body = {
//                 mobile: number,
//                 otp: otp,
//                 otp_expire_time: plus_one_minute,
//                 subscription_type_id: subscription_type_id,
//                 status: 1,
//             };
//             const new_user = await createUser(body);
//             Send_Central(new_user, "customer", "add");
//
//             if (new_user) {
//                 return res.json({
//                     msg: "Otp sent to phone number",
//                     data: {
//                         mobile: new_user.mobile,
//                         otp_expire_in_seconds: added_minute * 60,
//                         is_new: new_user.is_new,
//                         isVerified: new_user.isVerified ? new_user.isVerified : 0,
//                         status: new_user.status,
//                     },
//                     status: 0,
//                 });
//             }
//         } else {
//             const update_otp = await updateUserOTP(user_data._id, otp, plus_one_minute);
//             Send_Central(update_otp, "customer", "edit");
//
//             if (update_otp) {
//                 return res.status(200).json({
//                     msg: "Otp sent to phone number",
//                     data: {
//                         mobile: user_data.mobile,
//                         otp_expire_in_seconds: added_minute * 60,
//                         is_new: user_data.is_new,
//                         isVerified: user_data.isVerified ? user_data.isVerified : 0,
//                         status: user_data.status,
//                     },
//                     status: 0,
//                 });
//             }
//         }
//
//       //  res.status(500).json({ status: -1, msg: "Server error" });
//     } catch (err) {
//         console.error(err);
//         return res.status(500).json({ status: -1, msg: "Server error",error:err.toString() });
//     }
// }
//
// async function getUserData(number) {
//     const user_data = await UserModel.findOne({
//         mobile: number,
//     });
//
//     return user_data;
// }
//
// async function createUser(body) {
//     const new_user = await UserModel.create(body);
//     // await redis_set('users', new_user._id, new_user);
//
//     return new_user;
// }
//
// async function updateUserOTP(user_id, otp, plus_one_minute) {
//     const update_otp = await UserModel.findOneAndUpdate(
//         { _id: user_id },
//         { $set: { otp: otp, otp_expire_time: plus_one_minute } },
//         { new: true }
//     );
//     return update_otp;
// }

// Verify OTP
export async function verifyOTP(req, res, next) {
  try {
    let body = req.body;
    let subscription_details,
      subscription_type_id,
      subscription_type_name,
      is_premium_user;
    const rules = {
      mobile: "required|size:11",
      otp: "required",
    };

    let error;
    await validator(body, rules, {}, (err) => {
      error = err;
    });

    if (error) {
      return res.status(200).json({
        status: -1,
        data: error,
        msg: "Validation error.",
      });
    }
    const mobile = body.mobile;
    const otp = body.otp;
    const user_data = await UserModel.findOne({
      mobile: mobile,
    });

    if (user_data) {
      let user_otp = user_data.otp;

      let is_otp_timed_out = moment(user_data.otp_expire_time).isAfter(
        new Date()
      );

      if (!is_otp_timed_out) {
        return res.status(200).json({
          msg: "OTP timed out. Please login again.",
          status: -1,
        });
      }

      if (otp == user_otp) {
        const update_user = await UserModel.findOneAndUpdate(
          {
            mobile: mobile,
          },
          {
            $set: {
              is_verified: 1,
              device_id: body.device_id,
            },
          },
          { returnOriginal: false }
        );
        // await redis_set('users', update_user._id, update_user);
        if (update_user) {
          if (update_user.subscription_type_id) {
            subscription_details = await SubscriptionTypeModel.findById(
              update_user.subscription_type_id,
              { _id: 1, name: 1, is_premium: 1 }
            );
            is_premium_user = subscription_details.is_premium;
            subscription_type_id = update_user.subscription_type_id;
            subscription_type_name = subscription_details.name;
          }

          await Send_Queue(
            cms_queue,
            "user_queue",
            update_user,
            "customer",
            "edit"
          );
          //await Send_Central(update_user, "customer", "edit");

          let uu_data = {
            token: await generateToken({
              id: update_user._id,
            }),
            _id: update_user._id,
            mobile: update_user.mobile,
            is_new: update_user.is_new,
            isVerified: update_user.isVerified,
            subscription_type_id: subscription_type_id
              ? subscription_type_id
              : null,
            is_premium_user: is_premium_user ? is_premium_user : false,
            subscription_type_name: subscription_type_name
              ? subscription_type_name
              : "Not Found",
            active_status: update_user.is_active,
          };
          update_user.is_new == 0
            ? (uu_data.firstName = update_user.firstName)
            : "";
          update_user.is_new == 0
            ? (uu_data.lastName = update_user.lastName)
            : "";
          return res.status(200).json({
            msg: "Verification Successful",
            data: uu_data,
            status: 0,
          });
        } else {
          return res.status(200).json({
            msg: "Something went wrong",
            status: -1,
          });
        }
      } else {
        return res.status(200).json({
          msg: "Wrong OTP",
          status: -1,
        });
      }
    } else {
      return res.status(200).json({
        msg: "User not found.",
        status: -1,
      });
    }
  } catch (err) {
    console.error(err);
    return res.status(500).json({ status: -1, msg: "Server error" });
  }
}

export async function address_add(req, res, next) {
  try {
    let body = req.body;
    const user_id = body.id;
    const rules = {
      // label: "required",
      // street: "required",
      // apartment_name: "required",
      lat: "required",
      long: "required",
    };

    const validators = new Validator(body, rules);
    if (validators.fails()) {
      const validationErrors = validators.errors.all();
      return res.status(200).json({
        status: -1,
        data: validationErrors,
        msg: "Validation error.",
      });
    }

    let error;
    await validator(body, rules, {}, (err) => {
      error = err;
    });

    if (error) {
      return res.json({
        status: -1,
        data: error,
        msg: "Validation error.",
      });
    }
    //
    const data = await UserAddressModel.findOneAndUpdate(
      { user: user_id, label: body.label },
      {
        user: user_id,
        label: body.label,
        street: body.street,
        apartment_name: body.apartment_name,
        delivery_instruction: body.delivery_instruction,
        lat_long: { type: "Point", coordinates: [body.long, body.lat] },
      },
      {
        upsert: true,
        new: true,
        setDefaultsOnInsert: true,
        rawResult: true,
      }
    );

    //  console.log("data :", data.value);
    // const address_data = await redis_get('user_addresses', user_id);
    //
    // if (address_data) {
    //     let addresses = JSON.parse(address_data);
    //     if (!Array.isArray(addresses)) {
    //         addresses = [addresses]; // convert non-array data to array
    //     }
    //     addresses.push(data);
    //      redis_set('user_addresses', user_id, addresses);
    // } else {
    //     await redis_set('user_addresses', user_id, [data]); // create new array if no data exists
    // }

    if (data.value) {
      if (data && data.lastErrorObject.updatedExisting == false) {
        await Send_Queue(cms_queue, "user_queue", data.value, "address", "add");
        //   await Send_Central(cart_update, "cart", "add");
        console.log("Document Inserted");
      }
      if (data && data.lastErrorObject.updatedExisting == true) {
        await Send_Queue(
          cms_queue,
          "user_queue",
          data.value,
          "address",
          "edit"
        );
        //await Send_Central(cart_update, "cart", "edit");
        console.log("Document Updated");
      }

      return res.status(200).json({
        status: 0,
        msg: "Successfully Added.",
        data: data.value,
      });
    } else {
      return res.status(200).json({
        status: -1,
        msg: "Failed to add data.",
      });
    }
  } catch (err) {
    console.error(err);
    return res.status(500).json({ status: -1, msg: "Server error" });
  }
}

export async function address_get(req, res, next) {
  try {
    let body = req.body;
    let returnData, cacheResults, mongoResults;
    let isCached = false;
    let isMongo = false;
    let isSql = false;
    const user_id = body.id;
    // cacheResults=await redis_get('user_addresses',user_id)
    if (cacheResults) {
      isCached = true;
      returnData = JSON.parse(cacheResults);
    } else {
      mongoResults = await crud_helper.findActive(
        UserAddressModel,
        { user: user_id },
        {
          _id: 1,
          label: 1,
          street: 1,
          apartment_name: 1,
          delivery_instruction: 1,
          lat: {
            $let: {
              vars: {
                ll: { $arrayElemAt: ["$lat_long.coordinates", 0] },
              },
              in: { $arrayElemAt: ["$$ll", 1] },
            },
          },
          long: {
            $let: {
              vars: {
                ll: { $arrayElemAt: ["$lat_long.coordinates", 0] },
              },
              in: { $arrayElemAt: ["$$ll", 0] },
            },
          },
        }
      );
      returnData = mongoResults;
      isMongo = true;
    }

    if (!returnData) {
      return res.json({
        status: -1,
        msg: "Data not found",
      });
    }

    return res.json({
      status: 0,
      msg: "Data found",
      fromCache: isCached,
      fromMonngo: isMongo,
      fromSql: isSql,
      data: returnData,
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ status: -1, msg: "Server error" });
  }
}

export async function address_edit(req, res, next) {
  try {
    let body = req.body;
    const user_id = body.id;
    const rules = {
      _id: "required",
      // label: "required",
      // street: "required",
      // apartment_name: "required",
      lat: "required",
      long: "required",
    };

    let error;
    validator(body, rules, {}, (err) => {
      error = err;
    });

    if (error) {
      return {
        status: -1,
        data: error,
        msg: "Validation error.",
      };
    }
    const data = await UserAddressModel.findOneAndUpdate(
      { _id: body._id, user: user_id },
      {
        $set: {
          label: body.label,
          street: body.street,
          apartment_name: body.apartment_name,
          delivery_instruction: body.delivery_instruction,
          lat_long: { type: "Point", coordinates: [body.long, body.lat] },
        },
      },
      {
        new: true,

        fields: {
          _id: 1,
          label: 1,
          street: 1,
          apartment_name: 1,
          is_active: 0,
          created_at: 0,
          created_by: 0,
          updated_at: 0,
          updated_by: 0,
          lat_long: 0,
          delivery_instruction: 1,
          lat: {
            $let: {
              vars: {
                ll: { $arrayElemAt: ["$lat_long.coordinates", 0] },
              },
              in: { $arrayElemAt: ["$$ll", 1] },
            },
          },
          long: {
            $let: {
              vars: {
                ll: { $arrayElemAt: ["$lat_long.coordinates", 0] },
              },
              in: { $arrayElemAt: ["$$ll", 0] },
            },
          },
        },
      }
    );

    if (data) {
      const send_data = await UserAddressModel.findOne({ _id: data._id });
      await Send_Queue(cms_queue, "user_queue", send_data, "address", "edit");
      // await Send_Central(send_data, "address", "edit");
    }

    //  const address_data = await redis_delete('user_addresses');
    //
    //  if (address_data) {
    //      let addresses = JSON.parse(address_data);
    //      if (!Array.isArray(addresses)) {
    //          addresses = [addresses]; // convert non-array data to array
    //      }
    //      addresses.push(data);
    //      await redis_set('user_addresses', user_id, addresses);
    //  } else {
    //      await redis_set('user_addresses', user_id, [data]); // create new array if no data exists
    //  }
    if (!data) {
      return res.json({
        status: -1,
        msg: "Failed to update data.",
      });
    }

    return res.json({
      status: 0,
      data: data,
      msg: "Successfully Updated.",
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ status: -1, msg: "Server error" });
  }
}

export async function address_delete(req, res, next) {
  try {
    let body = req.body;
    const user_id = body.id;
    const rules = {
      _id: "required",
    };

    let error;
    await validator(body, rules, {}, (err) => {
      error = err;
    });

    if (error) {
      return {
        status: -1,
        data: error,
        msg: "Validation error.",
      };
    }

    const data = await UserAddressModel.deleteOne({
      _id: body._id,
      user: user_id,
    });

    if (!data) {
      return res.json({
        status: -1,
        msg: "Failed to delete data.",
      });
    }
    await Send_Queue(
      cms_queue,
      "user_queue",
      { _id: body._id },
      "address",
      "delete"
    );
    // await Send_Central({ _id: body._id }, "address", "delete");

    return res.json({
      status: 0,
      msg: "Successfully deleted.",
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ status: -1, msg: "Server error" });
  }
}

export async function user_details(req, res) {
  try {
    const data = await UserModel.findById({ _id: req.body.id });
    if (!data) {
      return res.status(401).json({
        status: -1,
        msg: "Failed to fetch data.",
      });
    }

    return res.status(200).json({
      status: 0,
      data: data,
    });
  } catch (err) {
    return res.status(500).json({ status: -1, msg: "Server error" });
  }
}

//Customer Setting
export async function customer_setting(req, res, next) {
  try {
    let results = {};
    let body = req.body;
    let setting = {
      customer_id: body.id,
      language: body.language,
      rcv_push_notification: body.rcv_push_notification,
      rcv_offers_by_email: body.rcv_offers_by_email,
      show_floating_icon: body.show_floating_icon,
    };

    let user_data = await CustomerSetting.findOneAndUpdate(
      { customer_id: body.id },
      setting,
      {
        returnOriginal: false,
      }
    );

    if (!user_data) {
      const create_data = await CustomerSetting.create(setting);
      if (create_data) {
        await Send_Queue(
          cms_queue,
          "user_queue",
          create_data,
          "customer_ui_setting",
          "add"
        );
      }
      //await Send_Central(create_data, "customer_ui_setting", "add");
    } else {
      await Send_Queue(
        cms_queue,
        "user_queue",
        user_data,
        "customer_ui_setting",
        "edit"
      );
      //  await Send_Central(user_data, "customer_ui_setting", "edit");
    }

    results = {
      status: 0,
      msg: "Successfully Updated",
    };
    return res.status(200).json(results);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ status: -1, msg: "Server error" });
  }
}
export async function get_customer_setting(req, res, next) {
  try {
    let results = {};
    let body = req.body;
    let match = { $match: { customer_id: body.id } };
    let projection = {
      $project: {
        customer_id: 1,
        language: 1,
        rcv_push_notification: 1,
        rcv_offers_by_email: 1,
        show_floating_icon: 1,
      },
    };
    const data = await ListService(null, CustomerSetting, match, projection);

    if (data[0]) {
      results = {
        status: 0,
        data: data[0],
      };
    } else {
      results = {
        status: -1,
        msg: "No Data Found!",
      };
    }

    return res.json(results);
  } catch (err) {
    console.error(err);
    res.status(500).json({ status: -1, msg: "Server error" });
  }
}

export async function rider_assign(req, res, next) {
  try {
    let user_data,
      rest_data,
      us_data = {},
      rs_data = {};
    us_data = {
      body: {
        order_id: req.body.order_id,
        order_status: req.body.order_status,
        rider_id: req.body.rider_id,
        customer_name: req.body.customer_name,
        branch_name: req.body.branch_name,
      },
    };
    user_data = await Send_Queue(
      "main_rider_request",
      "user_queue",
      us_data,
      "RidersOrder",
      "socket_add"
    );
    rest_data = await Send_Queue(
      "main_restaurant_request",
      "user_queue",
      {
        _id: req.body.order_id,
        order_status: req.body.order_status,
      },
      "OrderModel",
      "edit"
    );
    console.log("user_data", user_data.data);

    res.status(200).json(user_data.data);
  } catch (err) {
    console.error(err);
    res.status(500).json({ status: -1, msg: "Server error" });
  }
}

export async function logout(req, res, next) {
  try {
    let bearerHeader = req.headers["authorization"];
    if (typeof bearerHeader !== "undefined") {
      const bearer = bearerHeader.split(" ");
      const bearerToken = bearer[1];
      const revokedToken = await RevokedTokenModel.create({
        token: bearerToken,
      });
      if (revokedToken) {
        await Send_Queue(
          "main_restaurant_request",
          "user_queue",
          revokedToken,
          "RevokedTokenModel",
          "add"
        );

        return res.status(200).json({
          status: 1,
          msg: "Logout Successful",
        });
      } else {
        return res.status(405).json({
          status: -1,
          msg: "Something went wrong..!",
        });
      }
    } else {
      return res.status(405).json({
        status: -1,
        msg: "Something went wrong..!",
      });
    }
  } catch (err) {
    return res.status(500).json({
      status: -1,
      msg: "Server Error.",
    });
  }
}

export async function login_with_google(req, res, next) {
  try {
    const {
      displayName,
      family_name,
      given_name,
      email,
      email_verified,
      photoURL,
      device_id,
    } = req.body;

    if (!family_name || !given_name || !email) {
      return res.status(400).json({ status: -1, msg: "Bad request" });
    }

    const findUser = await UserModel.findOne({ email: email });

    if (!findUser) {
      const createNewUser = {
        _id: uuidv4(),
        email: email,
        firstName: given_name,
        lastName: family_name,
        image: photoURL,
        device_id: device_id ? device_id : null,
        signupBy: "google",
      };
      const insertedUser = await UserModel.create(createNewUser);
      let uu_data = {
        token: await generateToken({
          id: insertedUser._id,
        }),
        _id: insertedUser._id,
        firstName: insertedUser.firstName,
        lastName: insertedUser.lastName,
        email: insertedUser.email,
        mobile_number: insertedUser.mobile_number,
        image: insertedUser.image,
        subscription_type_id: insertedUser.subscription_type_id,
        is_premium_user: insertedUser.is_premium_user,
        active_status: insertedUser.is_active,
        subscription_type_name: insertedUser.subscription_type_name,
      };

      return res.status(200).json({
        msg: "User login Successfully",
        data: uu_data,
        status: 0,
      });
    }

    if (findUser) {
      let uu_data = {
        token: await generateToken({
          id: findUser._id,
        }),
        _id: findUser._id,
        firstName: findUser.firstName,
        lastName: findUser.lastName,
        email: findUser.email,
        image: findUser.image,
        subscription_type_id: findUser.subscription_type_id,
        is_premium_user: findUser.is_premium_user,
        active_status: findUser.is_active,
        subscription_type_name: findUser.subscription_type_name,
      };

      return res.status(200).json({
        msg: "User login Successfully",
        data: uu_data,
        status: 0,
      });
    }
  } catch (err) {
    return res.status(500).json({ status: -1, msg: "Server error" });
  }
}

export async function login_with_facebook(req, res) {
  try {
    const { userID, accessToken, device_id } = req.body;
    if (!accessToken || !userID) {
      return res.status(401).json({ status: -1, msg: "Token/UserId required" });
    }
    const facebook_url = `https://graph.facebook.com/v2.11/${userID}/?fields=id,name,email,picture&access_token=${accessToken}`;
    https.get(facebook_url, async (response) => {
      const data = [];
      response.on("data", (chunk) => {
        data.push(chunk);
      });
      let user;
      response.on("end", async () => {
        user = JSON.parse(Buffer.concat(data).toString());
      });

      const findUser = await UserModel.findOne({ email: user.email });

      if (!findUser) {
        const createNewUser = {
          _id: uuidv4(),
          email: user.email,
          firstName: user.name,
          lastName: user.family_name,
          image: user.picture,
          device_id: device_id,
          signupBy: "facebook",
        };
        const insertedUser = await UserModel.create(createNewUser);
        let uu_data = {
          token: await generateToken({
            id: insertedUser._id,
          }),
          _id: insertedUser._id,
          firstName: insertedUser.firstName,
          lastName: insertedUser.lastName,
          email: insertedUser.email,
          mobile_number: insertedUser.mobile_number,
          image: insertedUser.image,
          subscription_type_id: insertedUser.subscription_type_id,
          is_premium_user: insertedUser.is_premium_user,
          active_status: insertedUser.is_active,
          subscription_type_name: insertedUser.subscription_type_name,
        };

        res.status(200).json({
          msg: "User login Successfully",
          data: uu_data,
          status: 0,
        });

        if (findUser) {
          let uu_data = {
            token: await generateToken({
              id: findUser._id,
            }),
            _id: findUser._id,
            firstName: findUser.firstName,
            lastName: findUser.lastName,
            email: findUser.email,
            image: findUser.image,
            subscription_type_id: findUser.subscription_type_id,
            is_premium_user: findUser.is_premium_user,
            active_status: findUser.is_active,
            subscription_type_name: findUser.subscription_type_name,
          };

          return res.status(200).json({
            msg: "User login Successfully",
            data: uu_data,
            status: 0,
          });
        }
      }
    });
  } catch (err) {
    return res.status(500).json({ status: -1, msg: "Server error" });
  }
}

export async function update_user_profile(req, res) {
  try {
    const userId = req.body.id;
    const rules = updateUserBasicRules;
    let error;
    let body = req.body;
    await validator(body, rules, {}, (err) => {
      error = err;
    });
    if (error) {
      return res.json({
        status: -1,
        data: error,
        msg: "Validation error.",
      });
    }

    const obj = {
      firstName: body.firstName,
      lastName: body.lastName,
      email: body.email,
      mobile: body.mobile,
    };

    const updatedProfile = await UserModel.findOneAndUpdate(
      { _id: userId },
      obj,
      {
        new: true,
      }
    );
    if (updatedProfile) {
      let sendQ = await Send_Queue(
        cms_queue,
        "user_queue",
        updatedProfile,
        "customer",
        "edit"
      );
    }
    return res.status(200).json(updatedProfile);
  } catch (err) {
    console.log(err);
    return res.status(500).json({
      status: -1,
      msg: "Server error",
    });
  }
}
