import jwt from "jsonwebtoken";
import * as https from "https";
import RevokedTokenModel from "../models/RevokedToken";
import fetch from "node-fetch";

const httpsAgent = new https.Agent({
  rejectUnauthorized: false,
});
const makeid = (length) => {
  let result = "";
  let characters =
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
  let charactersLength = characters.length;
  for (let i = 0; i < length; i++) {
    result += characters.charAt(Math.floor(Math.random() * charactersLength));
  }
  return result;
};

const generateToken = async (data) => {
  var token = await jwt.sign(
    {
      exp: Math.floor(Date.now() / 1000) + 60 * 60 * 24 * 30,
      data: data,
    },
    "foodi@#$2020"
  );
  return token;
};
const expiredToken = async (token, secret) => {
  try {
    // verify JWT token
    jwt.verify(token, secret);

    // invalidate JWT token by setting expiry to 0
    const newToken = jwt.sign({}, secret, { expiresIn: 0 });

    return newToken;
  } catch (error) {
    // handle any errors thrown by jwt.verify()
    console.error(error);
    throw new Error("Invalid token");
  }
};
const isTokenRevoked = async (token) => {
  // Check if the token exists in the revoked tokens collection
  const revokedToken = await RevokedTokenModel.findOne({ token: token });
  return revokedToken !== null;
};
// const initOTP = async (mobile_number, otp) => {
//   let new_mobile_number = "88" + mobile_number;
//   console.log("otp number", new_mobile_number);
//   // let sid = "FOODIBRAND";
//   // let api_key = "jncl2wn2-o0omijuf-z6om6uzt-nvgaof5i-w74dhpwc";
//   let msg = "Your OTP is " + otp + ". Don't share the code with anyone.";
//   // let url = "https://smsplus.sslwireless.com/api/v3/send-sms";
//
//   // let data = {
//   //   api_token: api_key,
//   //   sid: sid,
//   //   msisdn: new_mobile_number,
//   //   sms: msg,
//   //   csms_id: makeid(8),
//   // };
//
//   const data = {
//     api_key: "Qte20ePwXEM5Vp4D5Zng",
//     senderid: "8809601004409",
//     number: new_mobile_number,
//     message: msg,
//   };
//   const url = "https://bulksmsbd.net/api/smsapi";
//
//   try {
//     const res = await fetch(url, {
//         agent:httpsAgent,
//       method: "post",
//       headers: {
//         Accept: "application/json",
//         "Content-Type": "application/json",
//       },
//       body: JSON.stringify(data),
//
//     });
//     const res_data = await res.json();
//     console.log("otp send data", res_data);
//     if (res_data.response_code != 202) {
//       return false;
//     }
//     return otp;
//   } catch (e) {
//     console.error(e);
//     return false;
//   }
// };

const initOTP = async (number, otp) => {
  const new_mobile_number = "88" + number;
  const api_key = "C2001709628cdabc0ddda8.08137042";
  const from = "8809612442509";
  const msg = `Your OTP for Foodi App is ${otp} ,Don't share the code with anyone`;
  // const url = "http://app.smsbd.pro/smsapi";

  const url =
    "https://api.mobireach.com.bd/SendTextMessage?Username=frush&Password=Dhaka@2022&From=Food%20Rush&To=" +
    number +
    "&Message=" +
    msg +
    "";

  const data = {
    api_key,
    type: "text/unicode",
    contacts: new_mobile_number,
    senderid: from,
    msg,
  };

  try {
    const res = await fetch(url, {
      method: "get",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      // body: JSON.stringify(data),
    });

    //const res_data = await res.json();
    //   console.log('res',res)
    if (res.status != 200) {
      return false;
    }

    return otp;
  } catch (e) {
    console.error(e);
    return false;
  }
};

export { initOTP, generateToken, expiredToken, isTokenRevoked };
