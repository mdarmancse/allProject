import Validator from "validatorjs";

export const userBasicRules = {
  firstName: "required|max:15",
  lastName: "required|max:15",
};

export const updateUserBasicRules = {
  firstName: "required|max:15",
  lastName: "required|max:15",
  mobile: "required|max:15",
};
// Validator.registerAsync(
//   "label_unique",
//   async function (value, requirement, attribute, passes) {
//     const user_id = this.validator.input.id;
//     UserAddressModel.findOne({
//       user: user_id,
//       label: value,
//     }).then((data) => {
//       console.log("data :", data);
//       if (data) {
//         console.log("this");
//         passes(false, "You already have an address with this label.");
//         return;
//       }
//       console.log("that");
//       passes();
//     });
//     // console.log("is_label_not_unique :", is_label_not_unique);
//     // // setTimeout(() => {
//     // return !is_label_not_unique;
//     // }, 1000);
//   }
// );

export const validator = async (body, rules, customMessages, callback) => {
  const validation = new Validator(body, rules, customMessages);
  validation.passes(() => callback(null, true));
  validation.fails(() => callback(validation.errors, false));
  // validation.checkAsync(
  //   () => callback(null, true),
  //   () => callback(validation.errors, false)
  // );
};
