// import redis from "ioredis";
// const redis_client = redis.createClient({
//     host: process.env.REDIS_URL,
//     port: process.env.REDIS_PORT,
//     password: process.env.REDIS_PASS
// });
// export const redis_set = (key,id,data) => {
//    return redis_client.hset(key, id, JSON.stringify(data));
// };
//
// export const redis_get = (key,id) => {
//   return redis_client.hget(key, id);
// };
//
// export const redis_delete_by_id = (key,id) => {
//   return redis_client.del(key, id);
// };
//
// export const redis_delete=  (key) => {
//     return redis_client.del(key);
// };
//
