const amqp = require("amqplib");

var connection, channel;

async function connect() {
  try {
    const amqpService = "amqp://admin:admin2023@localhost:5672";
    connection = await amqp.connect(amqpService);
    channel = await connection.createChannel();
    await channel.assertQueue("AUTH");
    console.log("Message Broker Connected!!");
  } catch (e) {
    console.log(e);
  }
}

// exports.connect=()=>{
//
//
//     try{
//         const amqpService = "amqp://localhost:5672";
//         connection =await amqp.connect(amqpService);
//         channel = await connection.createChannel();
//         await channel.assertQueue("PRODUCT")
//     }catch (e) {
//
//         console.log(e);
//
//     }
//
// };

module.exports = connect;
