const DetailsByIDService = async (body, DataModel) => {
  try {
    let DetailsID = body.id;

    let QueryObject = {};
    QueryObject["_id"] = DetailsID;

    let data = await DataModel.aggregate([{ $match: QueryObject }]);
    return data;
  } catch (error) {
    return { status: "fail", data: error.toString() };
  }
};
export default DetailsByIDService;
