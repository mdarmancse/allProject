import admin from "firebase-admin";

import serviceAccount from "../../../serviceAccountKey.json" assert { type: "json" };

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
});
export const sendMuiltiNotifications = async (message) => {
  try {
    const response = await admin.messaging().sendMulticast(message);
    console.log("Successfully sent message:", response);
    return { status: "success", data: response.responses };
  } catch (error) {
    return { status: "failed", error: error.toString() };
  }
};

export const sendNotifications = async (message) => {
  try {
    const response = await admin.messaging().send(message);
    console.log("Successfully sent message:", response);
    return { status: "success", data: response };
  } catch (error) {
    return { status: "failed", error: error.toString() };
  }
};
