import UserModel from "../../models/UserModel";
import UserAddressModel from "../../models/UserAddressModel";
import SubscriptionType from "../../models/SubscriptionTypeModel";
import CustomerNotifications from "../../models/Notifications/CustomerNotifications";
import Notifications from "../../models/Notifications/Notifications";
import { sendNotifications } from "./Notifications";
import SubscriptionPayment from "../../models/SubscriptionPayment";
const models = {
  UserModel: UserModel,
  UserAddressModel: UserAddressModel,
  SubscriptionType: SubscriptionType,
  SubscriptionPayment: SubscriptionPayment,
  Notification: Notifications,
  CustomerNotifications: CustomerNotifications,
};

export const CreateService = async (Request, DataModel) => {
  if (DataModel == "Notification") {
    let push_noti = await CustomerNotifications.insertMany(Request.customers);
    if (push_noti) {
      let tokens = Request.customers.map((item) => item.device_id);
      let message = {
        notification: {
          title: Request.title,
          body: Request.description,
          image: Request.image,
        },
        data: {
          screenType: "notification",
        },
        tokens: tokens,
      };
      await sendNotifications(message);
      // console.log("tokens",tokens)
      // console.log("push_noti",push_noti)
      // console.log("Request.image",Request.image)
    }
  }

  try {
    let PostBody = Request;
    console.log("Request", Request);
    let MODEL = models[DataModel];
    let data = await MODEL.create(PostBody);
    if (data) return { status: "success", data: data };
  } catch (error) {
    console.error(error);
    return { status: "failed" };
  }
};

export const UpdateService = async (Request, DataModel) => {
  try {
    let PostBody = Request;
    let id = Request._id;
    let MODEL = models[DataModel];
    let data = await MODEL.updateOne({ _id: id }, PostBody);
    if (data) return { status: "success", data: data };
  } catch (error) {
    console.error("error :", error);
    return { status: "failed" };
  }
};

export const DeleteService = async (Request, DataModel) => {
  try {
    let DeleteID = Request._id;
    let MODEL = models[DataModel];
    const data = await MODEL.deleteMany({ _id: DeleteID });

    if (data) return { status: "success", data: data };
  } catch (error) {
    console.error("error :", error);
    return { status: "failed" };
  }
};

export const GetService = async (Request, DataModel) => {
  try {
    let MODEL = models[DataModel];
    let data = await MODEL.findOne({ _id: Request._id });
    if (data) return { status: "success", data: data };
  } catch (error) {
    return { status: "failed" };
  }
};

export const GetServiceByCondition = async (Request, DataModel) => {
  try {
    return new Promise(async (resolve, reject) => {
      let MODEL = models[DataModel];
      let data = await MODEL.findOne(Request);
      if (data) resolve({ data: data });
      reject({
        status: "Failed",
      });
    });
  } catch (error) {
    return { status: "Failed Fetch" };
  }
};
export const UpdateByCondition = async (Request, DataModel) => {
  try {
    let MODEL = models[DataModel];
    let condition = Request.condition;
    let update_data = Request.data;
    let data = await MODEL.updateOne(condition, update_data);
    if (data) return { status: "success", data: data };
  } catch (error) {
    return { status: "failed", err: error.toString() };
  }
};

export const UpdateOrInsertByCondition = async (Request, DataModel) => {
  try {
    let MODEL = models[DataModel];
    let condition = Request.condition;
    let update_data = Request.data;

    console.log("Condition", condition);
    console.log("update_data", update_data);
    let data = await MODEL.findOneAndUpdate(
      condition,
      {
        $set: update_data,
      },
      { returnOriginal: false, upsert: true }
    );
    if (data) return { status: "success", data: data };
  } catch (error) {
    return { status: "failed", err: error.toString() };
  }
};
