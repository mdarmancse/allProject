import {
  registration,
  login,
  verifyOTP,
  address_add,
  address_get,
  address_edit,
  address_delete,
  user_details,
  customer_setting,
  get_customer_setting,
} from "./controllers/UserController";

const paths = {
  registration: registration,
  login: login,
  verifyOTP: verifyOTP,
  address_add: address_add,
  address_get: address_get,
  address_edit: address_edit,
  address_delete: address_delete,
  user_details: user_details,
  customer_setting: customer_setting,
  get_customer_setting: get_customer_setting,
};

export default async (path, body) => {
  let response;
  try {
    response = paths[path](body);
    if (response) return response;
  } catch (err) {
    console.error(err);
    return {
      status: -1,
      msg: "Gateway not found",
    };
  }
};
