import { Router } from "express";
import Auth from "../middleware/AuthVerifier";

import {
  address_add,
  address_delete,
  address_edit,
  address_get,
  checkLogin,
  customer_setting,
  get_customer_setting,
  login,
  login_with_facebook,
  login_with_google,
  logout,
  registration,
  rider_assign,
  update_user_profile,
  user_details,
  verifyOTP,
} from "../controllers/UserController";
import { getSubscriptionType } from "../controllers/ExpressUserController";
const router = Router();
router
  .post("/registration", Auth, registration)
  .post("/login", login)
  .post("/google-login", login_with_google)
  .post("/facebook-login", login_with_facebook)
  .post("/check_login", Auth, checkLogin)
  .post("/verifyOTP", verifyOTP)
  .post("/setting/create", Auth, customer_setting)
  .get("/setting/get", Auth, get_customer_setting)
  .get("/address", Auth, address_get)
  .get("/subscriptionType/get", Auth, getSubscriptionType)
  .post("/address/add", Auth, address_add)
  .post("/address/edit", Auth, address_edit)
  .delete("/address/delete", Auth, address_delete)
  .post("/riderAssign", Auth, rider_assign)
  .put("/profile-update", Auth, update_user_profile)
  .get("/profile-details", Auth, user_details)
  .get("/logout", Auth, logout);

export default router;
