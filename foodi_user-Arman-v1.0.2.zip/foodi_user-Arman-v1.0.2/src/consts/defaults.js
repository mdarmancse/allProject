export const SYSTEM_TIMEZONE = {
  HOURS: 6,
  MINUTES: 0,
};
