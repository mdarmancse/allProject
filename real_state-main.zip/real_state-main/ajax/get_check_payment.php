<?php
	session_start();
	include("../config.php");
	if(isset($_SESSION['objLogin'])){

		$r_id=$_POST['r_id'];
		$month=$_POST['month'];
		$year=$_POST['year'];

		$check = mysqli_query($link,"SELECT * from tbl_add_fair  where rid = ".$r_id." and month_id = ".$month."  and xyear = ".$year."" );

		$rowcount=mysqli_num_rows($check);


		echo json_encode($rowcount);
		//		if($row_emp = mysqli_fetch_array($check)){
//			echo $row_emp;
//		}


	}



?>
