
<div class="row compo">
    <div class="col-12" style="padding: 0">
        <div class="carousel_div">
            <h5 class="bk-org title">গ্যালারি</h5>
            <div id="carouselGalleryInterval" class="carousel slide" data-ride="carousel">
                <div class="carousel-inner">
                    @foreach($sliders as $slider)
                        @if($loop->first)
                            <div class="carousel-item active">
                                <img src="{{ $slider->image }}" class="d-block w-100" alt="{{ $slider->title }}">
                                <div class="carousel-caption text-left gall">
                                    <h1>{{ $slider->title }}</h1>
                                </div>
                            </div>
                        @else
                            <div class="carousel-item">
                                <img src="{{ $slider->image }}" class="d-block w-100" alt="{{ $slider->title }}">
                                <div class="carousel-caption text-left gall">
                                    <h1>{{ $slider->title }}</h1>
                                </div>
                            </div>
                        @endif
                    @endforeach
                </div>
                <a class="carousel-control-prev" href="#carouselGalleryInterval" role="button" data-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
                </a>
                <a class="carousel-control-next" href="#carouselGalleryInterval" role="button" data-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                </a>
            </div>
        </div>
    </div>
</div>

<div class="row no-gutters">
    <div class="col-md-6 p-0">
        <h5 class="bk-org title">ভিডিও</h5>
        <div class="embed-responsive embed-responsive-4by3">
            <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/Dh2rd08AiOo" allowfullscreen></iframe>
        </div>
    </div>
    <div class="col-md-6 p-0">
        <h5 class="bk-org title">ম্যাপ</h5>
        <div class="embed-responsive embed-responsive-4by3">
            <iframe class="embed-responsive-item" src="https://maps.google.com/maps?q=nazirhat%20poroshova&t=&z=13&ie=UTF8&iwloc=&output=embed" frameborder="0"></iframe>
        </div>
    </div>
</div>




<div class="row compo">
    <div class="col-12" style="padding: 0">
      <h5 class="bk-org title">আশ্রয়ণের অধিকার শেখ হাসিনার উপহার</h5>
    </div>
    <div class="col-12 col-sm-4">
      <iframe frameborder="0" src="https://www.youtube.com/embed/l7G3TPz6P24" width="100%"></iframe>
    </div>
    <div class="col-12 col-sm-4">
      <iframe frameborder="0" src="https://www.youtube.com/embed/z6llDxY5JFs" width="100%"></iframe>
    </div>
    <div class="col-12 col-sm-4">
      <iframe frameborder="0" src="https://www.youtube.com/embed/MvTLqrU9ZbQ" width="100%"></iframe>
    </div>
  </div>

  <div class="row compo">
<div class="col-12" style="padding: 0">
      <h5 class="bk-org title">অন্যান্য ভিডিও</h5>
    </div>
    <div class="col-12 col-md-6">
      <div class="embed-responsive embed-responsive-16by9">
        <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/zBAKSZqTkRg"></iframe>
      </div>
      <p><strong>ফল আর্মিওয়ার্ম পর্যবেক্ষণ ও সনাক্তকরণ</strong></p>
    </div>
    <div class="col-12 col-md-6">
      <div class="embed-responsive embed-responsive-16by9">
        <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/GT9ShGE_qjg"></iframe>
      </div>
      <p><strong>বন্যার সময় কি করণীয়</strong></p>
    </div>
  </div>















