<div class="row compo">
    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 notice-board-bg">
        <h2>নোটিশ বোর্ড</h2>
        <div id="notice-board-ticker">
            <ul>
                @foreach($notice as $nt)
                <li>
                    <a href="{{url('/viewnotice/'.$nt->id)}}">{{$nt->title}}</a>
                </li>
                @endforeach
            </ul>
            <a class="btn btn-info btn-sm float-right mt-2" href="{{url('/all_notice')}}">সকল</a>
        </div>
    </div>
</div>
