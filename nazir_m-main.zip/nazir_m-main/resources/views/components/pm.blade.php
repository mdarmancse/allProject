

<div class="row compo">
    <div class="col-12" style="padding: 0">
        <a href="https://www.youtube.com/watch?v=v1R-CB3e-pw" target="_blank" style="padding: 0">
            <img class="img-fluid" src="{{asset('images/pm.jpeg')}}" alt="Prime Minister">
        </a>
    </div>
</div>




<div class="row compo">
  <div class="col-12" style="padding: 0">
    <h3 class="marquee-text">
                        <marquee direction="left" scrollamount="4" onmouseover="this.stop()" onmouseout="this.start()">
                            নো মাস্ক নো সার্ভিস। করোনাভাইরাসের বিস্তার রোধে এখনই ডাউনলোড করুন Corona Tracer BD অ্যাপ। ডাউনলোড করতে ক্লিক করুন <a href="https://bit.ly/coronatracerbd" target="_blank" style="color: blue;">https://bit.ly/coronatracerbd</a>। নিজে সুরক্ষিত থাকুন অন্যকেও নিরাপদ রাখুন। দেশের প্রথম ক্রাউডফান্ডিং প্ল্যাটফর্ম 'একদেশ'- এর মাধ্যমে আর্থিক অনুদান পৌঁছে দিন নির্বাচিত সরকারি-বেসরকারি প্রতিষ্ঠানসমূহে। ভিজিট করুন <a href="//ekdesh.ekpay.gov.bd" target="_blank" style="color: blue;">ekdesh.ekpay.gov.bd</a> অথবা <a href="//play.google.com/store/apps/details?id=com.synesis.donationapp" target="_blank" style="color: blue;">“Ek Desh”</a> অ্যাপ ডাউনলোড করুন। করোনার লক্ষণ দেখা দিলে গোপন না করে ডাক্তারের পরামর্শের জন্য ফ্রি কল করুন ৩৩৩ ও ১৬২৬৩ নম্বরে। করোনাভাইরাস প্রতিরোধে নিয়ম মেনে মাস্ক ব্যবহার করুন। আতঙ্কিত না হয়ে বরং সচেতন থাকুন। ভিজিট করুন <a href="//corona.gov.bd" target="_blank" style="color: blue;">corona.gov.bd</a>
                        </marquee>
    </h3>


    </div>


</div>



<div class="row compo">
  <div class="col-sm-12 col-md-12 col-lg-12 col-xs-12">
    <div style="background-color: #EFEFEF; border: 1px solid #CCCCCC; margin-bottom: 20px; padding: 10px;" class="row" id="news">
      <h5 style="float: left; margin: -3px 5px 0 0; font-weight: bold; font-size: .9em;">খবর:</h5>
      <div id="notice-board-ticker">
        <ul>
          @foreach($news as $nw)
          <li>
            <a href="{{url('/viewnews/'.$nw->id)}}">{{$nw->title}}</a>
          </li>
          @endforeach
        </ul>
        <a class="btn btn-info btn-sm float-right" href="{{url('/all_news')}}">সকল</a>
      </div>
    </div>
  </div>
</div>





    </div>
    <div class="row compo">
    @foreach($menu_card as $menu)
        <div id="" class="col-12 col-sm-6 col-md-6 col-lg-6 board-bg">
            <h4>{{$menu->sub_title}}</h4>
            <div class="row eknojor">
                <div class="col-4 col-md-4 col-lg-4 d-flex align-items-center justify-content-center">
                    <img src="{{$menu->image ? $menu->image:asset('images/placeholder.png')}}" alt="{{$menu->sub_title}}" class="img-fluid" style="max-height: 150px;">
                </div>
                <div class="col-8 col-md-8 col-lg-8">
                    <ul class="list-unstyled" style="margin:0">
                        @foreach($menu->submenu as $sub)
                            <li><a href="{{url('/viewpage/'.$sub->id)}}" title="{{$sub->sub_menu_name}}"><i class="fa fa-angle-right"></i> {{$sub->sub_menu_name}}</a></li>
                        @endforeach
                    </ul>
                </div>
            </div>
        </div>
    @endforeach
</div>
































