@extends('layout.app2')
@section('content')



    <div id="mainDiv" class="container ">
        <h4 class="modal-title w-10 font-weight-bold p-4"><span><i class="fas fa-newspaper"></i> </span> News</h4>
    <hr>

        <div class="row">
            <div class="col-md-12 p-5">

                @if(Session::has('success'))
                    <div class="alert alert-success">
                        {{Session::get('success')}}
                    </div>

                @elseif(Session::has('error'))
                    <div class="alert alert-danger">
                        {{Session::get('error')}}
                    </div>
                @endif





                    <button id="addFormBtn" type="button" class="m-3 btn btn-sm btn-danger">Add News</button>





                <table id="table" class="table table-striped table-sm table-bordered" cellspacing="0" width="100%">

                    <thead>
                    <tr>
                        <th class="th-sm text-center font-weight-bold">Title</th>
                        <th class="th-sm text-center font-weight-bold">Content</th>
                        <th class="th-sm text-center text-center font-weight-bold">Image</th>
                        <th class="th-sm text-center text-center font-weight-bold">Action</th>


                    </tr>
                    </thead>
                    <tbody id="user_table">

                    @foreach($data as $dt)
                        <tr>
                            <td class="text-center ">{{$dt->title}}</td>
                            <td class=" text-justify" > {!! $dt->content !!}</td>
                            <td class="text-center " width="200px">      <img style="width: 50%;height: 100%" src="{{$dt->image ? $dt->image:asset('images/placeholder.png')}}" /></td>
                            <td class="text-center ">
                                <a class="btn btn-info btn-sm" data-toggle="tooltip" data-placement="top" onclick="getNewsData({{$dt->id}})" data-original-title="Edit" title="Edit"><i class="fas fa-edit"></i></a>

                                <a href="{{url('/news_delete/'.$dt->id)}}" class="btn btn-danger btn-sm" data-toggle="tooltip" data-placement="top" data-original-title="Delete" title="Delete"><i class="fas fa-trash-alt"></i></a>

                            </td>
                        </tr>

                    @endforeach





                    </tbody>
                </table>

            </div>
        </div>
    </div>





    <div class="modal fade bd-example-modal-lg" id="addModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header text-center">
                    <h4 class="modal-title w-100 font-weight-bold">Add News</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form  action="/newsAdd" method="POST" class="m-5 loginForm" enctype="multipart/form-data">
                    @csrf
                    <div class="modal-body mx-3">
                        <div class="md-form">
                            <label class="m-2">Title:</label>

                            <input   placeholder="Title" name="title" type="text" id="title" class="form-control validate">

                        </div>

                        <div class="md-form">
                            <label class="m-2">Content:</label>
                            <textarea rows="5" id="" placeholder="Content" name="content" type="text" id="content" class="form-control editor validate"> </textarea>

                        </div>




                        <div class="md-form">
                            <label class="m-2">Image:</label>
                            <input   placeholder="" name="image" type="file" id="image" class="form-control validate">
                        </div>








                    </div>
                    <div class="modal-footer d-flex justify-content-center">
                        <button type="button" class="btn btn-danger btn-sm" data-dismiss="modal">
                            Close
                        </button>
                        <button type="submit" id="userAddConfirmBtn" class="btn btn-sm btn-success">Save</button>
                    </div>

                </form>
            </div>
        </div>
    </div>

    <div class="modal fade bd-example-modal-lg" id="editMenuModal" tabindex="-1" role="dialog" aria-labelledby="mySubModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header text-center">
                    <h4 class="modal-title w-100 font-weight-bold">Edit News</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form  action="/newsEdit" method="POST" class="m-5 loginForm" enctype="multipart/form-data">
                    @csrf
                    <div class="modal-body mx-3">
                        <div class="md-form">
                            <label class="m-2">Title:</label>

                            <input   placeholder="Title" name="title" type="text" id="edit_title" class="form-control validate">
                            <input   placeholder="Title" name="news_id" type="hidden" id="news_id" class="form-control validate">
                            <input   placeholder="Title" name="old_image" type="hidden" id="old_image" class="form-control validate">

                        </div>

                        <div class="md-form">
                            <label class="m-2">Content:</label>
                            <textarea rows="5" id="editor" placeholder="Content" name="content" type="text" id="edit_content" class="form-control content editor validate"> </textarea>

                        </div>




                        <div class="md-form">
                            <label class="m-2">Image:</label>
                            <input   placeholder="" name="image" type="file" id="image" class="form-control validate">
                        </div>








                    </div>
                    <div class="modal-footer d-flex justify-content-center">
                        <button type="button" class="btn btn-danger btn-sm" data-dismiss="modal">
                            Close
                        </button>
                        <button type="submit" id="userAddConfirmBtn" class="btn btn-sm btn-success">Save</button>
                    </div>

                </form>
            </div>

        </div>
    </div>





@endsection

@section('script')



    <script type="text/javascript">


        $('#addFormBtn').click(function () {
            $('#addModal').modal('show');
        })








    </script>


@endsection
