@extends('layout.app2')
@section('content')

    <div id="mainDiv" class="container ">
        <h4 class="modal-title w-10 font-weight-bold p-4"><span> <i class="fas fa-scroll"></i> </span> Notices</h4>
    <hr>

        <div class="row">
            <div class="col-md-12 p-5">

                @if(Session::has('success'))
                    <div class="alert alert-success">
                        {{Session::get('success')}}
                    </div>

                @elseif(Session::has('error'))
                    <div class="alert alert-danger">
                        {{Session::get('error')}}
                    </div>
                @endif





                    <button id="addFormBtn" type="button" class="m-3 btn btn-sm btn-danger">Add New</button>





                <table id="table" class="table table-striped table-sm table-bordered" cellspacing="0" width="100%">

                    <thead>
                    <tr>
                        <th class="th-sm text-center font-weight-bold">Title</th>
                        <th class="th-sm text-center text-center font-weight-bold">File</th>
                        <th class="th-sm text-center text-center font-weight-bold">Action</th>


                    </tr>
                    </thead>
                    <tbody id="user_table">

                    @foreach($data as $dt)
                        <tr>
                            <td class="text-center ">{{$dt->title}}</td>
                            <td class="text-center "><a href="{{$dt->file}}"><i class="fas fa-download"></i> Download</a></td>
                            <td class="text-center ">
                                <a class="btn btn-info btn-sm" data-toggle="tooltip" data-placement="top" onclick="getNoticeData({{$dt->id}})" data-original-title="Edit" title="Edit"><i class="fas fa-edit"></i></a>

                                <a href="{{url('/notice_delete/'.$dt->id)}}" class="btn btn-danger btn-sm" data-toggle="tooltip" data-placement="top" data-original-title="Delete" title="Delete"><i class="fas fa-trash-alt"></i></a>

                            </td>
                        </tr>

                    @endforeach





                    </tbody>
                </table>

            </div>
        </div>
    </div>









    <div class="modal fade" id="addModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
         aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header text-center">
                    <h4 class="modal-title w-100 font-weight-bold">Add Notice</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form  action="/noticeAdd" method="POST" class="m-5 loginForm" enctype="multipart/form-data">
                    @csrf
                    <div class="modal-body mx-3">
                        <div class="md-form">


                        </div>


                        <div class="md-form">
                            <label class="m-2">Title:</label>

                            <input   placeholder="Notice Title" name="title" type="text" id="title" class="form-control validate">

                        </div>



                        <div class="md-form">
                            <label class="m-2">File:</label>
                            <input   placeholder="" name="file" type="file" id="file" class="form-control validate">
                        </div>










                    </div>
                    <div class="modal-footer d-flex justify-content-center">
                        <button type="button" class="btn btn-danger btn-sm" data-dismiss="modal">
                            Close
                        </button>
                        <button type="submit" id="userAddConfirmBtn" class="btn btn-sm btn-success">Save</button>
                    </div>

                </form>
            </div>
        </div>
    </div>


    <div class="modal fade" id="editMenuModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
         aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header text-center">
                    <h4 class="modal-title w-100 font-weight-bold">Edit News</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form  action="/noticeEdit" method="POST" class="m-5 loginForm" enctype="multipart/form-data">
                    @csrf
                    <div class="modal-body mx-3">
                        <div class="md-form">
                            <label class="m-2">Title:</label>

                            <input   placeholder=" Title" name="title" type="text" id="edit_title" class="form-control validate">
                            <input   placeholder="" name="notice_id" type="hidden" id="notice_id" class="form-control validate">
                            <input   placeholder="" name="old_image" type="hidden" id="old_image" class="form-control validate">

                        </div>



                        <div class="md-form">
                            <label class="m-2">File:</label>
                            <input   placeholder="" name="image" type="file" id="edit_image" class="form-control validate">
                        </div>








                    </div>
                    <div class="modal-footer d-flex justify-content-center">
                        <button type="button" class="btn btn-danger btn-sm" data-dismiss="modal">
                            Close
                        </button>
                        <button type="submit" id="userAddConfirmBtn" class="btn btn-sm btn-success">Save</button>
                    </div>

                </form>
            </div>
        </div>
    </div>


@endsection

@section('script')



    <script type="text/javascript">


        $('#addFormBtn').click(function () {
            $('#addModal').modal('show');
        })








    </script>


@endsection
