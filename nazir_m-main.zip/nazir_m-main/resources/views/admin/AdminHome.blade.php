@extends('layout.app2')
@section('content')



    <div id="mainDiv" class="container ">

        <div class="row">

        <div class="col-md-4 p-3">
            <div class="card">
                <div class="card-body">
                    <h3 class="count card-title">{{$TotalNotice}}</h3>
                    <h3 class="count card-text">Total Notices</h3>
                </div>
            </div>
        </div>
            <div class="col-md-4 p-3">
                <div class="card">
                    <div class="card-body">
                        <h3 class="count card-title">{{$TotalNews}}</h3>
                        <h3 class="count card-text">Total News</h3>
                    </div>
                </div>
            </div>
            <div class="col-md-4 p-3">
                <div class="card">
                    <div class="card-body">
                        <h3 class="count card-title">{{$TotalMenu}}</h3>
                        <h3 class="count card-text">Total Menu</h3>
                    </div>
                </div>
            </div>

        </div>

    </div>










@endsection

@section('script')
    <script type="text/javascript">
        getUsersData();


        function getUsersData() {

            axios.get("/getUserData")
                .then(function(response) {

                    if (response.status == 200) {

                        $('#mainDiv').removeClass('d-none')


                        $('#userDataTable').DataTable().destroy();
                        $('#user_table').empty();
                        var jsonData = response.data;
                        // $.each(jsonData, function (i, item) {   })
                        for (var i = 0; i < jsonData.length; i++) {

                            // var obj = jsonData[i];
                            // console.log(obj.id);
                            $('<tr>').html(
                                "<td>" + jsonData[i].name + "</td>" +
                                "<td>" + jsonData[i].email + "</td>" +
                                "<td>" + jsonData[i].user_type + "</td>"

                            ).appendTo('#user_table');
                        }

                        $('#userDataTable').DataTable({"order":false});
                        $('.dataTables_length').addClass('bs-select');

                    }
                }).catch(function(error) {


            })

        }

        ;





        $('#addFormBtn').click(function () {
            $('#addModal').modal('show');
        })








    </script>

@endsection
