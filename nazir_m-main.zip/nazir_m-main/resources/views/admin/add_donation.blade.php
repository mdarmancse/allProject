@extends('layout.app2')
@section('content')



    <div id="mainDiv" class="container ">
        <h4 class="modal-title w-10 font-weight-bold p-4"><span><i class="fas fa-clipboard-list"></i></span> Donations</h4>
    <hr>

        <div class="row">
            <div class="col-md-12 p-5">

                @if(Session::has('success'))
                    <div class="alert alert-success">
                        {{Session::get('success')}}
                    </div>

                @elseif(Session::has('error'))
                    <div class="alert alert-danger">
                        {{Session::get('error')}}
                    </div>
                @endif





                    <button id="addsubMenuBtn" type="button" class="m-3 btn btn-sm btn-danger">Add Donation</button>






                    <table id="table" class="table table-striped table-sm table-bordered" cellspacing="0" width="100%">

                        <thead>
                        <tr>
                            <th class="th-sm text-center font-weight-bold">#</th>
                            <th class="th-sm text-center font-weight-bold">Financial Year</th>
                            <th class="th-sm text-center font-weight-bold">Sector Name</th>
                            <th class="th-sm text-center text-center font-weight-bold">Donation Number</th>
                            <th class="th-sm text-center text-center font-weight-bold">Total Amount</th>
                            <th class="th-sm text-center text-center font-weight-bold">Notes</th>
                            <th class="th-sm text-center text-center font-weight-bold">File</th>
                            <th class="th-sm text-center text-center font-weight-bold">Action</th>


                        </tr>
                        </thead>
                        <tbody id="user_table">

                        @php
                            $sl=1;
                             $total=0;
                    @endphp

                    @foreach($result as $item)

                            @php
                               $cc= $item->Donations->count();

                        @endphp



                            @if($cc > 0)

                        <tr >
                            <td class="text-center"  rowspan="{{count($item->donations)}}">{{$sl++}}</td>

                            <td class="text-center "  rowspan="{{count($item->donations)}}">{{$item->finance_year}}</td>



                            @php

                                $i=0;
                                $j=0;



            foreach ($item->Donations as $key=>$value)

              {

              if (fmod($i,3)) echo '<tr>';
              echo '<td class="text-center">',$value->title,'</td>';
              echo '<td class="text-center">',$value->project_number,'</td>';
              echo '<td class="text-center">',number_format($value->amount,2),'</td>';
              echo '<td class="text-center">',$value->notes,'</td>';
              echo '<td class="text-center ">','<a href='.$value->file.'><i class="fas fa-download"></i> Download</a></td>';
              echo '<td class="text-center">','<a class="btn btn-info btn-sm" data-toggle="tooltip" data-placement="top" onclick="getDonationData('.$value->id.')" data-original-title="Edit" title="Edit"><i class="fas fa-edit"></i></a> ',
                                             '<a  href=/donation_delete/'.$value->id.' class="btn btn-danger btn-sm" data-toggle="tooltip" data-placement="top" data-original-title="Delete" title="Delete"><i class="fas fa-trash-alt"></i></a>','</td>';
              if (fmod($i,3)) echo '</tr>';

              $i++;
                    $total= $value->sum('amount');
              }





                            @endphp

                        </tr>
                        @endif




                    @endforeach






                    </tbody>
                        <tfoot>



                        <tr>
                            <th colspan="4" class="text-right">Grand Total</th>
                            <th colspan="1" class="text-right">{{number_format($total,2)}}</th>
                            <th colspan="3"></th>
                        </tr>
                        </tfoot>
                </table>

            </div>
        </div>
    </div>


    <div class="modal fade" id="addModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
         aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header text-center">
                    <h4 class="modal-title w-100 font-weight-bold">Add Menu</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form  action="/menuAdd" method="POST" class="m-5 loginForm" enctype="multipart/form-data">
                    @csrf
                    <div class="modal-body mx-3">
                        <div class="md-form">
                            <label class="m-2">Menu Title:</label>

                            <input   placeholder="Menu Title" name="menu_name" type="text" id="menu_name" class="form-control validate">

                        </div>

                        <div class="md-form">
                            <label class="m-2">Sub Title:</label>

                            <input   placeholder="Sub Title" name="sub_title" type="text" id="sub_title" class="form-control validate">

                        </div>


                        <div class="md-form">
                            <label class="m-2">Image:</label>
                            <input   placeholder="" name="image" type="file" id="image" class="form-control validate">
                        </div>








                    </div>
                    <div class="modal-footer d-flex justify-content-center">
                        <button type="button" class="btn btn-danger btn-sm" data-dismiss="modal">
                            Close
                        </button>
                        <button type="submit" id="userAddConfirmBtn" class="btn btn-sm btn-success">Save</button>
                    </div>

                </form>
            </div>
        </div>
    </div>


    <div class="modal fade bd-example-modal-lg" id="addSubModal" tabindex="-1" role="dialog" aria-labelledby="mySubModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-content">
                    <div class="modal-header text-center">
                        <h4 class="modal-title w-100 font-weight-bold">Add New</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <form  action="/donationAdd" method="POST" class="m-5 loginForm" enctype="multipart/form-data">
                        @csrf
                        <div class="modal-body mx-3">

                            <div class="md-form ">
                                <label class="m-2">Financial Year:</label>

                                <select class="form-select form-control" name="year_id" aria-label="Default select example">
                                    @foreach($result as $val)
                                        <option value="{{$val->id}}">{{$val->finance_year}}</option>
                                    @endforeach
                                </select>

                            </div>

                            <div class="md-form">
                                <label class="m-2">Sector Name:</label>

                                <input   placeholder="Sector Name" name="name" type="text" id="name" class="form-control validate">

                            </div>


                            <div class="md-form">
                                <label class="m-2">Project Number:</label>

                                <input   placeholder="Project Number" name="project_number" type="number" id="project_number" class="form-control validate">

                            </div>

                            <div class="md-form">
                                <label class="m-2">Total Amount:</label>

                                <input   placeholder="Total Amount" name="total_amount" type="number" id="total_amount" class="form-control validate">

                            </div>


                            <div class="md-form">
                                <label class="m-2">File:</label>
                                <input   placeholder="" name="image" type="file" id="image" class="form-control validate">
                            </div>

                            <div class="md-form">
                                <label class="m-2">Notes:</label>

                                <textarea id="" rows="5" placeholder="Notes" name="notes" type="text"  class="form-control  validate"> </textarea>

                            </div>




                        </div>
                        <div class="modal-footer d-flex justify-content-center">
                            <button type="button" class="btn btn-danger btn-sm" data-dismiss="modal">
                                Close
                            </button>
                            <button type="submit" id="userAddConfirmBtn" class="btn btn-sm btn-success">Save</button>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade bd-example-modal-lg " id="editSubModal" tabindex="-1" role="dialog" aria-labelledby="mySubModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-content">
                    <div class="modal-header text-center">
                        <h4 class="modal-title w-100 font-weight-bold">Edit</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <form  action="/donationEdit" method="POST" class="m-5 loginForm" enctype="multipart/form-data">
                        @csrf
                        <div class="modal-body mx-3">

{{--                            <div class="md-form ">--}}
{{--                                <label class="m-2">Financial Year:</label>--}}

{{--                                <select class="form-select form-control" name="year_id" aria-label="Default select example">--}}
{{--                                    @foreach($result as $val)--}}
{{--                                        <option value="{{$val->id}}">{{$val->finance_year}}</option>--}}
{{--                                    @endforeach--}}
{{--                                </select>--}}

{{--                            </div>--}}

                            <div class="md-form">
                                <label class="m-2">Sector Name:</label>

                                <input   placeholder="Sector Name" name="name" type="text" id="edit_name" class="form-control validate">
                                <input   name="donation_id" type="hidden" id="donation_id" class="form-control validate">
                                <input   name="year_id" type="hidden" id="finance_year_id" class="form-control validate">
                                <input   name="old_image" type="hidden" id="old_image" class="form-control validate">

                            </div>


                            <div class="md-form">
                                <label class="m-2">Project Number:</label>

                                <input   placeholder="Project Number" name="project_number" type="number" id="edit_project_number" class="form-control validate">

                            </div>

                            <div class="md-form">
                                <label class="m-2">Total Amount:</label>

                                <input   placeholder="Total Amount" name="total_amount" type="number" id="edit_total_amount" class="form-control validate">

                            </div>


                            <div class="md-form">
                                <label class="m-2">File:</label>
                                <input   placeholder="" name="image" type="file" id="image" class="form-control validate">
                            </div>

                            <div class="md-form">
                                <label class="m-2">Notes:</label>

                                <textarea id="edit_notes" rows="5" placeholder="Notes" name="notes" type="text"   class="form-control  validate"> </textarea>

                            </div>




                        </div>
                        <div class="modal-footer d-flex justify-content-center">
                            <button type="button" class="btn btn-danger btn-sm" data-dismiss="modal">
                                Close
                            </button>
                            <button type="submit" id="userAddConfirmBtn" class="btn btn-sm btn-success">Save</button>
                        </div>

                    </form>

                </div>
            </div>
        </div>
    </div>




@endsection

@section('script')



    <script type="text/javascript">


        $('#addsubMenuBtn').click(function () {
            $('#addSubModal').modal('show');
        })








    </script>


@endsection
