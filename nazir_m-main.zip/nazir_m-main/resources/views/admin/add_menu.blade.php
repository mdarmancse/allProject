@extends('layout.app2')
@section('content')



    <div id="mainDiv" class="container ">
        <h4 class="modal-title w-10 font-weight-bold p-4"><span><i class="fas fa-clipboard-list"></i></span> Menu</h4>
    <hr>

        <div class="row">
            <div class="col-md-12 p-5">

                @if(Session::has('success'))
                    <div class="alert alert-success">
                        {{Session::get('success')}}
                    </div>

                @elseif(Session::has('error'))
                    <div class="alert alert-danger">
                        {{Session::get('error')}}
                    </div>
                @endif





                    <button id="addFormBtn" type="button" class="m-3 btn btn-sm btn-danger">Add Menu</button>
                    <button id="addsubMenuBtn" type="button" class="m-3 btn btn-sm btn-info float-right">Add Sub-Menu</button>





                <table id="table" class="table table-striped table-sm table-bordered" cellspacing="0" width="100%">

                    <thead>
                    <tr>
                        <th class="th-sm text-center font-weight-bold">Menu</th>
                        <th class="th-sm text-center font-weight-bold">Title</th>
                        <th class="th-sm text-center font-weight-bold">Sub menu</th>
                        <th class="th-sm text-center text-center font-weight-bold">Image</th>
                        <th class="th-sm text-center text-center font-weight-bold">Action</th>


                    </tr>
                    </thead>
                    <tbody id="user_table">

{{--                    @php--}}
{{--                    echo $moctail;die()--}}
{{--                    @endphp--}}


{{--@foreach($json as $item)--}}
{{--    {{ $item }}--}}
{{--@endforeach--}}



                    @foreach($result as $item)

                        <tr>
                            <td class="text-center ">{{$item->title}}</td>
                            <td class="text-center ">{{$item->sub_title}}</td>
                            <td class=" text-center">

                                @foreach($item->submenu as $sub)
                                    <ul>

                                        <li class="">
                                            <a class="" target="_blank" href="{{url('/viewpage/'.$sub->id)}}"> {{$sub->sub_menu_name}}</a>
                                            @if($sub->id == 6 || $sub->id == 7)
{{--                                            <a  class="btn-outline-info btn-xs" data-toggle="tooltip" data-placement="top" onclick="getSubmenuData({{$sub->id}})" data-original-title="Edit" title="Edit"><i class="fas fa-edit"></i></a>--}}
{{--                                            <a href="{{url('/sub_delete/'.$sub->id)}}" class=" btn-outline-danger btn-xs" data-toggle="tooltip" data-placement="top" data-original-title="Delete" title="Delete"><i class="fas fa-trash-alt"></i></a>--}}
                                            @else
                                                <a  class="btn-outline-info btn-xs" data-toggle="tooltip" data-placement="top" onclick="getSubmenuData({{$sub->id}})" data-original-title="Edit" title="Edit"><i class="fas fa-edit"></i></a>

                                                <a href="{{url('/sub_delete/'.$sub->id)}}" class=" btn-outline-danger btn-xs" data-toggle="tooltip" data-placement="top" data-original-title="Delete" title="Delete"><i class="fas fa-trash-alt"></i></a>

                                            @endif
                                        </li>
                                    </ul>



                                @endforeach

                            </td>
                            <td class="text-center " width="200px"><img style="width: 50%;height: 100%" src="{{$item->image ? $item->image:asset('images/placeholder.png')}}" /></td>
                            <td class="text-center ">

                                <a class="btn btn-info btn-sm" data-toggle="tooltip" data-placement="top" onclick="getMenuData({{$item->id}})" data-original-title="Edit" title="Edit"><i class="fas fa-edit"></i></a>
                                <a href="{{url('/menu_delete/'.$item->id)}}" class="btn btn-danger btn-sm" data-toggle="tooltip" data-placement="top" data-original-title="Delete" title="Delete"><i class="fas fa-trash-alt"></i></a>

                            </td>
                        </tr>

                    @endforeach





                    </tbody>
                </table>

            </div>
        </div>
    </div>









    <div class="modal fade" id="addModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
         aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header text-center">
                    <h4 class="modal-title w-100 font-weight-bold">Add Menu</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form  action="/menuAdd" method="POST" class="m-5 loginForm" enctype="multipart/form-data">
                    @csrf
                    <div class="modal-body mx-3">
                        <div class="md-form">
                            <label class="m-2">Menu Title:</label>

                            <input   placeholder="Menu Title" name="menu_name" type="text" id="menu_name" class="form-control validate">

                        </div>

                        <div class="md-form">
                            <label class="m-2">Sub Title:</label>

                            <input   placeholder="Sub Title" name="sub_title" type="text" id="sub_title" class="form-control validate">

                        </div>

                        <div class="md-form">
                            <label class="m-2">Content:</label>
                            <textarea id="" rows="5" placeholder="" name="content" type="text"  class="form-control content editor validate "> </textarea>

                        </div>

                        <div class="md-form">
                            <label class="m-2">Image:</label>
                            <input   placeholder="" name="image" type="file" id="image" class="form-control validate">
                        </div>








                    </div>
                    <div class="modal-footer d-flex justify-content-center">
                        <button type="button" class="btn btn-danger btn-sm" data-dismiss="modal">
                            Close
                        </button>
                        <button type="submit" id="userAddConfirmBtn" class="btn btn-sm btn-success">Save</button>
                    </div>

                </form>
            </div>
        </div>
    </div>
    <div class="modal fade" id="editMenuModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
         aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header text-center">
                    <h4 class="modal-title w-100 font-weight-bold">Add Menu</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form  action="/menuEdit" method="POST" class="m-5 loginForm" enctype="multipart/form-data">
                    @csrf
                    <div class="modal-body mx-3">
                        <div class="md-form">
                            <label class="m-2">Title:</label>

                            <input   placeholder="Menu Title" name="menu_name" type="text" id="edit_title" class="form-control validate">
                            <input   placeholder="" name="menu_id" type="hidden" id="menu_id" class="form-control validate">
                            <input   placeholder="" name="old_image" type="hidden" id="old_image" class="form-control validate">

                        </div>

                        <div class="md-form">
                            <label class="m-2">Sub Title:</label>

                            <input   placeholder="Sub Title" name="sub_title" type="text" id="edit_sub_title" class="form-control validate">

                        </div>
                        <div class="md-form">
                            <label class="m-2">Content:</label>
                            <textarea id="menu_content" rows="5" placeholder="Content" name="content" type="text"  class="form-control editor  validate"> </textarea>

                        </div>


                        <div class="md-form">
                            <label class="m-2">Image:</label>
                            <input   placeholder="" name="image" type="file" id="edit_image" class="form-control validate">
                        </div>








                    </div>
                    <div class="modal-footer d-flex justify-content-center">
                        <button type="button" class="btn btn-danger btn-sm" data-dismiss="modal">
                            Close
                        </button>
                        <button type="submit" id="userAddConfirmBtn" class="btn btn-sm btn-success">Save</button>
                    </div>

                </form>
            </div>
        </div>
    </div>

    <div class="modal fade bd-example-modal-lg" id="addSubModal" tabindex="-1" role="dialog" aria-labelledby="mySubModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-content">
                    <div class="modal-header text-center">
                        <h4 class="modal-title w-100 font-weight-bold">Add Sub-Menu</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <form  action="/sub_menuAdd" method="POST" class="m-5 loginForm" enctype="multipart/form-data">
                        @csrf
                        <div class="modal-body mx-3">

                            <div class="md-form ">
                                <label class="m-2">Menu:</label>

                                <select class="form-select form-control" name="menu_id" aria-label="Default select example">
                                    @foreach($result as $menu)
                                        <option value="{{$menu->id}}">{{$menu->title}}</option>
                                    @endforeach
                                </select>

                            </div>

                            <div class="md-form">
                                <label class="m-2">Sub Menu:</label>

                                <input   placeholder="Sub-Menu" name="sub_menu" type="text" id="sub_menu" class="form-control validate">

                            </div>

                            <div class="md-form">
                                <label class="m-2">Content:</label>
                                                            <textarea id="" rows="5" placeholder="Content" name="content" type="text"  class="form-control editor validate"> </textarea>

                            </div>




                            <div class="md-form">
                                <label class="m-2">Image:</label>
                                <input   placeholder="" name="image" type="file" id="image" class="form-control validate">
                            </div>






                        </div>
                        <div class="modal-footer d-flex justify-content-center">
                            <button type="button" class="btn btn-danger btn-sm" data-dismiss="modal">
                                Close
                            </button>
                            <button type="submit" id="userAddConfirmBtn" class="btn btn-sm btn-success">Save</button>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade bd-example-modal-lg " id="editSubModal" tabindex="-1" role="dialog" aria-labelledby="mySubModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-content">
                    <div class="modal-header text-center">
                        <h4 class="modal-title w-100 font-weight-bold">Edit Sub-Menu</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <form  action="/sub_menuEdit" method="POST" class="m-5 loginForm" enctype="multipart/form-data">
                        @csrf
                        <div class="modal-body mx-3">

                            <div class="md-form">
                                <label class="m-2">Sub Menu:</label>

                                <input   placeholder="Sub-Menu" name="sub_menu" type="text" id="edit_sub_menu" class="form-control validate">
                                <input   placeholder="" name="sub_menu_id" type="hidden" id="sub_menu_id" class="form-control validate">
                                <input   placeholder="" name="sub_old_image" type="hidden" id="sub_old_image" class="form-control validate">

                            </div>

                            <div class="md-form">
                                <label class="m-2">Content:</label>
                                <textarea id="editor" rows="5" placeholder="" name="content" type="text"  class="form-control content  validate "> </textarea>

                            </div>




                            <div class="md-form">
                                <label class="m-2">Image:</label>
                                <input   placeholder="" name="image" type="file" id="edit_image" class="form-control validate">
                            </div>






                        </div>
                        <div class="modal-footer d-flex justify-content-center">
                            <button type="button" class="btn btn-danger btn-sm" data-dismiss="modal">
                                Close
                            </button>
                            <button type="submit" id="userAddConfirmBtn" class="btn btn-sm btn-success">Save</button>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>




@endsection

@section('script')



    <script type="text/javascript">


        $('#addFormBtn').click(function () {
            $('#addModal').modal('show');
        });

        $('#addsubMenuBtn').click(function () {
            $('#addSubModal').modal('show');
        })








    </script>


@endsection
