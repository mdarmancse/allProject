@extends('layout.app2')
@section('content')

    <div id="mainDiv" class="container ">
        <h4 class="modal-title w-10 font-weight-bold p-4"><span> <i class="fas fa-user"></i> </span> Mayor & Councillor</h4>
    <hr>

        <div class="row">
            <div class="col-md-12 p-5">

                @if(Session::has('success'))
                    <div class="alert alert-success">
                        {{Session::get('success')}}
                    </div>

                @elseif(Session::has('error'))
                    <div class="alert alert-danger">
                        {{Session::get('error')}}
                    </div>
                @endif





                    <button id="addFormBtn" type="button" class="m-3 btn btn-sm btn-danger">Add New</button>





                <table id="table" class="table table-striped table-sm table-bordered" cellspacing="0" width="100%">

                    <thead>
                    <tr>
                        <th class="th-sm text-center font-weight-bold">#</th>
                        <th class="th-sm text-center font-weight-bold">Image</th>
                        <th class="th-sm text-center font-weight-bold">Name</th>
                        <th class="th-sm text-center text-center font-weight-bold">Designation</th>
                        <th class="th-sm text-center text-center font-weight-bold">Mobile</th>
                        <th class="th-sm text-center text-center font-weight-bold">Action</th>


                    </tr>
                    </thead>
                    <tbody id="user_table">
                    @php
                        $sl=0;
                    @endphp
                    @foreach($data as $dt)
                        @php
                            $sl++
                        @endphp
                        <tr>
                            <td class="text-center">{{$sl}}</td>
                            <td class="text-center " width="200px"><img style="width: 50%;height: 100%" src="{{$dt->image ? $dt->image:asset('images/user.png')}}" /></td>
                            <td class="text-center ">{{$dt->name}}</td>
                            <td class="text-center ">{{$dt->designation}}</td>
                            <td class="text-center ">{{$dt->mobile}}</td>
                            <td class="text-center ">
                                <a class="btn btn-info btn-sm" data-toggle="tooltip" data-placement="top" onclick="getMayorData({{$dt->id}})" data-original-title="Edit" title="Edit"><i class="fas fa-edit"></i></a>

                                <a href="{{url('/mayor_delete/'.$dt->id)}}" class="btn btn-danger btn-sm" data-toggle="tooltip" data-placement="top" data-original-title="Delete" title="Delete"><i class="fas fa-trash-alt"></i></a>

                            </td>
                        </tr>

                    @endforeach





                    </tbody>
                </table>

            </div>
        </div>
    </div>









    <div class="modal fade" id="addModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
         aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header text-center">
                    <h4 class="modal-title w-100 font-weight-bold">Add New</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form  action="/mayorAdd" method="POST" class="m-5 loginForm" enctype="multipart/form-data">
                    @csrf
                    <div class="modal-body mx-3">
                        <div class="md-form">


                        </div>


                        <div class="md-form">
                            <label class="m-2">Name:</label>

                            <input   placeholder="Name" name="name" type="text" id="name" class="form-control validate">

                        </div>

                        <div class="md-form">
                            <label class="m-2">Designation:</label>

                            <input   placeholder="Designation" name="designation" type="text" id="designation" class="form-control validate">

                        </div>

                              <div class="md-form">
                            <label class="m-2">Mobile No:</label>

                            <input   placeholder="Mobile" name="mobile" type="number" id="designation" class="form-control validate">

                        </div>




                        <div class="md-form">
                            <label class="m-2">Image:</label>
                            <input   placeholder="" name="image" type="file" id="file" class="form-control validate">
                        </div>










                    </div>
                    <div class="modal-footer d-flex justify-content-center">
                        <button type="button" class="btn btn-danger btn-sm" data-dismiss="modal">
                            Close
                        </button>
                        <button type="submit" id="userAddConfirmBtn" class="btn btn-sm btn-success">Save</button>
                    </div>

                </form>
            </div>
        </div>
    </div>


    <div class="modal fade" id="editMenuModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
         aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header text-center">
                    <h4 class="modal-title w-100 font-weight-bold">Edit</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form  action="/mayorEdit" method="POST" class="m-5 loginForm" enctype="multipart/form-data">
                    @csrf
                    <div class="modal-body mx-3">
                        <div class="md-form">
                            <label class="m-2">Name:</label>

                            <input   placeholder="Name" name="name" type="text" id="edit_name" class="form-control validate">
                            <input   placeholder="" name="mayor_id" type="hidden" id="mayor_id" class="form-control validate">
                            <input   placeholder="" name="old_image" type="hidden" id="old_image" class="form-control validate">

                        </div>


                        <div class="md-form">
                            <label class="m-2">Designation:</label>

                            <input   placeholder="Designation" name="designation" type="text" id="edit_designation" class="form-control validate">

                        </div>

                        <div class="md-form">
                            <label class="m-2">Mobile No:</label>

                            <input   placeholder="Mobile" name="mobile" type="number" id="edit_mobile" class="form-control validate">

                        </div>



                        <div class="md-form">
                            <label class="m-2">Image:</label>
                            <input   placeholder="" name="image" type="file" id="image" class="form-control validate">
                        </div>




                    </div>
                    <div class="modal-footer d-flex justify-content-center">
                        <button type="button" class="btn btn-danger btn-sm" data-dismiss="modal">
                            Close
                        </button>
                        <button type="submit" id="userAddConfirmBtn" class="btn btn-sm btn-success">Save</button>
                    </div>

                </form>
            </div>
        </div>
    </div>


@endsection

@section('script')



    <script type="text/javascript">


        $('#addFormBtn').click(function () {
            $('#addModal').modal('show');
        })








    </script>


@endsection
