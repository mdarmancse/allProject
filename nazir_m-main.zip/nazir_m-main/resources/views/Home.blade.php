@extends('layout.app')
@section('content')


        @include('components.notice')
        @include('components.pm')
        @include('components.caro')
        @include('layout.web_footer')


@endsection

@section('script')


@endsection
