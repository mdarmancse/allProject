<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/2.9.3/umd/popper.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.0.1/js/bootstrap.min.js"></script>
<div id="main-wrapper " class="container">

    <div class="head col-12 ">
        <div class="row">
            <div class="col-4 slide-panel-btns" style="">
                <a style="color: white;font-size:.9em;" href="http://www.bangladesh.gov.bd/" target="_blank">বাংলাদেশ জাতীয় তথ্য বাতায়ন</a>
            </div>
                    <div class=" col-4 slide-panel-btns" style="float: left;width: 200px;height: 30px">
                        <select class="form-select" aria-label="Default select example" style="width:100px;border-radius: 4px;height: 25px;" >

                            <option value="1">One</option>
                            <option value="2">Two</option>
                            <option value="3">Three</option>
                        </select>
                        &nbsp;<button type="submit" style="height: 23px" class="btn btn-success btn-sm">Go</button>
                    </div>
            <div class="col-4  slide-panel-btns" style="">
                <form action="" style="float: right;">
                    <input class="input-xs" style="width:90px;border-radius: 4px;height: 25px;" id="search" name="key" value="" />

                    &nbsp;<button type="submit" style="height: 25px" class="btn btn-success btn-sm"><i class="fas fa-search"></i></button>
                    {{--                    <button class="btn-sm btn btn-success" type="submit" style="margin: 0;padding: 1px 10px">Search</button>--}}
                </form>

            </div>
        </div>











    </div>

<div class="carousel_div">
    <div id="carouselExampleInterval" class="carousel slide" data-ride="carousel">
        <div class="header-site-info row d-md-block d-none">
            <img id="logo" src="{{asset('images/logo.jpg')}}" alt="" width="110" height="">
            <h1 id="logo_title" class="font-weight-bold">নাজিরহাট পৌরসভা</h1>
        </div>
        <div class="carousel-inner">
            <div class="carousel-item active" data-interval="10000">
                <img src="https://cdn.pixabay.com/photo/2021/11/11/20/49/sauerland-6787215_960_720.jpg" class="d-block w-100 img-fluid" alt="...">
            </div>
            <div class="carousel-item" data-interval="2000">
                <img src="https://cdn.pixabay.com/photo/2021/11/17/10/39/kangaroo-6803201_960_720.jpg" class="d-block w-100 img-fluid" alt="...">
            </div>
            <div class="carousel-item">
                <img src="https://cdn.pixabay.com/photo/2021/11/17/10/39/kangaroo-6803201_960_720.jpg" class="d-block w-100 img-fluid" alt="...">
            </div>
        </div>
        <a class="carousel-control-prev" href="#carouselExampleInterval" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleInterval" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>
</div>

    <div class="">
    <nav class="navbar navbar-expand-lg navbar-dark bg-darkred">
  <div class="container-fluid">

    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavDropdown">
      <ul class="navbar-nav mr-auto">
        <li class="nav-item {{ (request()->is('/')) ? 'active active_menu' : '' }}" >
          <a class="nav-link menu" href="{{url('/')}}">প্রথম পাতা</a>
        </li>
        @foreach($nav_menu as $menu)
          @if(! $menu->submenu->isEmpty())
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle menu" href="#" data-bs-toggle="dropdown">{{$menu->title}}</a>
              <ul class="dropdown-menu">
                @foreach($menu->submenu as $sub)
                  <li><a class="dropdown-item menu" href="{{url('/viewpage/'.$sub->id)}}">{{$sub->sub_menu_name}}</a></li>
                @endforeach
              </ul>
            </li>
          @else
            <li class="nav-item {{ (request()->is('/page')) ? 'active active_menu' : '' }}">
              <a class="nav-link menu" href="{{url('/page/'.$menu->id)}}">{{$menu->title}}</a>
            </li>
          @endif
        @endforeach

        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle menu" href="#" data-bs-toggle="dropdown"> বাজেট ও প্রকল্প</a>
          <ul class="dropdown-menu">
            <li class="nav-item {{ (request()->is('/all_budget')) ? 'active active_menu' : '' }}">
              <a class="dropdown-item menu" href="{{url('/all_budget')}}">পৌরসভার বাজেট সমূহ</a>
            </li>
            <li class="nav-item {{ (request()->is('/all_project')) ? 'active active_menu' : '' }}">
              <a class="dropdown-item menu" href="{{url('/all_project')}}">পৌরসভার চলমান প্রকল্প সমূহ</a>
            </li>
          </ul>
        </li>
      </ul>
    </div>
  </div>
</nav>

{{--        <nav class="navbar navbar-expand-lg navbar-dark bg-darkred">--}}

{{--            <div class="collapse navbar-collapse" id="navbarText">--}}
{{--                <ul class="navbar-nav mr-auto">--}}



{{--                    <li class="nav-item dropdown ">--}}
{{--                        <a class="nav-link  dropdown-toggle menu" href="#" data-bs-toggle="dropdown"> গ্যালারি</a>--}}
{{--                        <ul class="dropdown-menu">--}}
{{--                            <li><a class="dropdown-item menu" href="#"> ফটোগ্যালারি</a></li>--}}
{{--                            <li><a class="dropdown-item menu" href="#"> ভিডিও গ্যালারি </a></li>--}}

{{--                        </ul>--}}
{{--                    </li>--}}
{{--                    <li class="nav-item dropdown ">--}}
{{--                        <a class="nav-link  dropdown-toggle menu" href="#" data-bs-toggle="dropdown"> যোগাযোগ</a>--}}
{{--                        <ul class="dropdown-menu">--}}
{{--                            <li><a class="dropdown-item menu" href="#"> মতামত ও পরামর্শ</a></li>--}}

{{--                        </ul>--}}
{{--                    </li>--}}
{{--                    <li class="nav-item dropdown ">   <a class="nav-link menu  " href="https://mujib100.gov.bd/index_bn.html" target="_blank" data-bs-toggle=""> কোভিড-১৯ ট্র্যাকার</a></li>--}}


{{--                </ul>--}}



{{--            </div>--}}
{{--        </nav>--}}

        <div class="sidenav">
            <div class=" na-board-bg">
                <h5 class="bk-org  title">
                    জাতীয় সংগীত
                </h5>
                <audio controls="" style="width:100%">
                    <source src="{{asset('audio/amar_sonar_bangla.mp3')}}" type="audio/mp3">
                </audio>
            </div>
            <div class=" social">

                <h5 class="bk-org  title">
                    মেয়র
                </h5>
                <img style="height:100%; width:100%"  alt="মেয়র" src="{{$mayor->image ? $mayor->image:asset('images/user.png')}}" />


            </div>
            <div class="social">

                <h5 class="bk-org  title">
                    হটলাইন
                </h5>
                <img alt="hotline" src="{{asset('images/placeholder.png')}}" style="height:100%; width:100%">


            </div>
            <div class=" social">

                <h5 class="bk-org  title">
                    নাজিরহাট পৌরসভা মানচিত্র
                </h5>
                <img alt="মেয়র" src="{{asset('images/map.jpg')}}" style="height:100%; width:100%">

            </div>
            <div class="social">


                <h5 class="bk-org">
                    ফেসবুক পেইজ
                </h5>
                <p style="text-align: center;"><iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2FChittagong4353%2F&tabs=timeline&width=350&height=180&small_header=true&adapt_container_width=true&hide_cover=false&show_facepile=false&appId" width="350" height="180" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowfullscreen="true" allow="autoplay; clipboard-write; encrypted-media; picture-in-picture; web-share"></iframe></p>

            </div>

            <div class="social">

                <h5 class="bk-org  title">
                    কেন্দ্রীয় ই-সেবা
                </h5>
                <ul>
                    <li><a style="color: black;font-size: 17px" href="" title="ওয়েব মেইল">ওয়েব মেইল</a></li>
{{--                    <li><a style="color: black;font-size: 14px" href="" title="ওয়েব মেইল">ওয়েব মেইল</a></li>--}}
                </ul>
            </div>
            <div class="social">

                <h5 class="bk-org  title">
                    গুরুর্তপূর্ন লিঙ্ক সমূহ
                </h5>
                <ul>
                    <li><a style="color: black;font-size: 17px" href="" title="লিঙ্কসমূহ"></a>লিঙ্কসমূহ</li>
                    {{--                    <li><a style="color: black;font-size: 14px" href="" title="ওয়েব মেইল">ওয়েব মেইল</a></li>--}}
                </ul>
            </div>

            <div class="social">

                <h5 class="bk-org  title">
                    জরুরি হটলাইন
                </h5>
                <img alt="
  জরুরি হটলাইন
  " src="{{asset('images/hotline.jpg')}}" style="height:100%; width:100%">



            </div>
        </div>

        <div class="main_div">











