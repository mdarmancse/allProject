<div class="main_div col-12">
  <img class="footer_img_1" src="{{asset('images/footer_top_bg.png')}}" alt="Footer Top Background">
  <div class="footer_div_2 row justify-content-between align-items-center">
    <div class="col-12 col-md-6 order-md-1 mb-3 mb-md-0" style="font-size: .9em; text-align: center; ">
      সাইটটি শেষ হাল-নাগাদ করা হয়েছে: <span style="font-style: italic;">২০২১-১২-৭ ১১:৫১:১৮</span>
      <!--<span><a href="http://support.portal.gov.bd/" style="color: green" target="_blank"> | <u>হেল্পডেস্ক</u></a></span>-->
    </div>
    <div class="col-12 col-md-6 order-md-2 text-md-right" style="font-size: .9em; ">
      <p style="margin-bottom: .5rem;">
        পরিকল্পনা ও বাস্তবায়নে:
        <a href="http://www.cabinet.gov.bd/" title="মন্ত্রিপরিষদ বিভাগ">মন্ত্রিপরিষদ বিভাগ</a>,
        <a href="https://a2i.gov.bd" title="এটুআই">এটুআই</a>,
        <a href="http://www.bcc.net.bd/" title="বিসিসি">বিসিসি</a>,
        <a href="http://doict.gov.bd/" title="ডিওআইসিটি">ডিওআইসিটি</a> ও
        <a href="http://www.basis.org.bd/" title="বেসিস">বেসিস</a>।
      </p>
      <p style="margin-bottom: .5rem;">
        কারিগরি সহায়তায়:
        <img style="vertical-align: baseline; max-width: 100%;" src="{{asset('images/karigori.png')}}" alt="Karigori Logo">
      </p>
    </div>
  </div>
</div>
