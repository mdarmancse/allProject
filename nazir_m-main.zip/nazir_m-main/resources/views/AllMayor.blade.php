@extends('layout.app')
@section('content')





        <div class="row">
            <div class="col-md-12">

                <h4 class="modal-title w-10 font-weight-bold">মেয়র,কাউন্সিলর গণের নাম ও মোবাইল নম্বরঃ</h4><hr>
                <div class="container">


                    <div class="row ">
                        @foreach($result as $dt)
                            @if($loop->first)


                        <div class="col-lg-12 col-md-12 col-sm-6 justify-content-md-center" >
                            <center>
                            <div class="our-team-main ">
                                <div class="pic">
                                    <img  src="{{$dt->image ? $dt->image:asset('images/user.png')}}" />
                                </div>
                                <h3 class="title">{{$dt->name}}</h3>
                                <span class="sub-title">{{$dt->designation}}</span>
                                <span class="post">{{$dt->mobile}}</span>

                            </div>
                                </center>
                        </div>


                            @else

                                <div class="col-md-4 col-sm-6 pt-3 pb-3">
                                    <div class="our-team">
                                        <div class="pic">
                                            <img  src="{{$dt->image ? $dt->image:asset('images/user.png')}}" />
                                        </div>
                                        <h3 class="title">{{$dt->name}}</h3>
                                        <span class="sub-title">{{$dt->designation}}</span>
                                        <span class="post">{{$dt->mobile}}</span>

                                    </div>
                                </div>

                            @endif
                        @endforeach


                    </div>


                </div>


            </div>
        </div>

        @include('layout.web_footer')












@endsection

@section('script')



    <script type="text/javascript">



   //     $('#userDataTable').DataTable();











    </script>


@endsection
