@extends('layout.app')
@section('content')





        <div class="row">
            <div class="col-md-12">

                <h4 class="modal-title w-10 font-weight-bold">সকল নোটিশ</h4><hr>

                <table id="table" class="table table-striped table-sm table-bordered" cellspacing="0" width="100%">

                    <thead>
                    <tr>
                        <th class="th-sm text-center font-weight-bold">ক্রমিক</th>
                        <th class="th-sm text-center font-weight-bold">শিরোনাম</th>
                        <th class="th-sm text-center text-center font-weight-bold">প্রকাশের তারিখ</th>
                        <th class="th-sm text-center text-center font-weight-bold">ডাউনলোড</th>



                    </tr>
                    </thead>
                    <tbody id="user_table">
                    @php
                    $sl=0;
                    @endphp

                    @foreach($data as $dt)

                     @php
                     $sl++
                     @endphp

                        <tr>
                            <td class="text-center ">{{$sl}}</td>
                          <td class="text-center "> <a href="{{url('/viewnotice/'.$dt->id)}}">{{$dt->title}}</a></td>
                            <td class="text-center ">{{$dt->date_time}}</td>
                            <td class="text-center "><a href="{{$dt->file}}"><i class="fas fa-download"></i> </a></td>

                        </tr>

                    @endforeach





                    </tbody>
                </table>

            </div>
        </div>
        @include('layout.web_footer')












@endsection

@section('script')



    <script type="text/javascript">



   //     $('#userDataTable').DataTable();











    </script>


@endsection
