@extends('layout.app')
@section('content')


    <div class="twelve columns" id="left-content">
{{--        <div id="print_btn_div"><img src="{{asset('images/print_btn.png')}}" style="cursor: pointer;" onclick="print_content();" width="24" title="প্রিন্ট" /></div>--}}
<div id='printable_area'><h4 class="modal-title w-10 font-weight-bold">{{$page->sub_menu_name}}</h4><hr>
{{--    <h3 class="modal-title w-10 font-weight-bold"> <u>{{$page->sub_menu_name}}</u> </h3>--}}


    <img class="center"  style="float: right;margin: 10px" src="{{$page->sub_image}}">


    <p style="text-align: justify;">   {!! $page->content !!}</p>


    </div>



    @include('layout.web_footer')


@endsection

@section('script')


@endsection
