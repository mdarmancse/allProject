@extends('layout.app')
@section('content')





        <div class="row">
            <div class="col-md-12">

                <h4 class="modal-title w-10 font-weight-bold">কর্মকর্তাবৃন্দের তালিকা </h4><hr>
                @php
                    $sl=0;
                @endphp

                @foreach($result as $dt)
                <table id="table" class="table table-striped table-sm table-bordered" cellspacing="0" width="100%">
                    <tr>
                        <td rowspan="3" width="200px"><img style="width: 50%;height: 100%" src="{{$dt->image ? $dt->image:asset('images/user.png')}}" /></td>
                        <th>নামঃ</th>
                        <th>{{$dt->name}}</th>

                    </tr>
                    <tr>
                        <td rowspan="1">পদবিঃ</td>
                        <td>{{$dt->designation}}</td>

                    </tr>
                    <tr>
                        <td rowspan="2">মোবাইল নম্বরঃ</td>
                        <td>{{$dt->mobile}}</td>

                    </tr>

                </table>
                @endforeach

{{--                <table id="table" class="table table-striped table-sm table-bordered" cellspacing="0" width="100%">--}}


{{--                    <tbody id="user_table">--}}
{{--                    @php--}}
{{--                        $sl=0;--}}
{{--                    @endphp--}}
{{--                    @foreach($result as $dt)--}}
{{--                        @php--}}
{{--                            $sl++--}}
{{--                        @endphp--}}
{{--                        <tr>--}}
{{--                            <td class="text-center" rowspan="2">{{$sl}}</td>--}}
{{--                            <td class="text-center " rowspan="2" width="200px"><img style="width: 50%;height: 100%" src="{{$dt->image ? $dt->image:asset('images/user.png')}}" /></td>--}}
{{--                            <td class="text-center " rowspan="2">{{$dt->name}}</td>--}}
{{--                            <td>s   </td>--}}
{{--                            <td>   ds</td>--}}
{{--                            <td class="text-center ">{{$dt->designation}}</td>--}}
{{--                            <td class="text-center ">{{$dt->mobile}}</td>--}}

{{--                        </tr>--}}

{{--                    @endforeach--}}





{{--                    </tbody>--}}
{{--                </table>--}}

            </div>
        </div>

        @include('layout.web_footer')












@endsection

@section('script')



    <script type="text/javascript">



   //     $('#userDataTable').DataTable();











    </script>


@endsection
