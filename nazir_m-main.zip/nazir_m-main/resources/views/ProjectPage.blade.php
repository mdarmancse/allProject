@extends('layout.app')
@section('content')


    <div class="twelve columns" id="left-content">
{{--        <div id="print_btn_div"><img src="{{asset('images/print_btn.png')}}" style="cursor: pointer;" onclick="print_content();" width="24" title="প্রিন্ট" /></div>--}}
<div id='printable_area'><h4 class="modal-title w-10 font-weight-bold">বাজেট</h4><hr>
            <a href="{{$result->file}}"><h3><i class="fas fa-download"></i> {{$result->title}}</h3></a>


            <div class="viewer" style="background-color: rgb(255, 255, 255); width: 720px;"><iframe width="720" height="1000" src="{{$result->file}}"></iframe></div>




    </div>



    @include('layout.web_footer')


@endsection

@section('script')


@endsection
