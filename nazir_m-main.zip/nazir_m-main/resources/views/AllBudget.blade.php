@extends('layout.app')
@section('content')





        <div class="row">
            <div class="col-md-12">

                <h4 class="modal-title w-10 font-weight-bold">এক নজরে নাজিরহাট পৌরসভার বাস্তবায়িত ও বাস্তবাইয়িতব্য উন্নয়মূলক কাজের বিবরণী</h4><hr>

                <table id="table" class="table table-striped table-sm table-bordered" cellspacing="0" width="100%">

                    <thead>
                    <tr>
                        <th class="th-sm text-center font-weight-bold">ক্রমিক</th>
                        <th class="th-sm text-center font-weight-bold"> অর্থ বছর</th>
                        <th class="th-sm text-center font-weight-bold">খাতের নাম</th>
                        <th class="th-sm text-center font-weight-bold">প্রকল্প সংখ্যা</th>
                        <th class="th-sm text-right font-weight-bold">টাকার পরিমাণ</th>
                        <th class="th-sm text-center font-weight-bold">মন্তব্য</th>
{{--                        <th class="th-sm text-center text-center font-weight-bold">File</th>--}}



                    </tr>
                    </thead>
                    <tbody id="user_table">

                    @php
                    $total=0;
                        $sl=1;
                    @endphp

                    @foreach($result as $item)

                        @php
                            $cc= $item->budgets->count();

                        @endphp



                        @if($cc > 0)

                            <tr >
                                <td class="text-center"  rowspan="{{count($item->budgets)}}">{{$sl++}}</td>

                                <td class="text-center "  rowspan="{{count($item->budgets)}}">{{$item->finance_year}}</td>



                                @php

                                    $i=0;
                                    $j=0;


                foreach ($item->budgets as $key=>$value)


                  {

                  if (fmod($i,3)) echo '<tr>';
                  echo '<td class="text-center">',$value->title,'</td>';
                  echo '<td class="text-center">',$value->project_number,'</td>';
                  echo '<td class="text-right">',number_format($value->amount,2),'</td>';
                  echo '<td class="text-center">',$value->notes,'</td>';


                  if (fmod($i,3)) echo '</tr>';

                  $i++;


                      $total= $value->sum('amount');

                  }





                                @endphp

                            </tr>
                        @endif




                    @endforeach






                    </tbody>
                    <tfoot>



                    <tr>
                        <th colspan="4" class="text-right">সর্বমোট</th>
                        <th colspan="1" class="text-right">{{number_format($total,2)}}</th>
                    </tr>
                    </tfoot>
                </table>

            </div>
        </div>
        <div class="row">
            <div class="col-md-12">

                <h4 class="modal-title w-10 font-weight-bold text-center ">সরকার প্রদত্ত টি, আর খাতে বরাদ্দ অর্থ</h4><hr>

                <table id="table" class="table table-striped table-sm table-bordered" cellspacing="0" width="100%">

                    <thead>
                    <tr>
                        <th class="th-sm text-center font-weight-bold">ক্রমিক</th>
                        <th class="th-sm text-center font-weight-bold"> অর্থ বছর</th>
                        <th class="th-sm text-center font-weight-bold">খাতের নাম</th>
                        <th class="th-sm text-center  font-weight-bold">প্রকল্প সংখ্যা</th>
                        <th class="th-sm text-right  font-weight-bold">টাকার পরিমাণ</th>
                        <th class="th-sm text-center font-weight-bold">মন্তব্য</th>
{{--                        <th class="th-sm text-center text-center font-weight-bold">File</th>--}}



                    </tr>
                    </thead>
                    <tbody id="user_table">

                    @php
                        $sl=1;
                        $total=0;
                    @endphp

                    @foreach($result_d as $item)

                        @php
                            $c= $item->donations->count();

                        @endphp



                        @if($c > 0)

                            <tr >
                                <td class="text-center"  rowspan="{{count($item->donations)}}">{{$sl++}}</td>

                                <td class="text-center "  rowspan="{{count($item->donations)}}">{{$item->finance_year}}</td>



                                @php

                                    $i=0;
                                    $j=0;


                foreach ($item->donations as $key=>$value)

                  {

                  if (fmod($i,3)) echo '<tr>';
                  echo '<td class="text-center">',$value->title,'</td>';
                  echo '<td class="text-center">',$value->project_number,'</td>';
                  echo '<td class="text-right">',number_format($value->amount,2),'</td>';
                  echo '<td class="text-center">',$value->notes,'</td>';


                  if (fmod($i,3)) echo '</tr>';

                  $i++;
                    $total= $value->sum('amount');
                  }





                                @endphp

                            </tr>
                        @endif




                    @endforeach






                    </tbody>
                    <tfoot>



                    <tr>
                        <th colspan="4" class="text-right">সর্বমোট</th>
                        <th colspan="1" class="text-right">{{number_format($total,2)}}</th>
                    </tr>
                    </tfoot>
                </table>

            </div>
        </div>


        @if(!empty($files))
            <div class="row " >
                <div class="col-sm-12 col-md-12 col-lg-12 col-xs-12 " >
                    <h4 class="modal-title w-10 font-weight-bold text-center ">বাজেটসমূহ</h4><hr>

                    <div id="n">
                        <ul>
                            @foreach($files as $nt)
                                @if(!empty($nt->b_title))
                                <li>
                                    <a href="{{url('/viewBudget/'.$nt->id)}}">{{$nt->b_title}}</a>
                                </li>
                                @endif
                            @endforeach

                        </ul>

                    </div>
                </div>
                @endif

        @include('layout.web_footer')












@endsection

@section('script')



    <script type="text/javascript">



   //     $('#userDataTable').DataTable();











    </script>


@endsection
