<?php


use Illuminate\Support\Facades\Session;

class Auth{

    static function id(){
        return Session::get('id');
    }
    static function user(){
        $id=Session::get('id');
        return \App\User::where('id',$id)->first();
    }
    static function check(){
        return Session::get('user',true);
    }
    static function logout(){
        return \session()->flush();
    }

}
