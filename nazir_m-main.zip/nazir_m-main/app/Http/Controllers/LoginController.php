<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\AdminModel;
use App\Http\Middleware\LoginCheckMiddleware;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Redirect;


class LoginController extends Controller
{
    function LoginIndex(){
        return view('Login');

    }

    function AdminHome(){

        return view('admin/add_notice');

    }
    function onLogout(Request $request){
        $request->session()->flush();
        return redirect('/login');


    }


    function onLogin(Request $request){

        $userr= $request->input('userName');


        $user = AdminModel::where([
            'email' => $request->input('userName'),
            'password' => md5($request->input('userPassword'))
        ])->first();

        //dd($user);
        if ($user) {
            $request->session()->put('user',$userr);
            return Redirect::to("/AdminHome");
        }else{
            return redirect()->back()->withError('Login Fail!! Try again!!');
        }

        /*
        Feature of Custom login
        //Middleware checking name must be "user" ex: session->has('user') return $request(next)
        \Auth::user()->name;
        \Auth::user()->email;
        \Auth::user()->image; //if store in database image field
        \Auth::id();
        \Auth::check();
        \Auth::logout();
        */





    }
}
