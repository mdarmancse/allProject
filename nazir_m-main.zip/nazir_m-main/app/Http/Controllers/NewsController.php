<?php

namespace App\Http\Controllers;

use App\NewsModel;
use App\NoticeModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class NewsController extends Controller
{
    function news(){

        $result = NewsModel::orderBy('id','desc')->get();

        $data=[
            'data' =>$result
        ];

        //    dd($data);die();


        return view('admin/add_news',$data);
    }
    function edit_news(Request $request){
        $id=$request->input('id');
        $result=json_encode(NewsModel::where('id','=',$id)->get());
        return $result;


    }

    function news_delete($id){



        $file=NewsModel::where('id',$id)->get(['image']);


        if (file_exists($file)) {
            $file_path = explode('/', $file[0]['image'])[4];


            Storage::delete('public/' . $file_path);
        }


        $result = NewsModel::where('id',$id)->delete();

        if ($result == true) {
            return redirect('/news')->withSuccess('News Deleted!!');
        } else {
            return redirect()->back()->withError('Failed!!');
        }

        // return view('admin/add_notice');
    }


    function newsAdd(Request $request)
    {
        $title=$request->input('title');
        $content=$request->input('content');
        $date_time=date("Y-m-d H:i:s");

        if ($request->file('image')) {
            $filePath = $request->file('image')->store('public');

            $fileName = (explode('/', $filePath))[1];

            $host = $_SERVER['HTTP_HOST'];

            $file_location = 'https://' . $host . '/storage/app/public/' . $fileName;
        }else{
            $file_location='';
        }
        $result = NewsModel::insert(['title'=>$title,'content'=>$content,'image'=>$file_location,'date_time'=>$date_time]);
        if ($result == true) {
            return redirect('/news')->withSuccess('News Added!!');
        } else {
            return redirect()->back()->withError('Failed!!');
        }

    }
    function newsEdit(Request $request)
    {
        $title=$request->input('title');
        $content=$request->input('content');
        $old_image=$request->input('old_image');
        $id=$request->input('news_id');

        if ($request->file('image')) {
            $filePath = $request->file('image')->store('public');

            $fileName = (explode('/', $filePath))[1];

            $host = $_SERVER['HTTP_HOST'];

            $file_location = 'https://' . $host . '/storage/app/public/' . $fileName;
        }else{
            $file_location=$old_image;
        }
        $result = NewsModel::where('id',$id)->update(['title'=>$title,'content'=>$content,'image'=>$file_location]);
        if ($result == true) {
            return redirect('/news')->withSuccess('News Updated!!');
        } else {
            return redirect()->back()->withError('Failed!!');
        }

    }


}
