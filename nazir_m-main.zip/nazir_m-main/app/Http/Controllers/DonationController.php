<?php

namespace App\Http\Controllers;

use App\finance_year;
use App\Donation;
use Illuminate\Http\Request;

class DonationController extends Controller
{
    function donation(){

        $data['result'] = finance_year::with('donations')->get();

//        dd($data);
        return view('admin/add_donation',$data);
    }

    function donationAdd(Request $request)
    {
        $year_id=$request->input('year_id');
        $name=$request->input('name');
        $project_number=$request->input('project_number');
        $total_amount=$request->input('total_amount');
        $notes=$request->input('notes');

        if ($request->file('image')) {
            $filePath = $request->file('image')->store('public');

            $fileName = (explode('/', $filePath))[1];

            $host = $_SERVER['HTTP_HOST'];

            $file_location = 'https://' . $host . '/storage/app/public/' . $fileName;
        }else{
            $file_location='';
        }
        $result = Donation::insert([

            'title'=>$name,
            'finance_year_id'=>$year_id,
            'project_number'=>$project_number,
            'amount'=>$total_amount,
            'file'=>$file_location,
            'notes'=>$notes,

        ]);
        if ($result == true) {
            return redirect('/donation')->withSuccess('Successfully Added!!');
        } else {
            return redirect()->back()->withError('Failed!!');
        }

    }

    function donationEdit(Request $request)
    {
        $id=$request->input('donation_id');
        $year_id=$request->input('year_id');
        $name=$request->input('name');
        $project_number=$request->input('project_number');
        $total_amount=$request->input('total_amount');
        $notes=$request->input('notes');
        $old_image=$request->input('old_image');

        if ($request->file('image')) {
            $filePath = $request->file('image')->store('public');

            $fileName = (explode('/', $filePath))[1];

            $host = $_SERVER['HTTP_HOST'];

            $file_location = 'https://' . $host . '/storage/app/public/' . $fileName;
        }else{
            $file_location=$old_image;
        }
        $result = Donation::where('id',$id)->update([

            'title'=>$name,
            'finance_year_id'=>$year_id,
            'project_number'=>$project_number,
            'amount'=>$total_amount,
            'file'=>$file_location,
            'notes'=>$notes,

        ]);
        if ($result == true) {
            return redirect('/donation')->withSuccess('Successfully Updated!!');
        } else {
            return redirect()->back()->withError('Failed!!');
        }

    }


    function donation_delete($id){
        $file=Donation::where('id',$id)->get(['file']);


        if (file_exists($file)){
            $file_path=explode('/',$file[0]['file'])[4];
            Storage::delete('public/'.$file_path);

        }

        $result = Donation::where('id',$id)->delete();

        if ($result == true) {

            return redirect('/donation')->withSuccess('Successfully Deleted!!');
        } else {
            return redirect()->back()->withError('Failed!!');
        }

        // return view('admin/add_notice');
    }

    function edit_donation(Request $request){
        $id=$request->input('id');
        $result=json_encode(Donation::where('id','=',$id)->get());
        return $result;


    }
}
