<?php

namespace App\Http\Controllers;

use App\NoticeModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class NoticeController extends Controller
{
    function notice(){

        $result = NoticeModel::orderBy('id','desc')->get();

        $data=[
            'data' =>$result
        ];
        return view('admin/add_notice',$data);
    }

    function edit_notice(Request $request){
        $id=$request->input('id');
        $result=json_encode(NoticeModel::where('id','=',$id)->get());
        return $result;


    }

    function notice_delete($id){

        $file=NoticeModel::where('id',$id)->get(['file']);

        if (file_exists($file)){
            $file_path=explode('/',$file[0]['file'])[4];


            Storage::delete('public/'.$file_path);

        }


        $notice = NoticeModel::where('id',$id)->delete();

        if ($notice == true) {
            return redirect('/notice')->withSuccess('Notice Deleted!!');
        } else {
            return redirect()->back()->withError('Failed!!');
        }

        // return view('admin/add_notice');
    }

    function noticeAdd(Request $request)
    {
        $title=$request->input('title');
        //$file=$request->input('file');
        $date_time=date("Y-m-d H:i:s");

        if ($request->file('image')) {
            $filePath = $request->file('image')->store('public');

            $fileName = (explode('/', $filePath))[1];

            $host = $_SERVER['HTTP_HOST'];

            $file_location = 'https://' . $host . '/storage/app/public/' . $fileName;
        }else{
            $file_location='';
        }

        $result = NoticeModel::insert(['title'=>$title,'file'=>$file_location,'date_time'=>$date_time]);
        if ($result == true) {
            return redirect('/notice')->withSuccess('Notice Added!!');
        } else {
            return redirect()->back()->withError('Failed!!');
        }

    }
    function noticeEdit(Request $request)
    {
        $title=$request->input('title');
        $id=$request->input('notice_id');
        $old_image=$request->input('old_image');

        if ($request->file('image')) {
            $filePath = $request->file('image')->store('public');

            $fileName = (explode('/', $filePath))[1];

            $host = $_SERVER['HTTP_HOST'];

            $file_location = 'https://' . $host . '/storage/app/public/' . $fileName;
        }else{
            $file_location=$old_image;
        }

        $result = NoticeModel::where('id',$id)->update(['title'=>$title,'file'=>$file_location]);
        if ($result == true) {
            return redirect('/notice')->withSuccess('Notice Updated!!');
        } else {
            return redirect()->back()->withError('Failed!!');
        }

    }
}
