<?php

namespace App\Http\Controllers;

use App\MenuModel;
use App\NewsModel;
use App\SubMenuModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

class MenuController extends Controller
{
    function menu(){

      $data['result'] = MenuModel::with('submenu')->get();

    //  dd($data);

        return view('admin/add_menu',$data);
    }

    function menu_delete($id){

        $file=MenuModel::where('id',$id)->get(['image']);


        if (file_exists($file)) {
            $file_path = explode('/', $file[0]['image'])[4];


            Storage::delete('public/' . $file_path);
        }


        $result = MenuModel::where('id',$id)->delete();

        if ($result == true) {
            $file_sub=SubMenuModel::where('menu_id',$id)->get(['image']);


            $file_path_sub=explode('/',$file_sub[0]['sub_image'])[4];


            Storage::delete('public/'.$file_path_sub);

            SubMenuModel::where('menu_id',$id)->delete();
            return redirect('/menu')->withSuccess('Menu Deleted!!');
        } else {
            return redirect()->back()->withError('Failed!!');
        }

        // return view('admin/add_notice');
    }


    function menuAdd(Request $request)
    {
        $title=$request->input('menu_name');
        $sub_title=$request->input('sub_title');
        $content=$request->input('content');
        $menu_id=date('Ymdhs');
        if ($request->file('image')) {
            $filePath = $request->file('image')->store('public');

            $fileName = (explode('/', $filePath))[1];

            $host = $_SERVER['HTTP_HOST'];

            $file_location = 'https://' . $host . '/storage/app/public/' . $fileName;
        }else{
            $file_location='';
        }

        $result = MenuModel::insert(['title'=>$title,'menu_id'=>$menu_id,'sub_title'=>$sub_title,'content'=>$content,'image'=>$file_location,'status'=>1]);
        if ($result == true) {
            return redirect('/menu')->withSuccess('Menu Added!!');
        } else {
            return redirect()->back()->withError('Failed!!');
        }

    }
    function menuEdit(Request $request)
    {
        $id=$request->input('menu_id');
        $old_image=$request->input('old_image');
        $title=$request->input('menu_name');
        $content=$request->input('content');
        $sub_title=$request->input('sub_title');
        if ($request->file('image')) {
            $filePath = $request->file('image')->store('public');

            $fileName = (explode('/', $filePath))[1];

            $host = $_SERVER['HTTP_HOST'];

            $file_location = 'https://' . $host . '/storage/app/public/' . $fileName;
        }else{
            $file_location=$old_image;
        }

        $result = MenuModel::where('id',$id)->update(['title'=>$title,'sub_title'=>$sub_title,'content'=>$content,'image'=>$file_location,'status'=>1]);
        if ($result == true) {
            return redirect('/menu')->withSuccess('Menu Updated!!');
        } else {
            return redirect()->back()->withError('Failed!!');
        }

    }

    function edit_menu(Request $request){
        $id=$request->input('id');
        $result=json_encode(MenuModel::where('id','=',$id)->get());
        return $result;


    }
    function sub_menuAdd(Request $request)
    {
        $sub_menu=$request->input('sub_menu');
        $menu_id=$request->input('menu_id');
        $content=$request->input('content');
        $sub_menu_id=date('Ymdhs');
    if ($request->file('image')) {
    $filePath = $request->file('image')->store('public');

    $fileName = (explode('/', $filePath))[1];

    $host = $_SERVER['HTTP_HOST'];

    $file_location = 'https://' . $host . '/storage/' . $fileName;
    }else{
        $file_location='';
    }
        $result = SubMenuModel::insert(['menu_id'=>$menu_id,'sub_menu_id'=>$sub_menu_id,'sub_menu_name'=>$sub_menu,'sub_image'=>$file_location,'content'=>$content,'status'=>1]);
        if ($result == true) {
            return redirect('/menu')->withSuccess('Sub Menu Added!!');
        } else {
            return redirect()->back()->withError('Failed!!');
        }

    }
    function sub_menuEdit(Request $request)
    {
        $sub_menu=$request->input('sub_menu');
        $content=$request->input('content');
        $sub_menu_id=$request->input('sub_menu_id');
        $sub_old_image=$request->input('sub_old_image');
    if ($request->file('image')) {
    $filePath = $request->file('image')->store('public');

    $fileName = (explode('/', $filePath))[1];

    $host = $_SERVER['HTTP_HOST'];

    $file_location = 'https://' . $host . '/storage/app/public/' . $fileName;
    }else{
        $file_location=$sub_old_image;
    }
        $result = SubMenuModel::where('id',$sub_menu_id)->update(['sub_menu_name'=>$sub_menu,'sub_image'=>$file_location,'content'=>$content,'status'=>1]);
        if ($result == true) {
            return redirect('/menu')->withSuccess('Sub Menu Updated!!');
        } else {
            return redirect()->back()->withError('Failed!!');
        }

    }


    function sub_delete($id){
        $file=SubMenuModel::where('id',$id)->get(['sub_image']);


        if (file_exists($file)){
         $file_path=explode('/',$file[0]['sub_image'])[4];


      Storage::delete('public/'.$file_path);

        }



        $result = SubMenuModel::where('id',$id)->delete();

        if ($result == true) {

            return redirect('/menu')->withSuccess('Sub-Menu Deleted!!');
        } else {
            return redirect()->back()->withError('Failed!!');
        }

        // return view('admin/add_notice');
    }

    function edit_submenu(Request $request){
        $sub_id=$request->input('id');
        $result=json_encode(SubMenuModel::where('id','=',$sub_id)->get());
        return $result;


    }


}




