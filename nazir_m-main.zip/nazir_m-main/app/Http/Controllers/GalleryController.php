<?php

namespace App\Http\Controllers;

use App\GalleryModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class GalleryController extends Controller
{
    function gallery(){

        $result = GalleryModel::orderBy('id','desc')->get();

        $data=[
            'data' =>$result
        ];

        //    dd($data);die();


        return view('admin/add_gallery',$data);
    }
    function edit_gallery(Request $request){
        $id=$request->input('id');
        $result=json_encode(GalleryModel::where('id','=',$id)->get());
        return $result;


    }

    function gallery_delete($id){

        $file=GalleryModel::where('id',$id)->get(['image']);


        if (file_exists($file)) {
            $file_path = explode('/', $file[0]['image'])[4];


            Storage::delete('public/' . $file_path);
        }

        $result = GalleryModel::where('id',$id)->delete();

        if ($result == true) {
            return redirect('/gallery')->withSuccess('Image Deleted!!');
        } else {
            return redirect()->back()->withError('Failed!!');
        }

        // return view('admin/add_notice');
    }


    function galleryAdd(Request $request)
    {
        $title=$request->input('title');


        if ($request->file('image')) {
            $filePath = $request->file('image')->store('public');

            $fileName = (explode('/', $filePath))[1];

            $host = $_SERVER['HTTP_HOST'];

            $file_location = 'https://' . $host . '/storage/app/public/' . $fileName;
        }else{
            $file_location='';
        }

        $result = GalleryModel::insert(['title'=>$title,'image'=>$file_location]);
        if ($result == true) {
            return redirect('/gallery')->withSuccess('Image Added!!');
        } else {
            return redirect()->back()->withError('Failed!!');
        }

    }
    function galleryEdit(Request $request)
    {
        $title=$request->input('title');
        $gallery_id=$request->input('gallery_id');
        $old_image=$request->input('old_image');


        if ($request->file('image')) {
            $filePath = $request->file('image')->store('public');

            $fileName = (explode('/', $filePath))[1];

            $host = $_SERVER['HTTP_HOST'];

            $file_location = 'https://' . $host . '/storage/app/public/' . $fileName;
        }else{
            $file_location=$old_image;
        }

        $result = GalleryModel::where('id',$gallery_id)->update(['title'=>$title,'image'=>$file_location]);
        if ($result == true) {
            return redirect('/gallery')->withSuccess('Image Changed!!');
        } else {
            return redirect()->back()->withError('Failed!!');
        }

    }
}
