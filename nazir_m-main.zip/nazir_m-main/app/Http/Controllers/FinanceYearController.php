<?php

namespace App\Http\Controllers;

use App\finance_year;
use Illuminate\Http\Request;

class FinanceYearController extends Controller
{
    function year(){

        $result = finance_year::orderBy('id','desc')->get();

        $data=[
            'data' =>$result
        ];
        return view('admin/add_year',$data);
    }

    function edit_year(Request $request){
        $id=$request->input('id');
        $result=json_encode(finance_year::where('id','=',$id)->get());
        return $result;


    }

    function year_delete($id){


        $year = finance_year::where('id',$id)->delete();

        if ($year == true) {
            return redirect('/year')->withSuccess('Successfully Deleted!!');
        } else {
            return redirect()->back()->withError('Failed!!');
        }

        // return view('admin/add_year');
    }

    function yearAdd(Request $request)
    {
        $title=$request->input('name');

        $result = finance_year::insert([
            'finance_year'=>$title]);
        if ($result == true) {
            return redirect('/year')->withSuccess('Successfully Added!!');
        } else {
            return redirect()->back()->withError('Failed!!');
        }

    }
    function yearEdit(Request $request)
    {
        $title=$request->input('name');

        $id=$request->input('year_id');




        $result = finance_year::where('id',$id)->update([
            'finance_year'=>$title,
           ]);
        if ($result == true) {
            return redirect('/year')->withSuccess('Successfully Updated!!');
        } else {
            return redirect()->back()->withError('Failed!!');
        }

    }
}
