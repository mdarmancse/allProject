<?php

namespace App\Http\Controllers;

use App\finance_year;
use App\Project;
use Illuminate\Http\Request;

class ProjectController extends Controller
{
    function project(){

        $data['result'] = finance_year::with('projects')->get();

//        dd($data);
        return view('admin/add_project',$data);
    }

    function projectAdd(Request $request)
    {
        $year_id=$request->input('year_id');
        $name=$request->input('name');
        $project_number=$request->input('project_number');
        $total_amount=$request->input('total_amount');
        $notes=$request->input('notes');

        if ($request->file('image')) {
            $filePath = $request->file('image')->store('public');

            $fileName = (explode('/', $filePath))[1];

            $host = $_SERVER['HTTP_HOST'];

            $file_location = 'https://' . $host . '/storage/app/public/' . $fileName;
        }else{
            $file_location='';
        }
        $result = Project::insert([

            'title'=>$name,
            'finance_year_id'=>$year_id,
            'project_number'=>$project_number,
            'amount'=>$total_amount,
            'file'=>$file_location,
            'notes'=>$notes,

        ]);
        if ($result == true) {
            return redirect('/project')->withSuccess('Successfully Added!!');
        } else {
            return redirect()->back()->withError('Failed!!');
        }

    }

    function projectEdit(Request $request)
    {
        $id=$request->input('project_id');
        $year_id=$request->input('year_id');
        $name=$request->input('name');
        $project_number=$request->input('project_number');
        $total_amount=$request->input('total_amount');
        $notes=$request->input('notes');
        $old_image=$request->input('old_image');

        if ($request->file('image')) {
            $filePath = $request->file('image')->store('public');

            $fileName = (explode('/', $filePath))[1];

            $host = $_SERVER['HTTP_HOST'];

            $file_location = 'https://' . $host . '/storage/app/public/' . $fileName;
        }else{
            $file_location=$old_image;
        }
        $result = Project::where('id',$id)->update([

            'title'=>$name,
            'finance_year_id'=>$year_id,
            'project_number'=>$project_number,
            'amount'=>$total_amount,
            'file'=>$file_location,
            'notes'=>$notes,

        ]);
        if ($result == true) {
            return redirect('/project')->withSuccess('Successfully Updated!!');
        } else {
            return redirect()->back()->withError('Failed!!');
        }

    }


    function project_delete($id){
        $file=Project::where('id',$id)->get(['file']);


        if (file_exists($file)){
            $file_path=explode('/',$file[0]['file'])[4];
            Storage::delete('public/'.$file_path);

        }

        $result = Project::where('id',$id)->delete();

        if ($result == true) {

            return redirect('/project')->withSuccess('Successfully Deleted!!');
        } else {
            return redirect()->back()->withError('Failed!!');
        }

        // return view('admin/add_notice');
    }

    function edit_project(Request $request){
        $id=$request->input('id');
        $result=json_encode(Project::where('id','=',$id)->get());
        return $result;


    }
}
