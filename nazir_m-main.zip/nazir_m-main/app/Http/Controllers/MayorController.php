<?php

namespace App\Http\Controllers;

use App\Mayor;
use Illuminate\Http\Request;

class MayorController extends Controller
{
    function mayor(){

        $result = Mayor::orderBy('id','desc')->get();

        $data=[
            'data' =>$result
        ];
        return view('admin/add_mayor',$data);
    }

    function edit_mayor(Request $request){
        $id=$request->input('id');
        $result=json_encode(Mayor::where('id','=',$id)->get());
        return $result;


    }

    function mayor_delete($id){

        $file=Mayor::where('id',$id)->get(['image']);

        if (file_exists($file)){
            $file_path=explode('/',$file[0]['image'])[4];
            Storage::delete('public/'.$file_path);

        }


        $mayor = Mayor::where('id',$id)->delete();

        if ($mayor == true) {
            return redirect('/mayor')->withSuccess('Successfully Deleted!!');
        } else {
            return redirect()->back()->withError('Failed!!');
        }

        // return view('admin/add_mayor');
    }

    function mayorAdd(Request $request)
    {
        $title=$request->input('name');
        $designation=$request->input('designation');
        $mobile=$request->input('mobile');


        if ($request->file('image')) {
            $filePath = $request->file('image')->store('public');

            $fileName = (explode('/', $filePath))[1];

            $host = $_SERVER['HTTP_HOST'];

            $file_location = 'https://' . $host . '/storage/app/public' . $fileName;
        }else{
            $file_location='';
        }

        $result = Mayor::insert([
            'name'=>$title,
            'designation'=>$designation,
            'mobile'=>$mobile,
            'image'=>$file_location]);
        if ($result == true) {
            return redirect('/mayor')->withSuccess('Successfully Added!!');
        } else {
            return redirect()->back()->withError('Failed!!');
        }

    }
    function mayorEdit(Request $request)
    {
        $title=$request->input('name');
        $designation=$request->input('designation');
        $mobile=$request->input('mobile');
        $id=$request->input('mayor_id');
        $old_image=$request->input('old_image');

        if ($request->file('image')) {
            $filePath = $request->file('image')->store('public');

            $fileName = (explode('/', $filePath))[1];

            $host = $_SERVER['HTTP_HOST'];

            $file_location = 'https://' . $host . '/storage/app/public/' . $fileName;
        }else{
            $file_location=$old_image;
        }

        $result = Mayor::where('id',$id)->update([
            'name'=>$title,
            'designation'=>$designation,
            'mobile'=>$mobile,
            'image'=>$file_location]);
        if ($result == true) {
            return redirect('/mayor')->withSuccess('Successfully Updated!!');
        } else {
            return redirect()->back()->withError('Failed!!');
        }

    }
}
