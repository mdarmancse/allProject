<?php

namespace App\Http\Controllers;

use App\Budget;
use App\Employee;
use App\finance_year;
use App\GalleryModel;
use App\Mayor;
use App\MenuModel;
use App\NewsModel;
use App\NoticeModel;
use App\Project;
use App\SubMenuModel;
use Illuminate\Http\Request;

class WebController extends Controller
{

    function getData()
    {
        $notice = NoticeModel::orderBy('id','desc')->limit(3)->get();
        $news = NewsModel::orderBy('id','desc')->limit(1)->get();
        $menu_card=MenuModel::with('submenu')->orderBy('id','desc')->limit(4)->get();
        $menu=MenuModel::with('submenu')->get();
        $gallery = GalleryModel::orderBy('id','desc')->limit(3)->get();



        $data=[
            'notice' =>$notice,
            'news' =>$news,
            'menu_card' =>$menu_card,
            'sliders' =>$gallery,
            'nav_menu' =>$menu,
            'mayor' =>Mayor::first(),
        ];




        return view('Home',$data);
        //return $result;
    }

    function all_notice(){

        $result = NoticeModel::orderBy('id','desc')->get();
        $menu=MenuModel::with('submenu')->get();

        $data=[
            'data' =>$result,
            'nav_menu' =>$menu,
            'mayor' =>Mayor::first(),
        ];




        return view('AllNotice',$data);
    }

    function viewnotice($id)
    {

        $notice = NoticeModel::where('id',$id)->first();
        $menu=MenuModel::with('submenu')->get();

        $data=[
            'notice' =>$notice,
            'nav_menu' =>$menu,
            'mayor' =>Mayor::first(),
        ];

        // dd($notice->title);die();


        return view('NoticePage',$data);
        //return $result;
    }

    function viewpage($id)
    {

        $page = SubMenuModel::where('id',$id)->first();
        $menu=MenuModel::with('submenu')->get();

        $data=[
            'page' =>$page,
            'nav_menu' =>$menu,
            'mayor' =>Mayor::first(),
        ];



        return view('MenuPage',$data);

    }

    function page($id)
    {

        // dd($id);

        $page = MenuModel::where('id',$id)->first();
        $menu=MenuModel::with('submenu')->get();

        $data=[
            'page' =>$page,
            'nav_menu' =>$menu,
            'mayor' =>Mayor::first(),
        ];



        return view('MainMenuPage',$data);

    }



    function all_news(){

        $result = NewsModel::orderBy('id','desc')->get();
        $menu=MenuModel::with('submenu')->get();

        $data=[
            'data' =>$result,
            'nav_menu' =>$menu,
            'mayor' =>Mayor::first(),
        ];

        //    dd($data);die();


        return view('AllNews',$data);
    }





    function all_mayor(){

        $result = Mayor::all();
        $menu=MenuModel::with('submenu')->get();

        $data=[
            'result' =>$result,
            'nav_menu' =>$menu,
            'mayor' =>Mayor::first(),
        ];

        //dd($result);


        return view('AllMayor',$data);
    }
    function all_employee(){

        $result = Employee::all();
        $menu=MenuModel::with('submenu')->get();

        $data=[
            'result' =>$result,
            'nav_menu' =>$menu,
            'mayor' =>Mayor::first(),
        ];

        //dd($result);


        return view('AllEmployee',$data);
    }
    function all_project(){

        $result = finance_year::with('projects')->get();
        $menu=MenuModel::with('submenu')->get();

        $data=[
            'result' =>$result,
            'nav_menu' =>$menu,
            'mayor' =>Mayor::first(),
        ];

        //dd($result);


        return view('AllProject',$data);
    }
    function viewProject($id)
    {

        $result = Project::where('id',$id)->first();
        $menu=MenuModel::with('submenu')->get();

        $data=[
            'result' =>$result,
            'nav_menu' =>$menu,
            'mayor' =>Mayor::first(),
        ];

        // dd($notice->title);die();


        return view('ProjectPage',$data);
        //return $result;
    }
    function all_budget(){

        $result = finance_year::with('budgets')->get();
        $result_d = finance_year::with('donations')->get();
        $files = Budget::all();
        $menu=MenuModel::with('submenu')->get();

        $data=[
            'result' =>$result,
            'result_d' =>$result_d,
            'files' =>$files,
            'nav_menu' =>$menu,
            'mayor' =>Mayor::first(),
        ];

        //dd($result);


        return view('AllBudget',$data);
    }
    function viewBudget($id)
    {

        $result = Budget::where('id',$id)->first();
        $menu=MenuModel::with('submenu')->get();

        $data=[
            'result' =>$result,
            'nav_menu' =>$menu,
            'mayor' =>Mayor::first(),
        ];

        // dd($notice->title);die();


        return view('BudgetPage',$data);
        //return $result;
    }


}
