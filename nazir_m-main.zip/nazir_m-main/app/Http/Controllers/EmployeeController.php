<?php

namespace App\Http\Controllers;

use App\Employee;
use Illuminate\Http\Request;

class EmployeeController extends Controller
{
    function employee(){

        $result = Employee::orderBy('id','desc')->get();

        $data=[
            'data' =>$result
        ];
        return view('admin/add_employee',$data);
    }

    function edit_employee(Request $request){
        $id=$request->input('id');
        $result=json_encode(Employee::where('id','=',$id)->get());
        return $result;


    }

    function employee_delete($id){

        $file=Employee::where('id',$id)->get(['image']);

        if (file_exists($file)){
            $file_path=explode('/',$file[0]['image'])[4];
            Storage::delete('public/'.$file_path);

        }


        $employee = Employee::where('id',$id)->delete();

        if ($employee == true) {
            return redirect('/employee')->withSuccess('Successfully Deleted!!');
        } else {
            return redirect()->back()->withError('Failed!!');
        }

        // return view('admin/add_employee');
    }

    function employeeAdd(Request $request)
    {
        $title=$request->input('name');
        $designation=$request->input('designation');
        $mobile=$request->input('mobile');


        if ($request->file('image')) {
            $filePath = $request->file('image')->store('public');

            $fileName = (explode('/', $filePath))[1];

            $host = $_SERVER['HTTP_HOST'];

            $file_location = 'https://' . $host . '/storage/app/public/' . $fileName;
        }else{
            $file_location='';
        }

        $result = Employee::insert([
            'name'=>$title,
            'designation'=>$designation,
            'mobile'=>$mobile,
            'image'=>$file_location]);
        if ($result == true) {
            return redirect('/employee')->withSuccess('Successfully Added!!');
        } else {
            return redirect()->back()->withError('Failed!!');
        }

    }
    function employeeEdit(Request $request)
    {
        $title=$request->input('name');
        $designation=$request->input('designation');
        $mobile=$request->input('mobile');
        $id=$request->input('employee_id');
        $old_image=$request->input('old_image');

        if ($request->file('image')) {
            $filePath = $request->file('image')->store('public');

            $fileName = (explode('/', $filePath))[1];

            $host = $_SERVER['HTTP_HOST'];

            $file_location = 'https://' . $host . '/storage/app/public/' . $fileName;
        }else{
            $file_location=$old_image;
        }

        $result = Employee::where('id',$id)->update([
            'name'=>$title,
            'designation'=>$designation,
            'mobile'=>$mobile,
            'image'=>$file_location]);
        if ($result == true) {
            return redirect('/employee')->withSuccess('Successfully Updated!!');
        } else {
            return redirect()->back()->withError('Failed!!');
        }

    }
}
