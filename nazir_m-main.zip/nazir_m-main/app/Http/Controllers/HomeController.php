<?php

namespace App\Http\Controllers;


use App\MenuModel;
use App\NewsModel;
use Illuminate\Http\Request;
use App\AdminModel;
use App\NoticeModel;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;

class HomeController extends Controller
{
       //ADMIN
    function AdminHome(){


        $TotalNotice= NoticeModel::count();
        $TotalNews= NewsModel::count();
        $TotalMenu= MenuModel::count();

        return view('admin/AdminHome',[

            'TotalNotice'=>$TotalNotice,
            'TotalNews'=>$TotalNews,
            'TotalMenu'=>$TotalMenu,



        ]);



    }



}
