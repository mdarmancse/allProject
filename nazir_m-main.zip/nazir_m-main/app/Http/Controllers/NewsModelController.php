<?php

namespace App\Http\Controllers;

use App\NewsModel;
use Illuminate\Http\Request;

class NewsModelController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\NewsModel  $newsModel
     * @return \Illuminate\Http\Response
     */
    public function show(NewsModel $newsModel)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\NewsModel  $newsModel
     * @return \Illuminate\Http\Response
     */
    public function edit(NewsModel $newsModel)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\NewsModel  $newsModel
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, NewsModel $newsModel)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\NewsModel  $newsModel
     * @return \Illuminate\Http\Response
     */
    public function destroy(NewsModel $newsModel)
    {
        //
    }
}
