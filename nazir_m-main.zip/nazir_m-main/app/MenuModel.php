<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MenuModel extends Model
{
  protected $table='menu_models';
    public function submenu(){
        return $this->hasMany(SubMenuModel::class,'menu_id','id');
    }

}
