<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SubMenuModel extends Model
{
    protected $table='sub_menu_models';


}
