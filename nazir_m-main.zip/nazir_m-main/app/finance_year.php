<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class finance_year extends Model
{
    protected $table='finance_years';
    public function budgets(){
       return $this->hasMany(Budget::class,'finance_year_id','id');

    }
    public function projects(){
       return $this->hasMany(Project::class,'finance_year_id','id');

    }

    public function donations(){
       return $this->hasMany(Donation::class,'finance_year_id','id');

    }




}
