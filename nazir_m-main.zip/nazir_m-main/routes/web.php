<?php

use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
//Web
Route::get('/', 'WebController@getData');
Route::get('/viewnotice/{id}', 'WebController@viewnotice');
Route::get('/all_notice/', 'WebController@all_notice');

Route::get('/viewnews/{id}', 'WebController@viewnews');
Route::get('/all_news/', 'WebController@all_news');

Route::get('/viewBudget/{id}', 'WebController@viewBudget');
Route::get('/all_budget/', 'WebController@all_budget');

Route::get('/viewProject/{id}', 'WebController@viewProject');
Route::get('/all_project/', 'WebController@all_project');

Route::get('/page/3', 'WebController@all_notice');
Route::get('/page/{id}', 'WebController@page');


Route::get('/viewpage/6', 'WebController@all_mayor');
Route::get('/viewpage/7', 'WebController@all_employee');

Route::get('/viewpage/{id}', 'WebController@viewpage');






//Admin
Route::get('/AdminHome', 'HomeController@AdminHome')->middleware('logincheck');

//Notice
Route::get('/notice', 'NoticeController@notice')->middleware('logincheck');
Route::post('/noticeAdd', 'NoticeController@noticeAdd')->middleware('logincheck');
Route::post('/noticeEdit', 'NoticeController@noticeEdit')->middleware('logincheck');
Route::post('/edit_notice', 'NoticeController@edit_notice')->middleware('logincheck');
Route::get('/notice_delete/{id}', 'NoticeController@notice_delete')->middleware('logincheck');

//News
Route::get('/news', 'NewsController@news')->middleware('logincheck');
Route::post('/newsAdd', 'NewsController@newsAdd')->middleware('logincheck');
Route::post('/newsEdit', 'NewsController@newsEdit')->middleware('logincheck');
Route::post('/edit_news', 'NewsController@edit_news')->middleware('logincheck');
Route::get('/news_delete/{id}', 'NewsController@news_delete')->middleware('logincheck');

//Web Menu
Route::get('/menu', 'MenuController@menu')->name('menu')->middleware('logincheck');
Route::post('/menuAdd', 'MenuController@menuAdd')->middleware('logincheck');
Route::post('/menuEdit', 'MenuController@menuEdit')->middleware('logincheck');
Route::post('/edit_menu', 'MenuController@edit_menu')->middleware('logincheck');
Route::get('/menu_delete/{id}', 'MenuController@menu_delete')->middleware('logincheck');
//Sub Menuu
Route::post('/sub_menuAdd', 'MenuController@sub_menuAdd')->middleware('logincheck');
Route::post('/edit_submenu', 'MenuController@edit_submenu')->middleware('logincheck');
Route::post('/sub_menuEdit', 'MenuController@sub_menuEdit')->middleware('logincheck');
Route::get('/sub_delete/{id}', 'MenuController@sub_delete')->middleware('logincheck');


//Gallery
Route::get('/gallery', 'GalleryController@gallery')->name('menu')->middleware('logincheck');
Route::post('/galleryAdd', 'GalleryController@galleryAdd')->middleware('logincheck');
Route::post('/galleryEdit', 'GalleryController@galleryEdit')->middleware('logincheck');
Route::post('/edit_gallery', 'GalleryController@edit_gallery')->middleware('logincheck');
Route::get('/gallery_delete/{id}', 'GalleryController@gallery_delete')->middleware('logincheck');



//Mayor
Route::get('/mayor', 'MayorController@mayor')->middleware('logincheck');
Route::post('/mayorAdd', 'MayorController@mayorAdd')->middleware('logincheck');
Route::post('/mayorEdit', 'MayorController@mayorEdit')->middleware('logincheck');
Route::post('/edit_mayor', 'MayorController@edit_mayor')->middleware('logincheck');
Route::get('/mayor_delete/{id}', 'MayorController@mayor_delete')->middleware('logincheck');



//Employee
Route::get('/employee', 'EmployeeController@employee')->middleware('logincheck');
Route::post('/employeeAdd', 'EmployeeController@employeeAdd')->middleware('logincheck');
Route::post('/employeeEdit', 'EmployeeController@employeeEdit')->middleware('logincheck');
Route::post('/edit_employee', 'EmployeeController@edit_employee')->middleware('logincheck');
Route::get('/employee_delete/{id}', 'EmployeeController@employee_delete')->middleware('logincheck');


//Year
Route::get('/year', 'FinanceYearController@year')->middleware('logincheck');
Route::post('/yearAdd', 'FinanceYearController@yearAdd')->middleware('logincheck');
Route::post('/yearEdit', 'FinanceYearController@yearEdit')->middleware('logincheck');
Route::post('/edit_year', 'FinanceYearController@edit_year')->middleware('logincheck');
Route::get('/year_delete/{id}', 'FinanceYearController@year_delete')->middleware('logincheck');



//Budget
Route::get('/budget', 'BudgetController@budget')->name('menu')->middleware('logincheck');
Route::post('/budgetAdd', 'BudgetController@budgetAdd')->middleware('logincheck');
Route::post('/budgetEdit', 'BudgetController@budgetEdit')->middleware('logincheck');
Route::post('/edit_budget', 'BudgetController@edit_budget')->middleware('logincheck');
Route::get('/budget_delete/{id}', 'BudgetController@budget_delete')->middleware('logincheck');

//Donation
Route::get('/donation', 'DonationController@donation')->name('menu')->middleware('logincheck');
Route::post('/donationAdd', 'DonationController@donationAdd')->middleware('logincheck');
Route::post('/donationEdit', 'DonationController@donationEdit')->middleware('logincheck');
Route::post('/edit_donation', 'DonationController@edit_donation')->middleware('logincheck');
Route::get('donation_delete/{id}', 'DonationController@donation_delete')->middleware('logincheck');

//Project
Route::get('/project', 'ProjectController@project')->name('menu')->middleware('logincheck');
Route::post('/projectAdd', 'ProjectController@projectAdd')->middleware('logincheck');
Route::post('/projectEdit', 'ProjectController@projectEdit')->middleware('logincheck');
Route::post('/edit_project', 'ProjectController@edit_project')->middleware('logincheck');
Route::get('/project_delete/{id}', 'ProjectController@project_delete')->middleware('logincheck');


Route::get('/linkstorage', function () {
    Artisan::call('storage:link');
});

Route::get('/login', 'LoginController@LoginIndex');
Route::get('/onLogout', 'LoginController@onLogout');
Route::post('/onLogin', 'LoginController@onLogin');
