<!-- Closing Account start -->
<div class="content-wrapper">
    <section class="content-header">
        <div class="header-icon">
            <i class="pe-7s-note2"></i>
        </div>
        <div class="header-title">
            <h1>Day <?php echo display('closing_account') ?></h1>
            <small><?php echo display('close_your_account') ?></small>
            <ol class="breadcrumb">
                <li><a href="#"><i class="pe-7s-home"></i> <?php echo display('home') ?></a></li>
                <li><a href="#"><?php echo display('report') ?></a></li>
                <li class="active">Day <?php echo display('closing_account') ?></li>
            </ol>
        </div>
    </section>

    <section class="content">
        <!-- Alert Message -->
        <?php
        $message = $this->session->userdata('message');
        if (isset($message)) {
            ?>
            <div class="alert alert-info alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <?php echo $message ?>
            </div>
            <?php
            $this->session->unset_userdata('message');
        }
        $error_message = $this->session->userdata('error_message');
        if (isset($error_message)) {
            ?>
            <div class="alert alert-danger alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <?php echo $error_message ?>
            </div>
            <?php
            $this->session->unset_userdata('error_message');
        }
        ?>

        <div class="row">
            <div class="col-sm-12">


                <a href="<?php echo base_url('Admin_dashboard/closing_report') ?>" class="btn btn-primary m-b-5 m-r-2"><i class="ti-align-justify"> </i>  <?php echo display('closing_report') ?> </a>


            </div>
        </div>
        <div id="printableArea">
        <div class="row">
            <div class="col-sm-6">
                <div class="panel panel-bd lobidrag">
                    <div class="panel-heading">
                        <div class="panel-title">
                            <h4>Day <?php echo display('closing_account') ?> </h4>
                        </div>
                    </div>
                    <div class="panel-body">

                        <div class="row col-sm-12">
                            <div class="text-left col-sm-4">


                                <h5>LOC: <?php echo $outlet_name ?></h5>

                            </div>

                            <div class="text-center col-sm-4">

                                <h5>Restaurant Closing Report (MIS) </h5>

                            </div>
                            <div class="text-right col-sm-4">

                                <h5> <?php echo display('date') ?>:<?php echo date("d/m/Y"); ?> </h5>
                            </div>

                        </div>



                        <?php echo form_open_multipart('Accounts/add_daily_closing') ?>
                        <!--                        <form action="--><?php //echo base_url()?><!--Caccounts/add_daily_closing" method="post">-->

                        <div class="form-group row" >
                            <label for="last_day_closing" style="font-size: 14px" class="col-sm-3 col-form-label">Cash-Start</label>

                            <div class="col-sm-6" >
                                <input type="text" name="last_day_closing" class="form-control" id="last_day_closing" value="{last_day_closing}"  readonly="readonly" />
                                <input type="hidden" name="last_day" class="form-control" id="last_day" value="{last_day_closing}" readonly="readonly" />
                            </div>
                        </div>
<!--                                                <div class="form-group row" >-->
<!--                                                    <label for="last_day_closing" class="col-sm-3 col-form-label">Last Day Closing</label>-->
<!--                                                    <div class="col-sm-6" >-->
<!--                                                 -->
<!--                                                    </div>-->
<!--                                                </div>-->

                        <div class="form-group row">
                            <label for="cash_in" class="col-sm-3 col-form-label">Manager</label>
                            <div class="col-sm-6">
                                <input type="text" class="form-control" id="cash_man" name="cash_man" value="0" placeholder="0.00" onkeyup="cashCalculator()"  onchange="cashCalculator()" />
                            </div>
                        </div>

                        <div class="form-group row" style="margin-bottom: 5rem">
                            <label for="cash_out" class="col-sm-3 col-form-label">Counter</label>
                            <div class="col-sm-6">
                                <input type="text" class="form-control" id="cash_count" name="cash_count" value="0" placeholder="0.00" onkeyup="cashCalculator()"  onchange="cashCalculator()" />
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="cash_out" class="col-sm-3 col-form-label">Cash-In</label>
                            <div class="col-sm-6">
                                <input type="text" class="form-control total_cash" id="total_cash" name="total_cash" value="0" placeholder="0.00" onkeyup="cashCalculator()" onchange="cashCalculator()"  readonly/>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="cash_out" class="col-sm-3 col-form-label">Total Cash</label>
                            <div class="col-sm-6">
                                <input type="text" class="form-control total_sales" id="total_sales" name="total_sales" value="0" placeholder="0.00"  readonly/>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="cash_out" class="col-sm-3 col-form-label">Cash-Out</label>
                            <div class="col-sm-6">
                                <input id="" type="text" class="form-control total" readonly="" name="">
                            </div>
                        </div>




                    </div>
                    <div class="panel-heading">
                        <div class=" row">
                            <h1 for="cash_out" class="col-sm-3 panel-title">Cash-Close</h1>
                            <div class="col-sm-9">
                                <input type="text" class="form-control total_money" readonly="" name="grndtotal" >
                            </div>
                        </div>

                    </div>
                    <div class="panel-body">
                        <table class="table table-bordered table-hover">
                            <thead>
                            <tr>
                                <th class="text-center"><?php echo display('note_name') ?></th>
                                <th class="text-center"><?php echo display('pcs') ?></th>
                                <th class="text-center"><?php echo display('ammount') ?></th>
                            </tr>
                            </thead>
                            <tbody>
<!--                            <tr>-->
<!--                                <td class="2000">--><?php //echo '2000'; ?><!--</td>-->
<!--                                <td><input type="number" class="form-control text_0" name="thousands" onkeyup="cashCalculator()"  onchange="cashCalculator()"></td>-->
<!--                                <td><input type="text" class="form-control text_0_bal" readonly=""></td>-->
<!--                            </tr>-->
                            <tr>
                                <td class="1000"><?php echo display('1000') ?></td>
                                <td><input type="number" class="form-control text_1" name="thousands" onkeyup="cashCalculator()"  onchange="cashCalculator()"></td>
                                <td><input type="text" class="form-control text_1_bal" readonly=""></td>
                            </tr>
                            <tr>
                                <td class="500"><?php echo display('500') ?></td>
                                <td><input type="number" class="form-control text_2" name="fivehnd" onkeyup="cashCalculator()" onchange="cashCalculator()"></td>
                                <td><input type="text" class="form-control text_2_bal" readonly=""></td>
                            </tr>
                            <tr>
                                <td class="100"><?php echo display('100') ?></td>
                                <td><input type="number" class="form-control text_3" name="hundrad" onkeyup="cashCalculator()" onchange="cashCalculator()"></td>
                                <td><input type="text" class="form-control text_3_bal" readonly=""></td>
                            </tr>
                            <tr>
                                <td class="50"><?php echo display('50') ?></td>
                                <td><input type="number" class="form-control text_4" name="fifty" onkeyup="cashCalculator()" onchange="cashCalculator()"></td>
                                <td><input type="text" class="form-control text_4_bal" readonly=""></td>
                            </tr>
                            <tr>
                                <td class="20"><?php echo display('20') ?></td>
                                <td><input type="number" class="form-control text_5" name="twenty" onkeyup="cashCalculator()" onchange="cashCalculator()"></td>
                                <td><input type="text" class="form-control text_5_bal" readonly=""></td>
                            </tr>
                            <tr>
                                <td class="10"><?php echo display('10') ?></td>
                                <td><input type="number" class="form-control text_6" name="ten" onkeyup="cashCalculator()" onchange="cashCalculator()"></td>
                                <td><input type="text" class="form-control text_6_bal" readonly=""></td>
                            </tr>
                            <tr>
                                <td class="5"><?php echo display('5') ?></td>
                                <td><input type="number" class="form-control text_7" name="five" onkeyup="cashCalculator()" onchange="cashCalculator()"></td>
                                <td><input type="text" class="form-control text_7_bal" readonly=""></td>
                            </tr>

<!--                            <tr>-->
<!--                                <td class="2">--><?php //echo display('2') ?><!--</td>-->
<!--                                <td><input type="number" class="form-control text_8" name="two" onkeyup="cashCalculator()" onchange="cashCalculator()"></td>-->
<!--                                <td><input type="text" class="form-control text_8_bal" readonly=""></td>-->
<!--                            </tr>-->
<!--                            <tr>-->
<!--                                <td class="1">--><?php //echo display('1') ?><!--</td>-->
<!--                                <td><input type="number" class="form-control text_9" name="one" onkeyup="cashCalculator()" onchange="cashCalculator()"></td>-->
<!--                                <td><input type="text" class="form-control text_9_bal" readonly=""></td>-->
<!--                            </tr>-->


                            <thead>
                            <tr>
                                <th></th>
                                <th class="text-center">Torn Notes:</th>
                                <th></th>
                            </tr>
                            </thead>
<!--                            <tr>-->
<!--                                <td class="2000">--><?php //echo '2000'; ?><!--</td>-->
<!--                                <td><input type="number" class="form-control t_text_0" name="thousands" onkeyup="cashCalculator()"  onchange="cashCalculator()"></td>-->
<!--                                <td><input type="text" class="form-control t_text_0_bal" readonly=""></td>-->
<!--                            </tr>-->
                            <tr>
                                <td class="1000"><?php echo display('1000') ?></td>
                                <td><input type="number" class="form-control t_text_1" name="thousands_x" onkeyup="cashCalculator()"  onchange="cashCalculator()"></td>
                                <td><input type="text" class="form-control t_text_1_bal" readonly=""></td>
                            </tr>
                            <tr>
                                <td class="500"><?php echo display('500') ?></td>
                                <td><input type="number" class="form-control t_text_2" name="fivehnd_x" onkeyup="cashCalculator()" onchange="cashCalculator()"></td>
                                <td><input type="text" class="form-control t_text_2_bal" readonly=""></td>
                            </tr>
                            <tr>
                                <td class="100"><?php echo display('100') ?></td>
                                <td><input type="number" class="form-control t_text_3" name="hundrad_x" onkeyup="cashCalculator()" onchange="cashCalculator()"></td>
                                <td><input type="text" class="form-control t_text_3_bal" readonly=""></td>
                            </tr>
                            <tr>
                                <td class="50"><?php echo display('50') ?></td>
                                <td><input type="number" class="form-control t_text_4" name="fifty_x" onkeyup="cashCalculator()" onchange="cashCalculator()"></td>
                                <td><input type="text" class="form-control t_text_4_bal" readonly=""></td>
                            </tr>
                            <tr>
                                <td class="20"><?php echo display('20') ?></td>
                                <td><input type="number" class="form-control t_text_5" name="twenty_x" onkeyup="cashCalculator()" onchange="cashCalculator()"></td>
                                <td><input type="text" class="form-control t_text_5_bal" readonly=""></td>
                            </tr>
                            <tr>
                                <td class="10"><?php echo display('10') ?></td>
                                <td><input type="number" class="form-control t_text_6" name="ten_x" onkeyup="cashCalculator()" onchange="cashCalculator()"></td>
                                <td><input type="text" class="form-control t_text_6_bal" readonly=""></td>
                            </tr>
                            <tr>
                                <td class="5"><?php echo display('5') ?></td>
                                <td><input type="number" class="form-control t_text_7" name="five_x" onkeyup="cashCalculator()" onchange="cashCalculator()"></td>
                                <td><input type="text" class="form-control t_text_7_bal" readonly=""></td>
                            </tr>
<!--                            <tr>-->
<!--                                <td class="2">--><?php //echo display('2') ?><!--</td>-->
<!--                                <td><input type="number" class="form-control t_text_8" name="two" onkeyup="cashCalculator()" onchange="cashCalculator()"></td>-->
<!--                                <td><input type="text" class="form-control t_text_8_bal" readonly=""></td>-->
<!--                            </tr>-->
<!--                            <tr>-->
<!--                                <td class="1">--><?php //echo display('1') ?><!--</td>-->
<!--                                <td><input type="number" class="form-control t_text_9" name="one" onkeyup="cashCalculator()" onchange="cashCalculator()"></td>-->
<!--                                <td><input type="text" class="form-control t_text_9_bal" readonly=""></td>-->
<!--                            </tr>-->
                            </tbody>
<!--                            <tfoot>-->
<!--                            <tr>-->
<!--                                <td colspan="2" align="right"><b>--><?php //echo display('grand_total') ?><!--</b></td>-->
<!--                                <td class=""><input type="text" class="form-control total_money" readonly="" name="grndtotal" ></td>-->
<!--                            </tr>-->
<!---->
<!--                  -->
<!---->
<!--                            </tfoot>-->

                        </table>

<!--                        <div class="form-group row">-->
<!--                            <label for="example-text-input" class="col-sm-4 col-form-label"></label>-->
<!--                            <div class="col-sm-6">-->
<!--                                <input type="submit" id="add-deposit" class="btn btn-primary" name="add_deposit" value="--><?php //echo display('day_closing') ?><!--" required />-->
<!---->
<!--                            </div>-->
<!--                        </div>-->
                    </div>


                </div>
            </div>

            <div class="col-sm-6">
                <div class="panel panel-bd lobidrag">
                    <div class="panel-heading">
                        <div class=" row">
                            <h1 for="cash_out" class="col-sm-4 panel-title">Cash-Out</h1>
                            <div class="col-sm-8">
                                <input id="" type="text" class="form-control total" readonly="" name="grndtotal_out">
                            </div>
                        </div>
                        <table id='cash_out_a' class="table table-bordered table-hover">
                            <thead>
                            <tr>
                                <th class="text-center">Name</th>
                                <th class="text-center"><?php echo display('ammount') ?></th>
                            </tr>
                            </thead>
                            <tbody>

                            {category_list}
                            <tr class="cash_out_c">
                                <td class="2000">{category_name}</td>
                                <td>
                                    <input type="number" class="form-control text_0 cash_out_number" name="cash_out_number[]" onkeyup="cashCalculator()"  onchange="cashCalculator()"  />
                                    <input type="hidden" class="form-control category_id" name="category_id[]" value="{category_id}"  />
                                </td>

                            </tr>
                            {/category_list}

<!--                            --><?php //echo form_close() ?>

<!--                            <tfoot>-->
<!--                            <tr>-->
<!--                                <td colspan="1" align="right"><b>--><?php //echo display('grand_total') ?><!--</b></td>-->
<!--                                <td class=""><input id="total" type="text" class="form-control" readonly="" name="grndtotal"></td>-->
<!--                            </tr>-->
<!---->
<!---->
<!--                            -->
<!--                            </tfoot>-->

                        </table>
                    </div>


                </div>
            </div>
        </div>
        </div>
        <div class="panel-footer text-left">
            <input type="submit" id="add-deposit" class="btn btn-primary" name="add_deposit" value="<?php echo display('day_closing') ?>" required />

        </div>
        <?php echo form_close() ?>
        <!-- cashCalculator form -->
    </section>
</div>
<!-- Closing Account end -->

<script type="text/javascript">






    $('form input').keydown(function (e) {
        if (e.keyCode == 13) {
            var inputs = $(this).parents("form").eq(0).find(":input");
            if (inputs[inputs.index(this) + 1] != null) {
                inputs[inputs.index(this) + 1].focus();
            }
            e.preventDefault();
            return false;
        }
    });




</script>




