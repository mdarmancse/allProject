<?php
$CI = & get_instance();
$CI->load->model('Web_settings');
$Web_settings = $CI->Web_settings->retrieve_setting_editdata();
?>

<style>



    table, td, th {
        border: 1px solid black;
    }

    table {
        border-collapse: collapse;
        width: 50%;
    }

    th {
        height: 70px;
    }
</style>

<script src="<?php echo base_url() ?>my-assets/js/admin_js/invoice_onloadprint.js" type="text/javascript"></script>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="header-icon">
            <i class="pe-7s-note2"></i>
        </div>
        <div class="header-title">
            <h1><?php echo display('invoice_details') ?></h1>
            <small><?php echo display('invoice_details') ?></small>
            <ol class="breadcrumb">
                <li><a href="#"><i class="pe-7s-home"></i> <?php echo display('home') ?></a></li>
                <li><a href="#"><?php echo display('invoice') ?></a></li>
                <li class="active"><?php echo display('invoice_details') ?></li>
            </ol>
        </div>
    </section>
    <!-- Main content -->
    <section class="content">
        <!-- Alert Message -->
        <?php
        $message = $this->session->userdata('message');
        if (isset($message)) {
            ?>
            <div class="alert alert-info alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <?php echo $message ?>
            </div>
            <?php
            $this->session->unset_userdata('message');
        }
        $error_message = $this->session->userdata('error_message');
        if (isset($error_message)) {
            ?>
            <div class="alert alert-danger alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <?php echo $error_message ?>
            </div>
            <?php
            $this->session->unset_userdata('error_message');
        }
        ?>
        <div class="row">
            <div class="col-sm-12">
                <div class="panel panel-bd">
                    <div id="printableArea"  class=""  onload="printDiv('printableArea')">





                                <div class="row print_header">




                                    <div class="col-xs-12 text-center">
                                        <h2  style="font-size: 14px;"><strong>Sadia's Kitchen</strong></h2>
                                        <div style="font-size: 11px"><strong>Restaurent Cash Hand Over Sheet(MIS)</div>




<!--                                        <address class="" style="margin-top: 8px">-->
<!--                                            <span style="font-size: 8px" class="label label-success-outline m-r-20">Send To:</span><br>-->
<!--                                            <strong  class="c_name">--><?php //echo $chalan_detail[0]['outlet_name']?><!-- </strong><br>-->
<!---->
<!--                                        </address>-->
                                    </div>

                                    <div class="col-xs-12 row" style="margin-top: 10px">
                                        <div class="col-xs-4 text-left " style="font-size: 10px;margin-left: 5px">LOC:  <?php echo $outlet_name?></div>
                                        <div  class="col-xs-4 text-right" style="font-size: 10px ;margin-left: 50px">Date: <?php echo $closing_details[0]['date']?></div>



                                    </div>

                                </div>


                                <div class="col-xs-12 row" style="margin-top: 5px">
                                    <div class="col-xs-6 text-left">
                                        <h5 class="cash_field">
                                           Cash-START:<span style="padding: 5px"><?php echo number_format($closing_details[0]['cash_start'],2)?></span>
                                        </h5>
                                        <h6 class="cash_field">
                                            Manager: <span style="padding: 5px"><?php echo number_format($closing_details[0]['manager'],2)?></span>
                                        </h6>

                                        <h6 class="cash_field">
                                            Counter: <span style="padding: 5px"><?php echo number_format($closing_details[0]['counter'],2)?></span>
                                        </h6>

                                        <h5 class="cash_field">
                                            Cash-In:<span style="padding: 5px"><?php echo number_format($closing_details[0]['cash_in'],2)?></span>
                                        </h5>
                                        <h5 class="cash_field">
                                            Total Cash:<span style="padding: 5px"><?php echo number_format($closing_details[0]['total_cash'],2)?></span>
                                        </h5>
                                        <h5 class="cash_field">
                                            Expenses:<span style="padding: 5px"> <?php echo number_format($closing_details[0]['cash_out'],2)?></span>
                                        </h5>
                                        <h5 class="cash_field">
                                            Cash-Close:<span style="padding: 5px"><?php echo number_format($closing_details[0]['cash_close'],2)?></span>
                                        </h5>
                                        <table class=" table-responsive" width="100%" style="margin-bottom: 5px" >
                                            <thead>

                                            </thead>
                                            <tbody>

                                            <?php if ($closing_details[0]['thousands']):?>
                                            <tr >
                                                <td style="border-width:1px;border-style: dashed " class="note_font">1000x</td>
                                                <td style="border-width:1px;border-style: dashed;text-align: center " class="note_font"><?php echo $closing_details[0]['thousands']?></td>

                                            </tr>
                                            <?php endif ?>
                                            <?php if ($closing_details[0]['fivehnd']):?>
                                            <tr >
                                                <td style="border-width:1px;border-style: dashed " class="note_font">500x</td>
                                                <td style="border-width:1px;border-style: dashed;text-align: center " class="note_font"><?php echo $closing_details[0]['fivehnd']?></td>

                                            </tr>
                                            <?php endif ?>
                                            <?php if ($closing_details[0]['hundrad']):?>
                                            <tr >
                                                <td style="border-width:1px;border-style: dashed " class="note_font">100x</td>
                                                <td style="border-width:1px;border-style: dashed;text-align: center " class="note_font"><?php echo $closing_details[0]['hundrad']?></td>

                                            </tr>
                                            <?php endif ?>
                                            <?php if ($closing_details[0]['fifty']):?>
                                            <tr >
                                                <td style="border-width:1px;border-style: dashed " class="note_font">50x</td>
                                                <td style="border-width:1px;border-style: dashed;text-align: center " class="note_font"><?php echo $closing_details[0]['fifty']?></td>

                                            </tr>
                                            <?php endif ?>
                                            <?php if ($closing_details[0]['twenty']):?>
                                            <tr >
                                                <td style="border-width:1px;border-style: dashed " class="note_font">20x</td>
                                                <td style="border-width:1px;border-style: dashed;text-align: center " class="note_font"><?php echo $closing_details[0]['twenty']?></td>

                                            </tr>
                                            <?php endif ?>
                                            <?php if ($closing_details[0]['ten']):?>
                                            <tr >
                                                <td style="border-width:1px;border-style: dashed " class="note_font">10x</td>
                                                <td style="border-width:1px;border-style: dashed;text-align: center " class="note_font"><?php echo $closing_details[0]['ten']?></td>

                                            </tr>
                                            <?php endif ?>
                                            <?php if ($closing_details[0]['five']):?>
                                            <tr>
                                                <td style="border-width:1px;border-style: dashed " class="note_font">5x</td>
                                                <td style="border-width:1px;border-style: dashed;text-align: center " class="note_font"><?php echo $closing_details[0]['five']?></td>

                                            </tr>
                                            <?php endif ?>




                                            </tbody>




                                        </table>
                                        <h6 class="text-left">
                                            Torn Notes :
                                        </h6>
                                        <table class=" table-responsive" width="100%" >
                                            <thead>

                                            </thead>
                                            <tbody>

                                            <?php if ($closing_details[0]['thousands_x']):?>
                                            <tr >
                                                <td style="border-width:1px;border-style: dashed " class="note_font">1000x</td>
                                                <td style="border-width:1px;border-style: dashed;text-align: center " class="note_font"><?php echo $closing_details[0]['thousands_x']?></td>

                                            </tr>
                                            <?php endif ?>
                                            <?php if ($closing_details[0]['fivehnd_x']):?>
                                            <tr >
                                                <td style="border-width:1px;border-style: dashed " class="note_font">500x</td>
                                                <td style="border-width:1px;border-style: dashed;text-align: center " class="note_font"><?php echo $closing_details[0]['fivehnd_x']?></td>

                                            </tr>
                                            <?php endif ?>
                                            <?php if ($closing_details[0]['hundrad_x']):?>
                                            <tr >
                                                <td style="border-width:1px;border-style: dashed " class="note_font">100x</td>
                                                <td style="border-width:1px;border-style: dashed;text-align: center " class="note_font"><?php echo $closing_details[0]['hundrad_x']?></td>

                                            </tr>
                                            <?php endif ?>
                                            <?php if ($closing_details[0]['fifty_x']):?>
                                            <tr >
                                                <td style="border-width:1px;border-style: dashed " class="note_font">50x</td>
                                                <td style="border-width:1px;border-style: dashed;text-align: center " class="note_font"><?php echo $closing_details[0]['fifty_x']?></td>

                                            </tr>
                                            <?php endif ?>
                                            <?php if ($closing_details[0]['twenty_x']):?>
                                            <tr >
                                                <td style="border-width:1px;border-style: dashed " class="note_font">20x</td>
                                                <td style="border-width:1px;border-style: dashed;text-align: center " class="note_font"><?php echo $closing_details[0]['twenty_x']?></td>

                                            </tr>
                                            <?php endif ?>
                                            <?php if ($closing_details[0]['ten_x']):?>
                                            <tr >
                                                <td style="border-width:1px;border-style: dashed " class="note_font">10x</td>
                                                <td style="border-width:1px;border-style: dashed;text-align: center " class="note_font"><?php echo $closing_details[0]['ten_x']?></td>

                                            </tr>
                                            <?php endif ?>
                                            <?php if ($closing_details[0]['five_x']):?>
                                            <tr>
                                                <td style="border-width:1px;border-style: dashed " class="note_font">5x</td>
                                                <td style="border-width:1px;border-style: dashed;text-align: center " class="note_font"><?php echo $closing_details[0]['five_x']?></td>

                                            </tr>
                                            <?php endif ?>




                                            </tbody>




                                        </table>




                                    </div>
                                    <div class="col-xs-6 text-left ">
                                        <h5 class="cash_field">
                                            Cash-Expenses:<span style="padding: 5px"><?php echo number_format($closing_details[0]['cash_out'],2)?></span>
                                        </h5>
                                        <table class="table-responsive" style="width: 100%" >
                                            <thead>

                                            </thead>
                                            <tbody>

                                                {cash_out_details}
                                                <tr >
                                                    <td style="border-width:thin;border-style: solid;text-align: left;padding: 5px " class="note_font">  {category_name}</td>
                                                    <td style="border-width:thin;border-style: solid; text-align: center " class="note_font">  {amount}</td>

                                                </tr>
                                                {/cash_out_details}





                                            </tbody>




                                        </table>



                                    </div>
                                </div>



                                <div class="row footer" >
                                    <div class="col-sm-4">
                                        <div class="inv-footer-left">
                                           Restaurant Manager
                                        </div>
                                    </div>
                                    <div class="col-sm-4"></div>
                                    <div class="col-sm-4"> <div class="inv-footer-right">
                                         Accounts
                                        </div></div>
                                </div>



                    </div>

                    <div class="panel-footer text-left">
                        <input type="hidden" name="" id="url" value="<?php echo base_url('Admin_dashboard/outlet_closing');?>">
                        <a  class="btn btn-danger" href="<?php echo base_url('Admin_dashboard/outlet_closing');?>"><?php echo display('cancel') ?></a>
                        <button  class="btn btn-info" onclick="printDiv('printableArea')"><span class="fa fa-print"></span></button>

                    </div>
                </div>
            </div>
        </div>
    </section> <!-- /.content -->
</div> <!-- /.content-wrapper -->

