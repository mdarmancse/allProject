<!-- Closing Account start -->
<div class="content-wrapper">
    <section class="content-header">
        <div class="header-icon">
            <i class="pe-7s-note2"></i>
        </div>
        <div class="header-title">
            <h1>Update Closing</h1>
            <small>Update Closing</small>
            <ol class="breadcrumb">
                <li><a href="#"><i class="pe-7s-home"></i> <?php echo display('home') ?></a></li>
                <li><a href="#"><?php echo display('report') ?></a></li>
                <li class="active">Update Closing</li>
            </ol>
        </div>
    </section>

    <section class="content">
        <!-- Alert Message -->
        <?php
        $message = $this->session->userdata('message');
        if (isset($message)) {
            ?>
            <div class="alert alert-info alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <?php echo $message ?>
            </div>
            <?php
            $this->session->unset_userdata('message');
        }
        $error_message = $this->session->userdata('error_message');
        if (isset($error_message)) {
            ?>
            <div class="alert alert-danger alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <?php echo $error_message ?>
            </div>
            <?php
            $this->session->unset_userdata('error_message');
        }
        ?>

        <?php echo form_open_multipart('Accounts/update_daily_closing') ?>
        <div class="row">
            <div class="col-sm-6">


                <a href="<?php echo base_url('Admin_dashboard/closing_report') ?>" class="btn btn-primary m-b-5 m-r-2"><i class="ti-align-justify"> </i>  <?php echo display('closing_report') ?> </a>

            </div>

            <div class="col-sm-6" style="text-align: right">


                <input type="submit" id="add-deposit" class="btn btn-danger" name="add_deposit" value="Update" required />
            </div>
        </div>
        <div id="printableArea">
        <div class="row">
            <div class="col-sm-3">
                <div class="panel panel-bd lobidrag">
                    <div class="panel-heading">
                        <div class="panel-title">
                            <h4>Update <?php echo display('closing_account') ?> </h4>
                        </div>
                    </div>
                    <div class="panel-body">

                        <div class="row col-sm-12">
                            <div class="text-left col-sm-4">


                                <h6>loc:<?php echo $closing_details[0]['outlet_name']?></h6>

                            </div>

                            <div class="text-center col-sm-3">

                                <h6>MIS </h6>

                            </div>
                            <div class="text-right col-sm-3">

                                <h6>Date:<?php echo $closing_details[0]['date']?> </h6>
                            </div>

                        </div>



                        <!--                        <form action="--><?php //echo base_url()?><!--Caccounts/add_daily_closing" method="post">-->

                        <div class="form-group row" >
                            <label for="last_day_closing" style="font-size: 11px" class="col-sm-3 col-form-label">Cash-Start</label>

                            <div class="col-sm-6" >
                                <input type="text"   style="font-size: 11px" name="last_day_closing" class="form-control input-sm" id="last_day_closing" value="<?php echo $closing_details[0]['cash_start']?>"  readonly="readonly" />
                                <input type="hidden" name="last_day" class="form-control" id="last_day" value="<?php echo $last_closing_amount ?>" readonly="readonly" />
                                <input type="hidden" name="closing_id" class="form-control" id="closing_id" value="<?php echo $closing_details[0]['closing_id']?>" readonly="readonly" />
                            </div>
                        </div>


                        <div class="form-group row">
                            <label for="cash_in" style="font-size: 11px" class="col-sm-3 col-form-label">Manager</label>
                            <div class="col-sm-6">
                                <input type="text"  style="font-size: 11px" class="form-control input-sm" id="cash_man" name="cash_man" value="<?php echo $closing_details[0]['manager']?>" placeholder="0.00" onkeyup="cashCalculator()"  onchange="cashCalculator()" />
                            </div>
                        </div>

                        <div class="form-group row" style="margin-bottom: 5rem">
                            <label for="cash_out" style="font-size: 11px" class="col-sm-3 col-form-label">Counter</label>
                            <div class="col-sm-6">
                                <input type="text"  style="font-size: 11px" class="form-control input-sm" id="cash_count" name="cash_count" value="<?php echo $closing_details[0]['counter']?>" placeholder="0.00" onkeyup="cashCalculator()"  onchange="cashCalculator()" />
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="cash_out" style="font-size: 11px" class="col-sm-3 col-form-label">Cash-In</label>
                            <div class="col-sm-6">
                                <input type="text"  style="font-size: 11px" class="form-control input-sm total_cash" id="total_cash" name="total_cash" value="<?php echo $closing_details[0]['cash_in']?>" placeholder="0.00" onkeyup="cashCalculator()" onchange="cashCalculator()"  readonly/>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="cash_out"  style="font-size: 11px" class="col-sm-3 col-form-label">Total Cash</label>
                            <div class="col-sm-6">
                                <input type="text"  style="font-size: 11px" class="form-control total_sales input-sm" id="total_sales" name="total_sales" value="<?php echo $closing_details[0]['total_cash']?>" placeholder="0.00"  readonly/>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="cash_out" style="font-size: 11px" class="col-sm-3 col-form-label">Cash-Out</label>
                            <div class="col-sm-6">
                                <input id="" type="text"  style="font-size: 11px" class="form-control total input-sm" readonly="" name="" value="<?php echo $closing_details[0]['cash_out']?>">
                            </div>
                        </div>


<!--                        <div class="panel-footer text-left">-->
<!--                            <input type="submit" id="add-deposit" class="btn btn-danger" name="add_deposit" value="--><?php //echo display('day_closing') ?><!--" required />-->
<!---->
<!--                        </div>-->

                    </div>



                </div>
            </div>
            <div class="col-sm-3">
                <div class="panel panel-bd lobidrag">
                    <div class="panel-heading">
                        <div class=" row">
                            <h1 for="cash_out" class="col-sm-3 panel-title">Cash-Close</h1>
                            <div class="col-sm-9">
                                <input type="text"  style="font-size: 11px" class="form-control input-sm total_money" readonly="" value="<?php echo $closing_details[0]['cash_close']?>" name="grndtotal" >
                            </div>
                        </div>

                    </div>

                    <div class="panel-body">
                        <table class="table table-bordered table-hover">
                            <thead>
                            <tr>
                                <th class="text-center"><?php echo display('note_name') ?></th>
                                <th class="text-center"><?php echo display('pcs') ?></th>
                                <th class="text-center"><?php echo display('ammount') ?></th>
                            </tr>
                            </thead>
                            <tbody>

                            <tr>
                                <td class="1000" style="font-size: 11px"><?php echo display('1000') ?></td>
                                <td><input type="text"  style="font-size: 11px" class="input-sm form-control text_1" name="thousands" onkeyup="cashCalculator()"  onchange="cashCalculator()" value="<?php echo $closing_details[0]['thousands']?>"></td>
                                <td><input type="text"  style="font-size: 11px" class=" input-sm form-control text_1_bal" readonly="" value="<?php echo $closing_details[0]['thousands'] * 1000?>"></td>
                            </tr>
                            <tr>
                                <td class="500" style="font-size: 11px"><?php echo display('500') ?></td>
                                <td><input type="text"  style="font-size: 11px" class="input-sm form-control text_2" name="fivehnd" onkeyup="cashCalculator()" onchange="cashCalculator()" value="<?php echo $closing_details[0]['fivehnd']?>"></td>
                                <td><input type="text"  style="font-size: 11px" class="input-sm form-control text_2_bal" readonly="" value="<?php echo $closing_details[0]['fivehnd'] * 500?>"></td>
                            </tr>
                            <tr>
                                <td class="100" style="font-size: 11px"><?php echo display('100') ?></td>
                                <td><input type="text"  style="font-size: 11px" class="input-sm form-control text_3" name="hundrad" onkeyup="cashCalculator()" onchange="cashCalculator()" value="<?php echo $closing_details[0]['hundrad']?>"></td>
                                <td><input type="text"  style="font-size: 11px" class="input-sm form-control text_3_bal" readonly="" value="<?php echo $closing_details[0]['hundrad'] * 100?>"></td>
                            </tr>
                            <tr>
                                <td class="50" style="font-size: 11px"><?php echo display('50') ?></td>
                                <td><input type="text"  style="font-size: 11px" class="input-sm form-control text_4" name="fifty" onkeyup="cashCalculator()" onchange="cashCalculator()" value="<?php echo $closing_details[0]['fifty']?>"></td>
                                <td><input type="text" style="font-size: 11px" class="input-sm form-control text_4_bal" readonly="" value="<?php echo $closing_details[0]['fifty']* 50?>"></td>
                            </tr>
                            <tr>
                                <td class="20" style="font-size: 11px"><?php echo display('20') ?></td>
                                <td><input type="text"  style="font-size: 11px" class="input-sm form-control text_5" name="twenty" onkeyup="cashCalculator()" onchange="cashCalculator()" value="<?php echo $closing_details[0]['twenty']?>"></td>
                                <td><input type="text"  style="font-size: 11px" class="input-sm form-control text_5_bal" readonly="" value="<?php echo $closing_details[0]['twenty'] * 20?>"></td>
                            </tr>
                            <tr>
                                <td class="10" style="font-size: 11px"><?php echo display('10') ?></td>
                                <td><input type="text"  style="font-size: 11px" class="input-sm form-control text_6" name="ten" onkeyup="cashCalculator()" onchange="cashCalculator()" value="<?php echo $closing_details[0]['ten']?>"></td>
                                <td><input type="text"  style="font-size: 11px" class="input-sm form-control text_6_bal" readonly="" value="<?php echo $closing_details[0]['ten'] * 10?>"></td>
                            </tr>
                            <tr>
                                <td class="5" style="font-size: 11px"><?php echo display('5') ?></td>
                                <td><input type="text"  style="font-size: 11px" class="input-sm form-control text_7" name="five" onkeyup="cashCalculator()" onchange="cashCalculator()" value="<?php echo $closing_details[0]['five']?>"></td>
                                <td><input type="text"  style="font-size: 11px" class="input-sm form-control text_7_bal" readonly="" value="<?php echo $closing_details[0]['five'] * 5?>"></td>
                            </tr>


                        </table>


                    </div>




                </div>
            </div>
            <div class="col-sm-3">
                <div class="panel panel-bd lobidrag">
                    <div class="panel-heading">
                        <div class=" row">

                            <div class="col-sm-9">
                                <h1 for="cash_out" class="col-sm-3 panel-title">Torn Notes:</h1>
                            </div>
                        </div>

                    </div>

                    <div class="panel-body">
                        <table class="table table-bordered table-hover">
                            <thead>
                            <tr>
                                <th class="text-center"><?php echo display('note_name') ?></th>
                                <th class="text-center"><?php echo display('pcs') ?></th>
                                <th class="text-center"><?php echo display('ammount') ?></th>
                            </tr>
                            </thead>



<!--                            <thead>-->
<!--                            <tr>-->
<!--                                <th></th>-->
<!--                                <th class="text-center">Torn Notes:</th>-->
<!--                                <th></th>-->
<!--                            </tr>-->
<!--                            </thead>-->

                            <tr>
                                <td class="1000" style="font-size: 11px"><?php echo display('1000') ?></td>
                                <td><input type="text"  style="font-size: 11px" class="input-sm form-control t_text_1" name="thousands_x" onkeyup="cashCalculator()"  onchange="cashCalculator()" value="<?php echo $closing_details[0]['thousands_x']?>"></td>
                                <td><input type="text"  style="font-size: 11px" class="input-sm form-control t_text_1_bal" readonly="" value="<?php echo $closing_details[0]['thousands_x'] * 1000?>"></td>
                            </tr>
                            <tr>
                                <td class="500" style="font-size: 11px"><?php echo display('500') ?></td>
                                <td><input type="text"  style="font-size: 11px" class="input-sm form-control t_text_2" name="fivehnd_x" onkeyup="cashCalculator()" onchange="cashCalculator()" value="<?php echo $closing_details[0]['fivehnd_x']?>"></td>
                                <td><input type="text"  style="font-size: 11px" class="input-sm form-control t_text_2_bal" readonly="" value="<?php echo $closing_details[0]['fivehnd_x']*500?>"></td>
                            </tr>
                            <tr>
                                <td class="100" style="font-size: 11px"><?php echo display('100') ?></td>
                                <td><input type="text"  style="font-size: 11px" class="input-sm form-control t_text_3" name="hundrad_x" onkeyup="cashCalculator()" onchange="cashCalculator()" value="<?php echo $closing_details[0]['hundrad_x']?>"></td>
                                <td><input type="text"  style="font-size: 11px" class="input-sm form-control t_text_3_bal" readonly="" value="<?php echo $closing_details[0]['hundrad_x'] * 100 ?>"></td>
                            </tr>
                            <tr>
                                <td class="50" style="font-size: 11px"><?php echo display('50') ?></td>
                                <td><input type="text"  style="font-size: 11px" class="input-sm form-control t_text_4" name="fifty_x" onkeyup="cashCalculator()" onchange="cashCalculator()" value="<?php echo $closing_details[0]['fifty_x']?>"></td>
                                <td><input type="text"  style="font-size: 11px" class="input-sm form-control t_text_4_bal" readonly="" value="<?php echo $closing_details[0]['fifty_x'] * 50 ?> "></td>
                            </tr>
                            <tr>
                                <td class="20" style="font-size: 11px"><?php echo display('20') ?></td>
                                <td><input type="text"  style="font-size: 11px" class="input-sm form-control t_text_5" name="twenty_x" onkeyup="cashCalculator()" onchange="cashCalculator()" value="<?php echo $closing_details[0]['twenty_x']?>"></td>
                                <td><input type="text"  style="font-size: 11px" class="input-sm form-control t_text_5_bal" readonly="" value="<?php echo $closing_details[0]['twenty_x'] * 20?>"></td>
                            </tr>
                            <tr>
                                <td class="10" style="font-size: 11px"><?php echo display('10') ?></td>
                                <td><input type="text"   style="font-size: 11px" class="input-sm form-control t_text_6" name="ten_x" onkeyup="cashCalculator()" onchange="cashCalculator()" value="<?php echo $closing_details[0]['ten_x']?>"></td>
                                <td><input type="text"   style="font-size: 11px" class="input-sm form-control t_text_6_bal" readonly="" value="<?php echo $closing_details[0]['ten_x']  * 10 ?>"></td>
                            </tr>
                            <tr>
                                <td class="5" style="font-size: 11px"><?php echo display('5') ?></td>
                                <td><input type="text"  style="font-size: 11px" class="input-sm form-control t_text_7" name="five_x" onkeyup="cashCalculator()" onchange="cashCalculator()" value="<?php echo $closing_details[0]['five_x']?>"></td>
                                <td><input type="text"  style="font-size: 11px" class="input-sm form-control t_text_7_bal" readonly="" value="<?php echo $closing_details[0]['five_x'] * 5 ?>"></td>
                            </tr>

                            </tbody>


                        </table>


                    </div>




                </div>
            </div>
            <div class="col-sm-3">
                <div class="panel panel-bd lobidrag">
                    <div class="panel-heading">
                        <div class=" row">
                            <h1 for="cash_out" class="col-sm-4 panel-title">Cash-Out</h1>
                            <div class="col-sm-8">
                                <input id="" type="text" class="input-sm form-control total" readonly="" value="<?php echo $closing_details[0]['cash_out']  ?>" name="grndtotal_out">
                            </div>
                        </div>
                        <table id='cash_out_a' class="table table-bordered table-hover">
                            <thead>
                            <tr>
                                <th class="text-center">Name</th>
                                <th class="text-center"><?php echo display('ammount') ?></th>
                                <th class="text-center">Action</th>
                            </tr>
                            </thead>
                            <tbody>

                            {cash_out_details}
                            <tr class="cash_out_c">
                                <td class="2000" style="font-size: 11px">{category_name}</td>
                                <td>
                                    <input type="text" size="10" style="font-size: 11px" class="input-sm form-control text_0 cash_out_number" id="cash_out_{category_id}" name="cash_out_number[]" onkeyup="cashCalculator()"  onchange="cashCalculator()"  value="{amount}" />
                                    <input type="hidden" class="input-sm form-control category_id" name="category_id[]" value="{category_id}"  />

                                </td>

                                <td>

                                    <button type="button" id="save_btn_{category_id}" name="save_btn" title="Save as Draft"
                                            class="btn btn-info save_btn"
                                            style="border:none; outline:none"

                                            onclick="save_draft('{category_id}')"
                                    >
                                        <i class="fa fa-check" aria-hidden="true"></i>
                                    </button>


                                </td>

                            </tr>


                            {/cash_out_details}

                            </tbody>


                        </table>
                    </div>


                </div>
            </div>

        </div>
        </div>

        <?php echo form_close() ?>
        <!-- cashCalculator form -->
    </section>
</div>
<!-- Closing Account end -->

<script type="text/javascript">




    function save_draft(id) {

         var amount= $('#cash_out_'+id).val();

        var btn = $("#save_btn_" + id);

        // console.log(amount)
        var csrf_test_name = $('[name="csrf_test_name"]').val();

        $.ajax({
            url:"<?php echo base_url(); ?>Admin_dashboard/save_draft",
            method:"POST",
            data:{
                csrf_test_name:csrf_test_name,
                category_id:id,
                amount:amount,

            },
            success:function(data)
            {

                console.log(data);
                if (amount > 0){
                    toastr.success("Added to draft");
                    btn.html('<i class="fa fa-check-square-o"></i>');
                    btn.removeClass("btn-info");
                    btn.addClass("btn-success");

                    setTimeout(function(){
                            btn.html('<i class="fa fa-check"></i>')
                            btn.removeClass("btn-success");
                            btn.addClass("btn-info");
                        },
                        4000
                    );
                }else{
                    toastr.error("Please input first!!");
                }



                //$('#cart_details').html(data);



            }
            // error:function (e) {
            //
            //     console.log(e)
            //
            // }
        });
    }




    // $('.cash_out_number').keydown(function (e) {
    //     if (e.keyCode == 13) {
    //         $cash_out=$('#cash_out_number').val();
    //         $cat_id=$('.category_id').val();
    //
    //         console.log($cash_out+$cat_id)
    //     }
    // });




    $('form input').keydown(function (e) {
        if (e.keyCode == 13) {
            var inputs = $(this).parents("form").eq(0).find(":input");
            if (inputs[inputs.index(this) + 1] != null) {
                inputs[inputs.index(this) + 1].focus();
            }
            e.preventDefault();
            return false;
        }
    });




</script>




