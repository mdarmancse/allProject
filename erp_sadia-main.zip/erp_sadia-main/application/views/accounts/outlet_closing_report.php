
<!-- Closing Report Start -->
<div class="content-wrapper">
    <section class="content-header">
        <div class="header-icon">
            <i class="pe-7s-note2"></i>
        </div>
        <div class="header-title">
            <h1><?php echo display('closing_report') ?></h1>
            <small><?php echo display('account_closing_report') ?></small>
            <ol class="breadcrumb">
                <li><a href="#"><i class="pe-7s-home"></i> <?php echo display('home') ?></a></li>
                <li><a href="#"><?php echo display('report') ?></a></li>
                <li class="active"><?php echo display('closing_report') ?></li>
            </ol>
        </div>
    </section>

    <section class="content">
        <!-- Alert Message -->
        <?php
        $message = $this->session->userdata('message');
        if (isset($message)) {
            ?>
            <div class="alert alert-info alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <?php echo $message ?>                    
            </div>
            <?php
            $this->session->unset_userdata('message');
        }
        $error_message = $this->session->userdata('error_message');
        if (isset($error_message)) {
            ?>
            <div class="alert alert-danger alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <?php echo $error_message ?>                    
            </div>
            <?php
            $this->session->unset_userdata('error_message');
        }
        ?>



        <div class="row">
            <div class="col-sm-12">
                <div class="panel panel-default">
                    <div class="panel-body"> 
                        <?php echo form_open('Admin_dashboard/date_wise_outlet_closing_reports/', array('class' => 'form-inline', 'method' => 'get')) ?>
                        <?php $today = date('Y-m-d'); ?>
                        <label class="select"><?php echo display('search_by_date') ?>: <?php echo display('from') ?></label>
                        <input type="text" name="from_date"  value="<?php echo html_escape($today); ?>" class="datepicker form-control"/>
                        <label class="select"><?php echo display('to') ?></label>
                        <input type="text" name="to_date" class="datepicker form-control" value="<?php echo html_escape($today); ?>"/>
                        <button type="submit" class="btn btn-success"><?php echo display('search') ?></button>
                        <a  class="btn btn-warning" href="#" onclick="printDiv('printableArea')"><?php echo display('print') ?></a>
                        <?php echo form_close() ?>		            
                    </div>
                </div>
            </div>
        </div>


        <div class="row">
            <div class="col-sm-12">
                <div class="panel panel-bd lobidrag">
                    <div class="panel-heading">
                        <div class="panel-title">
                            <h4><?php echo display('closing_report') ?> </h4>
                        </div>
                    </div>
                    <div class="panel-body">
                        <div id="printableArea">
                             <table class="print-table" width="100%">

                                 <tr>
                                     <td align="left" class="print-table-tr" >

                                         <strong> <span class="text-success" id="time"></span></strong>

                                     </td>

                                     <td align="center" class="print-cominfo">
                                                        <span class="company-txt">
                                                            <?php echo html_escape($outlet_name);?>

                                                        </span><br>

                                         <hr/>
                                     </td>

                                     <td align="right" class="print-table-tr">
                                         <strong>
                                                         <span class="text-success">
                                                        <?php echo display('date')?>: <?php
                                                             echo date('d-M-Y');
                                                             ?>
                                                         </span>
                                         </strong>
                                     </td>
                                 </tr>

                             </table>

                            <div class="table-responsive">
                                <table class="table table-bordered table-striped table-hover">
                                    <caption class="text-center"><?php
                                    $from_date = (!empty($from_date)?$from_date:'');
                                     if($from_date){?><?php echo display('closing_report').'('.display('from').' '?>{from_date} <?php echo display('to').' '?>{to_date})
                                        <?php }?></caption>
                                    <thead>
                                        <tr>
                                            <th><?php echo display('sl') ?></th>
                                            <th><?php echo display('date') ?></th>
                                            <th>Outlet Name</th>

                                            <th class="text-right"><?php echo display('balance') ?></th>
                                            <th class="text-right">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        if ($daily_closing_data) {
                                            ?>
                                            <?php $i = 1;
                                            foreach ($daily_closing_data as $row) {
                                                ?>
                                                <tr>
                                                    <td><?php echo $i ?></td>
                                                    <td><?php echo html_escape($row['final_date']); ?></td>
                                                    <td><?php echo html_escape($row['outlet_name']); ?></td>
                                                    <td align="right"><?php
                                                        echo (($position == 0) ? "$currency " : " $currency");
                                                        $id=$row['closing_id'];

                                                        echo html_escape(number_format($row['last_day_closing'], 2, '.', ','));
                                                        ?></td>
                                                    <td  align="right">
                                                        <a href="<?php echo base_url("Admin_dashboard/view_closing_data/$id") ?>" class="btn btn-success btn-sm"  title="View"><i class="fa fa-eye"></i></a>
                                                    </td>
                                                </tr>
                                                <?php $i++;

                                            ?>
    <?php
}
?>
                                    </tbody>

                                    <tfoot>
                                    <tr>
                                        <td colspan="3" class="text-right"><b>Total Balance:</b></td>
                                        <td class="text-right"><b><?php
                                            echo (($position == 0) ? "$currency " : " $currency");

                                            echo html_escape(number_format($total, 2, '.', ','));
                                            ?></b></td>
                                    </tr>
                                    </tfoot>
                                    <?php } ?>
                                </table>
                            </div>
                        </div>
                        <div class="text-right"><?php echo html_escape($links) ?></div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
<!-- Closing Report End -->
<script type="text/javascript">

    var get_time = document.getElementById('time');

    function time() {
        var d = new Date();
        var s = d.getSeconds();
        var m = d.getMinutes();
        var h = d.getHours();
        get_time.textContent ='Time: '+
            ("0" + h).substr(-2) + ":" + ("0" + m).substr(-2) + ":" + ("0" + s).substr(-2);
    }

    setInterval(time, 1000);
</script>
