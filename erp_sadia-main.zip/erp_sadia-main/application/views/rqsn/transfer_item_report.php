
<!-- Closing Report Start -->
<div class="content-wrapper">
    <section class="content-header">
        <div class="header-icon">
            <i class="pe-7s-note2"></i>
        </div>
        <div class="header-title">
            <h1>Transfer Item Report</h1>
            <small>Transfer Item Report</small>
            <ol class="breadcrumb">
                <li><a href="#"><i class="pe-7s-home"></i> <?php echo display('home') ?></a></li>
                <li><a href="#"><?php echo display('report') ?></a></li>
                <li class="active">Transfer Item Report</li>
            </ol>
        </div>
    </section>

    <section class="content">
        <!-- Alert Message -->
        <?php
        $message = $this->session->userdata('message');
        if (isset($message)) {
            ?>
            <div class="alert alert-info alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <?php echo $message ?>                    
            </div>
            <?php
            $this->session->unset_userdata('message');
        }
        $error_message = $this->session->userdata('error_message');
        if (isset($error_message)) {
            ?>
            <div class="alert alert-danger alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <?php echo $error_message ?>                    
            </div>
            <?php
            $this->session->unset_userdata('error_message');
        }
        ?>



        <div class="row">
            <div class="col-sm-12">
                <div class="panel panel-default">
                    <div class="panel-body"> 
                        <?php echo form_open('Crqsn/date_wise_transfer_reports/', array('class' => 'form-inline', 'method' => 'get')) ?>
                        <?php $today = date('Y-m-d'); ?>
                        <label class="" for="category">Outlet:</label>
                        <div class="form-group">

                            <select  name="outlet_id" class="form-control" id="outlet">
                                <option value="">--select one -- </option>
                                <?php
                                foreach ($outlet_list as $outlet) {
                                    ?>
                                    <option value="<?php echo $outlet['outlet_id']; ?>"><?php echo $outlet['outlet_name']; ?></option>
                                <?php } ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label class="" for="from_date"><?php echo display('start_date') ?></label>
                            <input autocomplete="off" type="text" name="from_date" class="form-control datepicker" id="from_date" placeholder="<?php echo display('start_date') ?>" value="">
                        </div>

                        <div class="form-group">
                            <label class="" for="to_date"><?php echo display('end_date') ?></label>
                            <input autocomplete="off" type="text" name="to_date" class="form-control datepicker" id="to_date" placeholder="<?php echo display('end_date') ?>" value="">
                        </div>
                        <button type="submit" class="btn btn-success"><?php echo display('search') ?></button>
                        <a  class="btn btn-warning" href="#" onclick="printDiv('printableArea')"><?php echo display('print') ?></a>
                        <?php echo form_close() ?>		            
                    </div>
                </div>
            </div>
        </div>


        <div class="row">
            <div class="col-sm-12">
                <div class="panel panel-bd lobidrag">
                    <div class="panel-heading">
                        <div class="panel-title">
                            <h4>Transfer Item Report </h4>
                        </div>
                    </div>
                    <div class="panel-body">
                        <div id="printableArea">
                             <table class="print-table" width="100%">
                                                
                                                <tr>
                                                    <td align="left" class="print-table-tr">
                                                        <img src="<?php echo html_escape($software_info[0]['logo']);?>" alt="logo">
                                                    </td>
                                                    <td align="center" class="print-cominfo">
                                                        <span class="company-txt">
                                                            <?php echo html_escape($company[0]['company_name']);?>
                                                           
                                                        </span><br>
                                                        <?php echo html_escape($company[0]['address']);?>
                                                        <br>
                                                        <?php echo html_escape($company[0]['email']);?>
                                                        <br>
                                                         <?php echo html_escape($company[0]['mobile']);?>
                                                        
                                                    </td>
                                                   
                                                     <td align="right" class="print-table-tr">
                                                        <date>
                                                        <?php echo display('date')?>: <?php
                                                        echo date('d-M-Y');
                                                        ?> 
                                                    </date>
                                                    </td>
                                                </tr>            
                                   
                                </table>

                            <div class="table-responsive">
                                <table class="datatable table table-bordered table-hover">
                                    <thead>
                                    <tr>
                                        <th><?php echo display('sl_no') ?></th>
                                        <th>Reacquisition NO</th>
                                        <th>Outlet Name</th>
                                        <th><?php echo display('date') ?></th>

                                        <!--                                 <th>Product Name</th>-->
                                        <!--                                <th>Unit</th>-->
                                        <!--                                 <th>Cook</th>-->
                                        <!--                                 <th>Nan</th>-->
                                        <!--                                 <th>Grill</th>-->
                                        <!--                                 <th>Pantry</th>-->
                                        <!--                                 <th>Hall</th>-->
                                        <!--                                 <th style="width: 70px">Total Quantity</th>-->
                                        <!--                                 <th style="width: 70px">Transfer Quantity</th>-->


                                        <th><?php echo display('action') ?></th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php if (!empty($approve)) ?>
                                    <?php $sl = 1; ?>
                                    <?php foreach ($t as $approve) { ?>
                                        <tr>
                                            <td><?php echo $sl++; ?></td>
                                            <td> <?php echo $approve['rqsn_no']?> </td>
                                            <td> <?php echo $approve['outlet_name']?> </td>
                                            <td><?php echo $approve['tr_date']?> </td>


                                            <?php $id=$approve['rqsn_id'] ?>


                                            <td class="text-center">


                                                <a href="<?php echo base_url("Crqsn/tr_items/$id/") ?>" class="btn btn-info btn-sm"  title="Edit"><i class="fa fa-info-circle"></i></a>



                                            </td>
                                        </tr>
                                    <?php } ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="text-right"><?php echo html_escape($links) ?></div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
<!-- Closing Report End -->