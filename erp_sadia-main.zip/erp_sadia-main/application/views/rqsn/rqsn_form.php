
<!-- Invoice js -->
<script src="<?php echo base_url() ?>my-assets/js/admin_js/rqsn.js.php" type="text/javascript"></script>
<style type="text/css">
    .form-control{
        padding: 6px 5px;
    }

    th, td {
        width: 2px;
        height: 2px;
        padding: 10px;
        text-align: left;
    }

</style>
<!-- Customer type change by javascript end -->

<!-- Add New Invoice Start -->
<div class="content-wrapper">


    <section class="content">
        <!-- Alert Message -->
        <?php
        $message = $this->session->userdata('message');
        if (isset($message)) {
            ?>
            <div class="alert alert-info alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <?php echo $message ?>
            </div>
            <?php
            $this->session->unset_userdata('message');
        }
        $error_message = $this->session->userdata('error_message');
        if (isset($error_message)) {
            ?>
            <div class="alert alert-danger alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <?php echo $error_message ?>
            </div>
            <?php
            $this->session->unset_userdata('error_message');
        }
        ?>


        <!--Add Invoice -->
        <div class="row">
            <div class="col-sm-12">

                    <div class="rqsn_panel" >
                        <h4 style="margin-left: 16px;margin-bottom: 10px;margin-top: 0;font-weight: bolder">Requisition Form:</h4>
                        <?php echo form_open_multipart('Crqsn/insert_rqsn',array('class' => 'form-vertical','method'=>'post', 'id' => 'insert_rqsn'))?>
                   <div class="col-sm-12">

                       <div class="row">

                           <div class="col-sm-3" id="payment_from">

                               <div class="form-group row">
                                   <label for="payment_type" class="col-sm-2 col-form-label">From<i class="text-danger">*</i></label>
                                   <div class="col-sm-6">
                                       <select name="from_id" class="form-control" required=""  tabindex="3">
                                           <?php foreach($outlet_list as $outlet){?>
                                               <option value="<?php echo html_escape($outlet['outlet_id'])?>"><?php echo html_escape($outlet['outlet_name']) ;?></option>
                                           <?php }?>


                                       </select>

                                   </div>

                               </div>


                           </div>

                           <div class="col-sm-3" id="payment_from">

                               <div class="form-group row">
                                   <label for="payment_type" class="col-sm-3 col-form-label">To<i class="text-danger">*</i></label>
                                   <div class="col-sm-6">
                                       <select name="to_id" class="form-control" required=""  tabindex="3">
                                           <?php foreach($cw_list as $cw){?>
                                               <option value="<?php echo html_escape($cw['warehouse_id'])?>"><?php echo html_escape($cw['central_warehouse']) ;?></option>
                                           <?php }?>



                                       </select>

                                   </div>

                               </div>


                           </div>
                           <div class="col-sm-3">
                               <div class="form-group row">
                                   <label for="date" class="col-sm-4 col-form-label"><?php echo display('date') ?> <i class="text-danger">*</i></label>
                                   <div class="col-sm-8">
                                       <?php

                                       $date = date('d-m-Y');
                                       ?>
                                       <input class="form-control" type="text" size="50" name="invoice_date" id="date" required value="<?php echo html_escape($date); ?>" tabindex="4" readonly/>
                                   </div>
                               </div>

                             </div>

                           <div class="col-sm-3">
                               <div class="form-group row">
                                   <label class="col-sm-4 col-form-label">Product Name : </label>
                                   <div class="col-sm-8">
                                       <input type="text" autocomplete="off" name="product_name" onkeypress="productList_with_cat_subcat()" id="product_name" class="form-control productSelection" placeholder="<?php echo display('product_name') ?>" tabindex="5">

                                       <input type="hidden" class="autocomplete_hidden_value product_id" id="SchoolHiddenId" />
                                       <input type="hidden" value="<?php echo base_url() ?>" class="baseUrl" name="" id="baseUrl" />

                                   </div>
                               </div>

                           </div>
                   </div>


                        <div class="row">

                            </div>




                        </div>
                        <br>

                        <div class="col-sm-12">
                            <div class="panel panel-bd lobidrag">

                                <div id="cart_details">
                                    <h3 align="center">Requisition is Empty</h3>
                                </div>
<!--                                <div class="panel-heading">-->
<!---->
<!--                                    <table id='rqsn_table' class="table table-bordered table-hover " style="width:100%">-->
<!--                                        <thead>-->
<!--                                        <tr>-->
<!---->
<!--                                            <th width="5%" class="text-center">Item Name(EN)</th>-->
<!--                                            <th width="5%" class="text-center">Item Name(BN)</th>-->
<!--                                            <th width="5%" class="text-center">TTL QTY</th>-->
<!--                                            <th width="5%" class="text-center">Unit</th>-->
<!--                                            <th width="5%" class="text-center">Cook</th>-->
<!--                                            <th width="5%" class="text-center">Nan</th>-->
<!--                                            <th width="5%" class="text-center">Grill</th>-->
<!--                                            <th width="5%" class="text-center">Pantry</th>-->
<!--                                            <th width="5%" class="text-center">Hall</th>-->
<!---->
<!--                                        </tr>-->
<!--                                        </thead>-->
<!--                                        <tbody>-->
<!---->
<!--                                        {all_product}-->
<!---->
<!--                                        <tr class="cash_out_c" >-->
<!---->
<!---->
<!--                                            <td class="text-center" width="5%" style="font-size: 12px">-->
<!--                                                {product_name}-->
<!--                                                <input size="10"  type="hidden" value="{product_name}" class="form-control input-sm product_name_{product_id}" name="product_name[]"  readonly/>-->
<!--                                                <input  type="hidden" id="product_id" value="{product_id}" class="form-control product_id_{product_id}" name="product_id[]"   onkeyup="quantityCalculator({product_id})"  onchange="quantityCalculator({product_id})"/>-->
<!--                                            </td>-->
<!--                                            <td class="text-center" width="5%" style="font-size: 12px" >{product_name_bn}</td>-->
<!---->
<!--                                            <td  class="text-center" width="5px"><input  style="width: 60px"   type="number" id="total_quantity" value="0" class="form-control input-sm total_quantity_{product_id}"  name="total_quantity[]" readonly/> </td>-->
<!--                                            <td  class="text-center" style="font-size: 12px">-->
<!--                                                {unit}-->
<!--                                                <input  size="5" type="hidden" value="{unit}" class="form-control input-sm unit_{product_id}" name="unit[]"  readonly/>  </td>-->
<!--                                            <td  class="text-center" >-->
<!--                                                <input  style="width: 60px"  type="number" id="cook" value="0" class="form-control input-sm cook_{product_id}" name="cook[]"   onkeyup="quantityCalculator({product_id})"  onchange="quantityCalculator({product_id})"/>-->
<!--                                            </td>-->
<!--                                            <td  class="text-center">-->
<!--                                                <input   style="width: 60px"  type="number" value="0" class="form-control input-sm nan_{product_id}" name="nan[]"  onkeyup="quantityCalculator({product_id})"   onchange="quantityCalculator({product_id})"/>-->
<!--                                            </td>-->
<!--                                            <td  class="text-center"><input  style="width: 60px;"   type="number" value="0" class="form-control input-sm   grill_{product_id}" name="grill[]"  onkeyup="quantityCalculator({product_id})"   onchange="quantityCalculator({product_id})"/>  </td>-->
<!--                                            <td  class="text-center"><input  style="width: 60px"  type="number" value="0" class="form-control   input-sm pantry_{product_id}" name="pantry[]"  onkeyup="quantityCalculator({product_id})"   onchange="quantityCalculator({product_id})" /> </td>-->
<!--                                            <td  class="text-center"><input  style="width: 60px"   type="number" value="0" class="form-control  input-sm  hall_{product_id}" name="hall[]"  onkeyup="quantityCalculator({product_id})"   onchange="quantityCalculator({product_id})" /> </td>-->

<!---->
<!--                                        </tr>-->
<!---->
<!--                                        {/all_product}-->
<!---->
<!---->
<!---->
<!--                                        --><?php //echo form_close() ?>
<!---->
<!---->
<!--                                    </table>-->
<!--                                </div>-->

                            </div>
                        </div>



                        <div class="form-group row">
                            <div class="col-sm-6" style="margin-right: 5rem" >
                                <input type="submit" id="insert_rqsn" class="btn btn-success" name="" value="<?php echo display('submit') ?>" tabindex="17"/>
                                <!-- <input type="submit" value="<?php echo display('submit_and_add_another') ?>" name="add-purchase-another" class="btn btn-large btn-success" id="add_purchase_another" > -->
                            </div>
                        </div>



                        <?php echo form_close()?>
                    </div>

                </div>
            </div>





        </div>
    </section>
</div>
<!-- Invoice Report End -->

<script type="text/javascript">

    $(document).ready(function(){
        var base_url = $('.baseUrl').val();
        $('#cart_details').load(base_url + "Crqsn/load");

            $('#rqsn_table').DataTable();





    });



    function quantityCalculator(sl){
        var row = $("#rqsn_table tbody tr").length;
        var cook = 'cook_'+sl;
        var grill = 'grill_'+sl;
        var hall = 'hall_'+sl;
        var pantry = 'pantry_'+sl;
        var stuff = 'stuff_'+sl;
        var nan = 'nan_'+sl;
        var total = 'total_quantity_'+sl;
     // var ck=  $('.cook').val();

     var cook_qty=  parseFloat( $('.'+cook).val());
     var grill_qty=  parseFloat( $('.'+grill).val());
     var hall_qty=  parseFloat( $('.'+hall).val());
     var pantry_qty=  parseFloat( $('.'+pantry).val());
     var nan_qty=  parseFloat( $('.'+nan).val());
     var stuff_qty=  parseFloat( $('.'+stuff).val());

  //    var dd=  $('#product_td').attr("data-id");

      //  alert(row)

      var total_quantity=cook_qty+grill_qty+hall_qty+pantry_qty+nan_qty+stuff_qty;

        // $('#product_td').closest('tr').find('.total_quantity').val(total_quantity)
       $('.'+total).val(total_quantity);
         console.log(total_quantity);

        // var values = {};
        // $('td input').each(function() {
        //     values[$(this).attr('cook')] = $(this).val();
        // });
        // alert(JSON.stringify(values));


    }

    function productList_with_cat_subcat(sl) {

        var csrf_test_name = $('[name="csrf_test_name"]').val();
        var base_url = $("#base_url").val();




// Auto complete
        var options = {
            minLength: 0,
            source: function (request, response) {
                var product_name = $('#product_name').val();
                $.ajax({
                    url: base_url + "Crqsn/autosearch",
                    method: 'post',
                    dataType: "json",
                    data: {
                        term: request.term,
                        product_name: product_name,
                        // cat_id: cat_id,
                        // subcat_id: subcat_id,
                        // brand_id: brand_id,
                        // mdoel_id: model_id,
                        csrf_test_name: csrf_test_name,

                    },
                    success: function (data) {
                        response(data);

                    }
                });
            },
            focus: function (event, ui) {
                $(this).val(ui.item.label);
                return false;
            },
            select: function (event, ui) {
                $(this).parent().parent().find(".autocomplete_hidden_value").val(ui.item.value);
                $(this).val(ui.item.label);
                var id = ui.item.value;
                var base_url = $('.baseUrl').val();

                $.ajax({
                    type: "POST",
                    url: base_url + "Crqsn/add_product",
                    data: {
                        product_id: id,
                        csrf_test_name: csrf_test_name
                    },
                    cache: false,
                    success: function () {
                        toastr.success('Product Added.');
                        $('#cart_details').load(base_url + "Crqsn/load");
                        $("#product_name").val('');
                    }
                });

                $(this).unbind("change");
                return false;
            }
        }




        $('body').on('keypress.autocomplete', '.productSelection', function () {
            $(this).autocomplete(options);
        });
    }

    $(document).on('click', '.remove_inventory', function() {
        var row_id = $(this).attr("id");
        var csrf_test_name = $('[name="csrf_test_name"]').val();
        if (confirm("Are you sure you want to remove this?")) {
            $.ajax({
                url: "<?php echo base_url(); ?>Crqsn/remove",
                method: "POST",
                data: {
                    csrf_test_name: csrf_test_name,
                    row_id: row_id
                },
                success: function(data) {
                    toastr.error("Product removed from List!");
                    $('#cart_details').html(data);
                }
            });
        } else {
            return false;
        }
    });

    $(document).on('click', '#clear_cart', function() {
        if (confirm("Are you sure you want to clear cart?")) {
            $.ajax({
                url: "<?php echo base_url(); ?>Crqsn/clear",
                success: function(data) {
                    toastr.error("Your cart has been clear...");
                    $('#cart_details').html(data);
                }
            });
        } else {
            return false;
        }
    });

</script>












