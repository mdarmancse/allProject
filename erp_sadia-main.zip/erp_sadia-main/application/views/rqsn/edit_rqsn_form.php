
<!-- Invoice js -->
<script src="<?php echo base_url() ?>my-assets/js/admin_js/rqsn.js.php" type="text/javascript"></script>
<style type="text/css">
    .form-control{
        padding: 6px 5px;
    }
</style>
<!-- Customer type change by javascript end -->

<!-- Add New Invoice Start -->
<div class="content-wrapper">
    <section class="content-header">
        <div class="header-icon">
            <i class="pe-7s-note2"></i>
        </div>
        <div class="header-title">
            <h1>Requisition</h1>
            <small>Requisition Item</small>
            <ol class="breadcrumb">
                <li><a href="#"><i class="pe-7s-home"></i> <?php echo display('home') ?></a></li>
                <li><a href="#">Requisition</a></li>
                <li class="active">Requisition Item</li>
            </ol>
        </div>
    </section>

    <section class="content">
        <!-- Alert Message -->
        <?php
        $message = $this->session->userdata('message');
        if (isset($message)) {
            ?>
            <div class="alert alert-info alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <?php echo $message ?>
            </div>
            <?php
            $this->session->unset_userdata('message');
        }
        $error_message = $this->session->userdata('error_message');
        if (isset($error_message)) {
            ?>
            <div class="alert alert-danger alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <?php echo $error_message ?>
            </div>
            <?php
            $this->session->unset_userdata('error_message');
        }
        ?>
<!--        <div class="row">-->
<!--            <div class="col-sm-12">-->
<!---->
<!--                --><?php //if($this->permission1->method('manage_invoice','read')->access()){ ?>
<!--                    <a href="--><?php //echo base_url('Cinvoice/manage_invoice') ?><!--" class="btn btn-info m-b-5 m-r-2"><i class="ti-align-justify"> </i> --><?php //echo display('manage_invoice') ?><!-- </a>-->
<!--                --><?php //}?>
<!--                --><?php //if($this->permission1->method('pos_invoice','create')->access()){ ?>
<!--                    <a href="--><?php //echo base_url('Cinvoice/pos_invoice') ?><!--" class="btn btn-primary m-b-5 m-r-2"><i class="ti-align-justify"> </i>  --><?php //echo display('pos_invoice') ?><!-- </a>-->
<!--                --><?php //}?>
<!---->
<!---->
<!--            </div>-->
<!--        </div>-->


        <!--Add Invoice -->
        <div class="row">
            <div class="col-sm-12">
                <div class="panel panel-bd lobidrag">
                    <div class="panel-heading">
                        <div class="panel-title">
                            <h4>Requisition Item</h4>

                        </div>
                    </div>



                    <div class="rqsn_panel" >
                        <?php echo form_open_multipart('Crqsn/update_rqsn',array('class' => 'form-vertical', 'id' => 'insert_rqsn'))?>
                        <?php $today = date('Y-m-d'); ?>

                        <div class="col-sm-12">
                            <div class="row">

                                <div class="col-sm-4">
                                    <div class="form-group row">
                                        <label for="date" class="col-sm-4 col-form-label">RQ No: </label>
                                        <div class="col-sm-8">

                                            <input autocomplete="off" class=" form-control input-sm" type="text" size="50" name="tr_date" id="date"  value="<?php echo html_escape($all_product[0]['rqsn_no']) ;?>" tabindex="4" readonly />
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-4" id="payment_from">

                                    <div class="form-group row">
                                        <label for="payment_type" class="col-sm-3 col-form-label">From<i class="text-danger">*</i></label>
                                        <div class="col-sm-6">
                                            <select name="from_id" class="form-control" required=""  tabindex="3">
                                                <!--                                            --><?php //foreach($outlet_list as $outlet){?>
                                                <option value="<?php echo html_escape($all_product[0]['outlet_id'])?>"><?php echo html_escape($all_product[0]['outlet_name']) ;?></option>
                                                <!--                                            --><?php //}?>
                                                <!--                                            --><?php //foreach($cw_list as $cw){?>
                                                <!--                                                <option value="--><?php //echo html_escape($cw['warehouse_id'])?><!--">--><?php //echo html_escape($cw['central_warehouse']) ;?><!--</option>-->
                                                <!--                                            --><?php //}?>

                                            </select>

                                        </div>

                                    </div>


                                </div>


                                <div class="col-sm-4">
                                    <div class="form-group row">
                                        <label for="date" class="col-sm-4 col-form-label"><?php echo display('date') ?> <i class="text-danger">*</i></label>
                                        <div class="col-sm-8">
                                            <?php

                                            $date = date('d-m-Y');
                                            ?>
                                            <input autocomplete="off" class="datepicker form-control input-sm" type="text" size="50" name="tr_date" id="date" required value="<?php echo $date?>" tabindex="4" />
                                        </div>
                                    </div>
                                </div>


                            </div>

                        </div>


                        <div class="row">




                        </div>
                        <br>

                        <div class="col-sm-12">
                            <div class="panel panel-bd lobidrag">
                                <div class="panel-heading">

                                    <table id='rqsn_table' class="table table-bordered table-hover " style="width:100%">
                                        <thead>
                                        <tr>

                                            <th class="text-center">Item Name(EN)</th>
                                            <th class="text-center">Item Name(BN)</th>
                                            <th class="text-center">TTL QTY</th>
                                            <th class="text-center">Unit</th>
                                            <th class="text-center">Cook</th>
                                            <th class="text-center">Nan</th>
                                            <th class="text-center">Grill</th>
                                            <th class="text-center">Pantry</th>
                                            <th class="text-center">Hall</th>
                                            <th class="text-center">Stuff</th>

                                        </tr>
                                        </thead>
                                        <tbody>

                                        <?php foreach ($all_product as $product) {

                                        ?>
                                        <tr class="cash_out_c">

<!--                                            <td  class="2000" >{product_name}</td>-->
                                            <td class="text-center" style="font-size: 12px">
                                                <?php echo $product['product_name']?>

                                                <input  type="hidden" id="product_id" value="<?php echo $product['product_id']?>" class="form-control input-sm product_id_<?php echo $product['product_id']?>" name="product_id[]"   onkeyup="quantityCalculator(<?php echo $product['product_id']?>)"  onchange="quantityCalculator(<?php echo $product['product_id']?>)" readonly/>
                                                <input  type="hidden" id="rqsn_id" value="<?php echo $product['rqsn_id']?>" class="form-control input-sm" name="rqsn_id" readonly/>
                                            </td>
                                            <td class="text-center" style="font-size: 12px">
                                                <?php echo $product['product_name_bn']?>

                                            </td>
                                            <td class="text-center">
                                                <input step="0.01"  style="width: 80px" type="text" id="total_quantity" value="<?php echo $product['total_quantity']-$product['total_quantity_t']?>" class="form-control input-sm  total_quantity_<?php echo $product['product_id']?>"  name="total_quantity[]" readonly/>
                                                <input step="0.01" style="width: 80px" type="text" id="total_quantity" value="<?php echo $product['total_quantity']-$product['total_quantity_t']?>" class="form-control  input-sm total_quantity_t_<?php echo $product['product_id']?>"  name="total_quantity_t[]" readonly/>
                                            </td>
                                            <td class="text-center" style="font-size: 12px">
                                                <?php echo $product['unit']?>
                                                <input  type="hidden" value="<?php echo $product['unit']?>" class="form-control unit_{product_id}" name="unit[]"  readonly/>  </td>
                                            <td class="text-center">
                                                <input  step="0.01" style="width: 80px" type="text" id="cook" value="<?php echo $product['cook']-$product['cook_t']?>" class="form-control input-sm  cook_<?php echo $product['product_id']?>" name="cook[]"   onkeyup="quantityCalculator(<?php echo $product['product_id']?>)"  onchange="quantityCalculator(<?php echo $product['product_id']?>)" readonly/>
                                                <input  step="0.01" style="width: 80px" type="text" id="cook" value="<?php echo $product['cook']-$product['cook_t']?>" class="form-control  input-sm cook_t_<?php echo $product['product_id']?>" name="cook_t[]"   onkeyup="quantityCalculator(<?php echo $product['product_id']?>)"  onchange="quantityCalculator(<?php echo $product['product_id']?>)" />
                                            </td>
                                            <td class="text-center">
                                                <input step="0.01" style="width: 80px" type="text" value="<?php echo $product['nan']-$product['nan_t']?>" class="form-control  input-sm nan_<?php echo $product['product_id']?>" name="nan[]"  onkeyup="quantityCalculator(<?php echo $product['product_id']?>)"   onchange="quantityCalculator(<?php echo $product['product_id']?>)" readonly/>
                                                <input step="0.01" style="width: 80px" type="text" value="<?php echo $product['nan']-$product['nan_t']?>" class="form-control  input-sm nan_t_<?php echo $product['product_id']?>" name="nan_t[]"  onkeyup="quantityCalculator(<?php echo $product['product_id']?>)"   onchange="quantityCalculator(<?php echo $product['product_id']?>)" />
                                            </td>

                                            <td class="text-center">
                                                <input step="0.01" style="width: 80px" type="text" value="<?php echo $product['grill']-$product['grill_t']?>" class="form-control input-sm grill_<?php echo $product['product_id']?>" name="grill[]"  onkeyup="quantityCalculator(<?php echo $product['product_id']?>)"   onchange="quantityCalculator(<?php echo $product['product_id']?>)" readonly/>
                                                <input step="0.01" style="width: 80px" type="text" value="<?php echo $product['grill']-$product['grill_t']?>" class="form-control input-sm grill_t_<?php echo $product['product_id']?>" name="grill_t[]"  onkeyup="quantityCalculator<?php echo $product['product_id']?>"   onchange="quantityCalculator(<?php echo $product['product_id']?>)" />
                                            </td>

                                            <td class="text-center">
                                                <input step="0.01" style="width: 80px" type="text" value="<?php echo $product['pantry']-$product['pantry_t']?>" class="form-control  input-sm pantry_<?php echo $product['product_id']?>" name="pantry[]"  onkeyup="quantityCalculator(<?php echo $product['product_id']?>)"   onchange="quantityCalculator(<?php echo $product['product_id']?>)" readonly/>
                                                <input step="0.01" style="width: 80px"  type="text" value="<?php echo $product['pantry']-$product['pantry_t']?>" class="form-control input-sm  pantry_t_<?php echo $product['product_id']?>" name="pantry_t[]"  onkeyup="quantityCalculator(<?php echo $product['product_id']?>)"   onchange="quantityCalculator(<?php echo $product['product_id']?>)" />
                                            </td>
                                            <td class="text-center">
                                                <input step="0.01" style="width: 80px" type="text" value="<?php echo $product['hall']-$product['hall_t']?>" class="form-control input-sm hall_<?php echo $product['product_id']?>" name="hall[]"  onkeyup="quantityCalculator(<?php echo $product['product_id']?>)"   onchange="quantityCalculator(<?php echo $product['product_id']?>)" readonly/>
                                                <input step="0.01" style="width: 80px" type="text" value="<?php echo $product['hall']-$product['hall_t']?>" class="form-control input-sm hall_t_<?php echo $product['product_id']?>" name="hall_t[]"  onkeyup="quantityCalculator(<?php echo $product['product_id']?>)"   onchange="quantityCalculator(<?php echo $product['product_id']?>)" />
                                            </td>

                                            <td class="text-center">
                                                <input  step="0.01" style="width: 80px" type="text" value="<?php echo $product['stuff']-$product['stuff_t']?>" class="form-control input-sm  stuff_<?php echo $product['product_id']?>" name="stuff[]"  onkeyup="quantityCalculator(<?php echo $product['product_id']?>)"   onchange="quantityCalculator(<?php echo $product['product_id']?>)" readonly/>
                                                <input  step="0.01" style="width: 80px" type="text" value="<?php echo $product['stuff']-$product['stuff_t']?>" class="form-control input-sm  stuff_t_<?php echo $product['product_id']?>" name="stuff_t[]"  onkeyup="quantityCalculator(<?php echo $product['product_id']?>)"   onchange="quantityCalculator(<?php echo $product['product_id']?>)" />
                                            </td>


                                        </tr>

                                            <?php
                                        } ?>


<!--                                        <tfoot>-->
<!--                                        <tr>-->
<!--                                            <td colspan="1" align="right"><b>--><?php //echo display('grand_total') ?><!--</b></td>-->
<!--                                            <td class=""><input id="total" type="text" class="form-control" readonly="" name="grndtotal"></td>-->
<!--                                        </tr>-->
<!---->
<!--                                        </tfoot>-->
                                        <?php echo form_close() ?>


                                    </table>
                                </div>

                            </div>
                        </div>

                        <?php  $id= $product['rqsn_id']?>

                        <div class="form-group row">
                            <div class="col-sm-6" style="margin-right: 5rem" >
                                <input type="submit" id="insert_rqsn" class="btn btn-success btn-sm" name="" value="<?php echo display('submit') ?>" tabindex="17"/>
<!--                                <button  class="btn btn-info" onclick="printDiv('printableArea')"><span class="fa fa-print"></span></button>-->
<!--                                <input  style="width: 25px;height: 25px" type="checkbox" id="insert_rqsn" class="btn btn-warning" name="void" value="Void" tabindex="17"/><label style="margin-top: 10px;padding: 5px" class="form-control-label"> (Void)</label>-->
                                <a href="<?php echo base_url("Crqsn/pre_chalan_print/$id/") ?>" class="btn btn-sm btn-info"  title=""><span class="fa fa-print"></span></i></a>
<!--                                 <input type="submit" value="Void" name="add-purchase-another" class="btn btn-sm btn-success" id="add_purchase_another" >-->
                            </div>
                        </div>



                        <?php echo form_close()?>
                    </div>

                </div>
            </div>
<!--            <div class="modal fade" id="printconfirmodal" tabindex="-1" role="dialog" aria-labelledby="printconfirmodal" aria-hidden="true">-->
<!--                <div class="modal-dialog modal-sm">-->
<!--                    <div class="modal-content">-->
<!--                        <div class="modal-header">-->
<!---->
<!--                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>-->
<!---->
<!--                            <h4 class="modal-tit le" id="myModalLabel">--><?php //echo display('print') ?><!--</h4>-->
<!--                        </div>-->
<!--                        <div class="modal-body">-->
<!--                            --><?php //echo form_open('Cinvoice/invoice_inserted_data_manual', array('class' => 'form-vertical', 'id' => '', 'name' => '')) ?>
<!--                            <div id="outputs" class="hide alert alert-danger"></div>-->
<!--                            <h3> --><?php //echo display('successfully_inserted') ?><!--</h3>-->
<!--                            <h4>--><?php //echo display('do_you_want_to_print') ?><!-- ??</h4>-->
<!--                            <label class="ab">With Chalan </label>-->
<!--                            <input type="checkbox"  name="chalan_value" value=''>-->
<!---->
<!---->
<!--                            <input type="hidden" name="invoice_id" id="inv_id">-->
<!--                        </div>-->
<!--                        <div class="modal-footer">-->
<!--                            <button type="button" onclick="cancelprint()" class="btn btn-default" data-dismiss="modal">--><?php //echo display('no') ?><!--</button>-->
<!--                            <button type="submit" class="btn btn-primary" id="yes">--><?php //echo display('yes') ?><!--</button>-->
<!--                            --><?php //echo form_close() ?>
<!--                        </div>-->
<!--                    </div>-->
<!--                </div>-->
<!--            </div>-->


            <div class="modal fade modal-success" id="cust_info" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">

                            <a href="#" class="close" data-dismiss="modal">&times;</a>
                            <h3 class="modal-title"><?php echo display('add_new_customer') ?></h3>
                        </div>

                        <div class="modal-body">
                            <div id="customeMessage" class="alert hide"></div>
                            <?php echo form_open('Cinvoice/instant_customer', array('class' => 'form-vertical', 'id' => 'newcustomer')) ?>
                            <div class="panel-body">
                                <input type ="hidden" name="csrf_test_name" id="" value="<?php echo $this->security->get_csrf_hash();?>">
                                <div class="form-group row">
                                    <label for="customer_id_two" class="col-sm-3 col-form-label">Customer ID <i class="text-danger">*</i></label>
                                    <div class="col-sm-6">
                                        <input class="form-control" name ="customer_id_two" id="" type="text" placeholder="Customer ID"  required="" tabindex="1">
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="customer_name" class="col-sm-3 col-form-label"><?php echo display('customer_name') ?> <i class="text-danger">*</i></label>
                                    <div class="col-sm-6">
                                        <input class="form-control" name ="customer_name" id="" type="text" placeholder="<?php echo display('customer_name') ?>"  required="" tabindex="1">
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="email" class="col-sm-3 col-form-label"><?php echo display('customer_email') ?></label>
                                    <div class="col-sm-6">
                                        <input class="form-control" name ="email" id="email" type="email" placeholder="<?php echo display('customer_email') ?>" tabindex="2">
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="mobile" class="col-sm-3 col-form-label"><?php echo display('customer_mobile') ?></label>
                                    <div class="col-sm-6">
                                        <input class="form-control" name ="mobile" id="mobile" type="number" placeholder="<?php echo display('customer_mobile') ?>" min="0" tabindex="3">
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="customer_id_two" class="col-sm-3 col-form-label">Contact Person</label>
                                    <div class="col-sm-6">
                                        <input class="form-control" name ="contact_person" id="" type="text" placeholder="Contact Person"  required="" tabindex="1">
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="customer_id_two" class="col-sm-3 col-form-label">Contact Mobile</label>
                                    <div class="col-sm-6">
                                        <input class="form-control" name ="contact" id="" type="number" placeholder="Contact Mobile"  required="" tabindex="1">
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="address " class="col-sm-3 col-form-label"><?php echo display('customer_address') ?></label>
                                    <div class="col-sm-6">
                                        <textarea class="form-control" name="address" id="address " rows="3" placeholder="<?php echo display('customer_address') ?>" tabindex="4"></textarea>
                                    </div>
                                </div>

                            </div>

                        </div>

                        <div class="modal-footer">

                            <a href="#" class="btn btn-danger" data-dismiss="modal">Close</a>

                            <input type="submit" class="btn btn-success" value="Submit">
                        </div>
                        <?php echo form_close() ?>
                    </div><!-- /.modal-content -->
                </div><!-- /.modal-dialog -->
            </div><!-- /.modal -->

        </div>
    </section>
</div>
<!-- Invoice Report End -->

<script type="text/javascript">
    $(document).ready(function(){


        $('#rqsn_table').DataTable();

    });



    $("body").on("click",".remove_cheque",function(e){
        $(this).parents('.cheque').remove();
        //the above method will remove the user_data div
    });



    function quantityCalculator(sl){
        var row = $("#rqsn_table tbody tr").length;
        var ck = 'cook_'+sl;
        var gr = 'grill_'+sl;
        var hl = 'hall_'+sl;
        var pn = 'pantry_'+sl;
        var nn = 'nan_'+sl;
        var st = 'stuff_'+sl;

        var cook = 'cook_t_'+sl;
        var grill = 'grill_t_'+sl;
        var hall = 'hall_t_'+sl;
        var pantry = 'pantry_t_'+sl;
        var nan = 'nan_t_'+sl;
        var stuff = 'stuff_t_'+sl;
        var total = 'total_quantity_t_'+sl;
     // var ck=  $('.cook').val();

     var cook_old=  parseFloat( $('.'+ck).val());
     var grill_old=  parseFloat( $('.'+gr).val());
     var hall_old=  parseFloat( $('.'+hl).val());
     var pantry_old=  parseFloat( $('.'+pn).val());
     var nan_old=  parseFloat( $('.'+nn).val());
     var stuff_old=  parseFloat( $('.'+st).val());


     var cook_qty=  parseFloat( $('.'+cook).val());
     var grill_qty=  parseFloat( $('.'+grill).val());
     var hall_qty=  parseFloat( $('.'+hall).val());
     var pantry_qty=  parseFloat( $('.'+pantry).val());
     var nan_qty=  parseFloat( $('.'+nan).val());
     var stuff_qty=  parseFloat( $('.'+stuff).val());



      var total_quantity=cook_qty+grill_qty+hall_qty+pantry_qty+nan_qty+stuff_qty;

       $('.'+total).val(total_quantity);


        // $('.a_qty').on('change', function() {
        //     var qty=this.value;
        //     if (qty > z){
        //         var msg = "You can not transfer more than " + y + " Items";
        //         alert(msg);
        //     }
        // });
        if (cook_qty > cook_old){
            var a = "You can not transfer more than requested " + cook_old + " Items";
          //  alert(a);
            toastr.error(a);
        }

        if (grill_qty > grill_old){
            var b = "You can not transfer more than requested " + grill_old + " Items";
            toastr.error(b);
        }
        if (hall_qty > hall_old){
            var c = "You can not transfer more than requested " + hall_old + " Items";
            toastr.error(c);
        }
        if (pantry_qty > pantry_old){
            var d = "You can not transfer more than requested " + pantry_old + " Items";
            toastr.error(d);
        }
        if (nan_qty > nan_old){
            var e = "You can not transfer more than requested " + nan_old + " Items";
            toastr.error(e);
        }
        if (stuff_qty > stuff_old){
            var e = "You can not transfer more than requested " + stuff_old + " Items";
            toastr.error(e);
        }

    }

</script>












