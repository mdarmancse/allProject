<?php
$CI = & get_instance();
$CI->load->model('Web_settings');
$Web_settings = $CI->Web_settings->retrieve_setting_editdata();
?>

<style>



    table, td, th {
        border: 1px solid black;
    }

    table {
        border-collapse: collapse;
        width: 50%;
    }

    th {
        height: 70px;
    }
</style>

<script src="<?php echo base_url() ?>my-assets/js/admin_js/invoice_onloadprint.js" type="text/javascript"></script>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="header-icon">
            <i class="pe-7s-note2"></i>
        </div>
        <div class="header-title">
            <h1><?php echo display('invoice_details') ?></h1>
            <small><?php echo display('invoice_details') ?></small>
            <ol class="breadcrumb">
                <li><a href="#"><i class="pe-7s-home"></i> <?php echo display('home') ?></a></li>
                <li><a href="#"><?php echo display('invoice') ?></a></li>
                <li class="active"><?php echo display('invoice_details') ?></li>
            </ol>
        </div>
    </section>
    <!-- Main content -->
    <section class="content">
        <!-- Alert Message -->
        <?php
        $message = $this->session->userdata('message');
        if (isset($message)) {
            ?>
            <div class="alert alert-info alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <?php echo $message ?>
            </div>
            <?php
            $this->session->unset_userdata('message');
        }
        $error_message = $this->session->userdata('error_message');
        if (isset($error_message)) {
            ?>
            <div class="alert alert-danger alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <?php echo $error_message ?>
            </div>
            <?php
            $this->session->unset_userdata('error_message');
        }
        ?>
        <div class="row">
            <div class="col-sm-12">
                <div class="panel panel-bd">
                    <div id="printableArea"  class="watermark"  onload="printDiv('printableArea')">

                        <div class="watermark" style=" background-image: url('<?php echo base_url() ?>assets/images/icons/.png') !important;">

                            <div class="panel-body"  style="margin-left: 0.3in">



                                <div class="row print_header">




                                    <div class="col-xs-12 row">

                                        <div class="col-xs-12" style="width: 100%" >
                                            <address>
                                                <span style="font-size: 11px" class="label label-success-outline ">&nbsp;Pre Delivery Note&nbsp; &nbsp;&nbsp;||&nbsp;&nbsp;&nbsp; To: <?php echo $chalan_detail[0]['outlet_name']?>&nbsp;&nbsp; &nbsp;||&nbsp;&nbsp;&nbsp; RQ NO: <?php echo $chalan_detail[0]['rqsn_no']?>&nbsp;&nbsp;&nbsp;||&nbsp; &nbsp;&nbsp;Date:<?php echo $chalan_detail[0]['date']?>&nbsp;</span>
                                            </address>

                                        </div>





                                        <!--                                        <div class="text-left col-xs-3">-->
<!---->
<!---->
<!--                                            <address>-->
<!--                                                <span style="font-size: 8px;" class="label label-success-outline">To: --><?php //echo $chalan_detail[0]['outlet_name']?><!--</span>-->
<!---->
<!--                                            </address>-->
<!---->
<!---->
<!--                                        </div>-->



<!--                                        <div class="text-left col-xs-3">-->
<!---->
<!--                                            <address>-->
<!--                                            <span style="font-size: 8px" class="label label-success-outline ">RQ NO: --><?php //echo $chalan_detail[0]['rqsn_no']?><!--</span>-->
<!--                                            </address>-->
<!--                                        </div>-->
<!--                                        <h2  style="font-size: 14px">Delivery Note</h2>-->


<!--                                        <div class="text-right col-xs-3">-->
<!---->
<!--                                            <address>-->
<!--                                            <span style="font-size: 8px" class="label label-success-outline ">Date:--><?php //echo $chalan_detail[0]['date']?><!--</span>-->
<!--                                            </address>-->
<!--                                        </div>-->


                                    </div>

                                    <div class="col-xs-12 row">
<!--                                        <div class="text-left col-xs-6">-->
<!---->
<!---->
<!--                                            <div style="font-size: 10px">Requisition NO: --><?php //echo $chalan_detail[0]['rqsn_no']?><!--</div>-->
<!---->
<!--                                        </div>-->
<!---->
<!---->
<!--                                        <div class="text-right col-xs-6">-->
<!---->
<!---->
<!--                                            <div style="font-size: 10px;margin-left: 10px">Date:--><?php //echo $chalan_detail[0]['date']?><!--</div>-->
<!---->
<!--                                        </div>-->
<!--                                        <h2  style="font-size: 14px">Delivery Note</h2>-->





                                    </div>
                                </div>

                                <div class="table-bordered table-responsive " style="margin-top: 2rem;"  >

                                    <table class="" style="width: 100%;" >
                                        <thead>

                                        <tr>
                                            <th style="font-size: 8px" class="text-center"><?php echo display('sl') ?></th>
                                            <th style="font-size: 8px" class="text-center"><?php echo display('product_name') ?> (EN)</th>
                                            <th style="font-size: 8px" class="text-center"><?php echo display('product_name') ?> (BN)</th>
                                            <th style="font-size: 8px" class="text-center">Unit</th>
                                            <th style="font-size: 8px" class="text-center">Cook</th>
                                            <th style="font-size: 8px" class="text-center">Nan</th>
                                            <th style="font-size: 8px" class="text-center">Grill</th>
                                            <th style="font-size: 8px" class="text-center">Pantry</th>
                                            <th style="font-size: 8px" class="text-center">Hall</th>
                                            <th style="font-size: 8px" class="text-center">Stuff</th>
                                            <th style="font-size: 8px" class="text-center">Total QTY</th>

                                        </tr>
                                        </thead>
                                        <tbody>



                                        <?php
                                        if ($chalan_detail) {
                                            ?>
                                            <?php $sl=1;?>
                                            <?php foreach ($chalan_detail as $chalan_detail) {
                                                 $id = $chalan_detail['rqsn_id'];
                                                ?>
                                                <tr>
                                                    <td style="font-size: 7px" class="text-center"><?php echo $sl;?></td>
                                                    <td style="font-size: 7px" class="text-left"><?php echo $chalan_detail['product_name'];?></td>
                                                    <td style="font-size: 7px" class="text-left"><?php echo $chalan_detail['product_name_bn'];?></td>
                                                    <td style="font-size: 7px" class="text-center"><?php echo $chalan_detail['unit'];?></td>
                                                    <td style="font-size: 7px" class="text-center"><?php echo $chalan_detail['cook'];?></td>
                                                    <td style="font-size: 7px" class="text-center"><?php echo $chalan_detail['nan'];?></td>
                                                    <td style="font-size: 7px" class="text-center"><?php echo $chalan_detail['grill'];?></td>
                                                    <td style="font-size: 7px" class="text-center"><?php echo $chalan_detail['pantry'];?></td>
                                                    <td style="font-size: 7px" class="text-center"><?php echo $chalan_detail['hall'];?></td>
                                                    <td style="font-size: 7px" class="text-center"><?php echo $chalan_detail['stuff'];?></td>
                                                    <td style="font-size: 7px" class="text-center"><?php echo $chalan_detail['total_quantity'];?></td>

                                                </tr>
                                                <?php 	$sl++;
                                                ?>
                                                <?php
                                            } ?>
                                            <?php
                                        }
                                        ?>
<!--                                        --><?php //$sl=0 ?>
<!--                                        {chalan_detail}-->
<!--                                        <tr>-->
<!---->
<!--                                            <td class="text-center">--><?php //echo $sl ?><!--</td>-->
<!--                                            <td class="text-center"><div>{product_name}</div></td>-->
<!--                                            <td class="text-center"><div>{unit}</div></td>-->
<!---->
<!--                                            <td align="center">{cook}</td>-->
<!--                                            <td align="center">{nan}</td>-->
<!--                                            <td align="center">{grill}</td>-->
<!--                                            <td align="center">{pantry}</td>-->
<!--                                            <td align="center">{hall}</td>-->
<!--                                            <td align="right">{total_quantity}</td>-->
<!---->
<!--                                        </tr>-->
<!---->
<!--                                        {/chalan_detail}-->
<!--                                        --><?php //	$sl++;
//                                        ?>
                                        <!--                                        <tr>-->
                                        <!--                                            <td class="text-left" colspan="5"><b>--><?php //echo display('grand_total') ?><!--:</b></td>-->
                                        <!--                                            <td align="right" ><b>{subTotal_quantity}</b></td>-->
                                        <!--                                            <td></td>-->
                                        <!--                                            <td></td>-->
                                        <!--                                            <td align="right" ><b>--><?php //echo (($position == 0) ? "$currency {subTotal_ammount}" : "{subTotal_ammount} $currency") ?><!--</b></td>-->
                                        <!--                                        </tr>-->
                                        </tbody>

                                    </table>
                                </div>


                                <div class="row footer" style="margin-left: 0.3in" >
                                    <div class="col-sm-4">
                                        <div class="inv-footer-left" style="font-size: 8px">
                                            <?php echo display('received_by') ?>
                                        </div>
                                    </div>
                                    <div class="col-sm-4"></div>
                                    <div class="col-sm-4"> <div class="inv-footer-right" style="font-size: 8px">
                                            <?php echo display('authorised_by') ?>
                                        </div></div>
                                </div>

                            </div>
                        </div>
                    </div>

                    <div class="panel-footer text-left">
                        <input type="hidden" name="" id="url" value="<?php echo base_url('Crqsn/rqsn_edit/'.$id);?>">
                        <a  class="btn btn-danger" href="<?php echo base_url('Crqsn/rqsn_edit/'.$id);?>"><?php echo display('cancel') ?></a>
                        <button  class="btn btn-info" onclick="printDiv('printableArea')"><span class="fa fa-print"></span></button>

                    </div>
                </div>
            </div>
        </div>
    </section> <!-- /.content -->
</div> <!-- /.content-wrapper -->

