

<?php
$user_id = $this->session->userdata('user_id');
$user_type = $this->session->userdata('user_type');
?>
<!-- Admin Home Start -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->

    <section class="content-header">
        <div class="header-icon">
            <i class="pe-7s-world"></i>

        </div>
        <div class="header-title">
            <h1><?php echo display('dashboard') ?></h1>
            <small><?php echo display('home') ?></small>
            <ol class="breadcrumb">
                <li><a href="#"><i class="pe-7s-home"></i> <?php echo display('home') ?></a></li>
                <li class="active"><?php echo display('dashboard') ?></li>
            </ol>
        </div>
    </section>
    <!-- Main content -->
    <section class="content">
        <!-- Alert Message -->
        <?php 
if(isset($_POST['btnSearch']))
{
   $postdate = $_POST['alldata'];
}
$searchdate =(!empty($postdate)?$postdate:date('F Y'));

?>
        <?php
        $message = $this->session->userdata('message');
        if (isset($message)) {
            ?>
            <div class="alert alert-info alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <?php echo $message ?>                    
            </div>
            <?php
            $this->session->unset_userdata('message');
        }
        $error_message = $this->session->userdata('error_message');
        if (isset($error_message)) {
            ?>
            <div class="alert alert-danger alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <?php echo $error_message ?>                    
            </div>
            <?php
            $this->session->unset_userdata('error_message');
        }
        ?>
        <!-- First Counter -->
        <div class="row">
<!--            <div class="col-xs-12 col-sm-6 col-md-6 col-lg-3">-->
<!--                 <div class="small-box bg-green whitecolor">-->
<!--            <div class="inner">-->
<!--              <h4><span class="count-number">--><?php //echo html_escape($total_customer) ?><!--</span></h4>-->
<!--              <p>--><?php //echo display('total_customer')?><!--</p>-->
<!--            </div>-->
<!--            <div class="icon">-->
<!--             <i class="fa fa-users"></i>-->
<!--            </div>-->
<!--            <a href="--><?php //echo base_url('Ccustomer/manage_customer') ?><!--" class="small-box-footer">--><?php //echo display('total_customer')?><!--</a>-->
<!--          </div>-->
<!--            </div>-->
            <div class="col-xs-12 col-sm-6 col-md-6 col-lg-3">
                <div class="small-box bg-pase whitecolor">
            <div class="inner">
              <h4><span class="count-number"><?php echo html_escape($total_product) ?></span></h4>

              <p><?php echo display('total_product')?></p>
            </div>
            <div class="icon">
             <i class="fa fa-shopping-bag"></i>
            </div>
            <a href="<?php echo base_url('Cproduct/manage_product') ?>" class="small-box-footer"><?php echo display('total_product')?></a>
          </div>
            </div>

<!--            <div class="col-xs-12 col-sm-6 col-md-6 col-lg-3">-->
<!--         <div class="small-box bg-bringal whitecolor">-->
<!--            <div class="inner">-->
<!--              <h4><span class="count-number">--><?php //echo html_escape($total_suppliers)?><!--</span></h4>-->
<!---->
<!--              <p>--><?php //echo display('total_supplier')?><!--</p>-->
<!--            </div>-->
<!--            <div class="icon">-->
<!--             <i class="fa fa-user"></i>-->
<!--            </div>-->
<!--            <a href="--><?php //echo base_url('Csupplier/manage_supplier') ?><!--" class="small-box-footer">--><?php //echo display('total_supplier')?><!-- </a>-->
<!--          </div>-->
<!--            </div>-->
<!--            <div class="col-xs-12 col-sm-6 col-md-6 col-lg-3">-->
<!--            <div class="small-box bg-darkgreen whitecolor">-->
<!--            <div class="inner">-->
<!--              <h4><span class="count-number">--><?php //echo html_escape($total_sales) ?><!--</span> </h4>-->
<!---->
<!--              <p>--><?php //echo display('total_invoice')?><!--</p>-->
<!--            </div>-->
<!--            <div class="icon">-->
<!--             <i class="fa fa-money"></i>-->
<!--            </div>-->
<!--            <a href="--><?php //echo base_url('Cinvoice/manage_invoice') ?><!--" class="small-box-footer">--><?php //echo display('total_invoice')?><!-- </a>-->
<!--          </div>-->
<!--            </div>-->

        </div>
        <hr>

   <input type="hidden" id="currency" value="<?php echo  html_escape($currency)?>" name="">
        <input type="hidden" id="totalsalep" value="<?php echo html_escape($this->Reports->total_sales_amount($searchdate))?>" name="">
      <input type="hidden" id="totalplurchasep" value="<?php
     echo html_escape($this->Reports->total_purchase_amount($searchdate))?>" name="">
      <input type="hidden" id="totalexpensep" value="<?php
     echo html_escape($this->Reports->total_expense_amount($searchdate))?>" name="">
     <input type="hidden" id="totalemployeesalaryp" value="<?php
     echo html_escape($this->Reports->total_employee_salary($searchdate))?>" name="">

      <input type="hidden" id="totalservicep" value="<?php
     echo html_escape($this->Reports->total_service_amount($searchdate))?>" name="">

      <input type="hidden" id="month" value="<?php echo html_escape($month);?>" name="">
      <input type="hidden" id="tlvmonthsale" value="<?php echo html_escape($tlvmonthsale);?>" name="">
      <input type="hidden" id="tlvmonthpurchase" value="<?php echo html_escape($tlvmonthpurchase);?>" name=""> 
      <input type="hidden" id="salspurhcaselabel"  value="<?php echo display("sales_and_purchase_report_summary");?>- <?php echo  date("Y")?>" name="">     


<input type="hidden" id="bestsalelabel" value='<?php echo html_escape($chart_label);?>' name=""> 
<input type="hidden" id="bestsaledata" value='<?php echo html_escape($chart_data);?>' name=""> 

<input type="hidden" value='<?php $seperatedData = explode(',', $chart_data); echo html_escape(($seperatedData[0] + 10));?>' name="" id="bestsalemax">     
    </section> <!-- /.content -->
</div> <!-- /.content-wrapper -->
<!-- Admin Home end -->

<!-- ChartJs JavaScript -->

<script src="<?php echo base_url() ?>assets/js/Chart.min.js" type="text/javascript"></script>
<script src="<?php echo base_url() ?>assets/js/canvasjs.min.js" type="text/javascript"></script>
<script src="<?php echo base_url() ?>assets/js/dashboard.js" type="text/javascript"></script>




