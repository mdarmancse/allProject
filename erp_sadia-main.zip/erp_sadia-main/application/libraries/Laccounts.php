<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Laccounts extends CI_Model{

    //Retrieve  daily closing List	
    public function daily_closing_list($links = null, $per_page = null, $page = null) {
        $CI = & get_instance();
        $CI->load->model('Accounts');
        $CI->load->model('Web_settings');
        $CI->load->model('Reports');
        $CI->load->library('occational');
        $daily_closing_data = $CI->Accounts->get_closing_report($per_page, $page);

        $i = 0;
        if (!empty($daily_closing_data)) {
            foreach ($daily_closing_data as $k => $v) {
                $daily_closing_data[$k]['final_date'] = $CI->occational->dateConvert($daily_closing_data[$k]['date']);
            }
            foreach ($daily_closing_data as $k => $v) {
                $i++;
                $daily_closing_data[$k]['sl'] = $i + $CI->uri->segment(3);
            }
        }
        $total=$this->db->select('sum(last_day_closing) as balance')->from('closing')->get()->result_array();
        $currency_details = $CI->Web_settings->retrieve_setting_editdata();
        $company_info = $CI->Reports->retrieve_company();
        $data = array(
            'title'              => display('closing_report'),
            'daily_closing_data' => $daily_closing_data,
            'currency'           => $currency_details[0]['currency'],
            'position'           => $currency_details[0]['currency_position'],
            'company_info'       => $company_info,
            'links'              => $links,
            'software_info'      => $currency_details,
            'company'            => $company_info,
            'total'            => $total[0]['balance'],
        );
      //  echo '<pre>';print_r($data);exit();
        $reportList = $CI->parser->parse('accounts/closing_report', $data, true);
        return $reportList;
    }








    public function closing_html_data($id) {


        $CI = & get_instance();
        $CI->load->model('Invoices');
        $CI->load->model('Rqsn');
        $CI->load->model('Web_settings');
        $CI->load->library('occational');
        $CI->load->library('numbertowords');
        //   $this->load->library('session');

        // $user_id=$this->session->userdata('user_id');

        $currency_details = $CI->Web_settings->retrieve_setting_editdata();


        $closing_details=$CI->Rqsn->retrieve_closing_html_data($id);
        $cash_out_details=$CI->Rqsn->retrieve_cash_out_html_data($id);


//        $cod=$mr_detail['data'][0]['Credit'];
//
//        $credit_inword = $CI->numbertowords->convert_number($cod);

        // $sumDebit=$this->db->select('SUM(Debit)')->from('acc_transaction')->where('COAID',102030000001)->get()->result_array();

        $company_info = $CI->Invoices->retrieve_company();
        $user_id = $this->session->userdata('user_id');
        $outlet_name = $this->db->select('outlet_name')->from('outlet_warehouse')->where('user_id',$user_id)->get()->row();

        $data=array(

            'company_info'=>$company_info,
            'closing_details'=>$closing_details,
            'cash_out_details'=>$cash_out_details,
            'outlet_name'=>$outlet_name->outlet_name,
            //'outlet_name'=>$mr_detail['data'][0]['other_name']
            'currency'         => $currency_details[0]['currency'],
            //'cheque_no'=>$mr_detail['data'][0]['cheque_no'],
            //  'other'=>$mr_detail['data'][0]['other_name'],
            //  'pay_type'=>$mr_detail['data'][0]['pay_type'],
        );



       //  echo '<pre>';print_r($data);exit();
        $chapterList = $CI->parser->parse('accounts/closing_html',$data,true);
        return $chapterList;
    }

    public function closing_view_data($id) {


        $CI = & get_instance();
        $CI->load->model('Invoices');
        $CI->load->model('Rqsn');
        $CI->load->model('Web_settings');
        $CI->load->library('occational');
        $CI->load->library('numbertowords');
        //   $this->load->library('session');

        // $user_id=$this->session->userdata('user_id');

        $currency_details = $CI->Web_settings->retrieve_setting_editdata();


        $closing_details=$CI->Rqsn->retrieve_closing_view_data($id);
        $cash_out_details=$CI->Rqsn->retrieve_cash_out_html_data($id);


//        $cod=$mr_detail['data'][0]['Credit'];
//
//        $credit_inword = $CI->numbertowords->convert_number($cod);

        // $sumDebit=$this->db->select('SUM(Debit)')->from('acc_transaction')->where('COAID',102030000001)->get()->result_array();

        $company_info = $CI->Invoices->retrieve_company();
//        $user_id = $this->session->userdata('user_id');
//        $outlet_name = $this->db->select('outlet_name')->from('outlet_warehouse')->where('user_id',$user_id)->get()->row();

        $data=array(

            'company_info'=>$company_info,
            'closing_details'=>$closing_details,
            'cash_out_details'=>$cash_out_details,
//            'outlet_name'=>$outlet_name->outlet_name,
            //'outlet_name'=>$mr_detail['data'][0]['other_name']
            'currency'         => $currency_details[0]['currency'],
            //'cheque_no'=>$mr_detail['data'][0]['cheque_no'],
            //  'other'=>$mr_detail['data'][0]['other_name'],
            //  'pay_type'=>$mr_detail['data'][0]['pay_type'],
        );



       //  echo '<pre>';print_r($data);exit();
        $chapterList = $CI->parser->parse('accounts/closing_view',$data,true);
        return $chapterList;
    }



    public function outlet_daily_closing_list($links = null, $per_page = null, $page = null) {
        $CI = & get_instance();
        $CI->load->model('Accounts');
        $CI->load->model('Web_settings');
        $CI->load->model('Reports');
        $CI->load->library('occational');
        $daily_closing_data = $CI->Accounts->outlet_get_closing_report($per_page, $page);

        $i = 0;
        if (!empty($daily_closing_data)) {
            foreach ($daily_closing_data as $k => $v) {
                $daily_closing_data[$k]['final_date'] = $CI->occational->dateConvert($daily_closing_data[$k]['date']);
            }
            foreach ($daily_closing_data as $k => $v) {
                $i++;
                $daily_closing_data[$k]['sl'] = $i + $CI->uri->segment(3);
            }
        }
        $user_id = $this->session->userdata('user_id');
        $outlet_id = $this->db->select('*')->from('outlet_warehouse')->where('user_id',$user_id)->get()->row();
        $total=$this->db->select('sum(last_day_closing) as balance')->from('closing')->where('outlet_id',$outlet_id->outlet_id)->get()->result_array();
        $currency_details = $CI->Web_settings->retrieve_setting_editdata();
        $company_info = $CI->Reports->retrieve_company();
        $data = array(
            'title'              => display('closing_report'),
            'daily_closing_data' => $daily_closing_data,
            'currency'           => $currency_details[0]['currency'],
            'position'           => $currency_details[0]['currency_position'],
            'company_info'       => $company_info,
            'outlet_name'       => $outlet_id->outlet_name,
            'links'              => $links,
            'software_info'      => $currency_details,
            'company'            => $company_info,
            'total'            => $total[0]['balance'],
        );
        //echo '<pre>';print_r($data);exit();
        $reportList = $CI->parser->parse('accounts/outlet_closing_report', $data, true);
        return $reportList;
    }

    //Retrieve  Customer List	
    public function get_date_wise_closing_reports($links = null, $per_page = null, $page = null, $from_date, $to_date) {
        $CI = & get_instance();
        $CI->load->model('Accounts');
        $CI->load->model('Reports');
        $CI->load->library('occational');
        $daily_closing_data = $CI->Accounts->get_date_wise_closing_report($per_page, $page, $from_date, $to_date);
        $dateRange = "date BETWEEN '$from_date' AND '$to_date'";
        $total=$this->db->select('sum(last_day_closing) as balance')->from('closing')->where($dateRange)->get()->result_array();
        $i = 0;
        if (!empty($daily_closing_data)) {
            foreach ($daily_closing_data as $k => $v) {
                $daily_closing_data[$k]['final_date'] = $CI->occational->dateConvert($daily_closing_data[$k]['date']);
            }

            foreach ($daily_closing_data as $k => $v) {
                $i++;
                $daily_closing_data[$k]['sl'] = $i;
            }
        }
        $currency_details = $CI->Web_settings->retrieve_setting_editdata();
        $company_info = $CI->Reports->retrieve_company();
        $data = array(
            'title'              => display('closing_report'),
            'company_info'       => $company_info,
            'daily_closing_data' => $daily_closing_data,
            'from_date'          => $from_date,
            'to_date'            => $to_date,
            'currency'           => $currency_details[0]['currency'],
            'position'           => $currency_details[0]['currency_position'],
            'links'              => $links,
            'software_info'      => $currency_details,
            'company'            => $company_info,
            'total'            => $total[0]['balance'],
        );
        $reportList = $CI->parser->parse('accounts/closing_report', $data, true);
        return $reportList;
    }
    public function get_date_wise_outlet_closing_reports($links = null, $per_page = null, $page = null, $from_date, $to_date) {
        $CI = & get_instance();
        $CI->load->model('Accounts');
        $CI->load->model('Reports');
        $CI->load->library('occational');
        $daily_closing_data = $CI->Accounts->get_date_wise_closing_report($per_page, $page, $from_date, $to_date);
        $dateRange = "date BETWEEN '$from_date' AND '$to_date'";
        $user_id = $this->session->userdata('user_id');
        $outlet_id = $this->db->select('*')->from('outlet_warehouse')->where('user_id',$user_id)->get()->row();
        $total=$this->db->select('sum(last_day_closing) as balance')->from('closing')->where($dateRange)->where('outlet_id',$outlet_id->outlet_id)->get()->result_array();
        $i = 0;
        if (!empty($daily_closing_data)) {
            foreach ($daily_closing_data as $k => $v) {
                $daily_closing_data[$k]['final_date'] = $CI->occational->dateConvert($daily_closing_data[$k]['date']);
            }

            foreach ($daily_closing_data as $k => $v) {
                $i++;
                $daily_closing_data[$k]['sl'] = $i;
            }
        }
        $currency_details = $CI->Web_settings->retrieve_setting_editdata();
        $company_info = $CI->Reports->retrieve_company();
        $data = array(
            'title'              => display('closing_report'),
            'company_info'       => $company_info,
            'daily_closing_data' => $daily_closing_data,
            'from_date'          => $from_date,
            'to_date'            => $to_date,
            'currency'           => $currency_details[0]['currency'],
            'position'           => $currency_details[0]['currency_position'],
            'links'              => $links,
            'software_info'      => $currency_details,
            'company'            => $company_info,
            'total'            => $total[0]['balance'],
        );
        $reportList = $CI->parser->parse('accounts/closing_report', $data, true);
        return $reportList;
    }


    public function money_receipt_html_data($coaid,$id) {
        $CI = & get_instance();
        $CI->load->model('Invoices');
        $CI->load->model('Accounts_model');
        $CI->load->model('Web_settings');
        $CI->load->library('occational');
        $CI->load->library('numbertowords');
        $this->load->library('session');

        $user_id=$this->session->userdata('user_id');

        $currency_details = $CI->Web_settings->retrieve_setting_editdata();


        $mr_detail=$CI->Accounts_model->retrieve_mr_html_data($coaid,$id,$user_id);


        $cod=$mr_detail['data'][0]['Credit'];

        $credit_inword = $CI->numbertowords->convert_number($cod);

       // $sumDebit=$this->db->select('SUM(Debit)')->from('acc_transaction')->where('COAID',102030000001)->get()->result_array();

        $company_info = $CI->Invoices->retrieve_company();

        $data=array(

            'company_info'=>$company_info,
            'mr_detail'=>$mr_detail,
          'credit_inword'=>$credit_inword,
            'currency'         => $currency_details[0]['currency'],
            'cheque_no'=>$mr_detail['data'][0]['cheque_no'],
            'other'=>$mr_detail['data'][0]['other_name'],
            'pay_type'=>$mr_detail['data'][0]['pay_type'],
        );



       //echo '<pre>';print_r($data);exit();
        $chapterList = $CI->parser->parse('newaccount/mr_html',$data,true);
        return $chapterList;
    }
}

?>