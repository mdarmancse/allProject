<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Lrqsn {



    public function stock_report_outlet_item()
    {
        $CI = & get_instance();
        $CI->load->model('Rqsn');
        $CI->load->model('Web_settings');
        $CI->load->model('Reports');
        $outlet_list    = $CI->Rqsn->outlet_list();
        $cw_list    = $CI->Rqsn->cw_list();
        $currency_details = $CI->Web_settings->retrieve_setting_editdata();
        $taxfield = $CI->db->select('tax_name,default_value')
            ->from('tax_settings')
            ->get()
            ->result_array();
        $data = array(
            'title'         => "Reacquisition",
            'outlet_list' => $outlet_list,
            'cw_list' => $cw_list,
            'discount_type' => $currency_details[0]['discount_type'],
            'currency' => $currency_details[0]['currency'],
            'totalnumber'=> $CI->Reports->totalnumberof_product(),
          'taxes'         => $taxfield,
        );


//        echo print_r($data);
//        die();
        $invoiceForm = $CI->parser->parse('rqsn/outlet_stock', $data, true);
        return $invoiceForm;
    }

        public function rqsn_add_form() {
        $CI = & get_instance();
        $CI->load->model('Rqsn');
        $CI->load->model('Products');
        $CI->load->model('Web_settings');
        $all_product    = $CI->Products->all_product();
        $outlet_list    = $CI->Rqsn->outlet_list();
        $outlet_list_to    = $CI->Rqsn->outlet_list_to();
        $cw_list    = $CI->Rqsn->cw_list();
        $currency_details = $CI->Web_settings->retrieve_setting_editdata();
        $taxfield = $CI->db->select('tax_name,default_value')
                ->from('tax_settings')
                ->get()
                ->result_array();
        $data = array(
            'title'         => "Requisition ",
            'all_product' => $all_product,
            'outlet_list' => $outlet_list,
            'outlet_list_to' => $outlet_list_to,
            'cw_list' => $cw_list,
            'discount_type' => $currency_details[0]['discount_type'],
            'taxes'         => $taxfield,
        );

       // echo '<pre'; print_r($all_product);exit();
    //    die();
        $invoiceForm = $CI->parser->parse('rqsn/rqsn_form', $data, true);
        return $invoiceForm;
    }

        public function rqsn_edit_form($id) {
        $CI = & get_instance();
        $CI->load->model('Rqsn');
        $CI->load->model('Products');
        $CI->load->model('Web_settings');
        $all_product    = $CI->Rqsn->rqsn_edit_data($id);
        $outlet_list    = $CI->Rqsn->outlet_list();
        $outlet_list_to    = $CI->Rqsn->outlet_list_to();
        $cw_list    = $CI->Rqsn->cw_list();
        $currency_details = $CI->Web_settings->retrieve_setting_editdata();
        $taxfield = $CI->db->select('tax_name,default_value')
                ->from('tax_settings')
                ->get()
                ->result_array();

        $cook=$all_product['cook']-$all_product['cook_t'];
        $nan=$all_product[0]['nan']-$all_product[0]['nan_t'];
        $grill=$all_product[0]['grill']-$all_product[0]['grill_t'];
        $pantry=$all_product[0]['pantry']-$all_product[0]['pantry_t'];
        $hall=$all_product[0]['hall']-$all_product[0]['hall_t'];
        $stuff=$all_product[0]['stuff']-$all_product[0]['stiff_t'];
            $total=$all_product[0]['total_quantity']-$all_product[0]['total_quantity_t'];

        $data = array(
            'title'         => "Requisition",
            'all_product' => $all_product,
            'cook' => $cook,
            'nan' => $nan,
            'grill' => $grill,
            'pantry' => $pantry,
            'hall' => $hall,
            'stuff' => $stuff,
            'total_quantity' => $total,
            'outlet' => $all_product['outlet_id'],
            'outlet_list' => $outlet_list,
            'outlet_list_to' => $outlet_list_to,
            'cw_list' => $cw_list,
            'discount_type' => $currency_details[0]['discount_type'],
            'taxes'         => $taxfield,
        );

      //  echo '<pre>'; print_r($cook);exit();
    //    die();
        $invoiceForm = $CI->parser->parse('rqsn/edit_rqsn_form', $data, true);
        return $invoiceForm;
    }

        public function tr_items($id) {
        $CI = & get_instance();
        $CI->load->model('Rqsn');
        $CI->load->model('Products');
        $CI->load->model('Web_settings');
        $all_product    = $CI->Rqsn->tr_items($id);
        $outlet_list    = $CI->Rqsn->outlet_list();
        $outlet_list_to    = $CI->Rqsn->outlet_list_to();
        $cw_list    = $CI->Rqsn->cw_list();
        $currency_details = $CI->Web_settings->retrieve_setting_editdata();
        $taxfield = $CI->db->select('tax_name,default_value')
                ->from('tax_settings')
                ->get()
                ->result_array();


        $data = array(
            'title'         => "Transferred Items",
            'all_product' => $all_product,
            'outlet' => $all_product['outlet_id'],
            'outlet_list' => $outlet_list,
            'outlet_list_to' => $outlet_list_to,
            'cw_list' => $cw_list,
            'discount_type' => $currency_details[0]['discount_type'],
            'taxes'         => $taxfield,
        );

      //  echo '<pre>'; print_r($data);exit();
    //    die();
        $invoiceForm = $CI->parser->parse('rqsn/tr_items', $data, true);
        return $invoiceForm;
    }

        public function rqsn_rcv_form($id,$status) {
        $CI = & get_instance();
        $CI->load->model('Rqsn');
        $CI->load->model('Products');
        $CI->load->model('Web_settings');
        $all_product    = $CI->Rqsn->rqsn_edit_data($id);
        $outlet_list    = $CI->Rqsn->outlet_list();
        $outlet_list_to    = $CI->Rqsn->outlet_list_to();
        $cw_list    = $CI->Rqsn->cw_list();
        $currency_details = $CI->Web_settings->retrieve_setting_editdata();
        $taxfield = $CI->db->select('tax_name,default_value')
                ->from('tax_settings')
                ->get()
                ->result_array();
        $data = array(
            'title'         => "Requisition",
            'all_product' => $all_product,
            'outlet' => $all_product['outlet_id'],
            'rqsn_id' => $id,
            'sts' => $status,
            'outlet_list' => $outlet_list,
            'outlet_list_to' => $outlet_list_to,
            'cw_list' => $cw_list,
            'discount_type' => $currency_details[0]['discount_type'],
            'taxes'         => $taxfield,
        );

      //  echo '<pre'; print_r($data);exit();
    //    die();
        $invoiceForm = $CI->parser->parse('rqsn/edit_rqsn_rcv_form', $data, true);
        return $invoiceForm;
    }

        public function purchase_rqsn_form() {
        $CI = & get_instance();
        $CI->load->model('Rqsn');
        $CI->load->model('Web_settings');
        $outlet_list    = $CI->Rqsn->outlet_list();
        $cw_list    = $CI->Rqsn->cw_list();
        $currency_details = $CI->Web_settings->retrieve_setting_editdata();
        $taxfield = $CI->db->select('tax_name,default_value')
                ->from('tax_settings')
                ->get()
                ->result_array();
        $data = array(
            'title'         => "Central Warehouse Reacquisition",
            'outlet_list' => $outlet_list,
            'cw_list' => $cw_list,
            'discount_type' => $currency_details[0]['discount_type'],
            'taxes'         => $taxfield,
        );

       // echo '<pre'; print_r($cw_list);exit();
    //    die();
        $invoiceForm = $CI->parser->parse('rqsn/cw_purchase', $data, true);
        return $invoiceForm;
    }

    public function chalan_html_data($id) {


        $CI = & get_instance();
        $CI->load->model('Invoices');
        $CI->load->model('Rqsn');
        $CI->load->model('Web_settings');
        $CI->load->library('occational');
        $CI->load->library('numbertowords');
     //   $this->load->library('session');

       // $user_id=$this->session->userdata('user_id');

        $currency_details = $CI->Web_settings->retrieve_setting_editdata();


        $chalan_detail=$CI->Rqsn->retrieve_chalan_data($id);


//        $cod=$mr_detail['data'][0]['Credit'];
//
//        $credit_inword = $CI->numbertowords->convert_number($cod);

        // $sumDebit=$this->db->select('SUM(Debit)')->from('acc_transaction')->where('COAID',102030000001)->get()->result_array();

        $company_info = $CI->Invoices->retrieve_company();

        $data=array(

            'company_info'=>$company_info,
            'chalan_detail'=>$chalan_detail,
            //'outlet_name'=>$mr_detail['data'][0]['other_name']
            //'currency'         => $currency_details[0]['currency'],
            //'cheque_no'=>$mr_detail['data'][0]['cheque_no'],
          //  'other'=>$mr_detail['data'][0]['other_name'],
          //  'pay_type'=>$mr_detail['data'][0]['pay_type'],
        );



       // echo '<pre>';print_r($data);exit();
        $chapterList = $CI->parser->parse('rqsn/rqsnChalan',$data,true);
        return $chapterList;
    }

    public function pre_chalan_html_data($id) {


        $CI = & get_instance();
        $CI->load->model('Invoices');
        $CI->load->model('Rqsn');
        $CI->load->model('Web_settings');
        $CI->load->library('occational');
        $CI->load->library('numbertowords');
     //   $this->load->library('session');

       // $user_id=$this->session->userdata('user_id');

        $currency_details = $CI->Web_settings->retrieve_setting_editdata();


        $chalan_detail=$CI->Rqsn->retrieve_chalan_data($id);


//        $cod=$mr_detail['data'][0]['Credit'];
//
//        $credit_inword = $CI->numbertowords->convert_number($cod);

        // $sumDebit=$this->db->select('SUM(Debit)')->from('acc_transaction')->where('COAID',102030000001)->get()->result_array();

        $company_info = $CI->Invoices->retrieve_company();

        $data=array(

            'company_info'=>$company_info,
            'chalan_detail'=>$chalan_detail,
            //'outlet_name'=>$mr_detail['data'][0]['other_name']
            //'currency'         => $currency_details[0]['currency'],
            //'cheque_no'=>$mr_detail['data'][0]['cheque_no'],
          //  'other'=>$mr_detail['data'][0]['other_name'],
          //  'pay_type'=>$mr_detail['data'][0]['pay_type'],
        );



       // echo '<pre>';print_r($data);exit();
        $chapterList = $CI->parser->parse('rqsn/pre_rqsnChalan',$data,true);
        return $chapterList;
    }

}

?>