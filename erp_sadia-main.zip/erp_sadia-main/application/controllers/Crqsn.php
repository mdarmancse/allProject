<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Crqsn extends CI_Controller {

    public $menu;

    function __construct() {
        parent::__construct();
        $this->load->library('auth');
        $this->load->library('lrqsn');
        $this->load->library('session');
        $this->load->model('Rqsn');
        $this->auth->check_admin_auth();
    }

    //Default loading for service system.
    public function index() {
        $content = $this->lrqsn->rqsn_add_form();
        $this->template->full_admin_html_view($content);
    }



      public function rqsn_form() {
        $CI = & get_instance();
        $CI->auth->check_admin_auth();
        $CI->load->library('lrqsn');
        $content = $CI->lrqsn->rqsn_add_form();
        $this->template->full_admin_html_view($content);
    }

      public function cw_purchase() {
        $CI = & get_instance();
        $CI->auth->check_admin_auth();
        $CI->load->library('lrqsn');
        $content = $CI->lrqsn->purchase_rqsn_form();
        $this->template->full_admin_html_view($content);
    }

    public function insert_rqsn(){
        $CI = & get_instance();

        //echo "Ok";exit();

        $CI->auth->check_admin_auth();
        $CI->load->model('Rqsn');

        $rqsn = $CI->Rqsn->rqsn_entry();



     //   echo "ok";exit();




}
    public function update_rqsn(){
        $CI = & get_instance();

        //echo "Ok";exit();

        $CI->auth->check_admin_auth();
        $CI->load->model('Rqsn');

        $rqsn_id = $CI->Rqsn->rqsn_update();



     //   echo "ok";exit();

        if ($rqsn_id == TRUE) {
        //    $this->session->set_userdata(array('message' => display('successfully_added')));

            redirect(base_url('Crqsn/chalan_print/'.$rqsn_id));

        } else {
            $this->session->set_userdata(array('error_message' => display('please_try_again')));
            redirect(base_url('Crqsn/rqsn_form'));
        }


}

    public function insert_rqsn_cw(){
        $CI = & get_instance();

        //echo "Ok";exit();

        $CI->auth->check_admin_auth();
        $CI->load->model('Rqsn');

        $rqsn = $CI->Rqsn->rqsn_entry_cw();



     //   echo "ok";exit();

        if ($rqsn == TRUE) {
            $this->session->set_userdata(array('message' => display('successfully_added')));

            redirect(base_url('Crqsn/cw_purchase'));

        } else {
            $this->session->set_userdata(array('error_message' => display('please_try_again')));
            redirect(base_url('Crqsn/cw_purchase'));
        }



}


    public function rqsn_noti(){
        $CI = & get_instance();
        $this->auth->check_admin_auth();
        $CI->load->model('Rqsn');
        $data=$this->Rqsn->approve_rqsn_count();
        echo json_encode($data);
    }

    public function rqsn_edit($id){
        $content = $this->lrqsn->rqsn_edit_form($id);
        $this->template->full_admin_html_view($content);
    }


    public function test(){

        $values = array('one', 'two', 'three', 'four', 'five');
        $string = '';

        foreach ( $values as $val ) {
            $string .= '"'.$val.'", ';
        }

        echo $string;

        echo trim(preg_replace("/(.*?)((,|\s)*)$/m", "$1", $string));
    }
    public function tr_items($id){
        $content = $this->lrqsn->tr_items($id);
        $this->template->full_admin_html_view($content);
    }

    public function rqsn_rcv($id,$status){
        $content = $this->lrqsn->rqsn_rcv_form($id,$status);
        $this->template->full_admin_html_view($content);
    }

    public function autosearch()
    {
        $CI =& get_instance();
        $this->auth->check_admin_auth();
        $CI->load->model('Rqsn');
        $product_name   = $this->input->post('product_name',TRUE);
//        $category_id   = $this->input->post('cat_id',TRUE);
//        $brand_id   = $this->input->post('brand_id',TRUE);
//        $model_id   = $this->input->post('model_id',TRUE);


        $subcat_id   = $this->input->post('subcat_id',TRUE);
        $product_info   = $CI->Rqsn->autocompletproductdata($product_name);

        if(!empty($product_info)){
            $list[''] = '';
            foreach ($product_info as $value) {
                $json_product[] = array(
                    'label'=>$value['product_name'].' ('.$value['product_name_bn'].')',
                    'value'=>$value['product_id']
                );
            }
        }else{
            $json_product[] = 'No Product Found';
        }
        echo json_encode($json_product);
    }

    public function add_product()
    {
        $this->load->model("Products");
        $product_id = $_POST["product_id"];
        $user_id = $this->session->userdata('user_id');

        $outlet_id=$this->db->select('outlet_id')
            ->from('outlet_warehouse')
            ->where('outlet_warehouse.user_id',$user_id)
            ->get()->row()->outlet_id;

       // $pr_data = $this->Products->retrieve_product_full_data($product_id);

        $data = array(

            'outlet_id' => $outlet_id,
            'product_id' => $product_id,
            'status'   => 1,

            // 'sku'        => $pr_data[0]['sku']
        );

        // var_dump($data); exit();

        // $this->db->where('purchase_id', $po_id);
        $this->db->insert('rqsn_cart', $data);
    }
    function load()
    {
        echo $this->view();
    }

    function remove()
    {
        $user_id = $this->session->userdata('user_id');
        $outlet_id=$this->db->select('outlet_id')
            ->from('outlet_warehouse')
            ->where('outlet_warehouse.user_id',$user_id)
            ->get()->row()->outlet_id;

        $row_id = $_POST["row_id"];
        //        $data = array(
        //            'rowid'  => $row_id,
        //            'qty'  => 0
        //        );

        $this->db->where('outlet_id', $outlet_id);
        $this->db->where('product_id', $row_id);
        $this->db->delete('rqsn_cart');
        echo $this->view();
    }

    function clear()
    {
        $user_id = $this->session->userdata('user_id');
        $outlet_id=$this->db->select('outlet_id')
            ->from('outlet_warehouse')
            ->where('outlet_warehouse.user_id',$user_id)
            ->get()->row()->outlet_id;

        $this->db->where('outlet_id', $outlet_id);
        $this->db->delete('rqsn_cart');
        echo $this->view();
    }

    function view()
    {
        $this->load->library("cart");
        $this->load->model("Rqsn");
        //   $product_id=$_POST["product_id"];
        $cart_list = $this->Rqsn->cart_list();


       // echo '<pre>';print_r($cart_list);exit();


        $output = '';
        $output .= '

  <div class="table-responsive">
   <div align="right">
    <button type="button" id="clear_cart" class="btn btn-warning">Clear Requisition</button>
   </div>
   <br />
   <table class="table table-bordered table-hover">
    <tr>
           <th width="5%" class="text-center">Item Name(EN)</th>
         <th width="5%" class="text-center">Item Name(BN)</th>
             <th class="text-center">TTL QTY</th>
              <th class="text-center">Unit</th>
             <th class="text-center">Cook</th>
              <th class="text-center">Nan</th>
             <th class="text-center">Grill</th>
                <th class="text-center">Pantry</th>
               <th class="text-center">Hall</th>
               <th  class="text-center">Stuff</th>
     <th width="5%">Action</th>
    </tr>

  ';


        $count = 0;
        foreach ($cart_list as $items) {
       //     $total_quantity = $this->db->select('sum(qty) as total_qty')->from('rqsn_cart')->where('product_id', $items["product_id"])->get()->row();
            $count++;
            $output .= '
   <tr>
   <td>
 <input size="10"  type="text" value="' . $items["product_name"] . '" class="form-control input-sm product_name_'.$items["product_id"] .'" name="product_name[]"  readonly/>
    <input name="product_id[]" type="hidden" class="form-control" value="' . $items["product_id"] . '"  readonly>

    </td>
    <td>
  <input size="10"  type="text" value="' . $items["product_name_bn"] . '" class="form-control input-sm product_name_bn_'.$items["product_id"].'" name="product_name[]"  readonly/>
    </td>
       <td  class="text-center" style="font-size: 12px"><input step="0.01" size="5"  type="number" id="total_quantity" value="0" class="form-control input-sm total_quantity_'.$items["product_id"] .'"  name="total_quantity[]" readonly/> </td>
    
  <td  class="text-center" style="font-size: 12px"> <input  size="5" type="text" value="' . $items["unit"] . '"  class="form-control input-sm unit_'.$items["product_id"].'" name="unit[]"  readonly/> </td>
  <td  class="text-center" ><input step="0.01" size="5" type="text" id="cook" value="0" class="form-control input-sm cook_'.$items["product_id"].'" name="cook[]"   onkeyup="quantityCalculator('.$items["product_id"].')"   onchange="quantityCalculator('.$items["product_id"].')"/> </td>
  <td   class="text-center"><input step="0.01" size="5"  type="text" value="0" class="form-control input-sm nan_'.$items["product_id"].'" name="nan[]"  onkeyup="quantityCalculator('.$items["product_id"].')"   onchange="quantityCalculator('.$items["product_id"].')"/></td>
  <td  class="text-center"><input step="0.01" size="5"    type="text" value="0" class="form-control input-sm   grill_'.$items["product_id"].'" name="grill[]"  onkeyup="quantityCalculator('.$items["product_id"].')"   onchange="quantityCalculator('.$items["product_id"].')"/>  </td>
  <td  class="text-center"><input step="0.01" size="5"  type="text" value="0" class="form-control   input-sm pantry_'.$items["product_id"].'" name="pantry[]"  onkeyup="quantityCalculator('.$items["product_id"].')"  onchange="quantityCalculator('.$items["product_id"].')"/> </td>
  <td  class="text-center"><input step="0.01" size="5"   type="text" value="0" class="form-control  input-sm  hall_'.$items["product_id"].'" name="hall[]"   onkeyup="quantityCalculator('.$items["product_id"].')"   onchange="quantityCalculator('.$items["product_id"].')" /> </td>
  <td  class="text-center"><input step="0.01" size="5"   type="text" value="0" class="form-control  input-sm  stuff_'.$items["product_id"].'" name="stuff[]"   onkeyup="quantityCalculator('.$items["product_id"].')"   onchange="quantityCalculator('.$items["product_id"].')"/> </td>

    <td><button type="button" name="remove" class="btn btn-danger btn-xs remove_inventory" id="' . $items["product_id"] . '">Remove</button></td>
   </tr>
   ';
        }
        $output .= '

  </table>

  </div>
  ';

        if ($count == 0) {
            $output = '<h3 align="center">Requisition  is Empty</h3>';
        }
        return $output;
    }

    //Aprove voucher
    public function aprove_rqsn(){
        $CI = & get_instance();
        $this->auth->check_admin_auth();
        $CI->load->model('Rqsn');
        $CI->load->model('Reports');
        $data['title'] = 'Approve Reacquisition';
        $data['t'] = $this->Rqsn->approve_rqsn();
        //$data['t'] = $this->Reports->getCheckList_rqsn();
       // $data = $this->Reports->getCheckLi st_rqsn();


      //  echo '<pre>';print_r($data);exit();
        $content = $this->parser->parse('rqsn/rqsn_approve', $data, true);
        $this->template->full_admin_html_view($content);
    }

    public function transfer_report(){
        $CI = & get_instance();
        $this->auth->check_admin_auth();
        $CI->load->model('Rqsn');
        $CI->load->model('Reports');
        $outlet_list    = $CI->Rqsn->outlet_list_to();
        $data['title'] = 'Transferred Item Report';
        $data['t'] = $this->Rqsn->transfer_item_report();
        $data['outlet_list'] = $outlet_list;
        //$data['t'] = $this->Reports->getCheckList_rqsn();
       // $data = $this->Reports->getCheckLi st_rqsn();


      //  echo '<pre>';print_r($data);exit();
        $content = $this->parser->parse('rqsn/transfer_item_report', $data, true);
        $this->template->full_admin_html_view($content);
    }

    public function date_wise_transfer_reports()
    {
        $CI = & get_instance();
        $CI->load->library('lreport');
        $CI->load->model('Reports');
        $outlet_list    = $CI->Rqsn->outlet_list_to();
        $from_date = $this->input->get('from_date');
        $to_date = $this->input->get('to_date');
        $outlet_id = $this->input->get('outlet_id');

        $data['title'] = 'Transferred Item Report';
        $data['t'] = $this->Rqsn->transfer_item_report_outlet_wise($outlet_id,$from_date,$to_date);
        $data['outlet_list'] = $outlet_list;
        //$data['t'] = $this->Reports->getCheckList_rqsn();
        // $data = $this->Reports->getCheckLi st_rqsn();


        //  echo '<pre>';print_r($data);exit();
        $content = $this->parser->parse('rqsn/transfer_item_report', $data, true);
        $this->template->full_admin_html_view($content);
    }

    public function aprove_rqsn_outlet(){
        $CI = & get_instance();
        $this->auth->check_admin_auth();
        $CI->load->model('Rqsn');
        $CI->load->model('Reports');
        $data['title'] = 'Approve Reacquisition';
        $data['t'] = $this->Rqsn->approve_rqsn_outlet();

        //$data['t'] = $this->Reports->getCheckList_rqsn();
       // $data = $this->Reports->getCheckLi st_rqsn();


      //  echo '<pre>';print_r($data);exit();
        $content = $this->parser->parse('rqsn/outlet_rqsn_approve', $data, true);
        $this->template->full_admin_html_view($content);
    }

    public function aprove_chalan(){
        $CI = & get_instance();
        $this->auth->check_admin_auth();
        $CI->load->model('Rqsn');
        $data['title'] = 'Chalan Approve';
        $data['aprrove'] = $this->Rqsn->approve_chalan();

       // echo '<pre>';print_r($data);exit();
        $content = $this->parser->parse('rqsn/approve_chalan', $data, true);
        $this->template->full_admin_html_view($content);
    }


    public function rqsn_list(){
        $CI = & get_instance();
        $this->auth->check_admin_auth();
        $CI->load->model('Rqsn');
        $data['title'] = 'Reacquisition List';
        $data['aprrove'] = $this->Rqsn->rqsn_list();

       //echo '<pre>';print_r($data);exit();
        $content = $this->parser->parse('rqsn/rqsn_list', $data, true);
        $this->template->full_admin_html_view($content);
    }

    public function rqsn_list_outlet(){
        $CI = & get_instance();
        $this->auth->check_admin_auth();
        $CI->load->model('Rqsn');
        $data['title'] = 'Stock Transferred Outlet';
        $data['aprrove'] = $this->Rqsn->rqsn_list_outlet();

       //echo '<pre>';print_r($data);exit();
        $content = $this->parser->parse('rqsn/rqsn_list_outlet', $data, true);
        $this->template->full_admin_html_view($content);
    }



    public function aprove_rqsn_purchase(){
        $CI = & get_instance();
        $this->auth->check_admin_auth();
        $CI->load->model('Rqsn');
        $data['title'] = 'Approve Reacquisition CW';
        $data['aprrove'] = $this->Rqsn->approve_rqsn_purchase();

        //echo '<pre>';print_r($data);exit();
        $content = $this->parser->parse('rqsn/rqsn_approve_purchase', $data, true);
        $this->template->full_admin_html_view($content);
    }



    public function outlet_approve(){
        $CI = & get_instance();
        $this->auth->check_admin_auth();
        $CI->load->model('Rqsn');
        $data['title'] = 'Outlet Approve';
        $data['t'] = $this->Rqsn->approve_outlet();

      //  echo '<pre>';print_r($data);exit();
        $content = $this->parser->parse('rqsn/rqsn_approve_outlet', $data, true);
        $this->template->full_admin_html_view($content);
    }

    public function outlet_approve_date_wise(){
        $CI = & get_instance();
        $this->auth->check_admin_auth();
        $CI->load->model('Rqsn');
       $from_date=$this->input->get('from_date');
       $to_date=$this->input->get('to_date');

        $data['title'] = 'Outlet Approve';
        $data['t'] = $this->Rqsn->approve_outlet_date_wise($from_date,$to_date);

       // echo '<pre>';print_r($data);exit();
        $content = $this->parser->parse('rqsn/rqsn_approve_outlet', $data, true);
        $this->template->full_admin_html_view($content);
    }

    public function isactive($id = null, $action = null,$cook=null,$nan=null,$grill=null,$pantry=null,$hall=null,$qty=null)
    {
        $CI = & get_instance();
        $CI->load->model('Rqsn');
        $action = ($action=='active'?2:1);
        $postData = array(
            'rqsn_detail_id'     => $id,
            'cook'=>$cook,
            'nan'=>$nan,
            'grill'=>$grill,
            'pantry'=>$pantry,
            'hall'=>$hall,
            'total_quantity'=>$qty,
            'status' => $action,
            'isaprv' =>1,
            'iscw' =>1
        );

//        print_r($postData);
//        die();

       // echo '<script>alert("Welcome to Geeks for Geeks")</script>';

        if ($this->Rqsn->approved($postData)) {
//
//            $this->session->set_flashdata('message', display('successfully_approved'));
            redirect(base_url('Crqsn/chalan_print/'.$id));
        } else {
            $this->session->set_flashdata('error_message', display('please_try_again'));
        }

        redirect($_SERVER['HTTP_REFERER']);
    }

    public function chalan_print($id) {
        $CI = & get_instance();
        $CI->auth->check_admin_auth();
        $CI->load->library('lrqsn');
        $content = $CI->lrqsn->chalan_html_data($id);
        $this->template->full_admin_html_view($content);
    }

    public function pre_chalan_print($id) {
        $CI = & get_instance();
        $CI->auth->check_admin_auth();
        $CI->load->library('lrqsn');
        $content = $CI->lrqsn->pre_chalan_html_data($id);
        $this->template->full_admin_html_view($content);
    }

    public function ischalan($id = null, $action = null,$value=null)
    {
        $CI = & get_instance();
        $CI->load->model('Rqsn');
        $action = ($action=='active'?1:2);
        $expiry_date=date('Y-m-d',strtotime(' +7 day'));
        $postData = array(
            'chalan_id'     => $id,
            'barcode'=>$value,
            'expired_date'=>$expiry_date,
            'status' => $action
        );

//        print_r($postData);
//        die();

       // echo '<script>alert("Welcome to Geeks for Geeks")</script>';

        if ($this->Rqsn->chalan_received($postData)) {
            $this->session->set_flashdata('message', display('successfully_approved'));
        } else {
            $this->session->set_flashdata('error_message', display('please_try_again'));
        }

        redirect($_SERVER['HTTP_REFERER']);
    }
    public function isapporve_purchase($id = null, $action = null,$value=null)
    {
        $CI = & get_instance();
        $CI->load->model('Rqsn');
        $action = ($action=='active'?4:1);
        $postData = array(
            'rqsn_detail_id'     => $id,
            'a_qty'=>$value,
            'status' => $action
        );

//        print_r($postData);
//        die();

       // echo '<script>alert("Welcome to Geeks for Geeks")</script>';

        if ($this->Rqsn->approved($postData)) {
            $this->session->set_flashdata('message', display('successfully_approved'));
        } else {
            $this->session->set_flashdata('error_message', display('please_try_again'));
        }

        redirect($_SERVER['HTTP_REFERER']);
    }

    public function rqsn_void($id = null, $action = null)
    {
        $CI = & get_instance();
        $CI->load->model('Rqsn');
        $action = ($action=='active'?3:2);
        $postData = array(
            'rqsn_id'     => $id,
            'status' => $action
        );

//        print_r($postData);
//        die();

       // echo '<script>alert("Welcome to Geeks for Geeks")</script>';

        if ($this->Rqsn->rqsn_void($postData)) {
            $this->session->set_flashdata('message','Requisition Voided!');
        } else {
            $this->session->set_flashdata('error_message', display('please_try_again'));
        }

        redirect($_SERVER['HTTP_REFERER']);
    }

    public function rqsn_delete($rqsn_id){
        if ($this->Rqsn->delete_rqsn($rqsn_id)) {
            $this->session->set_flashdata('message', display('successfully_delete'));
        } else {
            $this->session->set_flashdata('error_message', display('please_try_again'));
        }

        redirect($_SERVER['HTTP_REFERER']);

    }




    public function r_rqsn_delete($rqsn_id){
        if ($this->Rqsn->r_delete_rqsn($rqsn_id)) {
            $this->session->set_flashdata('message', display('successfully_delete'));
        } else {
            $this->session->set_flashdata('error_message', display('please_try_again'));
        }

        redirect($_SERVER['HTTP_REFERER']);

    }


    public function isreceive($id = null,$action = null)
    {
        $CI = & get_instance();
        $CI->load->model('Rqsn');
        $action = ($action=='active'?4:2);
            $postData = array(
                'rqsn_id'     => $id,
                'status' => $action,

            );



//        print_r($postData);
//        die();

        // echo '<script>alert("Welcome to Geeks for Geeks")</script>';

        if ($this->Rqsn->received($postData)) {
            $this->session->set_flashdata('message', 'Product Received');
            redirect(base_url('Crqsn/outlet_approve'));
        } else {
            $this->session->set_flashdata('error_message', display('please_try_again'));
            redirect($_SERVER['HTTP_REFERER']);
        }


    }

    public function outlet_rqsn_delete($rqsn_id){
        if ($this->Rqsn->delete_rqsn($rqsn_id)) {
            $this->session->set_flashdata('message', display('successfully_delete'));
        } else {
            $this->session->set_flashdata('error_message', display('please_try_again'));
        }

        redirect($_SERVER['HTTP_REFERER']);


    }
    public function stock(){

     //   echo 'Okay';die();

        $content = $this->lrqsn->stock_report_outlet_item();
       // echo 'Okay';die();
        $this->template->full_admin_html_view($content);
    }

    public function outlet_stock(){
        $this->load->model('Rqsn');
        $postData = $this->input->post();
        $data = $this->Rqsn->outlet_stock($postData);
        echo json_encode($data);
    }

}
