//all js 
function editinfo(id){
	'use strict';
	   var geturl=$("#url_"+id).val();
	   var myurl =geturl+'/'+id;
	    var dataString = "id="+id;
		 $.ajax({
		 type: "GET",
		 url: myurl,
		 data: dataString,
		 success: function(data) {
			 $('.editinfo').html(data);
			 $('#edit').modal('show');
			  $('.datepicker').bootstrapMaterialDatePicker({
    format: 'YYYY-MM-DD',
    shortTime: false,
    date: true,
    time: false,
    monthPicker: false,
    year: false,
    switchOnClick: true,
  });
		 } 
	});
	}
function editinforoom(id){
	'use strict';
	   var geturl=$("#url_"+id).val();
	   var myurl =geturl+'/'+id;
	    var dataString = "id="+id;
		 $.ajax({
		 type: "GET",
		 url: myurl,
		 data: dataString,
		 success: function(data) {
			 $('.editinfo').html(data);
			 $('#edit').modal('show');
			 $('select').selectpicker();
		 } 
	});

	}
	function serviceinforoom(id){
	'use strict';
	   var geturl=$("#service_url_"+id).val();
	   var myurl =geturl+'/'+id;
	    var dataString = "id="+id;
		 $.ajax({
		 type: "GET",
		 url: myurl,
		 data: dataString,
		 success: function(data) {
			 $('.serviceinfo').html(data);
			 $('#service').modal('show');
			 $('select').selectpicker();
		 }
	});
	}

	function rest_income(id){
	'use strict';
	   var geturl=$("#rest_url_"+id).val();
	   var myurl =geturl+'/'+id;
	    var dataString = "id="+id;
		 $.ajax({
		 type: "GET",
		 url: myurl,
		 data: dataString,
		 success: function(data) {
			 $('.restinfo').html(data);
			 $('#rest_income').modal('show');
			 $('select').selectpicker();
		 }
	});
	}
	function bar_income(id){
	'use strict';
	   var geturl=$("#bar_url_"+id).val();
	   var myurl =geturl+'/'+id;
	    var dataString = "id="+id;
		 $.ajax({
		 type: "GET",
		 url: myurl,
		 data: dataString,
		 success: function(data) {
			 $('.minibarinfo').html(data);
			 $('#bar_income').modal('show');
			 $('select').selectpicker();
		 }
	});
	}
	function laund_income(id){
	'use strict';
	   var geturl=$("#laund_url_"+id).val();
	   var myurl =geturl+'/'+id;
	    var dataString = "id="+id;
		 $.ajax({
		 type: "GET",
		 url: myurl,
		 data: dataString,
		 success: function(data) {
			 $('.laundinfo').html(data);
			 $('#laund_income').modal('show');
			 $('select').selectpicker();
		 }
	});
	}
	function drop_n_pick(id){
	'use strict';
	   var geturl=$("#drop_url_"+id).val();
	   var myurl =geturl+'/'+id;
	    var dataString = "id="+id;
		 $.ajax({
		 type: "GET",
		 url: myurl,
		 data: dataString,
		 success: function(data) {
			 $('.dropinfo').html(data);
			 $('#drop_income').modal('show');
			 $('select').selectpicker();
		 }
	});
	}

$(document).ready(function(){
	'use strict';
	$( "input[type='radio']" ).on( "click", function() {
	var getnationality=$("input:checked" ).val();
	if(getnationality=="foreigner"){
		$("#foreignerinfo").show();
		}
	else{
		$("#foreignerinfo").hide();
		}
	});
});
