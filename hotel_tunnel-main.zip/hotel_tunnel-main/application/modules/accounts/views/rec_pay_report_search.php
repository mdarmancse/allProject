<script src="<?php echo MOD_URL.$module;?>/assets/js/script.js"></script>

<?php

//        $op=0;
//        $cl=10;
//
//        $Hello = 10;
//         $op = "cl";
////         echo $var;
//         echo $$op;
//
//         exit();
$TotalReceiptOp=0;
$grTotalReceiptOp=0;
$TotalPaymentOp=0;



$closingBalOp=0;
$openingBal=0;
$TotalReceipt=0;
$grTotalReceipt=0;
$TotalPayment=0;

$closingBal=0;

$day_before = date( 'Y-m-d', strtotime( $dtpFromDate . ' -1 day' ) );

?>

<div class="col-md-12">

    <table class="table table-striped  table-bordered" width="100%">
        <tr>
            <td colspan="3" align="center" class="f_size_20">
                <b><?php echo 'Statement of Receipt and Payment' ?><br /><?php echo display('start_date')?>
                    <?php echo html_escape($dtpFromDate) ?> <?php echo display('end_date')?>
                    <?php echo html_escape($dtpToDate);?></b>
            </td>
        </tr>
    </table>
    <div class="row">
        <?php

        if(!empty($oResultTr)){?>
        <div class="col-6">
            <table width="50%" class="table table-striped  table-bordered " cellpadding="5" cellspacing="0">

                <tr>
                    <td colspan="3" align="center" class="f_size_20">
                        <b>Receipt</b>
                    </td>
                </tr>
                <tr class="table_head">

                    <td width="50%" align="center" class="b_left_top">
                        <strong><?php echo display('account_name');?></strong></td>

                    <td width="15%" align="center" class="b_left_right_top">
                        <strong><?php echo display('amount');?></strong></td>
                </tr>


                <?php

                $k=0;
                $openingBal='<span id="op"></span>'
                ?>

                <tr class="table_data">
                    <td colspan="1" align="right" class="b_left_top_bottom"><strong>Opening Balance</strong></td>
                    <td align="right" class="b_left_top_bottom">
                        <strong><?php echo strval($openingBal)?></strong>
                    </td>

                </tr>
                <?php

                  //echo $openingBal;

                for($i=0;$i<count($oResultTr);$i++)
                {

                    $COAID=$oResultTr[$i]['HeadCode'];
                    $HeadLevel=$oResultTr[$i]['HeadLevel'];

                    $sql="SELECT SUM(acc_transaction.Credit) AS Amount FROM acc_transaction WHERE acc_transaction.IsAppove =1 AND VDate BETWEEN '".$dtpFromDate."' AND '".$dtpToDate."' AND COAID LIKE '$COAID%' ";

                    $q1=$this->db->query($sql);
                    $oResultTrial = $q1->row();

                    $sqlF="SELECT SUM(acc_transaction.Credit) AS Amount FROM acc_transaction WHERE acc_transaction.IsAppove =1 AND acc_transaction.VDate >= '".$day_before."' AND COAID LIKE '$COAID%' ";
                    $q2=$this->db->query($sqlF);
                    $oResultTrialOp = $q2->row();

                    $TotalReceiptOp +=$oResultTrialOp->Amount;

                    $grTotalReceiptOp=$openingBal+$TotalReceiptOp;

                   // echo '<pre>';print_r($oResultTrialOp);exit();

//            $bg=$k&1?"#FFFFFF":"#E7E0EE";
                    $bg='';

            if($oResultTrial->Amount!=0)
            {
                    $k++;
                    ?>

                    <tr class="table_data">

                        <?php if ($HeadLevel == 0){ ?>
                            <td align="left" bgcolor="<?php echo $bg;?>" class="b_left_top">
                                <h5><strong><?php echo html_escape($oResultTr[$i]['HeadName']);?></strong></h5>
                            </td>
                        <?php }else if ($HeadLevel == 1){ ?>
                            <td align="left" bgcolor="<?php echo $bg;?>" class="b_left_top">
                                <strong>  &nbsp; <?php echo html_escape($oResultTr[$i]['HeadName']);?></strong>
                            </td>

                        <?php }else if ($HeadLevel == 2){ ?>
                            <td align="left" bgcolor="<?php echo $bg;?>" class="b_left_top">
                                <strong> &nbsp;&nbsp; &nbsp; <?php echo html_escape($oResultTr[$i]['HeadName']);?></strong>
                            </td>

                        <?php } else{?>
                            <td align="left" bgcolor="<?php echo $bg;?>" class="b_left_top">
                                <h6> &nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; <?php echo html_escape($oResultTr[$i]['HeadName']);?></h6>
                            </td>

                        <?php } ?>

                        <?php
                        if($oResultTrial)
                        {
                            ?>


                            <?php if ($HeadLevel == 0){ ?>
                            <td align="right" bgcolor="<?php echo $bg;?>" class="b_left_top" >
                                <h5><strong><?php

                                        $TotalReceipt += $oResultTrial->Amount; ?></strong></h5>
                            </td>
                        <?php }else if ($HeadLevel == 1){ ?>
                            <td align="right" bgcolor="<?php echo $bg;?>" class="b_left_top">
                                <strong>   <?php echo number_format($oResultTrial->Amount,2);?></strong>
                            </td>

                        <?php }else{?>
                            <td align="right" bgcolor="<?php echo $bg;?>" class="b_left_top">
                                <h6> <?php echo number_format($oResultTrial->Amount,2);?></h6>
                            </td>

                        <?php } ?>

                            <?php
                        }

                        ?>
                    </tr>
                    <?php
            }
                }


                ?>

                <tr class="table_head">
                    <td colspan="1" align="right" class="b_left_top_bottom"><strong>Total Receipt</strong></td>
                    <td align="right" class="b_left_top_bottom">
                        <input type="hidden" id="total_rec" value="<?=$TotalReceipt ?>" >
                                        <strong><span id=""><?php echo number_format($TotalReceipt,2); ?></span></strong>
                    </td>

                </tr>
                <tr class="table_head">
                    <td colspan="1" align="right" class="b_left_top_bottom"><strong>Grand Total Receipt</strong></td>
                    <td align="right" class="b_left_top_bottom">
                        <strong><span id="grand_rec"><?php echo number_format($grTotalReceipt=$openingBal+$TotalReceipt,2); ?></span></strong>
                    </td>

                </tr>
                <tr>
                    <td colspan="4" align="center">&nbsp;</td>
                </tr>

            </table>

        </div>
        <?php } ?>
        <?php if(!empty($oResultEx)){?>
        <div class="col-6">
            <table width="50%" class="table table-striped  table-bordered" cellpadding="5" cellspacing="0">

                <tr>
                    <td colspan="3" align="center" class="f_size_20">
                        <b>Payment</b>
                    </td>
                </tr>
                <tr class="table_head">

                    <td width="50%" align="center" class="b_left_top">
                        <strong><?php echo display('account_name');?></strong></td>

                    <td width="15%" align="center" class="b_left_right_top">
                        <strong><?php echo display('amount');?></strong></td>
                </tr>
                <?php

                $k=0;

                //  echo '<pre>';print_r($oResultTr);exit();

                for($i=0;$i<count($oResultEx);$i++)
                {

                    $COAID=$oResultEx[$i]['HeadCode'];
                    $HeadLevel=$oResultEx[$i]['HeadLevel'];
//            $sql="SELECT SUM(acc_transaction.Debit)-SUM(acc_transaction.Credit) AS Amount FROM acc_transaction INNER JOIN acc_coa ON acc_transaction.COAID = acc_coa.HeadCode COAID LIKE '$COAID%'";

                    $sql="SELECT SUM(acc_transaction.Debit) AS Amount FROM acc_transaction WHERE acc_transaction.IsAppove =1 AND VDate BETWEEN '".$dtpFromDate."' AND '".$dtpToDate."' AND COAID LIKE '$COAID%' ";

                    $q1=$this->db->query($sql);
                    $oResultExer = $q1->row();

                    $sqlF="SELECT SUM(acc_transaction.Credit) AS Amount FROM acc_transaction WHERE acc_transaction.IsAppove =1 AND acc_transaction.VDate >= '".$dtpToDate."' AND COAID LIKE '$COAID%' ";
                    $q2=$this->db->query($sqlF);
                    $oResultExCl = $q2->row();


                    $TotalPaymentOp +=$oResultExCl->Amount;

                    $openingBal=$grTotalReceiptOp-$TotalPaymentOp;
                    // echo '<pre>';print_r($oResultTrialOp);exit();

//            $bg=$k&1?"#FFFFFF":"#E7E0EE";
                    $bg='';

            if($oResultExer->Amount!=0)
            {
                    $k++;
                    ?>
                    <tr class="table_data">

                        <?php if ($HeadLevel == 0){ ?>
                            <td align="left" bgcolor="<?php echo $bg;?>" class="b_left_top">
                                <h5><strong><?php echo html_escape($oResultEx[$i]['HeadName']);?></strong></h5>
                            </td>
                        <?php }else if ($HeadLevel == 1){ ?>
                            <td align="left" bgcolor="<?php echo $bg;?>" class="b_left_top">
                                <strong>  &nbsp; <?php echo html_escape($oResultEx[$i]['HeadName']);?></strong>
                            </td>

                        <?php }else if ($HeadLevel == 2){ ?>
                            <td align="left" bgcolor="<?php echo $bg;?>" class="b_left_top">
                                <strong> &nbsp;&nbsp; &nbsp; <?php echo html_escape($oResultEx[$i]['HeadName']);?></strong>
                            </td>

                        <?php } else{?>
                            <td align="left" bgcolor="<?php echo $bg;?>" class="b_left_top">
                                <h6> &nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; <?php echo html_escape($oResultEx[$i]['HeadName']);?></h6>
                            </td>

                        <?php } ?>

                        <?php
                        if($oResultExer)
                        {
                            ?>


                            <?php if ($HeadLevel == 0){ ?>
                            <td align="right" bgcolor="<?php echo $bg;?>" class="b_left_top" >
                                <h5><strong><?php
                                        $TotalPayment += $oResultExer->Amount;
                                        ?></strong></h5>
                            </td>
                        <?php }else if ($HeadLevel == 1){ ?>
                            <td align="right" bgcolor="<?php echo $bg;?>" class="b_left_top">
                                <strong>   <?php echo number_format($oResultExer->Amount,2);?></strong>
                            </td>

                        <?php }else{?>
                            <td align="right" bgcolor="<?php echo $bg;?>" class="b_left_top">
                                <h6> <?php echo number_format($oResultExer->Amount,2);?></h6>
                            </td>

                        <?php } ?>

                            <?php
                        }

                        ?>
                    </tr>
                    <?php
            }
                }


                ?>

                <tr class="table_head">
                    <td colspan="1" align="right" class="b_left_top_bottom"><strong>Total Payment</strong></td>
                    <td align="right" class="b_left_top_bottom">
                        <input type="hidden" id="total_pay" value="<?=$TotalPayment ?>" >
                        <strong><span id=""><?php echo number_format($TotalPayment,2); ?></span></strong>
                    </td>

                </tr>
                <tr class="table_head">
                    <td colspan="1" align="right" class="b_left_top_bottom"><strong>Closing Balance</strong></td>
                    <td align="right" class="b_left_top_bottom">
                        <strong><span id="closing_bal"><?php echo number_format($grTotalReceipt-$TotalPayment,2); ?></span></strong>
                    </td>

                </tr>

                <input type="hidden" id="openBal" value="<?=$openingBal ?>">

                <tr>
                    <td colspan="4" align="center">&nbsp;</td>
                </tr>

            </table>

        </div>
         <?php } ?>


    </div>

                <table width="100%" cellpadding="1" cellspacing="20" class="mt_50">
                    <tr>
                        <td width="20%" class="b_top_1px" align="center">
                            <?php echo display('prepared_by');?></td>
                        <td width="20%" class="b_top_1px" align="center">
                            <?php echo display('accounts');?></td>
                        <td width="20%" class="b_top_1px" align='center'>
                            <?php echo display('chairman');?></td>
                    </tr>
                </table>


</div>



<script>
    $(document).ready(function() {
        'use strict';
        $("#exdatatable").DataTable({
            dom:"<'row m-0'<'col-sm-4'l><'col-sm-4 text-center'B><'col-sm-4'f>>tp",
            lengthMenu:[[10,25,50,-1],[10,25,50,"All"]],
            buttons:[{extend:"copy",className:"btn-sm prints"},
                {extend:"csv",title:"Data List",className:"btn-sm prints"},
                {extend:"pdf",title:"Data List",className:"btn-sm prints"},
                {extend:"print",className:"btn-sm prints"}]}),
            $('#dataTableExample2').DataTable({
                "dom": 'lBfrtip',
                "language": {
                    "search": '<i class="search__helper" data-sa-action="search-close"></i>',
                    "sFilterInput": "form-control",
                    "searchPlaceholder": "Search"
                },

                "buttons": [
                    {
                        extend: 'collection',
                        text: 'Export',
                        buttons: [
                            'copy',
                            'csv',
                            'pdf',
                            'print'
                        ]
                    }
                ]
            });
        $('.dataTables_filter').addClass('');
        $('.dataTables_filter label').addClass('search__inner');
        $('.dataTables_filter input').addClass('search__text');	});
</script>