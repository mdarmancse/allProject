
<?php
$GLOBALS['TotalAssertF']   = 0;

function AssertCoa($HeadName,$HeadCode,$GL,$oResultAsset,$Visited,$value,$dtpFromDate,$dtpToDate,$check){

    $CI =& get_instance();

    if($value==1)
    {
        ?>
<!--        <tr>-->
<!--            <td colspan="2" class="f_size_f_weight_b_left_right_top">--><?php //echo html_escape($HeadName);?><!--</td>-->
<!--        </tr>-->
        <?php
    }
    elseif($value>1)
    {
        $COAID=$HeadCode;
        if($check)
        {
            $sqlF="SELECT SUM(acc_transaction.Credit) AS Amount FROM acc_transaction INNER JOIN acc_coa ON acc_transaction.COAID = acc_coa.HeadCode COAID LIKE '$COAID%'";
        }
        else
        {
            $sqlF="SELECT SUM(acc_transaction.Credit) AS Amount FROM acc_transaction INNER JOIN acc_coa ON acc_transaction.COAID = acc_coa.HeadCode WHERE acc_transaction.IsAppove = 1 AND COAID LIKE '$COAID%'";
        }
        $q1 = $CI->db->query($sqlF);
        $oResultAmountPreF = $q1->row();

        if($value==2)
        {

                $GLOBALS['TotalAssertF']=$GLOBALS['TotalAssertF']+$oResultAmountPreF->Amount;

        }

        if($oResultAmountPreF->Amount!=0)
        {
            ?>
            <tr>
                <td align="left" style="b_left_b_right_f_size<?php echo (int)(20-$value*1.5)."px;";
                echo ($value<=3?" font-weight:bold; ":" ");
                ?>"><?php echo ($value>=3?"&nbsp;&nbsp;&nbsp;&nbsp;":""). $HeadName; ?></td>
                <td align="right" class="b_left_right_top"><?php echo number_format($oResultAmountPreF->Amount,2);?></td>
            </tr>
            <?php
        }
    }
    for($i=0;$i<count($oResultAsset);$i++)
    {
        if (!$Visited[$i]&&$GL==0)
        {
            if ($HeadName==$oResultAsset[$i]->PHeadName)
            {
                $Visited[$i]=true;
                AssertCoa($oResultAsset[$i]->HeadName,$oResultAsset[$i]->HeadCode,$oResultAsset[$i]->IsGL,$oResultAsset,$Visited,$value+1,$dtpFromDate,$dtpToDate,$check);
            }
        }
    }
}


?>

<div class="card mb-4">

    <div class="row">
        <div class="col-sm-12">
            <div class="card-body">
                <?php echo form_open('',array('class' => 'form-inline'))?>
                <?php date_default_timezone_set("Asia/Dhaka"); $today = date('d-m-Y'); ?>

                <div class="form-group">
                    <div id="reportrange" class="pull-left dateRange">
                        <i class="glyphicon glyphicon-calendar fa fa-calendar"></i>&nbsp;
                        <strong><span class="text-center p-4"></span></strong> <b class="caret"></b>
                    </div>


                </div>
                <div class="form-group">
                    <label class="padding_right_5px" for="from_date"><?php echo display('start_date') ?>
                    </label>
                    <input type="text" name="from_date" value=""
                           class="form-control " id="dtpFromDate"
                           placeholder="<?php echo display('start_date') ?>" readonly>

                </div>

                <div class="form-group">
                    <label class="padding_0_5px" for="to_date"> <?php echo display('end_date') ?> </label>
                    <input type="text" name="to_date" value=""
                           class="form-control " id="dtpToDate" placeholder="<?php echo "To"; ?>" readonly>
                </div>


                &nbsp;<a class="btn btn-success" onclick="getreport()"><span class="text-white">
                                <?php echo display('filter') ?></span></a>&nbsp;
                <?php echo form_close()?>


            </div>
        </div>
    </div>
</div>


<div class="row">
    <div class="col-sm-12 col-md-12">
        <div class="card"  id="printArea">
            <div class="card-header">
                <h4>
                    <?php echo display('income_details_report')?>
                    <small class="float-right" id="print">
                        <input type="button" class="btn btn-info button-print text-white" name="btnPrint" id="btnPrint"
                               value="Print" onclick="printContent('printArea')" />
                    </small>
                </h4>
            </div>
            <div>
                <div class="card-body" id="getresult2">

                    <table width="100%" class="table table-striped  table-bordered" cellpadding="5" cellspacing="0">

                        <tr>
                            <td width="80%" align="left" class="f_size_b_left_top">
                               <h5> <b><?php echo display('particulars')?></b></h5></td>
                            <td width="20%"  align="right" class="f_size_b_left_right_top">
                                <h5><b><?php echo display('amount')?></b></h5></td>
                        </tr>
                        <?php
                        for($i=0;$i<count($oResultAsset);$i++)
                        {
                            $Visited[$i] = false;
                        }

                        AssertCoa("COA","0",0,$oResultAsset,$Visited,0,$dtpFromDate,$dtpToDate,0);

                        $TotalAssetF=$GLOBALS['TotalAssertF'];
                        ?>
                        <tr >
                            <td align="right"><strong> <?php echo display('total_income')?></td></strong></td>
                            <td align="right" class="b_style_b_letft_right_top">
                                <strong><?php echo number_format($TotalAssetF,2); ?></strong>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" align="right"></td>
                        </tr>

                        <tr bgcolor="#FFF" >
                            <td colspan="2" align="center" height="120" valign="bottom" >
                                <table width="100%" cellpadding="1" cellspacing="20">

                                    <tr>
                                        <td width="20%" class="b_top_1px" align="center">
                                            <?php echo display('prepared_by')?></td>
                                        <td width="20%" class="b_top_1px" align="center">
                                            <?php echo display('accounts')?></td>
                                        <td width="20%" class="b_top_1px" align="center">
                                            <?php echo display('authorized_signature')?></td>
                                        <td width="20%" class="b_top_1px" align='center'>
                                            <?php echo display('chairman')?></td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Include Required Prerequisites -->
<script type="text/javascript" src="//cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>

<!-- Include Date Range Picker -->
<script type="text/javascript" src="//cdn.jsdelivr.net/bootstrap.daterangepicker/2/daterangepicker.js"></script>
<link rel="stylesheet" type="text/css" href="//cdn.jsdelivr.net/bootstrap.daterangepicker/2/daterangepicker.css"/>
<script src="<?php echo MOD_URL.$module;?>/assets/js/dateRanger.js"></script>
<script type="text/javascript">

</script>