<script src="<?php echo MOD_URL.$module;?>/assets/js/script.js"></script>

<?php

//        $op=0;
//        $cl=10;
//
//        $Hello = 10;
//         $op = "cl";
////         echo $var;
//         echo $$op;
//
//         exit();
$TotalReceiptOp=0;
$grTotalReceiptOp=0;
$TotalPaymentOp=0;



$closingBalOp=0;
$openingBal=0;
$TotalReceipt=0;
$grTotalReceipt=0;
$TotalPayment=0;

$closingBal=0;

$day_before = date( 'Y-m-d', strtotime( $dtpFromDate . ' -1 day' ) );

?>

<div class="col-md-12">

    <table class="table table-striped  table-bordered" width="100%">
        <tr>
            <td colspan="3" align="center" class="f_size_20">
                <b><?php echo 'Statement of Expenditure Details Report' ?><br /><?php echo display('start_date')?>
                    <?php echo html_escape($dtpFromDate) ?> <?php echo display('end_date')?>
                    <?php echo html_escape($dtpToDate);?></b>
            </td>
        </tr>
    </table>
    <div class="row">



        <?php if(!empty($oResultEx)){?>
        <div class="col-12">
            <table width="100%" class="table table-striped  table-bordered" cellpadding="5" cellspacing="0">

                <tr>
                    <td colspan="3" align="center" class="f_size_20">
                        <b>Expenditure</b>
                    </td>
                </tr>
                <tr class="table_head">

                    <td width="15%"  align="left" class="f_size_b_left_right_top">
                        <h5><b><?php echo display('date')?></b></h5></td>
                    <td width="70%" align="left" class="f_size_b_left_top">
                        <h5> <b><?php echo display('particulars')?></b></h5></td>
                    <td width="30%"  align="right" class="f_size_b_left_right_top">
                        <h5><b><?php echo display('amount')?></b></h5></td>
                </tr>
                <?php

                $k=0;

                //  echo '<pre>';print_r($oResultTr);exit();

                for($i=0;$i<count($oResultEx);$i++)
                {

                    $COAID=$oResultEx[$i]['HeadCode'];
                    $HeadLevel=$oResultEx[$i]['HeadLevel'];

                    $sql="SELECT acc_transaction.VDate , SUM(acc_transaction.Debit) AS Amount FROM acc_transaction WHERE acc_transaction.IsAppove =1 AND VDate BETWEEN '".$dtpFromDate."' AND '".$dtpToDate."' AND COAID LIKE '$COAID%' GROUP BY VDate";

                    $q1=$this->db->query($sql);
                    $oResultExer = $q1->result();




//            $bg=$k&1?"#FFFFFF":"#E7E0EE";
                    $bg='';
                    foreach ($oResultExer as $or){

            if($or->Amount!=0)
            {
                    $k++;
                    ?>
                    <tr class="table_data">
                        <td align="left" bgcolor="<?php echo $bg;?>" class="b_left_top">
                            <h6>  <?php echo html_escape($or->VDate);?></h6>
                        </td>

                        <?php if ($HeadLevel == 0){ ?>
                            <td align="left" bgcolor="<?php echo $bg;?>" class="b_left_top">
                                <h5><strong><?php echo html_escape($oResultEx[$i]['HeadName']);?></strong></h5>
                            </td>
                        <?php }else if ($HeadLevel == 1){ ?>
                            <td align="left" bgcolor="<?php echo $bg;?>" class="b_left_top">
                                <strong>  &nbsp; <?php echo html_escape($oResultEx[$i]['HeadName']);?></strong>
                            </td>

                        <?php }else if ($HeadLevel == 2){ ?>
                                  <td align="left" bgcolor="<?php echo $bg;?>" class="b_left_top">
                                      <strong> &nbsp;&nbsp; &nbsp; <?php echo html_escape($oResultEx[$i]['HeadName']);?></strong>
                                  </td>

                           <?php } else{?>
                            <td align="left" bgcolor="<?php echo $bg;?>" class="b_left_top">
                                <h6> &nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; <?php echo html_escape($oResultEx[$i]['HeadName']);?></h6>
                            </td>

                        <?php } ?>

                        <?php
                        if($oResultExer)
                        {
                            ?>


                            <?php if ($HeadLevel == 0){ ?>
                            <td align="right" bgcolor="<?php echo $bg;?>" class="b_left_top" >
                                <h5><strong><?php
                                        $TotalPayment += $or->Amount;
                                        ?>  <?php echo number_format($or->Amount,2);?></strong></h5>
                            </td>
                        <?php }else if ($HeadLevel == 1){ ?>
                            <td align="right" bgcolor="<?php echo $bg;?>" class="b_left_top">
                                <strong>   <?php echo number_format($or->Amount,2);?></strong>
                            </td>

                        <?php }else{?>
                            <td align="right" bgcolor="<?php echo $bg;?>" class="b_left_top">
                                <h6> <?php echo number_format($or->Amount,2);?></h6>
                            </td>

                        <?php } ?>

                            <?php
                        }

                        ?>
                    </tr>
                    <?php
            }

                }

                }
                ?>

                <tr class="table_head">
                    <td colspan="2" align="right" class="b_left_top_bottom"><strong>  <?php echo display('total_expense');?></strong></td>
                    <td align="right" class="b_left_top_bottom">
                        <input type="hidden" id="total_pay" value="<?=$TotalPayment ?>" >
                        <strong><span id=""><?php echo number_format($TotalPayment,2); ?></span></strong>
                    </td>

                </tr>


                <input type="hidden" id="openBal" value="<?=$openingBal ?>">

                <tr>
                    <td colspan="4" align="center">&nbsp;</td>
                </tr>

            </table>

        </div>
         <?php } ?>


    </div>

                <table width="100%" cellpadding="1" cellspacing="20" class="mt_50">
                    <tr>
                        <td width="20%" class="b_top_1px" align="center">
                            <?php echo display('prepared_by');?></td>
                        <td width="20%" class="b_top_1px" align="center">
                            <?php echo display('accounts');?></td>
                        <td width="20%" class="b_top_1px" align='center'>
                            <?php echo display('chairman');?></td>
                    </tr>
                </table>


</div>



<script>
    $(document).ready(function() {
        'use strict';
        $("#exdatatable").DataTable({
            dom:"<'row m-0'<'col-sm-4'l><'col-sm-4 text-center'B><'col-sm-4'f>>tp",
            lengthMenu:[[10,25,50,-1],[10,25,50,"All"]],
            buttons:[{extend:"copy",className:"btn-sm prints"},
                {extend:"csv",title:"Data List",className:"btn-sm prints"},
                {extend:"pdf",title:"Data List",className:"btn-sm prints"},
                {extend:"print",className:"btn-sm prints"}]}),
            $('#dataTableExample2').DataTable({
                "dom": 'lBfrtip',
                "language": {
                    "search": '<i class="search__helper" data-sa-action="search-close"></i>',
                    "sFilterInput": "form-control",
                    "searchPlaceholder": "Search"
                },

                "buttons": [
                    {
                        extend: 'collection',
                        text: 'Export',
                        buttons: [
                            'copy',
                            'csv',
                            'pdf',
                            'print'
                        ]
                    }
                ]
            });
        $('.dataTables_filter').addClass('');
        $('.dataTables_filter label').addClass('search__inner');
        $('.dataTables_filter input').addClass('search__text');	});
</script>