


<div class="card mb-4">
    <?php echo form_open('',array('class' => ''))?>
    <div class="row">
        <div class="col-sm-12">


            <div class="form-inline m-2 ">




                <div class="form-group m-2 ">
                    <label class="padding_right_5px" for="from_date">  <input id="chkpall" type="checkbox" >  &nbsp; Expense Head
                    </label>
                    <select class=" form-control selectpicker"  onchange="select_py_ledger()" aria-label="Default select example" id="parent_py_head" multiple >


                        <?php foreach ($rec_head as $rec){  ?>
                            <option value="<?= $rec->HeadType?>"><?= $rec->HeadName?></option>
                        <?php } ?>

                    </select>

                </div>
                <div class="form-group m-2 d-none" id="py">
                    <label class="padding_right_5px" for="from_date"> <input id="chkpyall" type="checkbox" >  &nbsp; Expense Ledger
                    </label>



                    <select  name="py_cat[]" id="py_cat" class=" form-control selectpicker" aria-label="Default select example" multiple>

                    </select>

                    <!--                    <select class=" form-control selectpicker" aria-label="Default select example" multiple>-->
                    <!--                  -->
                    <!--                    </select>-->
                </div>




            </div>

        </div>
        <?php echo form_close()?>
    </div>
    <div class="row">
        <div class="col-sm-12">


            <div class=" form-inline m-2">

                <?php date_default_timezone_set("Asia/Dhaka"); $today = date('d-m-Y'); ?>

                <div class="form-group">
                    <div id="reportrange" class="pull-left dateRange">
                        <i class="glyphicon glyphicon-calendar fa fa-calendar"></i>&nbsp;
                        <strong><span class="text-center p-4"></span></strong> <b class="caret"></b>
                    </div>
                </div>
                <div class="form-group">
                    <label class="padding_right_5px" for="from_date"><?php echo display('start_date') ?>
                    </label>
                    <input type="text" name="from_date" value=""
                           class="form-control " id="dtpFromDate"
                           placeholder="<?php echo display('start_date') ?>" readonly>

                </div>

                <div class="form-group">
                    <label class="padding_0_5px" for="to_date"> <?php echo display('end_date') ?> </label>
                    <input type="text" name="to_date" value=""
                           class="form-control " id="dtpToDate" placeholder="<?php echo "To"; ?>" readonly>
                </div>


                &nbsp;<a class="btn btn-success" onclick="getExreport()"><span class="text-white">
                                <?php echo display('filter') ?></span></a>&nbsp;



            </div>

        </div>
        <?php echo form_close()?>
    </div>
</div>
<div class="row">
    <div class="col-sm-12 col-md-12">
        <div class="card"  id="printArea">
            <div class="card-header">
                <h4>
                    <?php echo display('expense_report')?>
                    <small class="float-right" id="print">
                        <input type="button" class="btn btn-info button-print text-white" name="btnPrint" id="btnPrint"
                               value="Print" onclick="printContent('printArea')" />
                    </small>
                </h4>
            </div>
            <div>
                <div class="card-body" id="getresult2">

                </div>
            </div>
        </div>
    </div>
</div>

<!-- Include Required Prerequisites -->
<script type="text/javascript" src="//cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>

<!-- Include Date Range Picker -->
<script type="text/javascript" src="//cdn.jsdelivr.net/bootstrap.daterangepicker/2/daterangepicker.js"></script>
<link rel="stylesheet" type="text/css" href="//cdn.jsdelivr.net/bootstrap.daterangepicker/2/daterangepicker.css"/>
<script src="<?php echo MOD_URL.$module;?>/assets/js/dateRanger.js"></script>
<script type="text/javascript">



    $(document).ready(function() {
        $('#sub_cat_id').select2();
        $('#py_cat').select2();
        $('#parent_head').select2();
        $('#parent_py_head').select2();

        $("#chkall").click(function(){
            if($("#chkall").is(':checked')){
                $("#parent_head > option").prop("selected", "selected");
                $("#parent_head").trigger("change");
            } else {
                $("#parent_head > option").removeAttr("selected");
                $("#parent_head").trigger("change");
            }
        });

        $("#chrckall").click(function(){
            if($("#chrckall").is(':checked')){
                $("#sub_cat_id > option").prop("selected", "selected");
                $("#sub_cat_id").trigger("change");
            } else {
                $("#sub_cat_id > option").removeAttr("selected");
                $("#sub_cat_id").trigger("change");
            }
        });

        $("#chkpall").click(function(){
            if($("#chkpall").is(':checked')){
                $("#parent_py_head > option").prop("selected", "selected");
                $("#parent_py_head").trigger("change");
            } else {
                $("#parent_py_head > option").removeAttr("selected");
                $("#parent_py_head").trigger("change");
            }
        });

        $("#chkpyall").click(function(){
            if($("#chkpyall").is(':checked')){
                $("#py_cat > option").prop("selected", "selected");
                $("#py_cat").trigger("change");
            } else {
                $("#py_cat > option").removeAttr("selected");
                $("#py_cat").trigger("change");
            }
        });
    });
    function select_rc_ledger() {
        var parent_head = $("#parent_head").val();

        var base = $('#base_url').val();
        var csrf = $('#csrf_token').val();
        var myurl = base+"accounts/accounts/select_rc_ledger/";
        var sub_ledg_selected = ""


        $.ajax( {
            url: myurl,
            method: 'post',
            data: {
                parent_head:parent_head,
                sub_ledg_selected: sub_ledg_selected,
                csrf_test_name: csrf
            },
            cache: false,
            success: function( data ) {
                var obj = jQuery.parseJSON(data);
                $('#rc').removeClass('d-none');
                $('#sub_cat_id').html(obj.sub_cat);

               // console.log(obj.sub_cat)

            }
        })

    }
    function select_py_ledger() {
        var parent_head = $("#parent_py_head").val();

        var base = $('#base_url').val();
        var csrf = $('#csrf_token').val();
        var myurl = base+"accounts/accounts/select_py_ledger/";
        var sub_ledg_selected = ""


        $.ajax( {
            url: myurl,
            method: 'post',
            data: {
                parent_head:parent_head,
                sub_ledg_selected: sub_ledg_selected,
                csrf_test_name: csrf
            },
            cache: false,
            success: function( data ) {
                var obj = jQuery.parseJSON(data);

                $('#py').removeClass('d-none');
                $('#py_cat').html(obj.sub_cat);

               // console.log(obj.sub_cat)
                // $('#cat_id').val(obj.c_id);
                // var cat_id = $("#cat_id").val();

                // if(category_id == obj.c_id ){
                //     $("#subCat_div").css("display", "block");
                // }else{
                //     $("#subCat_div").css("display", "none");
                // }
            }
        })

    }

</script>