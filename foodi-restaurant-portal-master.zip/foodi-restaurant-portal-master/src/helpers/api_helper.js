import axios from "axios"
import accessToken from "./jwt-token-access/accessToken"
import { useNavigate } from "react-router-dom"

//pass new generated access token here
const token = accessToken

//apply base url for axios
const API_URL =
  "http://node-foodi-restaurant.theecotek.com:4500/api/v1/restaurant/portal"

const axiosApi = axios.create({
  baseURL: API_URL,
})

// axiosApi.defaults.headers.common["Authorization"] = token

axiosApi.interceptors.response.use(
  response => response,
  error => {
    if (error.response.status === 401) {
      window.open("/login", "_self")
    }
    return error
  }
)

export async function get(url, config = {}) {
  return await axiosApi.get(url, { ...config }).then(response => response.data)
}

export async function post(url, data, config = {}) {
  return axiosApi
    .post(url, { ...data }, { ...config })
    .then(response => response.data)
}

export async function put(url, data, config = {}) {
  return axiosApi
    .put(url, { ...data }, { ...config })
    .then(response => response.data)
}

export async function del(url, config = {}) {
  return await axiosApi
    .delete(url, { ...config })
    .then(response => response.data)
}

export const commonHeaders = {
  "Content-Type": "application/json",
  "Access-Control-Allow-Origin": "*",
}

export const commonHeadersAuthorized = {
  "Content-Type": "application/json",
  "Access-Control-Allow-Origin": "*",
  Authorization: `Bearer ${localStorage.getItem("foodi-jwt")}`,
}

export { axiosApi }
