import {
  SERVER_SIDE_PAGINATION_BRANCH,
  SERVER_SIDE_PAGINATION_BRANCH_FRESH,
  GET_BRANCH_BY_ID,
  GET_BRANCH_BY_ID_FRESH,
  GET_PERFORMANCE_BY_BRANCH_ID,
  GET_PERFORMANCE_BY_BRANCH_ID_FRESH,
} from "./actionTypes"
import axios from "axios"
import { commonHeadersAuthorized } from "helpers/api_helper"

export const getServerSidePaginationBranchAction = (index, limit, filters) => {
  // var url =
  //   process.env.REACT_APP_LOCALHOST +
  //   `/Branch/Search?page=${index}&limit=${limit}${filters ? "&" + filters : ""}`
  var url = process.env.REACT_APP_API_URL + `/restaurant/branch/list`
  const dataObject = {
    page: index,
    limit: limit,
    ...filters,
  }
  return dispatch => {
    axios
      .post(url, dataObject, { headers: commonHeadersAuthorized })
      .then(response => {
        dispatch({
          type: SERVER_SIDE_PAGINATION_BRANCH,
          payload: response.data,
          status: "Success",
        })
      })
      .catch(error => {
        dispatch({
          type: SERVER_SIDE_PAGINATION_BRANCH,
          status: "Failed",
        })
      })
  }
}

export const getServerSidePaginationBranchFresh = () => {
  return dispatch =>
    dispatch({
      type: SERVER_SIDE_PAGINATION_BRANCH_FRESH,
      status: false,
      payload: null,
    })
}

export const getBranchByIdAction = id => {
  // var url = process.env.REACT_APP_LOCALHOST + "/Branch/GetById?id=" + id
  var url = process.env.REACT_APP_API_URL + "/restaurant/details"

  const dataObject = {
    restaurant_id: id,
  }

  return dispatch => {
    const headers = {
      "Content-Type": "application/json",

      "Access-Control-Allow-Origin": "*",
    }
    axios
      .post(url, dataObject, { headers: commonHeadersAuthorized })
      .then(response => {
        console.log("response :", response)

        dispatch({
          type: GET_BRANCH_BY_ID,
          payload: response.data.data,
          status: "Success",
        })
      })
      .catch(error => {
        console.log("error :", error)
        dispatch({
          type: GET_BRANCH_BY_ID,
          status: "Failed",
        })
      })
  }
}

export const getBranchByIdFresh = () => {
  console.log("=======In the fresh ---------")
  return dispatch => {
    dispatch({
      type: GET_BRANCH_BY_ID_FRESH,
      status: false,
      payload: null,
    })
  }
}

export const getPerformanceByBranchIdAction = data => {
  // var url = process.env.REACT_APP_LOCALHOST + "/Branch/GetById?id=" + id
  var url = process.env.REACT_APP_API_URL + "/restaurant/performance"
  // const mockData = {
  //   totalOrder: 14,
  //   totalAcceptance: 8,
  //   totalCancel: 0,
  //   unavailableMenu: "0.00%",
  // }
  // return dispatch => {
  //   setTimeout(() => {
  //     dispatch({
  //       type: GET_PERFORMANCE_BY_BRANCH_ID,
  //       // payload: response.data?.data,
  //       payload: mockData,
  //       status: "Success",
  //     })
  //   }, 1000)
  // }
  return dispatch => {
    axios
      .post(url, data, { headers: commonHeadersAuthorized })
      .then(response => {
        console.log("response :", response)

        dispatch({
          type: GET_PERFORMANCE_BY_BRANCH_ID,
          payload: response.data?.data,
          status: "Success",
        })
      })
      .catch(error => {
        console.log("error :", error)
        dispatch({
          type: GET_PERFORMANCE_BY_BRANCH_ID,
          status: "Failed",
        })
      })
  }
}

export const getPerformanceByBranchIdActionFresh = () => {
  console.log("=======In the fresh ---------")
  return dispatch => {
    dispatch({
      type: GET_PERFORMANCE_BY_BRANCH_ID_FRESH,
      status: false,
      payload: null,
    })
  }
}
