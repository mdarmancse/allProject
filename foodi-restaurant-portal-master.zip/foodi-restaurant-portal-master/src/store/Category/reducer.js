import {
  ADD_CATEGORY,
  ADD_CATEGORY_FRESH,
  GET_ALL_CATEGORY,
  GET_ALL_CATEGORY_FRESH,
  CATEGORY_NAME_EDIT,
  CATEGORY_NAME_EDIT_FRESH,
  CATEGORY_STATUS_EDIT,
  CATEGORY_STATUS_EDIT_FRESH,
  GET_CATEGORY_NAME_BY_ID,
  CATEGORY_DELETE,
  CATEGORY_DELETE_FRESH,
  SERVER_SIDE_PAGINATION_CATEGORY,
  SERVER_SIDE_PAGINATION_CATEGORY_SEARCH,
  SERVER_SIDE_PAGINATION_SEARCH_CATEGORY_FRESH,
  GET_CATEGORY_BY_BRANCH_ID,
} from "./actionTypes"

const initialState = {
  // for category add
  add_category_data: null,
  add_category_error: null,
  add_category_loading: false,

  // load all category
  get_all_category_data: null,
  get_all_category_error: null,
  get_all_category_loading: false,

  //category name edit
  category_name_edit_data: null,
  category_name_edit_loading: false,

  category_status_edit_data: null,
  category_status_edit_loading: false,

  category_delete_loading: false,

  // server side pagination category
  get_server_side_pagination_category_data: null,
  get_server_side_pagination_category_error: null,
  get_server_side_pagination_category_loading: false,

  get_server_side_pagination_category_search_data: null,
  get_server_side_pagination_category_search_loading: false,

  get_category_by_branch_id_data: null,
  get_category_by_branch_id_error: null,
  get_category_by_branch_id_loading: false,
}

const category = (state = initialState, action) => {
  switch (action.type) {
    case ADD_CATEGORY:
      state = {
        ...state,
        add_category_data: action.payload,
        add_category_error: null,
        add_category_loading: action.status,
        get_all_category_loading: false,
      }
      break

    case ADD_CATEGORY_FRESH:
      state = {
        ...state,
        add_category_loading: action.status,
      }
      break

    case GET_ALL_CATEGORY:
      state = {
        ...state,
        get_all_category_data: action.payload,
        get_all_category_error: null,
        get_all_category_loading: action.status,
      }
      break

    case GET_ALL_CATEGORY_FRESH:
      state = {
        ...state,
        get_all_category_loading: action.status,
      }
      break

    case CATEGORY_NAME_EDIT:
      state = {
        ...state,
        category_name_edit_data: action.payload,
        category_name_edit_loading: action.status,
        get_all_category_loading: false,
      }
      break

    case CATEGORY_NAME_EDIT_FRESH:
      state = {
        ...state,
        category_name_edit_loading: action.status,
      }
      break

    case CATEGORY_STATUS_EDIT:
      state = {
        ...state,
        category_status_edit_data: action.payload,
        category_status_edit_loading: action.status,
        get_all_category_loading: false,
      }
      break

    case CATEGORY_STATUS_EDIT_FRESH:
      state = {
        ...state,
        category_status_edit_loading: action.status,
      }
      break

    case CATEGORY_DELETE:
      state = {
        ...state,
        category_delete_loading: action.status,
        get_all_category_loading: false,
      }
      break
    case CATEGORY_DELETE_FRESH:
      state = {
        ...state,
        category_delete_loading: action.status,
        get_all_category_loading: false,
      }
      break
    case SERVER_SIDE_PAGINATION_CATEGORY:
      state = {
        ...state,
        get_server_side_pagination_category_data: action.payload,
        get_server_side_pagination_category_error: null,
        get_server_side_pagination_category_loading: action.status,
      }
      break

    case SERVER_SIDE_PAGINATION_CATEGORY_SEARCH:
      state = {
        ...state,
        get_server_side_pagination_category_search_data: action.payload,
        get_server_side_pagination_category_search_loading: action.status,
      }
      break

    case SERVER_SIDE_PAGINATION_SEARCH_CATEGORY_FRESH:
      state = {
        ...state,
        get_server_side_pagination_category_search_data: action.payload,
        get_server_side_pagination_category_search_loading: action.status,
      }
      break

    case GET_CATEGORY_BY_BRANCH_ID:
      state = {
        ...state,
        get_category_by_branch_id_data: action.payload,
        get_category_by_branch_id_error: action.error,
        get_category_by_branch_id_loading: action.status,
      }
      break
  }
  return state
}

export default category
