export const CURRENCY_SYMBOLS = "TK"
