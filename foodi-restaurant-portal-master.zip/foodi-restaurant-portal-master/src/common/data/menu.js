export const menu_status_options = {
  unavailable_till: "Unavailable Till",
  unavailable_today: "Unavailable Today",
  unavailable_indefinitely: "Unavailable Indefinitely",
}
