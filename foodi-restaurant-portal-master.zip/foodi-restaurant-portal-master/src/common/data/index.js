// import React from "react"

import { calenderDefaultCategories, events } from "./calender"

export { events, calenderDefaultCategories }
