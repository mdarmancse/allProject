export const status_options = {
  open: "Open",
  set_to_busy: "Set to busy",
  close_for_today: "Close for today",
}

export const close_reasons = {
  outside_the_schedule: "Outside of schedule",
  updating_menu: "Updating Menu",
  holiday: "Holiday",
  technical_issue: "Technical Issue",
  undergoing_renovation: "Undergoing Renovation",
  bad_weather: "Bad Weather",
  other: "Other",
}

export const performanceCardStyles = {
  totalOrder: { backgroundColor: "#FF6384", color: "#fff" },
  totalAcceptance: { backgroundColor: "#36A2EB", color: "#fff" },
  totalCancel: { backgroundColor: "#FFCE56", color: "#fff" },
  unavailableMenu: { backgroundColor: "#4BC0C0", color: "#fff" },
}

export const performanceCardName = {
  totalOrder: "Total Order",
  totalAcceptance: "Total Accepted Order",
  totalCancel: "Total Cancelled Order",
  unavailableMenu: "Unavailable Menu",
}
