import React from "react"

// Authentication related pages
import Login from "../pages/Authentication/Login"
import Logout from "../pages/Authentication/Logout"
import Register from "../pages/Authentication/Register"
import ForgetPwd from "../pages/Authentication/ForgetPassword"

//  // Inner Authentication
import Login1 from "../pages/AuthenticationInner/Login"
import Register1 from "../pages/AuthenticationInner/Register"
import Register2 from "../pages/AuthenticationInner/Register2"
import Recoverpw from "../pages/AuthenticationInner/Recoverpw"
import Recoverpw2 from "../pages/AuthenticationInner/Recoverpw2"
import ForgetPwd1 from "../pages/AuthenticationInner/ForgetPassword"
import LockScreen from "../pages/AuthenticationInner/auth-lock-screen"
import LockScreen2 from "../pages/AuthenticationInner/auth-lock-screen-2"
import ConfirmMail from "../pages/AuthenticationInner/page-confirm-mail"
import ConfirmMail2 from "../pages/AuthenticationInner/page-confirm-mail-2"
import EmailVerification from "../pages/AuthenticationInner/auth-email-verification"
import EmailVerification2 from "../pages/AuthenticationInner/auth-email-verification-2"
import TwostepVerification from "../pages/AuthenticationInner/auth-two-step-verification"
import TwostepVerification2 from "../pages/AuthenticationInner/auth-two-step-verification-2"

//Pages
import Restaurant from "pages/Restaurant/Restaurant"
import Branch from "pages/Restaurant/Branch"
import BranchAdd from "pages/Restaurant/BranchAdd/BranchAdd"
import Menu from "pages/Restaurant/Menu/Menu"
import AddMenu from "pages/Restaurant/Menu/AddMenu/AddMenu"
import EditMenu from "pages/Restaurant/Menu/AddMenu/EditMenu"
import MenuTimeSlot from "pages/Restaurant/MenuItemTimeSlot/MenuTimeSlot"
import AddTimeSlot from "pages/Restaurant/MenuItemTimeSlot/AddTimeSlot/AddTimeSlot"
import Order from "pages/Order/Order"
import Invoice from "pages/Order/Invoice"
const userRoutes = [
  // Restaurant
  { path: "/restaurant", component: <Restaurant /> },

  { path: "/manage-branch", component: <Branch /> },
  { path: "/branch-add", component: <BranchAdd /> },

  { path: "/menu", component: <Menu /> },
  { path: "/add-menu", component: <AddMenu /> },
  { path: "/edit-menu", component: <EditMenu /> },

  { path: "/time-slot", component: <MenuTimeSlot /> },
  { path: "/add-time-slot", component: <AddTimeSlot /> },

  // Orders
  // { path: "/dispatch", component: <Order /> },
  { path: "/invoice/:orderID", component: <Invoice /> },

  // this route should be at the end of all other routes
  { path: "/", component: <Order /> },
]

const authRoutes = [
  { path: "/logout", component: <Logout /> },
  //{ path: "/login", component: <Login /> },
  { path: "/login", component: <Login1 /> },
  { path: "/forgot-password-2", component: <ForgetPwd /> },
  //{ path: "/register", component: <Register /> },
  // { path: "/register", component: <Register1 /> },

  // Authentication Inner
  //{ path: "/pages-login", component: <Login1 /> },
  //{ path: "/pages-register", component: <Register1 /> },
  { path: "/pages-register-2", component: <Register2 /> },
  // { path: "/page-recoverpw", component: <Recoverpw /> },
  { path: "/upload-token", component: <Recoverpw /> },
  { path: "/page-recoverpw-2", component: <Recoverpw2 /> },
  { path: "/forgot-password", component: <ForgetPwd1 /> },
  { path: "/auth-lock-screen", component: <LockScreen /> },
  { path: "/auth-lock-screen-2", component: <LockScreen2 /> },
  { path: "/page-confirm-mail", component: <ConfirmMail /> },
  { path: "/page-confirm-mail-2", component: <ConfirmMail2 /> },
  { path: "/auth-email-verification", component: <EmailVerification /> },
  { path: "/auth-email-verification-2", component: <EmailVerification2 /> },
  { path: "/auth-two-step-verification", component: <TwostepVerification /> },
  {
    path: "/auth-two-step-verification-2",
    component: <TwostepVerification2 />,
  },
]

export { userRoutes, authRoutes }
