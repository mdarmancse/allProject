import app from "./app.js";
import * as dotenv from "dotenv";
import { Server } from "socket.io";
import { createServer } from "http";

import chatRouter from "./src/routes/chat_route.js";

dotenv.config();
const PORT = process.env.PORT || 12500;

const server = createServer(app);
server.listen(PORT, () => {
  console.log('listening on *:'+ PORT);
});

global.io = new Server(server, {
    cors: {
        origin: "*",
    },
});


io.on('connection', (socket) => {
  console.log("Hi socket is connected")
  socket.broadcast.emit('Send Message');
});


export default io;
