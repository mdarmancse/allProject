<!-- Stock List Start -->
<div class="content-wrapper">
    <section class="content-header">
        <div class="header-icon">
            <i class="pe-7s-note2"></i>
        </div>
        <div class="header-title">
            <h1><?php echo display('stock_report') ?></h1>
            <small><?= $heading_text ?></small>
            <ol class="breadcrumb">
                <li><a href="#"><i class="pe-7s-home"></i> <?php echo display('home') ?></a></li>
                <li><a href="#"><?php echo display('stock') ?></a></li>
                <li class="active"><?= $heading_text ?></li>
            </ol>
        </div>
    </section>

    <section class="content">
        <!-- Alert Message -->
        <?php
        $message = $this->session->userdata('message');
        if (isset($message)) {
        ?>
            <div class="alert alert-info alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <?php echo $message ?>
            </div>
        <?php
            $this->session->unset_userdata('message');
        }
        $error_message = $this->session->userdata('error_message');
        if (isset($error_message)) {
        ?>
            <div class="alert alert-danger alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <?php echo $error_message ?>
            </div>
        <?php
            $this->session->unset_userdata('error_message');
        }
        ?>



        <div class="row">
            <div class="col-sm-12">
                <div class="panel panel-bd lobidrag">
                    <div class="panel-heading">
                        <div class="panel-title text-right">

                        </div>
                    </div>
                    <div class="panel-body">

                        <div class="row" style="margin-bottom: 10px;">
                            <div class="col-sm-6">
                                <label class="" for="from_date"><?php echo display('start_date') ?></label>
                                <input type="text" name="from_date" class="form-control datepicker" id="from_date" placeholder="<?php echo display('start_date') ?>" value="" autocomplete="off">
                            </div>

                            <div class="col-sm-6">
                                <label class="" for="to_date"><?php echo display('end_date') ?></label>
                                <input type="text" name="to_date" class="form-control datepicker" id="to_date" placeholder="<?php echo display('end_date') ?>" value="" autocomplete="off">
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-4" style="margin-bottom: 10px;">
                                <label for="supplier_id" class="col-form-label">Supplier : </label>
                                <select id="supplier_id" class="form-control" name="supplier_id">
                                    <option value="">Select One</option>
                                    {supplier_list}
                                    <option value="{supplier_id}">{supplier_name}</option>
                                    {/supplier_list}
                                </select>
                            </div>
                            <div class="col-md-4" style="margin-bottom: 10px;">
                                <label for="pr_status" class="col-form-label">Product Status : </label>
                                <select id="pr_status" class="form-control" name="pr_status">
                                    <option value="">Select One</option>
                                    <option value="1">Finished Goods</option>
                                    <option value="2">Raw Materials</option>
                                    <option value="3">Tools</option>
                                </select>
                            </div>
                            <div class="col-md-4" style="margin-bottom: 10px;">
                                <label for="cat_list" class="col-form-label">Category : </label>
                                <select id="cat_list" class="form-control" name="cat_list">
                                    <option value="">Select One</option>
                                    {cat_list}
                                    <option value="{category_id}">{category_name}</option>
                                    {/cat_list}
                                </select>
                            </div>
                        </div>

                        <div>

                            <div class="table-responsive" id="printableArea">
                                <table class="table table-striped table-bordered" cellspacing="0" width="100%" id="checkListSupplierList">
                                    <thead>
                                        <tr>
                                            <th class="text-center"><?php echo display('sl') ?></th>
                                            <th class="text-center">Supplier Name</th>
                                            <th class="text-center"><?php echo display('product_name') ?></th>
                                            <th class="text-center"><?php echo display('product_model') ?></th>
                                            <th class="text-center">Category</th>
                                            <th class="text-center">Color</th>
                                            <th class="text-center">Size</th>
                                            <th class="text-center"><?php echo display('sell_price') ?> (TK)</th>
                                            <th class="text-center"><?php echo display('purchase_price') ?> (TK)</th>
                                            <th class="text-center"><?php echo display('in_qnty') ?></th>
                                            <th class="text-center">Damaged Quantity</th>
                                            <th class="text-center"><?php echo display('out_qnty') ?></th>

                                            <th class="text-center">Opening Stock</th>
                                            <th class="text-center">Closing Stock</th>

                                            <th class="text-center"><?php echo display('stock_sale') ?> (TK)</th>
                                            <th class="text-center"><?php echo display('stock_purchase_price') ?> (TK)</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <tfoot>
                                        <tr>
                                            <th></th>
                                            <th></th>
                                            <th></th>
                                            <th></th>
                                            <th></th>
                                            <th></th>
                                            <th></th>
                                            <th></th>
                                            <th></th>
                                            <th></th>
                                            <th></th>
                                            <th class="text-right"><?php echo display('total') ?> :</th>
                                            <th id="stockqty"></th>
                                            <th id=""></th>
                                            <th></th>
                                            <th></th>
                                        </tr>

                                    </tfoot>

                                </table>
                            </div>
                        </div>
                        <input type="hidden" id="currency" value="{currency}" name="">
                        <input type="hidden" id="total_stock" value="<?php echo $totalnumber; ?>" name="">
                    </div>
                </div>
            </div>
        </div>

    </section>
</div>