import { Send_Queue } from "../../helper/common/RMQ.js";
import moment from "moment";
import RestaurentModel from "../../models/Restaurant/RestaurentModel.js";
import fs from "fs/promises";
import fsSync from "fs";
import path from "path";
import GenerateImageLink from "../../helper/GenerateImageLink.js";
import RestaurantReviews from "../../models/Restaurant/RestaurantReviews.js";
import Category from "../../models/Restaurant/Category.js";
import { SYSTEM_TIMEZONE } from "../../consts/defaults.js";
import Menu from "../../models/Restaurant/Menu.js";
import {
  calculateDelay,
  handleReactivationJob,
  reactivationQueue,
} from "../../helper/redis.js";
import BranchCloseReason from "../../models/Restaurant/BranchCloseReason.js";
import RestaurantUser from "../../models/RestaurantUser/RestaurantUser.js";
import Role from "../../models/RestaurantUser/Role.js";
import ParentRestaurant from "../../models/Restaurant/ParentRestaurant.js";

const cms_queue = process.env.CMS_QUEUE_NAME;
export async function getParentRestList(req, res, next) {
  let body = req.body;
  let results = {},
    check_id;

  try {
    let role_name = body.role_name;
    if (!role_name) {
      return res.json({ status: -1, msg: "Role not found" });
    }

    if (role_name === "central_admin") {
      check_id = body.id;
    } else {
      return res.status(401).json({ status: -1, msg: "Access Denied" });
    }

    let returnData = await ParentRestaurant.getParentRestList(
      check_id,
      body.limit,
      body.page
    );

    if (returnData.length > 0) {
      results = {
        status: 1,
        data: returnData,
      };
    } else {
      results = {
        status: -1,
        msg: "No Data Found",
      };
    }
    return res.json(results);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ status: -1, msg: "Server error", err: err.toString() });
  }
}

export async function getBranchList(req, res, next) {
  let body = req.body;
  let results = {},
    check_id;

  try {
    let role_name = body.role_name;
    if (!role_name) {
      return res.json({ status: -1, msg: "Role not found" });
    }
    check_id = body.id;
    // if (role_name === 'central_admin'){
    //     check_id=(await ParentRestaurant.findOne({central_admin:body.id},{_id:1}))._id;
    // }
    // else if(role_name === 'branch_admin'){
    //     check_id=body.id
    // }

    // return res.send(check_id)

    let returnData = await RestaurentModel.getBranchList(check_id, body.limit, body.page);

    if (returnData) {
      results = {
        status: 1,
        data: returnData,
      };
    } else {
      results = {
        status: -1,
        msg: "No Data Found",
      };
    }
    return res.json(results);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ status: -1, msg: "Server error", err: err.toString() });
  }
}
export async function getRestaurantDetails(req, res, next) {
  let body = req.body;
  let results = {};

  try {
    let returnData = await RestaurentModel.getRestaurantDetails(body.restaurant_id);

    const currentDay = moment().day();
    const currentTime = moment().format("HH:mm:ss");
    console.log("currentDay", currentDay);
    console.log("currentTime", currentTime);

    const currentDayHours = returnData.working_hours.find(
      (hour) => hour.day_number === currentDay
    );
    console.log("currentDayHours", currentDayHours);

    let isOpen = false;

    if (currentDayHours) {
      isOpen = currentDayHours.slots.some((slot) => {
        const openTime = moment(slot.open_time, "HH:mm");
        const closeTime = moment(slot.close_time, "HH:mm");
        const currentTimeMoment = moment(currentTime, "HH:mm:ss");
        return currentTimeMoment.isBetween(openTime, closeTime);
      });
    }

    console.log(`Restaurant is open: ${isOpen}`);
    if (returnData) {
      returnData.is_open = isOpen;
      results = {
        status: 1,
        data: returnData,
      };
    } else {
      results = {
        status: -1,
        msg: "No Data Found",
      };
    }
    return res.json(results);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ status: -1, msg: "Server error", err: err.toString() });
  }
}

export async function updateRestaurant(req, res, next) {
  try {
    const body = req.body;
    const restId = body.restaurant_id;
    const imagePath =
      req.files && Array.isArray(req.files.image) && req.files.image.length > 0
        ? req.files.image[0].path
        : null;
    const coverImagePath =
      req.files &&
      Array.isArray(req.files.cover_image) &&
      req.files.cover_image.length > 0
        ? req.files.cover_image[0].path
        : null;

    const updateData = {};

    // Update fields in the schema
    if (body.name) updateData.name = body.name;
    if (body.slug) updateData.slug = body.slug;
    if (body.phone_number) updateData.phone_number = body.phone_number;
    if (body.email) updateData.email = body.email;
    if (body.address) updateData.address = body.address;
    if (body.share_link) updateData.share_link = body.share_link;
    if (body.price_range) updateData.price_range = body.price_range;
    if (body.is_veg) updateData.is_veg = JSON.parse(body.is_veg);
    if (body.zonal_admin) updateData.zonal_admin = body.zonal_admin;
    if (body.min_order_value)
      updateData.min_order_value = JSON.parse(body.min_order_value);
    if (body.is_take_pre_order)
      updateData.is_take_pre_order = JSON.parse(body.is_take_pre_order);
    if (body.commission) updateData.commission = JSON.parse(body.commission);
    if (body.delivery_charge)
      updateData.delivery_charge = JSON.parse(body.delivery_charge);
    if (body.delivery_time) updateData.delivery_time = JSON.parse(body.delivery_time);
    if (body.pickup_time) updateData.pickup_time = JSON.parse(body.pickup_time);
    if (body.is_delivery) updateData.is_delivery = JSON.parse(body.is_delivery);
    if (body.is_pickup) updateData.is_pickup = JSON.parse(body.is_pickup);
    if (body.is_dine) updateData.is_dine = JSON.parse(body.is_dine);
    if (body.is_active) updateData.is_active = JSON.parse(body.is_active);
    if (body.location) updateData.location = JSON.parse(body.location);
    if (body.working_hours) updateData.working_hours = JSON.parse(body.working_hours);

    // updateData._id=restId
    // updateData.updated_by=body.id

    if (imagePath) {
      if (fsSync.existsSync(imagePath)) {
        updateData.image = (await GenerateImageLink(imagePath)).url;
        await fs.unlink(imagePath);
      } else {
        console.error(`Image file not found at path: ${imagePath}`);
      }
    }

    if (coverImagePath) {
      if (fsSync.existsSync(coverImagePath)) {
        updateData.cover_image = (await GenerateImageLink(coverImagePath)).url;
        await fs.unlink(coverImagePath);
      } else {
        console.error(`Cover image file not found at path: ${coverImagePath}`);
      }
    }

    const updatedRestaurant = await RestaurentModel.findByIdAndUpdate(
      restId,
      updateData,
      { new: true }
    );
    //console.log(typeof updateData.is_active)
    //  console.log('updateData',updateData)
    let cms_data = {
      _id: updatedRestaurant._id,
      slug: updatedRestaurant.slug,
      phone_number: updatedRestaurant.phone_number,
      email: updatedRestaurant.email,
      address: updatedRestaurant.address,
      share_link: updatedRestaurant.share_link,
      price_range: updatedRestaurant.price_range,
      is_veg: updatedRestaurant.is_veg,
      zonal_admin: updatedRestaurant.zonal_admin,
      min_order_value: updatedRestaurant.min_order_value,
      is_take_pre_order: updatedRestaurant.is_take_pre_order,
      commission: updatedRestaurant.commission,
      delivery_charge: updatedRestaurant.delivery_charge,
      delivery_time: updatedRestaurant.delivery_time,
      pickup_time: updatedRestaurant.pickup_time,
      is_delivery: updatedRestaurant.is_delivery,
      is_pickup: updatedRestaurant.is_pickup,
      is_dine: updatedRestaurant.is_dine,
      is_active: updatedRestaurant.is_active,
      location: updatedRestaurant.location,
      working_hours: updatedRestaurant.working_hours,
      updated_at: updatedRestaurant.updated_at,
      updated_by: updatedRestaurant.updated_by,
      image: updatedRestaurant.image,
      cover_image: updatedRestaurant.cover_image,
    };
    await Send_Queue(cms_queue, "restaurant_queue", cms_data, "branch", "edit");

    return res.status(200).json({
      status: 1,
      msg: "Successfully profile updated",
      data: updatedRestaurant,
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({
      status: -1,
      msg: "Server error.",
    });
  }
}

export async function addRestReview(req, res, next) {
  try {
    const body = req.body;
    const { rest_id, rider_id, order_id, rating, additional_notes } = req.body;
    const review = await RestaurantReviews.findOneAndUpdate(
      { rest_id, rider_id, order_id },
      {
        $set: {
          rest_id,
          rider_id,
          additional_notes,
          order_id,
          rating,
          created_by: body.id,
          updated_by: body.id,
        },
      },

      {
        upsert: true,
        new: true,
        setDefaultsOnInsert: true,
        rawResult: true,
      }
    );

    console.log("review", review);

    if (review && review.lastErrorObject.updatedExisting == false) {
      await Send_Queue(cms_queue, "restaurant_queue", review.value, "rate_rider", "add");
      console.log("Document Inserted");
    }
    if (review && review.lastErrorObject.updatedExisting == true) {
      await Send_Queue(cms_queue, "restaurant_queue", review.value, "rate_rider", "edit");
      console.log("Document Updated");
    }

    if (rating === "good") {
      return res.status(200).json({
        status: 1,
        data: {
          review_id: review.value._id,
          riderGoodReason: [
            {
              key: "rider_on_time",
              reason: "Rider on time",
              isSelected: false,
            },
            {
              key: "respectful",
              reason: "Respectful",
              isSelected: false,
            },
            {
              key: "proper_attire",
              reason: "Proper attire",
              isSelected: false,
            },
            {
              key: "follow_pickup_instructions",
              reason: "Follow Pickup Instructions",
              isSelected: false,
            },
            {
              key: "carried_bag",
              reason: "Carried Bag",
              isSelected: false,
            },
            {
              key: "checked_order_content",
              reason: "Checked order content",
              isSelected: false,
            },
            {
              key: "good_communication",
              reason: "Good Communication",
              isSelected: false,
            },
            {
              key: "other",
              reason: "Other",
              isSelected: false,
            },
          ],
        },
      });
    }
    if (rating === "bad") {
      return res.status(200).json({
        status: 1,
        data: {
          review_id: review.value._id,
          riderBadReason: [
            {
              key: "late",
              reason: "Late",
              isSelected: false,
            },
            {
              key: "too_early",
              reason: "Too Early",
              isSelected: false,
            },
            {
              key: "inappropriate_appearance",
              reason: "Inappropriate Appearance",
              isSelected: false,
            },
            {
              key: "forgot_item",
              reason: "Forgot Item",
              isSelected: false,
            },
            {
              key: "carried_bag",
              reason: "No Bag",
              isSelected: false,
            },
            {
              key: "ignore_instructions",
              reason: "Ignore Instructions",
              isSelected: false,
            },
            {
              key: "no_social_distancing",
              reason: "No social distancing",
              isSelected: false,
            },
            {
              key: "unprofessional",
              reason: "Unprofessional",
              isSelected: false,
            },
            {
              key: "bad_weather",
              reason: "Bad Weather",
              isSelected: false,
            },
            {
              key: "other",
              reason: "Other",
              isSelected: false,
            },
          ],
        },
      });
    }
  } catch (err) {
    console.error(err);
    return res.status(500).json({ status: -1, msg: "Server error" });
  }
}
export async function addRestReviewReason(req, res, next) {
  try {
    const body = req.body;
    let review;
    const { review_id, additional_notes, rating, good_issues, bad_issues } = req.body;
    if (rating === "good") {
      review = await RestaurantReviews.findOneAndUpdate(
        { _id: review_id },
        {
          $set: {
            additional_notes,
            good_issues,
            rating,
            created_by: body.id,
            updated_by: body.id,
          },
        },

        {
          upsert: true,
          new: true,
          setDefaultsOnInsert: true,
          rawResult: true,
        }
      );
    }

    if (rating === "bad") {
      review = await RestaurantReviews.findOneAndUpdate(
        { _id: review_id },
        {
          $set: {
            additional_notes,
            rating,
            bad_issues,
            created_by: body.id,
            updated_by: body.id,
          },
        },

        {
          upsert: true,
          new: true,
          setDefaultsOnInsert: true,
          rawResult: true,
        }
      );
    }

    if (review.value) {
      if (review && review.lastErrorObject.updatedExisting == false) {
        await Send_Queue(
          cms_queue,
          "restaurant_queue",
          review.value,
          "rate_rider",
          "add"
        );
        console.log("Document Inserted");
      }
      if (review && review.lastErrorObject.updatedExisting == true) {
        await Send_Queue(
          cms_queue,
          "restaurant_queue",
          review.value,
          "rate_rider",
          "edit"
        );
        console.log("Document Updated");
      }

      return res.json({ status: 1, msg: "Review added successfully" });
    } else {
      return res.json({ status: -1, msg: "Something went wrong!" });
    }
  } catch (err) {
    console.error(err);
    return res.status(500).json({ status: -1, msg: "Server error" });
  }
}

export async function restaurantStatus(req, res, next) {
  try {
    let results = {};
    const rest_id = req.params.rest_id;
    let returnData = await RestaurentModel.getRestaurantStatus(rest_id);
    if (returnData) {
      results = {
        status: 1,
        data: returnData,
      };
    } else {
      results = {
        status: -1,
        msg: "No Data Found",
      };
    }
    return res.json(results);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ status: -1, msg: "Server error" });
  }
}

export async function changeRestaurantStatus(req, res, next) {
  const { restaurant_id, status_option, close_reason, comment } = req.body;

  try {
    let deactivationDate, is_active, is_busy, branchCloseReason;

    if (status_option === "set_to_busy") {
      deactivationDate = moment()
        .add(SYSTEM_TIMEZONE.HOURS, "hours")
        .add(30, "minutes")
        .toDate();
      is_active = false;
      is_busy = true;
    } else if (status_option === "close_for_today") {
      deactivationDate = moment()
        .endOf("day")
        .add(SYSTEM_TIMEZONE.HOURS, "hours")
        .toDate();
      is_active = false;
      is_busy = false;
      if (close_reason) {
        branchCloseReason = await BranchCloseReason.create({
          branch_id: restaurant_id,
          close_reason,
          comment,
          created_by: req.body.id,
          updated_by: req.body.id,
        });
      }
    } else if (status_option === "open") {
      deactivationDate = null;
      is_active = true;
      is_busy = false;
    }

    const restData = await RestaurentModel.findOneAndUpdate(
      { _id: restaurant_id },
      {
        $set: {
          is_active: is_active,
          is_busy: is_busy,
          deactivation_date: deactivationDate,
          // deactivation_date: "2023-06-17T16:51:59.999+00:00",
        },
      },
      { new: true }
    );

    if (!restData) {
      return res.status(404).json({ message: "Restaurant not found" });
    }
    let branch_data = {
      _id: restData._id,
      is_active: restData.is_active,
      is_busy: restData.is_busy,
      deactivation_date: restData.deactivation_date,
      updated_at: restData.updated_at,
      updated_by: restData.updated_by,
    };
    let cms_data = {
      branch: {
        data: branch_data,
        method: "edit",
      },
      branch_closing_issue: {
        data: branchCloseReason ? branchCloseReason : null,
        method: "add",
      },
    };

    await Send_Queue(cms_queue, "restaurant_queue", cms_data, "branch", "change_status");

    //  Add reactivation job to the queue

    console.log("restData.deactivation_date", restData.deactivation_date);
    if (status_option == "close_for_today" || status_option == "set_to_busy") {
      await reactivationQueue.add(
        { id: restaurant_id, model: "RestaurentModel" },
        { delay: calculateDelay(restData.deactivation_date) }
      );
    }
    if (restData.is_active === true) {
      return res.status(200).json({ status: 1, msg: "Branch reactivated successfully" });
    } else {
      if (status_option === "set_to_busy") {
        return res
          .status(200)
          .json({ status: 1, msg: "Branch deactivated successfully" });
      } else if (status_option === "close_for_today") {
        if (branchCloseReason) {
          return res
            .status(200)
            .json({ status: 1, msg: "Branch deactivated successfully" });
        } else {
          return res.status(200).json({
            status: 1,
            closeReason: [
              {
                key: "outside_the_schedule",
                reason: "Outside The Schedule",
              },
              {
                key: "updating_menu",
                reason: "Updating Menu",
              },
              {
                key: "holiday",
                reason: "Holiday",
              },
              {
                key: "technical_issue",
                reason: "Technical Issue",
              },
              {
                key: "undergoing_renovation",
                reason: "Undergoing Renovation",
              },
              {
                key: "bad_weather",
                reason: "Bad Weather",
              },
              {
                key: "other",
                reason: "Other",
              },
            ],
          });
        }
      }
    }
  } catch (err) {
    console.log("ERROR", err.toString());
    return res
      .status(500)
      .json({ status: -1, msg: "Internal server error", err: err.toString() });
  }
}
