import OrderModel from "../../models/Order/Order.js";
import {
  coupon_val_check,
  coupon_val_check_by_id,
} from "../../helper/common/Calculation.js";
import { Send_Queue } from "../../helper/common/RMQ.js";
import { UpdateService } from "../../helper/common/CRUD.js";
import RestaurentModel from "../../models/Restaurant/RestaurentModel.js";
import ParentRestaurant from "../../models/Restaurant/ParentRestaurant.js";
import { autoRouting } from "../../helper/common/AutoRouting.js";
import { sendNotifications } from "../../helper/common/Notifications.js";
const cms_queue = process.env.CMS_QUEUE_NAME;

export async function getNewOrder(req, res, next) {
  let body = req.body;
  let results = {};

  try {
    let returnData = await OrderModel.getRestNewOrder(
      body.restaurant_id,
      body.limit,
      body.page
    );

    if (returnData.length > 0) {
      results = {
        status: 1,
        data: returnData,
      };
    } else {
      results = {
        status: -1,
        msg: "No Data Found",
      };
    }
    return res.json(results);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ status: -1, msg: "Server error", err: err.toString() });
  }
}
export async function getAcceptedOrder(req, res, next) {
  let body = req.body;
  let results = {};

  try {
    let returnData = await OrderModel.getRestAcceptedOrder(
      body.restaurant_id,
      body.limit,
      body.page
    );

    if (returnData.length > 0) {
      results = {
        status: 1,
        data: returnData,
      };
    } else {
      results = {
        status: -1,
        msg: "No Data Found",
      };
    }
    return res.json(results);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ status: -1, msg: "Server error", err: err.toString() });
  }
}

export async function getRecentOrder(req, res, next) {
  let body = req.body;
  let results = {};

  try {
    let returnData = await OrderModel.getRestRecentOrder(
      body.restaurant_id,
      body.limit,
      body.page
    );

    if (returnData) {
      results = {
        status: 1,
        data: returnData,
      };
    } else {
      results = {
        status: -1,
        msg: "No Data Found",
      };
    }
    return res.json(results);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ status: -1, msg: "Server error", err: err.toString() });
  }
}

export async function getOrderList(req, res, next) {
  let body = req.body,
    check_id;
  let results = {};

  try {
    let role_name = body.role_name;
    if (!role_name) {
      return res.json({ status: -1, msg: "Role not found" });
    }
    check_id = body.id;
    // if (role_name === 'central_admin'){
    //     check_id=(await ParentRestaurant.findOne({central_admin:body.id},{_id:1}))._id;
    // }
    // else if(role_name === 'branch_admin'){
    //     // check_id=(await RestaurentModel.findOne({branch_admin:body.id},{_id:1})).branch_admin;
    //     check_id=body.id;
    // }

    // return res.json({
    //     role_name,check_id
    // })
    let returnData = await OrderModel.getOrderList(
      check_id,
      body.order_id,
      body.order_type,
      body.order_status,
      body.order_date,
      body.order_total,
      body.payment_method,
      body.branch_name,
      body.branch_mobile,
      body.customer_name,
      body.zone_name,
      body.rider_name,
      body.rider_number,
      body.is_active,
      body.is_handover,
      body.is_ascending,
      body.limit,
      body.page
    );

    if (returnData) {
      results = {
        status: 1,
        data: returnData,
      };
    } else {
      results = {
        status: -1,
        msg: "No Data Found",
      };
    }
    return res.json(results);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ status: -1, msg: "Server error", err: err.toString() });
  }
}

export async function getOrderDetails(req, res, next) {
  let body = req.body;
  let results = {},
    discount_type,
    coupon_check,
    discount,
    discount_value;

  try {
    let returnData = await OrderModel.getRestOrderDetails(body.order_id);

    if (returnData) {
      let user_data;
      if (returnData.coupon_id != null) {
        coupon_check = await coupon_val_check_by_id(returnData.coupon_id);

        discount_value = coupon_check.is_percent
          ? coupon_check.discount_in_percent
          : coupon_check.discount_in_amount;
      }
      discount_type = coupon_check.is_percent ? "percent" : "amount";
      let calculation = [
        {
          name: "sub_total",
          display_name: "Sub total",
          amount: returnData.sub_total.toFixed(2),
        },
        {
          name: "discount",
          display_name: "(-) Discount -",
          amount: returnData.discount_amount,
          type: discount_type,
          value: discount_value,
        },
        {
          name: "vat",
          display_name: "(+) VAT",
          amount: returnData.total_vat.toFixed(2),
        },
        {
          name: "sd",
          display_name: "(+) SD",
          amount: returnData.total_sd.toFixed(2),
        },
        {
          name: "total",
          display_name: "Total",
          amount: returnData.total_amount.toFixed(2),
        },
        {
          name: "commission",
          display_name: "(-) Commission",
          type: "percent",
          value: returnData.commission,
          amount: ((returnData.sub_total * returnData.commission) / 100).toFixed(2),
        },
        {
          name: "receive",
          display_name: "Receivables",
          amount: returnData.payment_to_vendor
            ? returnData.payment_to_vendor.toFixed(2)
            : 0,
        },
      ];
      user_data = await Send_Queue(
        "main_user_request",
        "rider_queue",
        { _id: returnData.customer_id },
        "UserModel",
        "get"
      );
      console.log("user_data", user_data.data);

      let customer_name = user_data.data.firstName + " " + user_data.data.lastName;
      returnData.rider_lat = 22.3456;
      returnData.rider_long = 91.2355;
      returnData.customer_name = customer_name;
      returnData.calculation = calculation;
      results = {
        status: 1,
        data: returnData,
      };
    } else {
      results = {
        status: -1,
        msg: "No Data Found",
      };
    }
    return res.json(results);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ status: -1, msg: "Server error", err: err.toString() });
  }
}
export async function changeStatus(req, res, next) {
  const { order_id, order_status, is_handover } = req.body;
  let results = {};
  try {
    let returnData = await OrderModel.findOneAndUpdate(
      { _id: order_id },
      {
        $set: {
          order_status,
          is_handover,
        },
      },
      { new: true }
    );

    if (returnData) {
      let rest_id = returnData.branch_id;
      let order_id = returnData._id;
      let zone_id = returnData.zone_id;
      const rest_details = await RestaurentModel.findById(rest_id, {
        name: 1,
        location: 1,
      });
      let rest_name = rest_details.name;
      let rest_lat = parseFloat(rest_details.location.coordinates[1]);
      let rest_long = parseFloat(rest_details.location.coordinates[0]);
      if (returnData.order_status === "accepted") {
        await autoRouting(order_id, zone_id, rest_name, rest_lat, rest_long);
        let user_data = await Send_Queue(
          "main_user_request",
          "restaurant_queue",
          { _id: returnData.customer_id },
          "UserModel",
          "get"
        );
        if (user_data.data) {
          let message = {
            notification: {
              title: "Your order has been accepted.",
              body: "Click & track your order",
            },
            data: {
              screenType: "order",
            },
            token: user_data.data.device_id,
          };
          let push_noti = await sendNotifications(message);
        }
      }
      let order_status_history = {
        order_id: order_id,
        order_status_name: returnData.order_status,
        latitude: rest_lat,
        longitude: rest_long,
        created_by: req.body.id,
        updated_by: req.body.id,
      };

      console.log("order_status_history", order_status_history);
      await Send_Queue(cms_queue, "restaurant_queue", returnData, "order", "edit");
      await Send_Queue(
        "main_rider_request",
        "restaurant_queue",
        order_status_history,
        "OrderStatusHistory",
        "add"
      );

      results = {
        status: 1,
        msg: "Order status has been successfully updated",
      };
    } else {
      results = {
        status: -1,
        msg: "No Order Found",
      };
    }
    return res.json(results);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ status: -1, msg: "Server error", err: err.toString() });
  }
}
