import { Send_Queue } from "../../helper/common/RMQ.js";
import moment from "moment";
import { SYSTEM_TIMEZONE } from "../../consts/defaults.js";

import RestaurantUser from "../../models/RestaurantUser/RestaurantUser.js";
const cms_queue = process.env.CMS_QUEUE_NAME;

import * as crypto from "crypto";

import Order from "../../models/Order/Order.js";
import Category from "../../models/Restaurant/Category.js";
import Menu from "../../models/Restaurant/Menu.js";
import { generateToken } from "../../utility/functions.js";
import Role from "../../models/RestaurantUser/Role.js";
import RevokedToken from "../../models/RevokedToken.js";
import ParentRestaurant from "../../models/Restaurant/ParentRestaurant.js";
import RestaurentModel from "../../models/Restaurant/RestaurentModel.js";
import SystemOption from "../../models/Faq & Setting/SystemOption.js";

async function verifyPassword(password, passwordHash, passwordSalt) {
  try {
    const hmac = crypto.createHmac("sha512", passwordSalt);
    const computedHash = hmac.update(password).digest();
    const isMatch = Buffer.compare(computedHash, passwordHash) === 0;
    return isMatch;
  } catch (error) {
    console.error("Error verifying password:", error);
    throw error;
  }
}

export async function login(req, res, next) {
  const { email, password, device_id, web_device_id } = req.body;
  let results = {},
    roles,
    res_id,
    res_name,
    res_details;

  try {
    const user = await RestaurantUser.findOne({ email });

    if (!user) {
      return res.status(200).json({ status: -1, msg: "Invalid email or password" });
    }

    const passwordSalt = Buffer.from(user.password_salt.substring(2), "hex");
    const passwordHash = Buffer.from(user.password_hash.substring(2), "hex");

    const isValidPassword = await verifyPassword(password, passwordHash, passwordSalt);

    if (isValidPassword) {
      const updateUser = await RestaurantUser.updateOne(
        { _id: user._id },
        {
          $set: {
            device_id: device_id,
            web_device_id: web_device_id,
          },
        }
      );
      if (user.role_id) {
        roles = await Role.findById(user.role_id, { _id: 1, name: 1 });
        if (roles.name === "branch_admin") {
          res_details = await RestaurentModel.findOne(
            { branch_admin: user._id },
            { _id: 1, name: 1 }
          );
        }
      }
      let uu_data = {
        token: await generateToken({
          id: user._id,
        }),
        user_id: user._id,
        first_name: user.first_name,
        last_name: user.last_name,
        email: user.email,
        mobile_number: user.mobile_number,
        image: user.image,
        present_address: user.present_address,
        permanent_address: user.permanent_address,
        is_active: user.is_active,
        rest_id: res_details ? res_details._id : null,
        rest_name: res_details ? res_details.name : null,
        roles,
      };
      results = {
        status: 1,
        user_data: uu_data,
      };
      return res.json(results);
    } else {
      return res.status(200).json({ status: -1, msg: "Invalid email or password" });
    }
  } catch (err) {
    console.error(err);
    return res.status(500).json({ status: -1, msg: "Server error", err: err.toString() });
  }
}

export async function performance(req, res, next) {
  const { restaurant_id, last_days } = req.body;
  let results = {};

  try {
    let returnData = await Order.getRestPerformance(restaurant_id, last_days);

    let unavailableMenu = await Menu.getUnavailableMenu(restaurant_id, last_days);

    if (returnData) {
      let unavailableMenuPer = unavailableMenu
        ? unavailableMenu.unavailableMenuPercentage
        : 0;
      returnData.unavailableMenu = unavailableMenuPer.toFixed(2) + "%";
      results = {
        status: 1,
        data: returnData,
      };
    } else {
      results = {
        status: -1,
        msg: "No Data Found",
      };
    }
    return res.json(results);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ status: -1, msg: "Server error", err: err.toString() });
  }
}

export async function logout(req, res, next) {
  try {
    let bearerHeader = req.headers["authorization"];
    if (typeof bearerHeader !== "undefined") {
      const bearer = bearerHeader.split(" ");
      const bearerToken = bearer[1];
      const revokedToken = await RevokedToken.create({
        token: bearerToken,
      });
      if (revokedToken) {
        return res.status(200).json({
          status: 1,
          msg: "Logout Successful",
        });
      } else {
        return res.status(200).json({
          status: -1,
          msg: "Something went wrong..!",
        });
      }
    } else {
      return res.status(200).json({
        status: -1,
        msg: "Something went wrong..!",
      });
    }
  } catch (err) {
    return res.status(500).json({
      status: -1,
      msg: "Server Error.",
      err: err.toString(),
    });
  }
}

export async function getSystemOption(req, res, next) {
  let results = {};

  try {
    let returnData = await SystemOption.getSystemOption();

    if (returnData) {
      results = {
        status: 1,
        data: returnData,
      };
    } else {
      results = {
        status: -1,
        msg: "No Data Found",
      };
    }
    return res.json(results);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ status: -1, msg: "Server error", err: err.toString() });
  }
}
