import Category from "../../models/Restaurant/Category";

export async function getRestaurantCategory(req, res, next) {
  let body = req.body;
  let results = {};

  try {
    let returnData = await Category.getRestaurantCategory(
      body.restaurant_id,
      body.limit,
      body.page
    );

    if (returnData) {
      results = {
        status: 1,
        data: returnData,
      };
    } else {
      results = {
        status: -1,
        msg: "No Data Found",
      };
    }
    return res.json(results);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ status: -1, msg: "Server error", err: err.toString() });
  }
}
