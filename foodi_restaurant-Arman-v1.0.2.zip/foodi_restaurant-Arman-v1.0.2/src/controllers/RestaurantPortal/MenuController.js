import { Send_Queue } from "../../helper/common/RMQ.js";
import moment from "moment";
import Category from "../../models/Restaurant/Category.js";
import Menu from "../../models/Restaurant/Menu.js";
import { SYSTEM_TIMEZONE } from "../../consts/defaults.js";
import { calculateDelay, reactivationQueue } from "../../helper/redis.js";
import ParentRestaurant from "../../models/Restaurant/ParentRestaurant.js";
const cms_queue = process.env.CMS_QUEUE_NAME;

export async function menuDeactivation(req, res, next) {
  const { menu_id, deactivate_option, deactivation_date } = req.body;

  try {
    let deactivationDate, is_active;

    if (deactivate_option === "unavailable_today") {
      deactivationDate = moment()
        .endOf("day")
        .add(SYSTEM_TIMEZONE.HOURS, "hours")
        .toDate();
    } else if (deactivate_option === "unavailable_till") {
      deactivationDate = moment(deactivation_date)
        .endOf("day")
        .add(SYSTEM_TIMEZONE.HOURS, "hours")
        .toDate();
    }

    const data = await Menu.findOneAndUpdate(
      { _id: menu_id },
      {
        $set: {
          is_active: false,
          deactivation_date:
            deactivate_option === "unavailable_indefinitely" ? null : deactivationDate,
          //deactivation_date: "2023-06-17T16:42:59.999+00:00",
          updated_by: req.body.id,
        },
      },
      { new: true }
    );

    if (!data) {
      return res.status(404).json({ message: "Menu not found" });
    }
    let cms_data = {
      _id: data._id,
      is_active: data.is_active,
      deactivation_date: data.deactivation_date,
      updated_at: data.updated_at,
      updated_by: data.updated_by,
    };

    await Send_Queue(cms_queue, "restaurant_queue", cms_data, "menu", "edit");

    //  Add reactivation job to the queue

    console.log("menu.deactivation_date", menu.deactivation_date);
    if (
      deactivate_option == "unavailable_today" ||
      deactivate_option == "unavailable_till"
    ) {
      await reactivationQueue.add(
        { id: menu_id, model: "Menu" },
        { delay: calculateDelay(data.deactivation_date) }
      );
    }

    return res.status(200).json({ status: 1, msg: "Menu deactivated successfully" });
  } catch (err) {
    console.log("ERROR", err.toString());
    return res
      .status(500)
      .json({ status: -1, msg: "Internal server error", err: err.toString() });
  }
}
export async function menuReactivation(req, res, next) {
  const { menu_id } = req.body;
  let cms_data;
  try {
    const data = await Menu.findOneAndUpdate(
      { _id: menu_id },
      {
        $set: {
          is_active: true,
          deactivation_date: null,
          updated_by: req.body.id,
        },
      },
      { new: true }
    );

    if (!data) {
      return res.status(404).json({ message: "Menu not found" });
    }
    let cms_data = {
      _id: data._id,
      is_active: data.is_active,
      deactivation_date: data.deactivation_date,
      updated_at: data.updated_at,
      updated_by: data.updated_by,
    };

    await Send_Queue(cms_queue, "restaurant_queue", cms_data, "menu", "edit");

    return res.status(200).json({ status: 1, msg: "Menu reactivated successfully" });
  } catch (err) {
    console.log("ERROR", err.toString());
    return res
      .status(500)
      .json({ status: -1, msg: "Internal server error", err: err.toString() });
  }
}
export async function getRestaurantMenu(req, res, next) {
  let body = req.body;
  let results = {},
    check_id;

  try {
    let role_name = body.role_name;
    if (!role_name) {
      return res.json({ status: -1, msg: "Role not found" });
    }
    check_id = body.id;
    // if (role_name === 'central_admin'){
    //     check_id=(await ParentRestaurant.findOne({central_admin:body.id},{_id:1}))._id;
    // }
    // else if(role_name === 'branch_admin'){
    //     check_id=body.id;
    // }
    //
    // return res.json({
    //     role_name,check_id
    // })
    let returnData = await Menu.getRestaurantMenu(
      body.category_id,
      check_id,
      body.limit,
      body.page
    );

    if (returnData) {
      results = {
        status: 1,
        data: returnData,
      };
    } else {
      results = {
        status: -1,
        msg: "No Data Found",
      };
    }
    return res.json(results);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ status: -1, msg: "Server error", err: err.toString() });
  }
}
export async function getRestaurantMenuSearch(req, res, next) {
  let body = req.body;
  let results = {};
  let returnData;
  const { restaurant_id, search_query, unavailable, limit, page } = body;

  try {
    returnData = await Category.getRestaurantMenuSearch(
      restaurant_id,
      search_query,
      unavailable,
      limit,
      page
    );

    if (returnData) {
      results = {
        status: 1,
        data: returnData,
      };
    } else {
      results = {
        status: -1,
        msg: "No Data Found",
      };
    }
    return res.json(results);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ status: -1, msg: "Server error", err: err.toString() });
  }
}
