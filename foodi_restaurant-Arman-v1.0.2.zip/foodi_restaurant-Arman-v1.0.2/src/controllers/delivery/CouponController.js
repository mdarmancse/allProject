import SaveVoucher from "../../models/Coupon/SaveVoucher.js";

import {
  GetPoint,
  GetRewardsVoucher,
  GetUserCouponList,
} from "../../helper/Restaurant/GetCoupon.js";
import { couponBasicRules, validator } from "../../helper/validator.js";
import { coupon_val_check, get_point } from "../../helper/common/Calculation.js";
import VoucherSetting from "../../models/Rewards/VoucherSetting.js";
import EarnBurnHistory from "../../models/Rewards/EarnBurnHistory.js";
import CouponModel from "../../models/Coupon/CouponModel.js";
import CustomerCoupon from "../../models/Coupon/CustomerCoupon.js";
import { Send_Central, Send_Queue } from "../../helper/common/RMQ.js";
import RewardLevel from "../../models/Rewards/RewardLevel.js";
import VoucherRequest from "../../models/Rewards/VoucherRequest.js";
import { CreateService } from "../../helper/common/CRUD.js";
const cms_queue = process.env.CMS_QUEUE_NAME;
//create
export async function save_voucher(req, res, next) {
  let body = req.body;
  let rules = couponBasicRules;
  let error;
  let coupons;
  let val_data = {
    customer_id: body.id,
    coupon_name: body.coupon_name,
  };
  await validator(val_data, rules, {}, (err) => {
    error = err;
  });
  if (error) {
    return res.json({
      status: -1,
      data: error,
      msg: "Validation error.",
    });
  }
  let results = {};

  //
  try {
    let coupon_name = body.coupon_name;
    coupons = await coupon_val_check(coupon_name);
    if (!coupons) {
      return res.json({
        status: -1,
        msg: "Sorry! Coupon is not available!!",
      });
    }
    if (body.id) {
      let is_saved = await SaveVoucher.findOne({
        customer_id: body.id,
        coupon_id: coupons._id,
      });
      if (is_saved) {
        return res.json({
          status: -1,
          msg: "Already Saved!",
        });
      }
    }

    let voucher_data = {
      customer_id: body.id,
      coupon_id: coupons._id,
    };
    let returnData = await SaveVoucher.create(voucher_data);
    if (returnData) {
      await Send_Queue(cms_queue, "restaurant_queue", returnData, "saved_voucher", "add");
      // await Send_Central(returnData, "saved_voucher", "add");
    }
    results = {
      status: 0,
      data: returnData,
    };
    return res.json(results);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ status: -1, msg: "Server error" });
  }
}

export async function user_coupon_list(req, res, next) {
  let results = {};
  let body = req.body;
  let customer_id = body.id;
  //
  try {
    let returnData = await GetUserCouponList(customer_id);

    if (returnData) {
      results = {
        status: 0,
        data: returnData,
      };
    } else {
      results = {
        status: -1,
        msg: "No Data Found",
      };
    }

    return res.json(results);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ status: -1, msg: "Server error" });
  }
}

//Reward Voucher List
export async function rewards_voucher_list(req, res, next) {
  let results = {};
  let body = req.body;
  let customer_id = body.id;
  //
  try {
    let returnData = await GetRewardsVoucher(customer_id);

    if (returnData) {
      //total_current_point=returnData.total_point;

      results = {
        status: 1,
        data: returnData,
      };
    } else {
      results = {
        status: -1,
        msg: "No Data Found",
      };
    }

    return res.json(results);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ status: -1, msg: "Server error" });
  }
}

//Redeem Voucher
export async function redeem_voucher(req, res, next) {
  try {
    const { id: customerId, voucher_id: voucherId } = req.body;

    const customerPoint = await GetPoint(customerId);
    console.log("customer_point", customerPoint);

    const voucherDetails = await VoucherSetting.findOne({
      is_active: true,
      _id: voucherId,
    });

    if (customerPoint <= 0 || customerPoint < voucherDetails.voucher_cost_in_point) {
      return res.json({
        status: -1,
        msg: "Sorry, you are not eligible to redeem this voucher.",
      });
    }

    if (!voucherDetails) {
      return res.json({
        status: -1,
        msg: "Sorry, this voucher is currently unavailable.",
      });
    }

    const startTime = new Date();
    const endTime = new Date(
      startTime.getTime() + voucherDetails.validity_time * 60 * 60 * 1000
    );

    let generateCoupon;

    if (voucherDetails.type === "in_app") {
      const randomString = generateRandomString(8);
      let geneateCouponData = {
        name: randomString,
        description: voucherDetails.name,
        use_limit: 1,
        start_time: startTime,
        end_time: endTime,
        created_by: customerId,
        updated_by: customerId,
      };
      await CreateService(geneateCouponData, "CouponModel");
      let CustomerCoupon = {
        customer_id: customerId,
        coupon_id: generateCoupon ? generateCoupon._id : null,
        discount_in_amount: voucherDetails.voucher_amount,
      };
      await CreateService(CustomerCoupon, "CustomerCoupon");
    } else if (voucherDetails.type === "out_app") {
      let VoucherRequest = {
        customer_id: customerId,
        voucher_id: voucherId,
        created_by: customerId,
        updated_by: customerId,
      };

      await CreateService(VoucherRequest, "VoucherRequest");
    }
    let EarnBurnHistory = {
      type: "Burn",
      voucher_id: voucherId,
      customer_id: customerId,
      point: voucherDetails.voucher_cost_in_point,
      description: voucherDetails.name,
    };
    await CreateService(EarnBurnHistory, "EarnBurnHistory");

    const results = {
      status: 0,
      msg: "Voucher redeemed successfully!",
    };

    return res.json(results);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ status: -1, msg: "Server error" });
  }
}

function generateRandomString(length) {
  const characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
  let randomString = "";
  for (let i = 0; i < length; i++) {
    randomString += characters.charAt(Math.floor(Math.random() * characters.length));
  }
  return randomString;
}
