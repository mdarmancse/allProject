import { GetCartData } from "../../helper/Restaurant/GetOrderData.js";

export async function cartAdd(req, res) {
  try {
    let body = req.body;
    let cart_update = await GetCartData(body);

    if (cart_update.status === -1) {
      return res.json({
        status: cart_update.status,
        msg: cart_update.msg,
      });
    }
    return res.json({
      status: 0,
      data: cart_update.body,
    });
  } catch (err) {
    return res.status(500).json({
      status: -1,
      msg: "Server Error occurred",
      err: err.toString(),
    });
  }
}

const _check_coupon_discount = () => {};
