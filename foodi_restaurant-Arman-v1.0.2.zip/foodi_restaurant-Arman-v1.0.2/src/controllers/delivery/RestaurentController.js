import RestaurentModel from "../../models/Restaurant/RestaurentModel.js";
import OrderModel from "../../models/Order/Order.js";
import Reviews from "../../models/Restaurant/Reviews.js";
import FavRestaurant from "../../models/Restaurant/FavRestaurant.js";
import HelpfulReview from "../../models/Restaurant/HelpfulReview.js";
import PromotionModel from "../../models/Promotion/PromotionModel.js";
import { getZone } from "../../helper/zones/GetZone.js";
import { GetReviewList } from "../../helper/Restaurant/GetReviews.js";
import GetView from "../../helper/Restaurant/GetView.js";
import GetPopularMenu from "../../helper/Restaurant/GetPopularMenu.js";
import CuisineModel from "../../models/Cuisines/CuisineModel.js";
import ListService from "../../helper/common/ListService.js";
import PopUpBanner from "../../models/Promotion/PopUpBanner.js";
import { reviewBasicRules, validator } from "../../helper/validator.js";
import { Send_Central, Send_Queue } from "../../helper/common/RMQ.js";
import { faker } from "@faker-js/faker";
import { decryptLink, generateLink } from "../../helper/common/DeepLink.js";
import crud_helper from "../../helper/common/crud_helper.js";
import CampaignModel from "../../models/Campaign/CampaignModel.js";
import { riderData, userData } from "../../helper/common/common.js";
import moment from "moment";
import { SYSTEM_TIMEZONE } from "../../consts/defaults.js";
import BrancAttributes from "../../models/BranchAttributes/BrancAttributes.js";
import axios from "axios";

const DEEPLINK_BASE_URL = process.env.DEEPLINK_BASE_URL;
const cms_queue = process.env.CMS_QUEUE_NAME;
export async function getPromotions(req, res) {
  let body = req.body;
  let zone_id = await getZone(body.lat, body.long);
  if (!zone_id) {
    return res.json({
      status: -1,
      msg: "Failed to fetch zone",
    });
  }

  if (zone_id.length < 1) {
    return res.json({
      status: -1,
      msg: "No service available for this zone.",
    });
  }
  const data = await PromotionModel.getZonePromotions(zone_id[0]._id, body.id);

  if (!data)
    return res.json({
      status: -1,
      msg: "Failed to get data.",
    });

  const new_data = data.filter((item) => {
    return item.restaurants.length > 0;
  });
  console.log("new_data", data);
  if (new_data) {
    return res.json({
      status: 0,
      data: new_data,
    });
  } else {
    return res.json({
      status: -1,
      msg: "Failed to get data.",
    });
  }
}

export async function restaurant_view(req, res, next) {
  let body = req.body;
  let results = {};
  try {
    // const menu_data=await RestaurentModel.aggregate([
    //     {$project:{name:1,_id:1}}
    // ])
    // for (const menu_key in menu_data) {
    //     const menu = menu_data[menu_key];
    //     const insertData = {
    //         message:menu.name,
    //         id:menu._id,
    //         //device_id:"123",
    //     }
    //     const response = await axios.post(`http://52.77.254.104:9200/search-indexes/foodi`, insertData);
    // }
    let getView = await GetView(body.restaurant_id, body.lat, body.long, body.id);

    if (getView) {
      const deepLink = await generateLink("restaurant", body.restaurant_id);
      getView.restaurant.deepLink = DEEPLINK_BASE_URL + deepLink;
      results = {
        status: 0,
        data: getView,
      };
    } else {
      results = {
        status: -1,
        msg: "No Data Found",
      };
    }
    return res.json(results);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ status: -1, msg: "Server error" });
  }
}

export async function getCuisines(req, res, next) {
  try {
    let body = req.body;
    /** User Input Validation */
    const rules = {
      long: "required|numeric",
      lat: "required|numeric",
    };
    let error;
    await validator(body, rules, {}, (err) => {
      error = err;
    });
    if (error) {
      return res.json({
        status: -1,
        data: error,
        msg: "Validation error.",
      });
    }
    /** User Input Validation End */

    let zone_id = await getZone(body.lat, body.long);
    if (!zone_id) {
      return res.json({
        status: -1,
        msg: "Failed to fetch zone",
      });
    }

    if (zone_id.length < 1) {
      return res.json({
        status: -1,
        msg: "No service available for this zone.",
      });
    }
    // const data = await crud_helper.findActive(CuisineModel);
    const data = await CuisineModel.getActiveCuisines(zone_id);
    if (data) {
      return res.json({
        status: 0,
        data: data,
      });
    } else {
      return res.json({
        status: -1,
        msg: "No data found",
      });
    }
  } catch (err) {
    console.error(err);
    return res.status(500).json({ status: -1, msg: "Server error" });
  }
}

export async function getAttributes(req, res, next) {
  try {
    const data = await BrancAttributes.getActiveAttributes();
    if (data.length > 0) {
      return res.json({
        status: 1,
        data: data,
      });
    } else {
      return res.json({
        status: -1,
        msg: "No data found",
      });
    }
  } catch (err) {
    console.error(err);
    return res.status(500).json({ status: -1, msg: "Server error" });
  }
}

export async function cuisine_details(req, res) {
  let body = req.body;
  /** User Input Validation */
  const rules = {
    zone_id: "required",
    cuisine_id: "required",
  };

  let error;
  await validator(body, rules, {}, (err) => {
    error = err;
  });

  if (error) {
    return res.json({
      status: -1,
      data: error,
      msg: "Validation error.",
    });
  }
  /** User Input Validation End */

  const data = await CuisineModel.getCuisineRestaurants(
    body.zone_id,
    body.id,
    body.cuisine_id
  );
  if (data.length > 0) {
    return res.json({
      status: 0,
      data: data,
    });
  } else {
    return res.json({
      status: -1,
      msg: "No data found",
    });
  }
}

export async function fetch_popupbanner(req, res, next) {
  let body = req.body;
  let results = {};
  //
  try {
    let lat = body.lat,
      long = body.long;
    let zone_id = await getZone(lat, long);
    if (!zone_id) {
      return res.json({
        status: -1,
        msg: "Failed to fetch zone",
      });
    }
    let get_data = await PopUpBanner.getPopupBanner(zone_id[0]._id);

    //let get_data=  await PopUpBanner.aggregate([match,projection]);
    if (get_data.length > 0) {
      results = {
        status: 0,
        data: get_data,
      };
    } else {
      results = {
        status: -1,
        msg: "No Data Found",
      };
    }
    return res.json(results);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ status: -1, msg: "Server error" });
  }
}

export async function restaurant_nearby_get(req, res, next) {
  let body = req.body;
  /** User Input Validation */
  const rules = {
    long: "required|numeric",
    lat: "required|numeric",
  };

  let error;
  await validator(body, rules, {}, (err) => {
    error = err;
  });

  if (error) {
    return res.json({
      status: -1,
      data: error,
      msg: "Validation error.",
    });
  }
  /** User Input Validation End */

  let zone_id = await getZone(body.lat, body.long);
  if (!zone_id) {
    return res.json({
      status: -1,
      msg: "Failed to fetch zone",
    });
  }

  if (zone_id.length < 1) {
    return res.json({
      status: -1,
      msg: "No service available for this zone.",
    });
  }

  try {
    const data = await RestaurentModel.getNearbyRestaurant(
      zone_id[0]._id,
      body.id,
      body.long,
      body.lat,
      body.limit,
      body.page
    );
    if (!data)
      return res.json({
        status: -1,
        msg: "No data found",
      });

    return res.json({
      status: 0,
      data: data,
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ status: -1, msg: "Server error" });
  }
}

export async function your_restaurant(req, res, next) {
  let body = req.body;
  /** User Input Validation */
  const rules = {
    long: "required|numeric",
    lat: "required|numeric",
  };

  let error;
  await validator(body, rules, {}, (err) => {
    error = err;
  });

  if (error) {
    return res.json({
      status: -1,
      data: error,
      msg: "Validation error.",
    });
  }
  /** User Input Validation End */

  let zone_id = await getZone(body.lat, body.long);
  if (!zone_id) {
    return res.json({
      status: -1,
      msg: "Failed to fetch zone",
    });
  }

  if (zone_id.length < 1) {
    return res.json({
      status: -1,
      msg: "No service available for this zone.",
    });
  }

  try {
    const data = await OrderModel.getYourRestaurant(
      zone_id[0]._id,
      body.id,
      body.long,
      body.lat,
      body.limit,
      body.page
    );
    if (!data)
      return res.json({
        status: -1,
        msg: "No data found",
      });

    return res.json({
      status: 0,
      data: data,
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ status: -1, msg: "Server error" });
  }
}
export async function favourite_restaurant(req, res, next) {
  let body = req.body;
  /** User Input Validation */
  const rules = {
    long: "required|numeric",
    lat: "required|numeric",
    id: "required",
  };

  let error;
  await validator(body, rules, {}, (err) => {
    error = err;
  });

  if (error) {
    return res.json({
      status: -1,
      data: error,
      msg: "Validation error.",
    });
  }
  /** User Input Validation End */

  let zone_id = await getZone(body.lat, body.long);
  if (!zone_id) {
    return res.json({
      status: -1,
      msg: "Failed to fetch zone",
    });
  }

  if (zone_id.length < 1) {
    return res.json({
      status: -1,
      msg: "No service available for this zone.",
    });
  }

  try {
    const data = await FavRestaurant.getFavouriteRestaurant(
      zone_id[0]._id,
      body.id,
      body.long,
      body.lat,
      body.limit,
      body.page
    );
    if (data.length > 0) {
      return res.json({
        status: 0,
        data: data,
      });
    } else {
      return res.json({
        status: -1,
        msg: "No data found",
      });
    }
  } catch (err) {
    console.error(err);
    return res.status(500).json({ status: -1, msg: "Server error" });
  }
}

export async function restaurant_popular_get(req, res, next) {
  let body = req.body;
  /** User Input Validation */
  const rules = {
    long: "required|numeric",
    lat: "required|numeric",
  };

  let error;
  await validator(body, rules, {}, (err) => {
    error = err;
  });

  if (error) {
    return res.json({
      status: -1,
      data: error,
      msg: "Validation error.",
    });
  }
  /** User Input Validation End */

  let zone_id = await getZone(body.lat, body.long);
  if (!zone_id) {
    return res.json({
      status: -1,
      msg: "Failed to fetch zone",
    });
  }

  if (zone_id.length < 1) {
    return res.json({
      status: -1,
      msg: "No service available for this zone.",
    });
  }

  try {
    const data = await RestaurentModel.getPopularRestaurants(
      zone_id[0]._id,
      body.id,
      body.long,
      body.lat,
      body.limit,
      body.page
    );
    if (!data)
      return res.json({
        status: -1,
        msg: "No data found",
      });

    return res.json({
      status: 0,
      data: data,
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ status: -1, msg: "Server error" });
  }
}

export async function get_review_rating(req, res, next) {
  let body = req.body;
  let results = {};
  //
  try {
    let get_data = await GetReviewList(
      body.restaurant_id,
      body.sort_by,
      body.limit,
      body.page
    );

    if (get_data.length > 0) {
      results = {
        status: 0,
        data: get_data[0],
      };
    } else {
      results = {
        status: -1,
        msg: "No Data Found",
      };
    }
    return res.json(results);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ status: -1, msg: "Server error" });
  }
}

//Add Review
export async function add_review(req, res, next) {
  let body = req.body;
  let rules = reviewBasicRules;
  let error;
  await validator(body, rules, {}, (err) => {
    error = err;
  });
  if (error) {
    return res.json({
      status: -1,
      data: error,
      msg: "Validation error.",
    });
  }

  let results = {};

  try {
    let user_data, rider_data, rider_name;
    user_data = await userData(body.id);
    if (!user_data) {
      return res.json({
        status: -1,
        msg: "Customer not found!",
      });
    }

    let customer_name = user_data.firstName + " " + user_data.lastName;

    if (body.rider_id) rider_data = await riderData(body.rider_id);
    if (rider_data) rider_name = rider_data.first_name + " " + rider_data.last_name;

    if (!customer_name) {
      return res.json({
        status: -1,
        msg: "Failed to add",
      });
    }

    let reviews = await Reviews.findOneAndUpdate(
      { order_id: body.order_id },
      {
        $set: {
          rest_id: body.rest_id,

          order_id: body.order_id,

          user_id: body.id,
          name: customer_name,
          rider_name: rider_name,
          rating: body.rating,
          review: body.review,

          rider_id: body.rider_id,
          rider_rating: body.rider_rating,
          rider_review: body.rider_review,

          created_by: body.id,
          updated_by: body.id,
        },
      },
      {
        upsert: true,
        new: true,
        setDefaultsOnInsert: true,
        rawResult: true,
      }
    );
    if (reviews && reviews.lastErrorObject.updatedExisting == false) {
      await Send_Queue(cms_queue, "restaurant_queue", reviews.value, "review", "add");
      //   await Send_Central(cart_update, "cart", "add");
      console.log("Document Inserted");
    }
    if (reviews && reviews.lastErrorObject.updatedExisting == true) {
      await Send_Queue(cms_queue, "restaurant_queue", reviews.value, "review", "edit");
      //await Send_Central(cart_update, "cart", "edit");
      console.log("Document Updated");
    }

    if (reviews.value) {
      results = {
        status: 0,
        msg: "Thanks for your important feedback!",
      };
    }

    return res.json(results);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ status: -1, msg: "Server error" });
  }
}

//Add/remove helpful
export async function add_helpful(req, res, next) {
  let results = {},
    helpful_count,
    return_data;
  let body = req.body;
  try {
    let rules = { review_id: "required", id: "required" };
    let error;
    await validator(body, rules, {}, (err) => {
      error = err;
    });
    if (error) {
      return res.json({
        status: -1,
        data: error,
        msg: "Validation error.",
      });
    }
    let data = await HelpfulReview.findOne({
      customer_id: body.id,
      review_id: body.review_id,
    });

    if (data) {
      return_data = await HelpfulReview.deleteOne({
        _id: data._id,
      });
      if (return_data) {
        await Send_Queue(
          cms_queue,
          "restaurant_queue",
          { _id: data._id },
          "helpful_review",
          "delete"
        );
        //  await Send_Central({ _id: data._id }, "helpful_review", "delete");
        helpful_count = await HelpfulReview.count({ review_id: body.review_id });
      }
      results = {
        status: 0,
        is_helpful: 0,
        message: "Remove from helpful",
        helpful_count: helpful_count,
      };
    } else {
      let body_data = {
        customer_id: body.id,
        review_id: body.review_id,
      };
      return_data = await HelpfulReview.create(body_data);
      if (return_data) {
        await Send_Queue(
          cms_queue,
          "restaurant_queue",
          return_data,
          "helpful_review",
          "add"
        );
        // await Send_Central(return_data, "helpful_review", "add");
        helpful_count = await HelpfulReview.count({ review_id: body.review_id });
      }
      results = {
        status: 1,
        is_helpful: 1,
        message: "Added to helpful",
        helpful_count: helpful_count,
      };
    }
    return res.json(results);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ status: -1, msg: "Server error" });
  }
}

//Favourite Restaurant
export async function add_favourite_rest(req, res, next) {
  let body = req.body;
  let results = {};

  try {
    let data = await FavRestaurant.findOne({
      customer_id: body.id,
      branch_id: body.branch_id,
      is_delivery: true,
    });

    if (data) {
      await FavRestaurant.deleteOne({
        _id: data._id,
      });
      await Send_Queue(
        cms_queue,
        "restaurant_queue",
        { _id: data._id },
        "favourite_branch",
        "delete"
      );
      //  await Send_Central({ _id: data._id }, "favourite_branch", "delete");
      results = {
        status: 0,
        is_favourite: 0,
        message: "Remove from favourite",
      };
    } else {
      let body_data = {
        customer_id: body.id,
        branch_id: body.branch_id,
        is_delivery: true,
      };
      let return_data = await FavRestaurant.create(body_data);
      if (return_data) {
        await Send_Queue(
          cms_queue,
          "restaurant_queue",
          return_data,
          "favourite_branch",
          "add"
        );
        // await Send_Central(return_data, "favourite_branch", "add");
      }
      results = {
        status: 1,
        is_favourite: 1,
        message: "Added to favourite",
      };
    }
    return res.json(results);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ status: -1, msg: "Server error" });
  }
}
// Restaurant Popular Menu
export async function popular_menu(req, res, next) {
  let body = req.body;
  let results = {};

  try {
    let getData = await GetPopularMenu(body.restaurant_id);

    if (getData) {
      results = {
        status: 0,
        data: getData,
      };
    } else {
      results = {
        status: -1,
        msg: "No Data Found",
      };
    }

    return res.json(results);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ status: -1, msg: "Server error" });
  }
}

export async function decrypt_deep_link(req, res, next) {
  let body = req.body;
  let results = {};
  try {
    /**Zone validation start*/
    let zone_id = await getZone(body.lat, body.long);
    if (!zone_id) {
      return res.json({
        status: -1,
        msg: "Failed to fetch zone",
      });
    }

    if (zone_id.length < 1) {
      return res.json({
        status: -1,
        msg: "No service available for this zone.",
      });
    }
    /**Zone validation end */

    const link = body.link.split("/");
    const deep_link = link[3];
    const decryptedLink = await decryptLink(deep_link);

    if (decryptedLink.type === "restaurant") {
      /**Restaurant validation start */
      // Zone check
      const res_zone_check = await crud_helper.findActive(RestaurentModel, {
        _id: decryptedLink.id,
        "zone_id._id": zone_id[0]._id,
      });

      if (res_zone_check.length === 0) {
        return res.json({
          status: -1,
          msg: "Restaurant unavailable",
        });
      }
    }
    if (decryptedLink.type === "campaign") {
      let campaign = await CampaignModel.aggregate([
        {
          $match: {
            _id: decryptedLink.id,
            is_active: true,
            start_date: {
              $lte: moment()
                .add(SYSTEM_TIMEZONE.HOURS, "hours")
                .add(SYSTEM_TIMEZONE.MINUTES, "minutes")
                .toDate(),
            },
            end_date: {
              $gte: moment()
                .add(SYSTEM_TIMEZONE.HOURS, "hours")
                .add(SYSTEM_TIMEZONE.MINUTES, "minutes")
                .toDate(),
            },
          },
        },
      ]);
      if (campaign.length === 0) {
        return res.json({
          status: -1,
          msg: "Campaign is not available now!",
        });
      }
    }

    if (decryptedLink) {
      results = {
        status: 0,
        data: decryptedLink,
      };
    } else {
      results = {
        status: -1,
        msg: "No Data Found",
      };
    }
    return res.json(results);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ status: -1, msg: "Server error" });
  }
}

export async function rest_seeder(req, res) {
  let body = req.body;
  let results = {};
  let numOfSeeds = 10000;
  try {
    await Reviews.deleteMany({});
    // const seeds = [];
    // for (let i = 0; i < numOfSeeds; i++) {
    //   const data = new Reviews({
    //     rest_id: '63d51aac1066d4536ef632d5',
    //     user_id: '7bc620b4a20241088227a9f4c0be92a9',
    //     review: faker.lorem.sentences(),
    //     name: faker.name.fullName(),
    //     order_id: faker.datatype.uuid(),
    //     rating: faker.datatype.number({min: 1, max: 5}),
    //     is_active: faker.datatype.boolean(),
    //     created_by: faker.datatype.uuid(),
    //     updated_by: faker.datatype.uuid(),
    //   });
    //   seeds.push(data);
    // }
    // await Reviews.insertMany(seeds);
    results = {
      status: 0,
      msg: `Successfully seeded ${numOfSeeds} data!`,
    };
    //process.exit(1);
    console.log(`Successfully seeded ${numOfSeeds} data!`);
  } catch (err) {
    console.error(`Error while seeding data: ${err.message}`);
    process.exit(1);
    results = {
      status: -1,
      msg: `Error while seeding data: ${err.message}`,
    };
  }

  return res.json(results);
}

export async function get_zone(req, res, next) {
  let body = req.body;
  let results = {};
  /** User Input Validation */
  // const rules = {
  //     long: "required|numeric",
  //     lat: "required|numeric",
  // };
  // let error;
  // await validator(body, rules, {}, (err) => {
  //     error = err;
  // });
  // if (error) {
  //     return res.json( {
  //         status: -1,
  //         data: error,
  //         msg: "Validation error.",
  //     });
  // }

  try {
    let getData = await getZone(body.lat, body.long);

    if (getData.length > 0) {
      results = {
        status: 0,
        data: getData[0],
      };
    } else {
      results = {
        status: -1,
        msg: "No Data Found",
      };
    }

    return res.json(results);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ status: -1, msg: "Server error" });
  }
}

// const client = new Client({
//     node: 'http://54.179.110.123:9200',
//     sniffOnStart:false,
//     ssl: {
//         rejectUnauthorized: false
//     }
// });

// client.info()
//     .then(response => {
//         console.log(response);
//     })
//     .catch(error => {
//         console.error(error);
//     });
//
// const createIndex = async (indexName) => {
//     try {
//         const { body: exists } = await client.indices.exists({ index: indexName });
//
//         if (exists) {
//             console.log(`Index '${indexName}' already exists`);
//             return;
//         }
//
//         const { body: created } = await client.indices.create({ index: indexName });
//
//         if (created) {
//             console.log(`Index '${indexName}' created`);
//         }
//     } catch (error) {
//         console.error(error);
//     }
// };
//
// createIndex('my_index');
// client.search({
//     index: 'game-of-thrones',
// }, (err, result) => {
//     console.log("result",result)
//     if (err) console.log(err)
// })
