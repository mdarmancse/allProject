import crud_helper from "../../helper/common/crud_helper.js";
import { getZone } from "../../helper/zones/GetZone.js";
import RestaurentModel from "../../models/Restaurant/RestaurentModel.js";
import OrderModel from "../../models/Order/Order.js";
import {
  GetCartData,
  GetOngoingOrder,
  GetOrderData,
  GetOrderDetails,
  GetUserOrderList,
} from "../../helper/Restaurant/GetOrderData.js";
import { orderBasicRules, validator } from "../../helper/validator.js";
import {
  coupon_val_check,
  DeliveryCharge,
  get_point,
} from "../../helper/common/Calculation.js";
// import {redis_get, redis_set} from "../../helper/redis.js";
import Order from "../../models/Order/Order.js";
import CustomerCoupon from "../../models/Coupon/CustomerCoupon.js";
import BranchCoupon from "../../models/Coupon/BranchCoupon.js";
import ZoneCoupon from "../../models/Coupon/ZoneCoupon.js";
import CuisineCoupon from "../../models/Coupon/CuisineCoupon.js";
import GradualInformation from "../../models/Coupon/GradualInformation.js";
import CategoryCoupon from "../../models/Coupon/CategoryCoupon.js";
import MenuItemCoupon from "../../models/Coupon/MenuItemCoupon.js";
import moment from "moment";
import { Send_Central, Send_Queue } from "../../helper/common/RMQ.js";
import AppliedCoupon from "../../models/Order/AppliedCoupon.js";
import EarnBurnHistory from "../../models/Rewards/EarnBurnHistory.js";
import SubscriptionTypeCoupon from "../../models/Coupon/SubscriptionTypeCoupon.js";
import { riderOrderCount, userData } from "../../helper/common/common.js";
import { orderQueue, redis_get, redis_get_all, redis_set } from "../../helper/redis.js";
import Queue from "bull";
import Zone from "../../models/Zone/Zone.js";
import SystemOption from "../../models/Faq & Setting/SystemOption.js";
import CouponModel from "../../models/Coupon/CouponModel.js";
import { v4 as uuidv4 } from "uuid";
import {
  sendMuiltiNotifications,
  sendNotifications,
} from "../../helper/common/Notifications.js";
import RestaurantUser from "../../models/RestaurantUser/RestaurantUser.js";

const cms_queue = process.env.CMS_QUEUE_NAME;
const portal_url = process.env.PORTAL_URL;

export async function add_order(req, res) {
  try {
    const system_options = await SystemOption.getSystemOption();
    const SYSTEM_MAX_ORDER_VALUE = JSON.parse(system_options.max_order_value);
    const SYSTEM_MIN_ORDER_VALUE = JSON.parse(system_options.min_order_value);
    const SYSTEM_ORDER_VERIFICATION_VALUE = JSON.parse(
      system_options.order_verification_max_amount
    );

    let body = req.body;
    let {
      address,
      instruction,
      payment_method_id,
      restaurant_id,
      lat,
      long,
      menu_data,
      coupon_name,
    } = req.body;
    const user_id = body.id;
    let is_verified = true;
    let rules,
      user_data,
      subscription_type_id,
      customer_mobile,
      customer_name,
      applied_coupon_add,
      min_order_value,
      push_noti,
      device_ids;
    let applied_coupons = [];
    rules = orderBasicRules;
    user_data = await userData(user_id);
    if (!user_data) {
      return res.json({
        status: -1,
        msg: "Customer not found!",
      });
    }
    subscription_type_id = user_data.subscription_type_id;
    customer_mobile = user_data.mobile;
    customer_name = user_data.firstName + " " + user_data.lastName;

    let error = "",
      coupon_id = " ",
      wise_coupon_check,
      total = 0,
      total_vat = 0,
      total_sd = 0,
      discount = 0,
      grand_total = 0,
      sub_total_with_vat_sd = 0,
      discount_amount = 0,
      discount_in_percent = 0,
      rewards_point = 0,
      rewards_cost = 0,
      delivery_time = 0,
      rest_cust_duration = 0,
      delivery_charge = 0;

    //Required Validation
    await validator(body, rules, {}, (err) => {
      error = err;
    });
    if (error) {
      return res.json({
        status: -1,
        data: error,
        msg: "Validation error.",
      });
    }
    /**Zone validation start*/
    let zone_id = await getZone(body.lat, body.long);
    if (!zone_id) {
      return res.json({
        status: -1,
        msg: "Failed to fetch zone",
      });
    }

    if (zone_id.length < 1) {
      return res.json({
        status: -1,
        msg: "No service available for this zone.",
      });
    }
    /**Zone validation end */

    /**Restaurant validation start */

    // Zone check
    const res_zone_check = await crud_helper.findActive(RestaurentModel, {
      _id: restaurant_id,
      "zone_id._id": zone_id[0]._id,
    });

    if (res_zone_check.length === 0) {
      return res.json({
        status: -1,
        msg: "Restaurant deactivated or deleted or working hours ends",
      });
    }

    let rest_lat = parseFloat(res_zone_check[0].location.coordinates[1]);
    let rest_long = parseFloat(res_zone_check[0].location.coordinates[0]);
    min_order_value = res_zone_check[0].min_order_value;

    //delivery Charge Calculate
    let distance_data = await DeliveryCharge(
      zone_id[0]._id,
      rest_lat,
      rest_long,
      lat,
      long
    ); //TODO: need to change it when zone wise delivery charge is added
    if (distance_data.delivery_charge > 0) {
      delivery_charge = distance_data.delivery_charge;
    } else {
      return res.json({
        status: -1,
        msg: "Sorry..! Delivery unavailable in this area.",
      });
    }

    let order_data = await GetOrderData(restaurant_id, menu_data);

    if (order_data.length === 0) {
      return res.json({
        status: -1,
        msg: "Sorry,no menus are currently available !",
      });
    }

    const sum_data = order_data.reduce(
      (ac, cur) => {
        ac.total_item_total += cur.item_total ? cur.item_total : 0;
        ac.total_sd += cur.item_sd ? cur.item_sd : 0;
        ac.total_vat += cur.item_vat ? cur.item_vat : 0;
        ac.highest_recipe_time = Math.max(ac.highest_recipe_time, cur.recipe_time);
        return ac;
      },
      { total_item_total: 0, total_sd: 0, total_vat: 0, highest_recipe_time: 0 }
    );

    console.log(sum_data.highest_recipe_time);
    total = sum_data.total_item_total;
    total_sd = sum_data.total_sd;
    total_vat = sum_data.total_vat;
    rest_cust_duration = Math.round(distance_data.duration / 60);
    if (total < SYSTEM_MIN_ORDER_VALUE) {
      return {
        status: -1,
        msg: `Sorry..! Your food price should be greater than ${SYSTEM_MIN_ORDER_VALUE}`,
      };
    }
    if (total < min_order_value) {
      return {
        status: -1,
        msg: `Sorry..! Your food price should be greater than ${min_order_value}`,
      };
    }
    if (SYSTEM_MAX_ORDER_VALUE < total) {
      return {
        status: -1,
        msg: `Sorry..! Your food price should be less than ${SYSTEM_MAX_ORDER_VALUE}`,
      };
    }
    if (total > SYSTEM_ORDER_VERIFICATION_VALUE) {
      is_verified = false;
    }

    if (distance_data.duration) {
      delivery_time += rest_cust_duration;
      delivery_time += sum_data.highest_recipe_time ? sum_data.highest_recipe_time : 15;
      delivery_time += res_zone_check[0]["delivery_time"];
    }

    console.log("delivery_time", delivery_time);

    if (coupon_name) {
      if (typeof coupon_name === "string") {
        coupon_name = [coupon_name];
      }

      if (Array.isArray(coupon_name) && coupon_name.length > 0) {
        for (let i = 0; i < coupon_name.length; i++) {
          let c_name = coupon_name[i].toUpperCase();
          let coupon_check = await coupon_val_check(c_name);
          if (coupon_check) {
            coupon_id = coupon_check._id;

            let coupon_count = await Order.find({
              coupon_id: coupon_id,
              customer_id: body.id,
            }).count();

            if (coupon_count > coupon_check.use_limit) {
              body.coupon_msg = coupon_name[i] + " limit is over!";
            } else {
              let get_coupon_type = coupon_check.coupon_type_name;
              let minimum_order_amount = coupon_check.minimum_order_amount;
              let diff = minimum_order_amount - total;

              if (minimum_order_amount >= total) {
                //Check Min order value
                body.coupon_msg = "Add TK " + diff + " to use this voucher";
              } else {
                //Check type wise validation
                if (get_coupon_type === "user_wise") {
                  wise_coupon_check = await CustomerCoupon.findOne({
                    customer_id: body.id,
                    coupon_id: coupon_id,
                  });
                  if (wise_coupon_check) {
                    // if (coupon_check.maximum_discount_amount)
                    discount_amount += coupon_check.is_percent
                      ? (parseFloat(coupon_check.discount_in_percent) / 100) * total
                      : parseFloat(coupon_check.discount_in_amount);
                    discount_in_percent = coupon_check.discount_in_percent;
                    if (discount > coupon_check.maximum_discount_amount) {
                      discount_amount = coupon_check.maximum_discount_amount;
                    } else {
                      discount_amount = discount_amount;
                    }
                  } else {
                    body.coupon_msg = coupon_name[i] + " is not available for you!";
                  }
                } else if (get_coupon_type === "branch_wise") {
                  wise_coupon_check = await BranchCoupon.findOne({
                    branch_id: restaurant_id,
                    coupon_id: coupon_id,
                  });
                  // return wise_coupon_check;
                  if (wise_coupon_check) {
                    discount_amount += coupon_check.is_percent
                      ? (parseFloat(coupon_check.discount_in_percent) / 100) * total
                      : parseFloat(coupon_check.discount_in_amount);
                    discount_in_percent = coupon_check.discount_in_percent;
                    if (discount > coupon_check.maximum_discount_amount) {
                      discount_amount = coupon_check.maximum_discount_amount;
                    } else {
                      discount_amount = discount_amount;
                    }
                  } else {
                    body.coupon_msg =
                      coupon_name[i] + " is not available for this restaurant!";
                  }
                } else if (get_coupon_type === "zone_wise") {
                  wise_coupon_check = await ZoneCoupon.findOne({
                    zone_id: zone_id,
                    coupon_id: coupon_id,
                  });
                  // return wise_coupon_check;
                  if (wise_coupon_check) {
                    discount_amount += coupon_check.is_percent
                      ? (parseFloat(coupon_check.discount_in_percent) / 100) * total
                      : parseFloat(coupon_check.discount_in_amount);
                    discount_in_percent = coupon_check.discount_in_percent;
                    if (discount > coupon_check.maximum_discount_amount) {
                      discount_amount = coupon_check.maximum_discount_amount;
                    } else {
                      discount_amount = discount_amount;
                    }
                  } else {
                    body.coupon_msg = coupon_name[i] + " is not available in this zone!";
                  }
                } else if (get_coupon_type === "cuisine_wise") {
                  wise_coupon_check = await CuisineCoupon.aggregate([
                    {
                      $match: {
                        coupon_id: coupon_id,
                        cuisine_id: {
                          $in: cuisines ? cuisines.map((cs) => cs.cuisine_id) : [],
                        },
                      },
                    },
                  ]);
                  // return wise_coupon_check;
                  if (wise_coupon_check) {
                    discount_amount += coupon_check.is_percent
                      ? (parseFloat(coupon_check.discount_in_percent) / 100) * total
                      : parseFloat(coupon_check.discount_in_amount);
                    discount_in_percent = coupon_check.discount_in_percent;
                    if (discount > coupon_check.maximum_discount_amount) {
                      discount_amount = coupon_check.maximum_discount_amount;
                    } else {
                      discount_amount = discount_amount;
                    }
                  } else {
                    body.coupon_msg =
                      coupon_name[i] + " is not available for this cuisine!";
                  }
                } else if (get_coupon_type === "gradual_wise") {
                  let grad_coupon_count = await Order.find({
                    branch_id: restaurant_id,
                    coupon_id: coupon_id,
                    customer_id: body.id,
                  }).count();

                  wise_coupon_check = await GradualInformation.findOne({
                    coupon_id: coupon_id,
                  }).sort({ _id: -1 });

                  if (wise_coupon_check) {
                    let sequence = wise_coupon_check.sequence;
                    let new_seq = grad_coupon_count + 1;
                    if (sequence == new_seq) {
                      discount_amount += coupon_check.is_percent
                        ? (parseFloat(coupon_check.discount_in_percent) / 100) * total
                        : parseFloat(coupon_check.discount_in_amount);
                      discount_in_percent = coupon_check.discount_in_percent;
                      if (discount > coupon_check.maximum_discount_amount) {
                        discount_amount = coupon_check.maximum_discount_amount;
                      } else {
                        discount_amount = discount_amount;
                      }
                    } else {
                      body.coupon_msg = coupon_name[i] + " is not available for you!";
                    }
                  } else {
                    body.coupon_msg = coupon_name[i] + " is not available for you!";
                  }
                } else if (get_coupon_type === "category_wise") {
                  for (const order_data_key in order_data) {
                    const menu = order_data[order_data_key];
                    console.log("menud", menu);
                    wise_coupon_check = await CategoryCoupon.findOne({
                      category_id: menu.category_id,
                      coupon_id: coupon_id,
                    });
                    console.log("wise_coupon_check", wise_coupon_check);
                    if (wise_coupon_check) {
                      discount_amount += coupon_check.is_percent
                        ? (parseFloat(coupon_check.discount_in_percent) / 100) *
                          menu.item_total
                        : parseFloat(coupon_check.discount_in_amount);
                      discount_in_percent = coupon_check.discount_in_percent;
                      if (discount > coupon_check.maximum_discount_amount) {
                        discount_amount = coupon_check.maximum_discount_amount;
                      } else {
                        discount_amount = discount_amount;
                      }
                      //   discount_type = coupon_check.is_percent ? "percent" : "amount";
                    }

                    if (discount <= 0) {
                      body.coupon_msg = coupon_name[i] + " is not available!";
                    }
                  }
                } else if (get_coupon_type === "menu_item_wise") {
                  for (const order_data_key in order_data) {
                    const menu = order_data[order_data_key];
                    console.log("menud", menu);
                    wise_coupon_check = await MenuItemCoupon.findOne({
                      menu_item_id: menu._id,
                      coupon_id: coupon_id,
                    });
                    console.log("wise_coupon_check", wise_coupon_check);
                    if (wise_coupon_check) {
                      discount_amount += coupon_check.is_percent
                        ? (parseFloat(coupon_check.discount_in_percent) / 100) *
                          menu.item_total
                        : parseFloat(coupon_check.discount_in_amount);
                      discount_in_percent = coupon_check.discount_in_percent;
                      if (discount > coupon_check.maximum_discount_amount) {
                        discount_amount = coupon_check.maximum_discount_amount;
                      } else {
                        discount_amount = discount_amount;
                      }
                      //   discount_type = coupon_check.is_percent ? "percent" : "amount";
                    }
                  }

                  if (discount <= 0) {
                    body.coupon_msg = coupon_name[i] + " is not available!";
                  }
                } else if (get_coupon_type === "subscription_wise") {
                  wise_coupon_check = await SubscriptionTypeCoupon.findOne({
                    subscription_type_id: subscription_type_id,
                    coupon_id: coupon_id,
                  });
                  // return wise_coupon_check;
                  if (wise_coupon_check) {
                    discount_amount += coupon_check.is_percent
                      ? (parseFloat(coupon_check.discount_in_percent) / 100) * total
                      : parseFloat(coupon_check.discount_in_amount);
                    discount_in_percent = coupon_check.discount_in_percent;
                    if (discount > coupon_check.maximum_discount_amount) {
                      discount_amount = coupon_check.maximum_discount_amount;
                    } else {
                      discount_amount = discount_amount;
                    }
                  } else {
                    body.coupon_msg = coupon_name[i] + " is not available in this zone!";
                  }
                } else {
                  discount_amount += coupon_check.is_percent
                    ? (parseFloat(coupon_check.discount_in_percent) / 100) * total
                    : parseFloat(coupon_check.discount_in_amount);
                  discount_in_percent = coupon_check.discount_in_percent;
                  if (discount > coupon_check.maximum_discount_amount) {
                    discount_amount = coupon_check.maximum_discount_amount;
                  } else {
                    discount_amount = discount_amount;
                  }
                }
              }

              applied_coupons.push({
                coupon_id: coupon_id,
                coupon_name: coupon_name[i],
                branch_id: restaurant_id,
                customer_id: user_id,
                percent: coupon_check.discount_in_percent,
                amount: coupon_check.discount_in_amount,
                created_by: user_id,
                updated_by: user_id,
              });
              applied_coupon_add = await AppliedCoupon.insertMany(applied_coupons);
              console.log(applied_coupon_add);
            }
          } else {
            body.coupon_msg = coupon_name[i] + " is not available!";
          }
        }
      }
    }
    sub_total_with_vat_sd = total + total_vat + total_sd;

    grand_total = total + total_sd + total_vat + delivery_charge - discount_amount;

    const order_place = await OrderModel.create({
      customer_id: user_id,
      branch_id: restaurant_id,
      payment_method_id: payment_method_id,
      customer_name: customer_name,
      customer_mobile: customer_mobile,
      address: address,
      instruction: instruction,
      coupon_id: coupon_id,
      total_amount: grand_total,
      sub_total: sub_total_with_vat_sd,
      discount_amount: discount_amount,
      discount_in_percent: discount_in_percent,
      value_added_tax_inclusive: total_vat,
      supplementary_duty: total_sd,
      delivery_charge: delivery_charge,
      order_details: order_data,
      user_lat: body.lat,
      user_long: body.long,
      zone_id: zone_id[0]._id,
      delivery_time: delivery_time ? delivery_time : 15,
      highest_recipe_time: sum_data.highest_recipe_time
        ? sum_data.highest_recipe_time
        : 15,
      avg_time: res_zone_check[0]["delivery_time"]
        ? res_zone_check[0]["delivery_time"]
        : 15,
      rest_cust_duration: rest_cust_duration,
      //order_details: null,
      order_type: "delivery",
      is_cutlery_needed: body.is_cutlery_needed,
      is_pre_order: body.is_pre_order,
      is_verified: is_verified,
      created_by: user_id,
      updated_by: user_id,
    });

    if (order_place) {
      order_place._doc.applied_coupons = applied_coupon_add ? applied_coupon_add : [];

      let order_status_history = {
        order_id: order_place._id,
        order_status_name: "placed",
        latitude: lat,
        longitude: long,
        created_by: body.id,
        updated_by: body.id,
      };

      await Send_Queue(
        "main_rider_request",
        "restaurant_queue",
        order_status_history,
        "OrderStatusHistory",
        "add"
      );

      await Send_Queue(cms_queue, "restaurant_queue", order_place, "order", "add");
    }
    //  redis_set('order_masters', order_place._id, order_place);
    if (order_place) {
      if (order_place.is_verified) {
        let rest_branch_admin = res_zone_check[0]["branch_admin"];
        let rest_central_admin = res_zone_check[0]["central_admin"];
        if (rest_branch_admin || rest_central_admin) {
          device_ids = await RestaurantUser.find(
            { _id: { $in: [rest_branch_admin, rest_central_admin] } },
            { _id: 0, device_id: 1, web_device_id: 1 }
          );
          const deviceIds = device_ids
            .filter(({ device_id }) => device_id)
            .map(({ device_id }) => device_id);
          const webDeviceIds = device_ids
            .filter(({ web_device_id }) => web_device_id)
            .map(({ web_device_id }) => web_device_id);
          const tokens = [...deviceIds, ...webDeviceIds];

          let message = {
            notification: {
              title: "You have an order,Please Accept",
              body: "Click & track your order",
            },
            data: {
              screenType: "order",
            },
            webpush: {
              fcm_options: {
                link: portal_url,
              },
            },

            tokens: tokens,
          };
          push_noti = await sendMuiltiNotifications(message);
        }
      }

      return res.json({
        status: 0,
        order_id: order_place._id,
        order_details: order_place.order_details,
        payment_method_id: order_place.payment_method_id,
        order_status: order_place.order_status,
        rider_accepted: order_place.rider_accepted,
        arrived_vendor: order_place.arrived_vendor,
        arrived_customer: order_place.arrived_customer,
        coupon_msg: body.coupon_msg,
        sub_total: order_place.sub_total.toFixed(2),
        delivery_charge: order_place.delivery_charge.toFixed(2),
        total_vat: order_place.value_added_tax_inclusive.toFixed(2),
        total_sd: order_place.supplementary_duty.toFixed(2),
        discount_amount: order_place.discount_amount.toFixed(2),
        total_amount: order_place.total_amount.toFixed(2),
        address: address,
        rest_name: res_zone_check[0]["name"],
        delivery_time: order_place.delivery_time,
        order_type: order_place.order_type,
        is_verified: order_place.is_verified,
        message: "Order Placed Successfully",
        push_noti: push_noti,
        device_ids: device_ids,
      });
    } else {
      return res.json({
        status: -1,
        msg: "Something went wrong",
      });
    }
  } catch (err) {
    return res.status(500).json({
      status: -1,
      msg: "Server error",
      err: {
        message: err.toString(),
        stack: err.stack,
      },
    });
  }
}

export async function user_order_list(req, res, next) {
  let body = req.body;
  let results = {};

  let customer_id = body.id;
  //
  try {
    let returnData = await GetUserOrderList(customer_id);
    if (returnData) {
      results = {
        status: 0,
        data: returnData,
      };
    } else {
      results = {
        status: -1,
        msg: "No Data Found",
      };
    }
    return res.json(results);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ status: -1, msg: "Server error", err: err.toString() });
  }
}

export async function order_details(req, res, next) {
  let body = req.body;
  let results = {},
    returnData,
    rider_details,
    cacheResults,
    mongoResults;
  let isCached = false;
  let isMongo = false;
  let isSql = false;
  try {
    //  cacheResults=  await redis_get('order_masters', body.order_id);
    if (cacheResults) {
      isCached = true;
      returnData = JSON.parse(cacheResults);
    } else {
      mongoResults = await GetOrderDetails(body.order_id, body.id);
      returnData = mongoResults;
      isMongo = true;
    }
    if (returnData) {
      if (returnData.rider_id) {
        rider_details = await Send_Queue(
          "main_rider_request",
          "restaurant_queue",
          {
            _id: returnData.rider_id,
            project: { _id: 1, first_name: 1, last_name: 1, mobile_number: 1, image: 1 },
          },
          "RiderModel",
          "get"
        );
        rider_details.data.rating = 3.2;
        returnData.rider_details = rider_details.data;
      }
      results = {
        status: 0,
        fromCache: isCached,
        fromMongo: isMongo,
        fromSql: isSql,
        data: returnData,
      };
    } else {
      results = {
        status: -1,
        msg: "No Data Found",
      };
    }
  } catch (err) {
    console.error(err);
    return res.status(500).json({ status: -1, msg: "Server error", err: err.toString() });
  }

  return res.json(results);
}

export async function hitMap(req, res, next) {
  let body = req.body;
  let results = {};

  try {
    const last30Minutes = new Date(Date.now() - 500 * 60 * 1000);

    const results = await OrderModel.aggregate([
      {
        $match: {
          created_at: { $gte: last30Minutes },
        },
      },

      {
        $lookup: {
          from: "restaurents",
          localField: "branch_id",
          foreignField: "_id",
          as: "restaurant",
        },
      },

      {
        $unwind: "$restaurant",
      },

      {
        $project: {
          _id: 1,
          longitude: { $arrayElemAt: ["$restaurant.location.coordinates", 0] },
          latitude: { $arrayElemAt: ["$restaurant.location.coordinates", 1] },
        },
      },

      {
        $group: {
          _id: { longitude: "$longitude", latitude: "$latitude" },
          weight: { $sum: 1 },
        },
      },

      {
        $project: {
          _id: 0,
          longitude: "$_id.longitude",
          latitude: "$_id.latitude",
          weight: 1,
        },
      },
    ]);

    console.log(results);

    return res.status(200).json(results);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ status: -1, msg: "Server error", err: err.toString() });
  }
}

export async function re_order(req, res) {
  try {
    let body = req.body;
    const order_id = body.order_id;
    let order_details = await OrderModel.findById(order_id);
    if (!order_details)
      return res.json({
        status: -1,
        msg: "No order found",
      });
    let cart_update,
      coupon_name = "";
    if (order_details.coupon_id) {
      coupon_name = await CouponModel.findById(order_details.coupon_id, { name: 1 });
    }

    try {
      body.restaurant_id = order_details.branch_id;
      body.coupon_name = coupon_name ? coupon_name.name : null;
      body.menu_data = order_details.order_details;
      cart_update = await GetCartData(body);
    } catch (error) {
      return res.json({
        status: -1,
        msg: "Error while processing the order",
      });
    }
    if (cart_update.status === -1) {
      return res.json({
        status: cart_update.status,
        msg: cart_update.msg,
      });
    }
    return res.json({
      status: 0,
      data: cart_update.body,
    });
  } catch (err) {
    return res.status(500).json({
      status: -1,
      msg: "Server Error occurred",
      err: err.toString(),
    });
  }
}

export async function ongoing_order(req, res, next) {
  let body = req.body;
  let results = {};

  let customer_id = body.id;
  //
  try {
    let returnData = await GetOngoingOrder(customer_id);
    if (returnData) {
      results = {
        status: 0,
        data: returnData,
      };
    } else {
      results = {
        status: -1,
        msg: "No Data Found",
      };
    }
    return res.json(results);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ status: -1, msg: "Server error", err: err.toString() });
  }
}

export async function delivery_charge(req, res, next) {
  let body = req.body;
  let results = {};
  try {
    const delivery_charge = await DeliveryCharge(
      body.zone_id,
      body.rest_lat,
      body.rest_long,
      body.user_lat,
      body.user_long
    );
    if (delivery_charge > 0) {
      results = {
        status: 0,
        data: {
          delivery_charge: delivery_charge.toFixed(2),
        },
      };
    } else {
      results = {
        status: -1,
        msg: "Sorry..! Delivery unavailable in this area.",
      };
    }

    return res.json(results);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ status: -1, msg: "Server error", err: err.toString() });
  }
}

// const MAX_EXECUTION_COUNT = 3;
// const SET_TIME_OUT = 20000;
export async function autoRouting(req, res, next) {
  try {
    const system_options = await SystemOption.getSystemOption();

    const order_id = "ed3310f8-3a24-47f4-942e-f7002c2572f4";
    const order_data = {
      _id: order_id,
      lat: 23.810331902958538,
      long: 90.41251787915826,
    };
    const zone_id = "ab182111-9984-4348-bd42-1379ee5e876b";
    let riders_redis_data = await redis_get_all("rider_location");
    const check_riders = await Send_Queue(
      "main_rider_request_2",
      "restaurant_queue",
      { rider_json: riders_redis_data, zone_id: zone_id },
      "RiderModel",
      "checkRider"
    );

    const rider_order_count = await riderOrderCount(riders_redis_data);
    const check_rider_ids = new Set(check_riders.data.map((rider) => rider._id));
    for (const check_rider of check_riders.data) {
      for (const rider of rider_order_count) {
        if (!check_rider.is_available && rider.count >= check_rider.rider_max_order) {
          delete riders_redis_data[check_rider._id];
        }
      }
    }
    for (const rider_id in riders_redis_data) {
      if (!check_rider_ids.has(rider_id)) {
        delete riders_redis_data[rider_id];
      }
    }

    return res.json({
      riders_redis_data: riders_redis_data,
      check_rider: check_riders.data,
    });

    // return res.json({
    //     riders_redis_data:riders_redis_data,
    //     rider_order_count:rider_order_count,
    // })
    const MAX_EXECUTION_COUNT = JSON.parse(system_options.max_iteration_of_rider);
    const zone_radius = JSON.parse(system_options.rider_assign_radius);
    const SET_TIME_OUT = JSON.parse(system_options.iteration_interval) * 1000;

    let iterationCount = 0;
    let riderAccepted = false;
    let allocatedRiderId;

    while (iterationCount < MAX_EXECUTION_COUNT && !riderAccepted) {
      iterationCount++;

      const riders_redis_data_parse = {};
      for (let riderId in riders_redis_data) {
        const riderDataString = riders_redis_data[riderId];
        const riderData = JSON.parse(JSON.parse(riderDataString));
        riders_redis_data_parse[riderId] = {
          lat: riderData.lat,
          long: riderData.long,
          executionCount: 0,
        };
      }

      const targetLat = order_data.lat;
      const targetLon = order_data.long;
      let nearestRiders = [];
      if (riders_redis_data_parse) {
        nearestRiders = Object.entries(riders_redis_data_parse)
          .map(([riderId, riderData]) => {
            const { lat, long } = riderData;
            console.log(
              "calculateDistance",
              calculateDistance(targetLat, targetLon, lat, long)
            );
            return {
              riderId,
              distance: calculateDistance(targetLat, targetLon, lat, long),
              executionCount: riderData.executionCount,
            };
          })
          .filter((rider) => rider.distance.distance <= zone_radius)
          .filter((rider) => rider.executionCount <= MAX_EXECUTION_COUNT) // Filter out riders with exceeded execution count
          .sort((rider1, rider2) => rider1.distance.distance - rider2.distance.distance);
      }

      if (nearestRiders.length > 0) {
        const allocatedRider = nearestRiders[0];
        allocatedRiderId = allocatedRider.riderId;

        await allocateRiderToOrder(order_id, allocatedRider.riderId);

        const order = await Order.findOne({ _id: order_id });
        riderAccepted = order.rider_accepted;

        let rider_socket_body = {
          _id: uuidv4(),
          rider_id: allocatedRiderId,
          order_id: order_id,
          order_status: "assigned",
          customer_name: order.customer_name,
          branch_name: "TSET AUTO ROUTING",
        };

        const socket_add = await Send_Queue(
          "main_rider_request_2",
          "restaurant_queue",
          rider_socket_body,
          "RidersOrder",
          "socket_add"
        );
        if (riderAccepted) {
          return res.json({
            status: 1,
            msg: "Rider allocated successfully",
            riderId: allocatedRiderId,
          });
          break;
        }

        await new Promise((resolve) => setTimeout(resolve, SET_TIME_OUT));

        const updatedOrder = await Order.findOne({ _id: order_id });
        riderAccepted = updatedOrder.rider_accepted;

        if (!riderAccepted) {
          delete riders_redis_data[allocatedRider.riderId];
        }

        riders_redis_data_parse[allocatedRider.riderId].executionCount++;
      }
    }

    if (riderAccepted) {
      return res.json({
        status: 1,
        msg: "Rider allocated successfully",
        riderId: allocatedRiderId,
      });
    } else {
      await allocateRiderToOrder(order_id, null);
      return res.json({ status: 0, msg: "No available riders" });
    }
  } catch (err) {
    console.error(err);
    return res.status(500).json({ status: -1, msg: "Server error", err: err.toString() });
  }
}

export async function getRedisRider(req, res) {
  let results = {};

  try {
    let returnData = await redis_get_all("rider_location");

    if (returnData) {
      results = {
        status: 0,
        data: returnData,
      };
    } else {
      results = {
        status: -1,
        msg: "No Data Found",
      };
    }
    return res.json(results);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ status: -1, msg: "Server error", err: err.toString() });
  }
}

export async function allocateRiderToOrder(orderId, riderId) {
  try {
    const updatedOrder = await Order.findByIdAndUpdate(
      orderId,
      { rider_id: riderId },
      { new: true }
    );

    const riderAccepted = updatedOrder.rider_accepted;

    return { updatedOrder, riderAccepted };
  } catch (err) {
    console.error(err);
    throw new Error("Failed to allocate rider to order");
  }
}
// Function to calculate distance between coordinates
function calculateDistance(lat1, lon1, lat2, lon2) {
  const R = 6371; // Radius of the Earth in kilometers
  const dLat = degToRad(lat2 - lat1);
  const dLon = degToRad(lon2 - lon1);

  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(degToRad(lat1)) *
      Math.cos(degToRad(lat2)) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const distance = R * c;

  const p1 = { x: lat1, y: lon1 };
  const p2 = { x: lat2, y: lon2 };
  const x = p1.x - p2.x;
  const y = p1.y - p2.y;
  const radius = Math.sqrt(x * x + y * y);

  return { distance: distance, radius: radius };
}

function degToRad(degrees) {
  return degrees * (Math.PI / 180);
}

export async function orderCountByCunstomer(req, res) {
  try {
    const userId = req.params.userId;

    const orderCount = await Order.aggregate([
      {
        $match: { customer_id: userId },
      },
      {
        $group: {
          _id: null,
          delivery: {
            $sum: {
              $cond: [{ $eq: ["$order_type", "delivery"] }, 1, 0],
            },
          },
          pickup: {
            $sum: {
              $cond: [{ $eq: ["$order_type", "pickup"] }, 1, 0],
            },
          },
          dine: {
            $sum: {
              $cond: [{ $eq: ["$order_type", "dine_in"] }, 1, 0],
            },
          },
        },
      },
    ]);
    return res.status(200).json(orderCount[0]);
  } catch (err) {
    return res.status(500).json({ status: -1, msg: "Server error" });
  }
}
