import axios from "axios";
import * as dotenv from "dotenv";
import RestaurentModel from "../../models/Restaurant/RestaurentModel.js";
import CuisineModel from "../../models/Cuisines/CuisineModel";
import BranchAttributesModel from "../../models/BranchAttributes/BrancAttributes";
import { validator } from "../../helper/validator";
import { getZone } from "../../helper/zones/GetZone";
import BrancAttributes from "../../models/BranchAttributes/BrancAttributes";
dotenv.config();
const url = process.env.ELASTIC_URL;

export async function search(req, res, next) {
  // TODO: user input validation
  let body = req.body;
  console.log(body);
  try {
    const query = body.query;
    const zone_id = body.zone_id;
    const limit = body.limit;
    const page = body.page;
    const user_id = body.id;
    const sort_by = body.sort_by; // possible values are rating, delivery_time and distance
    const cuisine_id = body.cuisine_id; // Should be an array
    const attribute_id = body.attribute_id; // Should be an array
    const price_range = body.price_range;
    const lat = body.lat;
    const long = body.long;
    // TODO: get the menu and restaurant id's from elastic search
    const data = await RestaurentModel.getSearchResult(
      query,
      sort_by,
      cuisine_id,
      attribute_id,
      price_range,
      lat,
      long,
      zone_id,
      user_id,
      limit,
      page
    );

    if (!data)
      return res.json({
        status: -1,
        msg: "No data found",
      });

    return res.json({
      status: 0,
      data: data,
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ status: -1, msg: "Server error" });
  }
}
export async function search_suggest(req, res, next) {
  try {
    const searchQuery = {
      query: {
        match_phrase_prefix: {
          message: {
            query: req.params.value,
          },
        },
      },
    };

    const queryParams = {
      source: JSON.stringify(searchQuery),
    };

    console.log('params',req.params.value)
    console.log('queryParams',queryParams)

    const response = await axios.get(`${url}/_search`, { params: queryParams });

    const filteredHits = response.data.hits.hits.filter((hit) => !hit._source.id);
    const uniqueMessages = [...new Set(filteredHits.map((hit) => hit))];

    //console.log("filteredHits", filteredHits);

    return res.json({
      status: 0,
      data: uniqueMessages,
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ status: -1, msg: "Server error" });
  }
}
export async function create_index(req, res, next) {
  try {
    const insertData = {
      message: req.body.value,
      device_id: req.body.device_id,
    };

    const searchQuery = {
      query: {
        bool: {
          must: [
            { match: { message: insertData.message } },
            { match: { device_id: insertData.device_id } },
          ],
        },
      },
    };
    const searchResponse = await axios.post(`${url}_search`, searchQuery);

    if (searchResponse.data.hits.total > 0) {
      const existingData = searchResponse.data.hits.hits[0]._source;
      return res.json({
        status: 0,
        data: existingData,
      });
    } else {
      const insertResponse = await axios.post(`${url}/foodi`, insertData);
      console.log(insertResponse.data);
      return res.json({
        status: 0,
        data: insertResponse.data,
      });
    }
  } catch (err) {
    console.error(err);
    return res.status(500).json({ status: -1, msg: "Server error" });
  }
}

export async function search_data(req, res, next) {
  // Get Data

  try {
    const popularQuery = {
      aggs: {
        popular_searches: {
          terms: {
            field: "message",
            size: 10,
          },
        },
      },
    };
    const recentQuery = {
      query: {
        bool: {
          must: [
            {
              match: {
                device_id: req.body.device_id,
              },
            },
          ],
        },
      },
      sort: [
        {
          _score: {
            order: "desc",
          },
        },
      ],
      size: 5,
    };

    const popular = await axios.post(`${url}/_search`, popularQuery);
    const recent = await axios.post(`${url}/_search`, recentQuery);
    const popularSearches = popular.data.aggregations.popular_searches.buckets.map(
      (bucket) => bucket.key
    );
    const recentSearches = recent.data.hits.hits.map((hit) => hit);
    if (popularSearches.length > 0 || recentSearches.length > 0) {
      return res.json({
        status: 0,
        data: {
          popular_search: popularSearches,
          recent_search: recentSearches,
        },
      });
    } else {
      return res.json({
        status: -1,
        msg: "No Data Found",
      });
    }
  } catch (err) {
    console.error(err);
    return res.status(500).json({ status: -1, msg: "Server error" });
  }
}

export async function deleteSearch(req, res, next) {
  try {
    const { id } = req.params;

    const deleteResponse = await axios.delete(`${url}foodi/${id}`);

    console.log(deleteResponse.data);

    return res.json({
      status: 0,
      msg: "Success",
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ status: -1, msg: "Server error" });
  }
}

// Get search item
export async function searchItem(req, res, next) {
  try {
    let query = req.query;

    /** User Input Validation */
    const rules = {
      long: "required|numeric",
      lat: "required|numeric",
    };
    let error;
    await validator(query, rules, {}, (err) => {
      error = err;
    });
    if (error) {
      return res.json({
        status: -1,
        data: error,
        msg: "Validation error.",
      });
    }
    /** User Input Validation End */

    let zone_id = await getZone(Number(query.lat), Number(query.long));

    if (!zone_id) {
      return res.json({
        status: -1,
        msg: "Failed to fetch zone",
      });
    }

    if (zone_id.length < 1) {
      return res.json({
        status: -1,
        msg: "No service available for this zone.",
      });
    }

    const cuisines = await CuisineModel.getActiveCuisinesNameId(zone_id);
    const attributes = await BrancAttributes.getActiveAttributes();

    if (cuisines.length > 0 || attributes.length > 0) {
      return res.json({
        status: 0,
        data: {
          cuisines,
          attributes,
        },
      });
    } else {
      return res.json({
        status: -1,
        msg: "No data found",
      });
    }
  } catch (err) {
    console.error(err);
    return res.status(500).json({ status: -1, msg: "Server error" });
  }
}
