import CampaignModel from "../../models/Campaign/CampaignModel.js";
import ListService from "../../helper/common/ListService.js";
import { getZone } from "../../helper/zones/GetZone.js";
import { decryptLink, generateLink } from "../../helper/common/DeepLink.js";
//create
const DEEPLINK_BASE_URL = process.env.DEEPLINK_BASE_URL;

//create
export async function dine_fetch_campaign(req, res, next) {
  let body = req.body;

  let results = {};
  //
  try {
    let match = {
      $match: {
        is_active: true,
        is_dine: true,
        start_date: {
          $lte: new Date(),
        },
        end_date: {
          $gte: new Date(),
        },
      },
    };
    let projection = {
      $project: {
        _id: 1,
        name: 1,
        image: 1,
        description: 1,
        start_date: {
          $dateToString: {
            date: "$start_date",
            format: "%d-%m-%Y",
          },
        },
        end_date: {
          $dateToString: {
            date: "$end_date",
            format: "%d-%m-%Y",
          },
        },
      },
    };
    let fetch_campaign = await ListService(body, CampaignModel, match, projection);
    if (fetch_campaign) {
      results = {
        status: 0,
        data: fetch_campaign,
      };
    } else {
      results = {
        status: -1,
        msg: "No Data Found",
      };
    }
    res.json(results);
  } catch (err) {
    next(err);
  }
}

export const dine_getCampaignDetails = async (req, res) => {
  let body = req.body;
  let zone_id = await getZone(body.lat, body.long);
  let campaign_id = body.campaign_id;
  if (!zone_id) {
    res.json({
      status: -1,
      msg: "Failed to fetch zone",
    });
  }

  if (zone_id.length < 1) {
    res.json({
      status: -1,
      msg: "No service available for this zone.",
    });
  }
  const data = await CampaignModel.dine_getCampaignRestaurants(
    campaign_id,
    zone_id[0]._id,
    body.id
  );

  if (data[0]) {
    const deepLink = await generateLink("campaign", campaign_id);
    data[0].deepLink = DEEPLINK_BASE_URL + deepLink;
    res.json({
      status: 0,
      data: data[0],
    });
  } else {
    res.json({
      status: -1,
      msg: "No data found!",
    });
  }
};
