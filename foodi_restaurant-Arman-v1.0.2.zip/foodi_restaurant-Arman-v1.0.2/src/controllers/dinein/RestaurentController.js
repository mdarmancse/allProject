import RestaurentModel from "../../models/Restaurant/RestaurentModel.js";
import { getZone } from "../../helper/zones/GetZone.js";
import dine_GetView from "../../helper/Restaurant/dine_GetView.js";
import { validator } from "../../helper/validator.js";
import { generateLink } from "../../helper/common/DeepLink.js";
import CuisineModel from "../../models/Cuisines/CuisineModel.js";
const DEEPLINK_BASE_URL = process.env.DEEPLINK_BASE_URL;
export async function dine_restaurant_view(req, res, next) {
  let body = req.body;
  console.log("body", body);
  let results = {};
  try {
    let getView = await dine_GetView(body.restaurant_id, body.lat, body.long, body.id);

    if (getView) {
      const deepLink = await generateLink("restaurant", body.restaurant_id);
      getView.restaurant.deepLink = DEEPLINK_BASE_URL + deepLink;
      results = {
        status: 0,
        data: getView,
      };
    } else {
      results = {
        status: -1,
        msg: "No Data Found",
      };
    }
    res.json(results);
  } catch (err) {
    next(err);
  }
}
export async function dine_restaurant_nearby_get(req, res, next) {
  let body = req.body;
  /** User Input Validation */
  const rules = {
    long: "required|numeric",
    lat: "required|numeric",
  };

  let error;
  await validator(body, rules, {}, (err) => {
    error = err;
  });

  if (error) {
    res.json({
      status: -1,
      data: error,
      msg: "Validation error.",
    });
  }
  /** User Input Validation End */

  let zone_id = await getZone(body.lat, body.long);
  if (!zone_id) {
    res.json({
      status: -1,
      msg: "Failed to fetch zone",
    });
  }

  if (zone_id.length < 1) {
    res.json({
      status: -1,
      msg: "No service available for this zone.",
    });
  }

  try {
    const data = await RestaurentModel.dine_getNearbyRestaurant(
      zone_id[0]._id,
      body.id,
      body.long,
      body.lat,
      body.limit,
      body.page
    );
    if (!data)
      res.json({
        status: -1,
        msg: "No data found",
      });

    res.json({
      status: 0,
      data: data,
    });
  } catch (err) {
    next(err);
  }
}
export const dine_getCuisines = async (req, res, next) => {
  try {
    let body = req.body;
    /** User Input Validation */
    const rules = {
      long: "required|numeric",
      lat: "required|numeric",
    };
    let error;
    await validator(body, rules, {}, (err) => {
      error = err;
    });
    if (error) {
      res.json({
        status: -1,
        data: error,
        msg: "Validation error.",
      });
    }
    /** User Input Validation End */

    let zone_id = await getZone(body.lat, body.long);
    if (!zone_id) {
      res.json({
        status: -1,
        msg: "Failed to fetch zone",
      });
    }

    if (zone_id.length < 1) {
      res.json({
        status: -1,
        msg: "No service available for this zone.",
      });
    }
    // const data = await crud_helper.findActive(CuisineModel);
    const data = await CuisineModel.dine_getActiveCuisines(zone_id);
    if (data) {
      res.json({
        status: 0,
        data: data,
      });
    } else {
      res.json({
        status: -1,
        msg: "No data found",
      });
    }
  } catch (err) {
    next(err);
  }
};
export async function dine_cuisine_details(req, res) {
  let body = req.body;
  /** User Input Validation */
  const rules = {
    zone_id: "required",
    cuisine_id: "required",
  };

  let error;
  await validator(body, rules, {}, (err) => {
    error = err;
  });

  if (error) {
    res.json({
      status: -1,
      data: error,
      msg: "Validation error.",
    });
  }
  /** User Input Validation End */

  const data = await CuisineModel.dine_getCuisineRestaurants(
    body.zone_id,
    body.id,
    body.cuisine_id
  );
  if (data.length > 0) {
    res.json({
      status: 0,
      data: data,
    });
  } else {
    res.json({
      status: -1,
      msg: "No data found",
    });
  }
}
export async function dine_similar_restaurants(req, res, next) {
  let body = req.body;
  /** User Input Validation */
  const rules = {
    rest_long: "required|numeric",
    rest_lat: "required|numeric",
  };

  let error;
  await validator(body, rules, {}, (err) => {
    error = err;
  });

  if (error) {
    res.json({
      status: -1,
      data: error,
      msg: "Validation error.",
    });
  }
  /** User Input Validation End */

  let zone_id = await getZone(body.rest_lat, body.rest_long);

  //  res.send(zone_id)
  if (!zone_id) {
    res.json({
      status: -1,
      msg: "Failed to fetch zone",
    });
  }

  if (zone_id.length < 1) {
    res.json({
      status: -1,
      msg: "No service available for this zone.",
    });
  }

  try {
    const data = await RestaurentModel.dine_getSimilarRestaurant(
      zone_id[0]._id,
      body.id,
      body.restaurant_id,
      body.cuisine_id,
      body.rest_long,
      body.rest_lat,
      body.limit,
      body.page
    );
    if (data.length > 0) {
      res.json({
        status: 0,
        data: data,
      });
    } else {
      res.json({
        status: -1,
        msg: "No data found",
      });
    }
  } catch (err) {
    next(err);
  }
}
