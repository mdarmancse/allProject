import ListService from "../../helper/common/ListService.js";
import FAQModel from "../../models/Faq & Setting/Faq.js";

export async function dine_getFaq(req, res, next) {
  let body = req.body;
  let results = {};
  try {
    let match = { $match: { is_active: true, is_dine: true } };
    let projection = {
      $project: {
        _id: 1,
        question: 1,
        answer: 1,
      },
    };
    let data = await ListService(body, FAQModel, match, projection);
    if (data) {
      results = {
        status: 0,
        data: data,
      };
    } else {
      results = {
        status: -1,
        msg: "No Data Found",
      };
    }
    res.json(results);
  } catch (err) {
    next(err);
  }
}
