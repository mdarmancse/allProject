import axios from "axios";
import * as dotenv from "dotenv";
import RestaurentModel from "../../models/Restaurant/RestaurentModel.js";
dotenv.config();
const url = process.env.ELASTIC_URL;
export async function dine_search(req, res, next) {
  // TODO: user input validation
  let body = req.body;
  try {
    const query = body.query;
    const zone_id = body.zone_id;
    const limit = body.limit;
    const page = body.page;
    const user_id = body.id;
    const sort_by = body.sort_by; // possible values are rating, delivery_time and distance
    const cuisine_id = body.cuisine_id;
    const attribute_id = body.attribute_id;
    const price_range = body.price_range;
    const lat = body.lat;
    const long = body.long;
    // TODO: get the menu and restaurant id's from elastic search
    const data = await RestaurentModel.dine_getSearchResult(
      query,
      sort_by,
      cuisine_id,
      attribute_id,
      price_range,
      lat,
      long,
      zone_id,
      user_id,
      limit,
      page
    );

    if (!data)
      return res.json({
        status: -1,
        msg: "No data found",
      });

    return res.json({
      status: 0,
      data: data,
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ status: -1, msg: "Server error" });
  }
}
