import SaveVoucher from "../../models/Coupon/SaveVoucher.js";

import VoucherSetting from "../../models/Rewards/VoucherSetting.js";
import EarnBurnHistory from "../../models/Rewards/EarnBurnHistory.js";
import CouponModel from "../../models/Coupon/CouponModel.js";
import CustomerCoupon from "../../models/Coupon/CustomerCoupon.js";
import { GetPoint } from "../../helper/Restaurant/GetCoupon.js";

//Redeem Voucher
export async function dine_redeem_voucher(req, res, next) {
  let body = req.body;
  let results = {};

  let customer_id = body.id;
  let voucher_id = body.voucher_id;

  try {
    let customer_point = await GetPoint(customer_id);

    let voucher_details = await VoucherSetting.findOne({
      is_active: true,
      is_dine: true,
      _id: voucher_id,
    });
    if (customer_point <= 0 || customer_point < voucher_details.voucher_cost_in_point) {
      res.json({
        status: -1,
        msg: "Sorry..! You are not eligible!",
      });
    }
    if (!voucher_details) {
      res.json({
        status: -1,
        msg: "Sorry..! This voucher is currently not available",
      });
    }

    let start_time = new Date();
    let end_time = new Date(
      start_time.getTime() + voucher_details.validity_time * 60 * 60 * 1000
    ); // add 48 hours in milliseconds

    let characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    let randomString = "";
    for (let i = 0; i < 8; i++) {
      randomString += characters.charAt(Math.floor(Math.random() * characters.length));
    }
    // console.log(randomString);

    await EarnBurnHistory.create({
      type: "Burn",
      voucher_id: voucher_id,
      customer_id: customer_id,
      point: voucher_details.voucher_cost_in_point,
      description: voucher_details.name,
    });

    let generate_coupon = await CouponModel.create({
      name: randomString,
      description: voucher_details.name,
      use_limit: 1,
      start_time: start_time,
      end_time: end_time,
      is_active: true,
      is_dine: true,
      created_at: new Date(),
    });

    await CustomerCoupon.create({
      customer_id: body.id,
      coupon_id: generate_coupon._id,
      restaurant_id: body.restaurant_id,
      discount_in_amount: voucher_details.voucher_amount,
      is_dine: true,
    });

    if (generate_coupon) {
      const diffInMilliseconds = generate_coupon.end_time - new Date();
      const diffInMinutes = diffInMilliseconds / (1000 * 60);
      results = {
        status: 0,
        msg: "Voucher Redeem Successfully!",
        name: generate_coupon.name,
        description: generate_coupon.description,
        start_time: generate_coupon.start_time,
        end_time: generate_coupon.end_time,
        created_at: generate_coupon.end_time,
        validity_time: Math.floor(diffInMinutes),
      };
    } else {
      results = {
        status: -1,
        msg: "No Data Found",
      };
    }
    res.json(results);
  } catch (err) {
    next(err);
  }
}
export async function dine_check_coupon(req, res, next) {
  let body = req.body;
  let results = {};

  let customer_id = body.id;
  let restaurant_id = body.restaurant_id;

  try {
    let get_coupon = await CustomerCoupon.dine_checkCoupon(customer_id, restaurant_id);
    if (get_coupon.length > 0) {
      const diffInMilliseconds = get_coupon[0].end_time - new Date();
      const diffInMinutes = diffInMilliseconds / (1000 * 60);
      results = {
        status: 0,
        name: get_coupon[0].name,
        description: get_coupon[0].description,
        start_time: get_coupon[0].start_time,
        end_time: get_coupon[0].end_time,
        created_at: get_coupon[0].end_time,
        validity_time: Math.floor(diffInMinutes),
      };
    } else {
      results = {
        status: -1,
        msg: "No Data Found",
      };
    }
    res.json(results);
  } catch (err) {
    next(err);
  }
}
