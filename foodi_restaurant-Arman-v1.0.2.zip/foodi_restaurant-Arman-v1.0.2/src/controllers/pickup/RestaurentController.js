import RestaurentModel from "../../models/Restaurant/RestaurentModel.js";
import PromotionModel from "../../models/Promotion/PromotionModel.js";
import { getZone } from "../../helper/zones/GetZone.js";
import pick_GetView from "../../helper/Restaurant/pick_GetView.js";
import { validator } from "../../helper/validator.js";
import { generateLink } from "../../helper/common/DeepLink.js";
import FavRestaurant from "../../models/Restaurant/FavRestaurant.js";
import { Send_Central, Send_Queue } from "../../helper/common/RMQ.js";
const DEEPLINK_BASE_URL = process.env.DEEPLINK_BASE_URL;
const cms_queue = process.env.CMS_QUEUE_NAME;
export async function pick_getPromotions(req, res, next) {
  try {
    let body = req.body;
    let zone_id = await getZone(body.lat, body.long);
    if (!zone_id) {
      res.json({
        status: -1,
        msg: "Failed to fetch zone",
      });
    }

    if (zone_id.length < 1) {
      res.json({
        status: -1,
        msg: "No service available for this zone.",
      });
    }
    const data = await PromotionModel.pick_getZonePromotions(
      zone_id[0]._id,
      body.id,
      body.lat,
      body.long
    );

    if (!data)
      res.json({
        status: -1,
        msg: "Failed to get data.",
      });

    const new_data = data.filter((item) => {
      return item.restaurants.length > 0;
    });
    // console.log("new_data", data);
    if (new_data) {
      res.json({
        status: 0,
        data: new_data,
      });
    } else {
      res.json({
        status: -1,
        msg: "Failed to get data.",
      });
    }
  } catch (err) {
    next(err);
  }
}
export async function pick_restaurant_view(req, res, next) {
  let body = req.body;
  let results = {};
  try {
    let getView = await pick_GetView(body.restaurant_id, body.lat, body.long, body.id);

    if (getView) {
      const deepLink = await generateLink("restaurant", body.restaurant_id);
      getView.restaurant.deepLink = DEEPLINK_BASE_URL + deepLink;
      results = {
        status: 0,
        data: getView,
      };
    } else {
      results = {
        status: -1,
        msg: "No Data Found",
      };
    }
    res.json(results);
  } catch (err) {
    next(err);
  }
}
export async function pick_restaurant_nearby_get(req, res) {
  let body = req.body;
  /** User Input Validation */
  const rules = {
    long: "required|numeric",
    lat: "required|numeric",
  };

  let error;
  await validator(body, rules, {}, (err) => {
    error = err;
  });

  if (error) {
    res.json({
      status: -1,
      data: error,
      msg: "Validation error.",
    });
  }
  /** User Input Validation End */

  let zone_id = await getZone(body.lat, body.long);
  if (!zone_id) {
    res.json({
      status: -1,
      msg: "Failed to fetch zone",
    });
  }

  if (zone_id.length < 1) {
    res.json({
      status: -1,
      msg: "No service available for this zone.",
    });
  }

  try {
    const data = await RestaurentModel.pick_getNearbyRestaurant(
      zone_id[0]._id,
      body.id,
      body.long,
      body.lat,
      body.limit,
      body.page
    );
    if (!data)
      res.json({
        status: -1,
        msg: "No data found",
      });

    res.json({
      status: 0,
      data: data,
    });
  } catch (err) {
    res.json({
      status: -1,
      msg: "Server error",
    });
  }
}

//Favourite Restaurant
export async function pick_add_favourite_rest(req, res, next) {
  let body = req.body;
  let results = {};

  try {
    let data = await FavRestaurant.findOne({
      customer_id: body.id,
      branch_id: body.branch_id,
      is_pickup: true,
    });

    if (data) {
      await FavRestaurant.deleteOne({
        _id: data._id,
      });
      await Send_Queue(
        cms_queue,
        "restaurant_queue",
        { _id: data._id },
        "favourite_branch",
        "delete"
      );
      // await Send_Central({ _id:data._id }, "favourite_branch", "delete");
      results = {
        status: 0,
        is_favourite: 0,
        message: "Remove from favourite",
      };
    } else {
      let body_data = {
        customer_id: body.id,
        branch_id: body.branch_id,
        is_pickup: true,
      };
      let return_data = await FavRestaurant.create(body_data);
      if (return_data) {
        await Send_Queue(
          cms_queue,
          "restaurant_queue",
          return_data,
          "favourite_branch",
          "add"
        );
        //await Send_Central(return_data, "favourite_branch", "add");
      }
      results = {
        status: 1,
        is_favourite: 1,
        message: "Added to favourite",
      };
    }
    res.json(results);
  } catch (err) {
    next(err);
  }
}
export async function pick_favourite_restaurant(req, res, next) {
  let body = req.body;
  /** User Input Validation */
  const rules = {
    long: "required|numeric",
    lat: "required|numeric",
    id: "required",
  };

  let error;
  await validator(body, rules, {}, (err) => {
    error = err;
  });

  if (error) {
    res.json({
      status: -1,
      data: error,
      msg: "Validation error.",
    });
  }
  /** User Input Validation End */

  let zone_id = await getZone(body.lat, body.long);
  if (!zone_id) {
    res.json({
      status: -1,
      msg: "Failed to fetch zone",
    });
  }

  if (zone_id.length < 1) {
    res.json({
      status: -1,
      msg: "No service available for this zone.",
    });
  }

  try {
    const data = await FavRestaurant.pick_getFavouriteRestaurant(
      zone_id[0]._id,
      body.id,
      body.long,
      body.lat,
      body.limit,
      body.page
    );
    if (data.length > 0) {
      res.json({
        status: 0,
        data: data,
      });
    } else {
      res.json({
        status: -1,
        msg: "No data found",
      });
    }
  } catch (err) {
    next(err);
  }
}
