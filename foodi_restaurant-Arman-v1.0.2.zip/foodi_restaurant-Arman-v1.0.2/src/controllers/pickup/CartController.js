import crud_helper from "../../helper/common/crud_helper.js";
import { getZone } from "../../helper/zones/GetZone.js";
import RestaurentModel from "../../models/Restaurant/RestaurentModel.js";
import CartModel from "../../models/Order/CartModel.js";
import { GetOrderData } from "../../helper/Restaurant/GetOrderData.js";
const cms_queue = process.env.CMS_QUEUE_NAME;
import {
  coupon_val_check,
  pick_coupon_val_check,
} from "../../helper/common/Calculation.js";
import { Send_Central, Send_Queue } from "../../helper/common/RMQ.js";
import ZoneCoupon from "../../models/Coupon/ZoneCoupon.js";
import CouponModel from "../../models/Coupon/CouponModel.js";
import Order from "../../models/Order/Order.js";
import CustomerCoupon from "../../models/Coupon/CustomerCoupon.js";
import BranchCoupon from "../../models/Coupon/BranchCoupon.js";
import CuisineCoupon from "../../models/Coupon/CuisineCoupon.js";
import GradualInformation from "../../models/Coupon/GradualInformation.js";
import MenuItemCoupon from "../../models/Coupon/MenuItemCoupon.js";
import CategoryCoupon from "../../models/Coupon/CategoryCoupon.js";
import { userData } from "../../helper/common/common.js";
import SubscriptionTypeCoupon from "../../models/Coupon/SubscriptionTypeCoupon.js";
import SystemOption from "../../models/Faq & Setting/SystemOption.js";

export async function pick_cartAdd(req, res) {
  const system_options = await SystemOption.getSystemOption();
  const SYSTEM_MAX_ORDER_VALUE = JSON.parse(system_options.max_order_value);
  const SYSTEM_MIN_ORDER_VALUE = JSON.parse(system_options.min_order_value);

  let body = req.body;
  let { restaurant_id, lat, long, menu_data, coupon_name } = req.body;
  const user_id = body.id;
  let rules,
    user_data,
    subscription_type_id,
    customer_mobile,
    customer_name,
    applied_coupon_add;
  let applied_coupons = [];
  user_data = await userData(user_id);
  if (!user_data) {
    return res.json({
      status: -1,
      msg: "Customer not found!",
    });
  }
  subscription_type_id = user_data.subscription_type_id;
  customer_mobile = user_data.mobile;
  customer_name = user_data.firstName + " " + user_data.lastName;
  let error = "",
    total = 0,
    total_vat = 0,
    total_sd = 0,
    discount = 0,
    discount_amount = 0,
    discount_in_percent = 0,
    discount_type = "",
    menus = "",
    discount_value = 0,
    grand_total = 0,
    delivery_charge = 0,
    coupon_id,
    wise_coupon_check;

  body.auto_applied_coupon = "";

  /**Zone validation start*/
  let zone_id = await getZone(body.lat, body.long);
  if (!zone_id) {
    return res.json({
      status: -1,
      msg: "Failed to fetch zone",
    });
  }

  if (zone_id.length < 1) {
    return res.json({
      status: -1,
      msg: "No service available for this zone.",
    });
  }
  /**Zone validation end */

  /**Restaurant validation start */

  // Zone check
  const res_zone_check = await crud_helper.findActive(RestaurentModel, {
    _id: restaurant_id,
    is_pickup: true,
    "zone_id._id": zone_id[0]._id,
  });

  if (res_zone_check.length === 0) {
    return res.json({
      status: -1,
      msg: "Restaurant unavailable",
    });
  }
  body.restaurant_name = res_zone_check[0].name;
  body.restaurant_address = res_zone_check[0].address;
  body.res_lat = res_zone_check[0].location.coordinates[1];
  body.res_long = res_zone_check[0].location.coordinates[0];
  /**Restaurant validation end */
  let cuisines = res_zone_check[0].cuisines;
  let order_data = await GetOrderData(restaurant_id, menu_data);

  if (order_data.length === 0) {
    return res.json({
      status: -1,
      msg: "Sorry,no menus are currently available !",
    });
  }

  const sum_data = order_data.reduce(
    (ac, cur) => {
      ac.total_item_total += cur.item_total;
      ac.total_sd += cur.item_sd;
      ac.total_vat += cur.item_vat;
      return ac;
    },
    { total_item_total: 0, total_sd: 0, total_vat: 0 }
  );

  menus = order_data;
  total = sum_data.total_item_total;
  total_sd = sum_data.total_sd;
  total_vat = sum_data.total_vat;
  if (total < SYSTEM_MIN_ORDER_VALUE) {
    return res.json({
      status: -1,
      msg: `Sorry..! Your food price should be greater than ${SYSTEM_MIN_ORDER_VALUE}`,
    });
  }
  if (total < min_order_value) {
    return res.json({
      status: -1,
      msg: `Sorry..! Your food price should be greater than ${min_order_value}`,
    });
  }
  if (SYSTEM_MAX_ORDER_VALUE < total) {
    return res.json({
      status: -1,
      msg: `Sorry..! Your food price should be less than ${SYSTEM_MAX_ORDER_VALUE}`,
    });
  }
  if (error)
    return res.json({
      msg: error,
      status: -1,
    });
  /** Menu Check End */

  /** Coupon Check Start*/
  // TODO: check all kind of coupons

  let cat_list = [];
  for (const order_data_key in order_data) {
    const menu = order_data[order_data_key];
    cat_list.push(menu.category_id);
  }

  let auto_apply_coupon = await CouponModel.getAutoApplyCoupons({
    restaurant_id,
    user_id,
    zone_id,
    cuisines,
    cat_list,
    is_pickup: true,
  });

  if (auto_apply_coupon?.length > 0) {
    let coupon_check = auto_apply_coupon[0];
    let coupon_id = coupon_check._id;
    let coupon_count = await Order.find({
      coupon_id: coupon_id,
      customer_id: body.id,
    }).count();

    if (coupon_check.use_limit && coupon_count > coupon_check.use_limit) {
      body.coupon_msg = coupon_name + " limit is over!";
    } else {
      let get_coupon_type = coupon_check.coupon_type_name;
      console.log("get_coupon_type :", get_coupon_type);
      let minimum_order_amount = coupon_check.minimum_order_amount;
      let diff = minimum_order_amount - total;

      if (minimum_order_amount >= total) {
        //  Pass
      } else {
        body.auto_applied_coupon_id = coupon_id;
        //Check type wise validation
        if (get_coupon_type == "user_wise") {
          wise_coupon_check = await CustomerCoupon.findOne({
            customer_id: body.id,
            coupon_id: coupon_id,
          });
          if (wise_coupon_check) {
            // if (coupon_check.maximum_discount_amount)
            discount += coupon_check.is_percent
              ? (parseFloat(coupon_check.discount_in_percent) / 100) * total
              : parseFloat(coupon_check.discount_in_amount);

            discount_value = coupon_check.is_percent
              ? coupon_check.discount_in_percent
              : coupon_check.discount_in_amount;
            if (discount > coupon_check.maximum_discount_amount) {
              discount = coupon_check.maximum_discount_amount;
            } else {
              discount = discount;
            }

            discount_type = coupon_check.is_percent ? "percent" : "amount";
          } else {
            //   body.coupon_msg = coupon_name + " is not available for you!";
          }
        } else if (get_coupon_type == "branch_wise") {
          wise_coupon_check = await BranchCoupon.findOne({
            branch_id: restaurant_id,
            coupon_id: coupon_id,
          });
          // return wise_coupon_check;
          if (wise_coupon_check) {
            discount += coupon_check.is_percent
              ? (parseFloat(coupon_check.discount_in_percent) / 100) * total
              : parseFloat(coupon_check.discount_in_amount);

            discount_value = coupon_check.is_percent
              ? coupon_check.discount_in_percent
              : coupon_check.discount_in_amount;
            if (discount > coupon_check.maximum_discount_amount) {
              discount = coupon_check.maximum_discount_amount;
            } else {
              discount = discount;
            }

            discount_type = coupon_check.is_percent ? "percent" : "amount";
          } else {
            //   body.coupon_msg = coupon_name + " is not available for this restaurant!";
          }
        } else if (get_coupon_type == "zone_wise") {
          wise_coupon_check = await ZoneCoupon.findOne({
            zone_id: zone_id,
            coupon_id: coupon_id,
          });
          // return wise_coupon_check;
          if (wise_coupon_check) {
            discount += coupon_check.is_percent
              ? (parseFloat(coupon_check.discount_in_percent) / 100) * total
              : parseFloat(coupon_check.discount_in_amount);

            discount_value = coupon_check.is_percent
              ? coupon_check.discount_in_percent
              : coupon_check.discount_in_amount;
            if (discount > coupon_check.maximum_discount_amount) {
              discount = coupon_check.maximum_discount_amount;
            } else {
              discount = discount;
            }

            discount_type = coupon_check.is_percent ? "percent" : "amount";
          } else {
            //   body.coupon_msg = coupon_name + " is not available in this zone!";
          }
        } else if (get_coupon_type == "cuisine_wise") {
          wise_coupon_check = await CuisineCoupon.aggregate([
            {
              $match: {
                coupon_id: coupon_id,
                cuisine_id: {
                  $in: cuisines ? cuisines.map((cs) => cs.cuisine_id) : [],
                },
              },
            },
          ]);
          // return wise_coupon_check;
          if (wise_coupon_check) {
            discount += coupon_check.is_percent
              ? (parseFloat(coupon_check.discount_in_percent) / 100) * total
              : parseFloat(coupon_check.discount_in_amount);

            discount_value = coupon_check.is_percent
              ? coupon_check.discount_in_percent
              : coupon_check.discount_in_amount;
            if (discount > coupon_check.maximum_discount_amount) {
              discount = coupon_check.maximum_discount_amount;
            } else {
              discount = discount;
            }

            discount_type = coupon_check.is_percent ? "percent" : "amount";
          } else {
            //   body.coupon_msg = coupon_name + " is not available for this cuisine!";
          }
        } else if (get_coupon_type == "gradual_wise") {
          let grad_coupon_count = await Order.find({
            branch_id: restaurant_id,
            coupon_id: coupon_id,
            customer_id: body.id,
          }).count();

          wise_coupon_check = await GradualInformation.findOne({
            coupon_id: coupon_id,
          }).sort({ _id: -1 });

          if (wise_coupon_check) {
            let sequence = wise_coupon_check.sequence;
            let new_seq = grad_coupon_count + 1;
            if (sequence == new_seq) {
              discount += coupon_check.is_percent
                ? (parseFloat(coupon_check.discount_in_percent) / 100) * total
                : parseFloat(coupon_check.discount_in_amount);

              discount_value = coupon_check.is_percent
                ? coupon_check.discount_in_percent
                : coupon_check.discount_in_amount;
              if (discount > coupon_check.maximum_discount_amount) {
                discount = coupon_check.maximum_discount_amount;
              } else {
                discount = discount;
              }
            } else {
              // body.coupon_msg = coupon_name + " is not available for you!";
            }
            discount_type = coupon_check.is_percent ? "percent" : "amount";
          } else {
            //   body.coupon_msg = coupon_name + " is not available for you!";
          }
        } else if (get_coupon_type == "category_wise") {
          for (const order_data_key in order_data) {
            const menu = order_data[order_data_key];
            console.log("menud", menu);
            wise_coupon_check = await CategoryCoupon.findOne({
              category_id: menu.category_id,
              coupon_id: coupon_id,
            });
            console.log("wise_coupon_check", wise_coupon_check);
            if (wise_coupon_check) {
              discount += coupon_check.is_percent
                ? (parseFloat(coupon_check.discount_in_percent) / 100) * menu.item_total
                : parseFloat(coupon_check.discount_in_amount);
              console.log("discount", discount);
              discount_value = coupon_check.is_percent
                ? coupon_check.discount_in_percent
                : coupon_check.discount_in_amount;
              if (discount > coupon_check.maximum_discount_amount) {
                discount = coupon_check.maximum_discount_amount;
              } else {
                discount = discount;
              }
              //   discount_type = coupon_check.is_percent ? "percent" : "amount";
            }

            if (discount <= 0) {
              // body.coupon_msg = coupon_name + " is not available !";
            }
          }
        } else if (get_coupon_type == "menu_item_wise") {
          for (const order_data_key in order_data) {
            const menu = order_data[order_data_key];
            console.log("menud", menu);
            wise_coupon_check = await MenuItemCoupon.findOne({
              menu_item_id: menu._id,
              coupon_id: coupon_id,
            });
            console.log("wise_coupon_check", wise_coupon_check);
            if (wise_coupon_check) {
              discount += coupon_check.is_percent
                ? (parseFloat(coupon_check.discount_in_percent) / 100) * menu.item_total
                : parseFloat(coupon_check.discount_in_amount);
              console.log("discount", discount);
              discount_value = coupon_check.is_percent
                ? coupon_check.discount_in_percent
                : coupon_check.discount_in_amount;
              if (discount > coupon_check.maximum_discount_amount) {
                discount = coupon_check.maximum_discount_amount;
              } else {
                discount = discount;
              }
              //   discount_type = coupon_check.is_percent ? "percent" : "amount";
            }
          }

          if (discount <= 0) {
            //   body.coupon_msg = coupon_name + " is not available!";
          }
        } else {
          discount += coupon_check.is_percent
            ? (parseFloat(coupon_check.discount_in_percent) / 100) * total
            : parseFloat(coupon_check.discount_in_amount);

          discount_value = coupon_check.is_percent
            ? coupon_check.discount_in_percent
            : coupon_check.discount_in_amount;
          if (discount > coupon_check.maximum_discount_amount) {
            discount = coupon_check.maximum_discount_amount;
          } else {
            discount = discount;
          }

          discount_type = coupon_check.is_percent ? "percent" : "amount";
        }
      }
    }
  }

  if (coupon_name) {
    let c_name = coupon_name.toUpperCase();
    let coupon_check = await coupon_val_check(c_name);

    if (coupon_check) {
      coupon_id = coupon_check._id;

      let coupon_count = await Order.find({
        coupon_id: coupon_id,
        customer_id: body.id,
      }).count();

      if (coupon_check.use_limit > 0 && coupon_count > coupon_check.use_limit) {
        body.coupon_msg = coupon_name + " limit is over!";
      } else {
        let get_coupon_type = coupon_check.coupon_type_name;
        let minimum_order_amount = coupon_check.minimum_order_amount;
        let diff = minimum_order_amount - total;

        if (minimum_order_amount >= total) {
          //Check Min order value
          body.coupon_msg = "Add TK " + diff + " to use this voucher";
        } else {
          //Check type wise validation
          if (get_coupon_type == "user_wise") {
            wise_coupon_check = await CustomerCoupon.findOne({
              customer_id: body.id,
              coupon_id: coupon_id,
            });
            if (wise_coupon_check) {
              // if (coupon_check.maximum_discount_amount)
              discount += coupon_check.is_percent
                ? (parseFloat(coupon_check.discount_in_percent) / 100) * total
                : parseFloat(coupon_check.discount_in_amount);

              discount_value = coupon_check.is_percent
                ? coupon_check.discount_in_percent
                : coupon_check.discount_in_amount;
              if (discount > coupon_check.maximum_discount_amount) {
                discount = coupon_check.maximum_discount_amount;
              } else {
                discount = discount;
              }

              discount_type = coupon_check.is_percent ? "percent" : "amount";
            } else {
              body.coupon_msg = coupon_name + " is not available for you!";
            }
          } else if (get_coupon_type == "branch_wise") {
            wise_coupon_check = await BranchCoupon.findOne({
              branch_id: restaurant_id,
              coupon_id: coupon_id,
            });
            // return wise_coupon_check;
            if (wise_coupon_check) {
              discount += coupon_check.is_percent
                ? (parseFloat(coupon_check.discount_in_percent) / 100) * total
                : parseFloat(coupon_check.discount_in_amount);

              discount_value = coupon_check.is_percent
                ? coupon_check.discount_in_percent
                : coupon_check.discount_in_amount;
              if (discount > coupon_check.maximum_discount_amount) {
                discount = coupon_check.maximum_discount_amount;
              } else {
                discount = discount;
              }

              discount_type = coupon_check.is_percent ? "percent" : "amount";
            } else {
              body.coupon_msg = coupon_name + " is not available for this restaurant!";
            }
          } else if (get_coupon_type == "zone_wise") {
            wise_coupon_check = await ZoneCoupon.findOne({
              zone_id: zone_id,
              coupon_id: coupon_id,
            });
            // return wise_coupon_check;
            if (wise_coupon_check) {
              discount += coupon_check.is_percent
                ? (parseFloat(coupon_check.discount_in_percent) / 100) * total
                : parseFloat(coupon_check.discount_in_amount);

              discount_value = coupon_check.is_percent
                ? coupon_check.discount_in_percent
                : coupon_check.discount_in_amount;
              if (discount > coupon_check.maximum_discount_amount) {
                discount = coupon_check.maximum_discount_amount;
              } else {
                discount = discount;
              }

              discount_type = coupon_check.is_percent ? "percent" : "amount";
            } else {
              body.coupon_msg = coupon_name + " is not available in this zone!";
            }
          } else if (get_coupon_type == "cuisine_wise") {
            wise_coupon_check = await CuisineCoupon.aggregate([
              {
                $match: {
                  coupon_id: coupon_id,
                  cuisine_id: {
                    $in: cuisines ? cuisines.map((cs) => cs.cuisine_id) : [],
                  },
                },
              },
            ]);
            // return wise_coupon_check;
            if (wise_coupon_check) {
              discount += coupon_check.is_percent
                ? (parseFloat(coupon_check.discount_in_percent) / 100) * total
                : parseFloat(coupon_check.discount_in_amount);

              discount_value = coupon_check.is_percent
                ? coupon_check.discount_in_percent
                : coupon_check.discount_in_amount;
              if (discount > coupon_check.maximum_discount_amount) {
                discount = coupon_check.maximum_discount_amount;
              } else {
                discount = discount;
              }

              discount_type = coupon_check.is_percent ? "percent" : "amount";
            } else {
              body.coupon_msg = coupon_name + " is not available for this cuisine!";
            }
          } else if (get_coupon_type == "gradual_wise") {
            let grad_coupon_count = await Order.find({
              branch_id: restaurant_id,
              coupon_id: coupon_id,
              customer_id: body.id,
            }).count();

            wise_coupon_check = await GradualInformation.findOne({
              coupon_id: coupon_id,
            }).sort({ _id: -1 });

            if (wise_coupon_check) {
              let sequence = wise_coupon_check.sequence;
              let new_seq = grad_coupon_count + 1;
              if (sequence == new_seq) {
                discount += coupon_check.is_percent
                  ? (parseFloat(coupon_check.discount_in_percent) / 100) * total
                  : parseFloat(coupon_check.discount_in_amount);

                discount_value = coupon_check.is_percent
                  ? coupon_check.discount_in_percent
                  : coupon_check.discount_in_amount;
                if (discount > coupon_check.maximum_discount_amount) {
                  discount = coupon_check.maximum_discount_amount;
                } else {
                  discount = discount;
                }
              } else {
                body.coupon_msg = coupon_name + " is not available for you!";
              }
              discount_type = coupon_check.is_percent ? "percent" : "amount";
            } else {
              body.coupon_msg = coupon_name + " is not available for you!";
            }
          } else if (get_coupon_type == "category_wise") {
            for (const order_data_key in order_data) {
              const menu = order_data[order_data_key];
              console.log("menud", menu);
              wise_coupon_check = await CategoryCoupon.findOne({
                category_id: menu.category_id,
                coupon_id: coupon_id,
              });
              console.log("wise_coupon_check", wise_coupon_check);
              if (wise_coupon_check) {
                discount += coupon_check.is_percent
                  ? (parseFloat(coupon_check.discount_in_percent) / 100) * menu.item_total
                  : parseFloat(coupon_check.discount_in_amount);
                console.log("discount", discount);
                discount_value = coupon_check.is_percent
                  ? coupon_check.discount_in_percent
                  : coupon_check.discount_in_amount;
                if (discount > coupon_check.maximum_discount_amount) {
                  discount = coupon_check.maximum_discount_amount;
                } else {
                  discount = discount;
                }
                discount_type = coupon_check.is_percent ? "percent" : "amount";
              }

              if (discount <= 0) {
                body.coupon_msg = coupon_name + " is not available !";
              }
            }
          } else if (get_coupon_type == "menu_item_wise") {
            for (const order_data_key in order_data) {
              const menu = order_data[order_data_key];
              console.log("menud", menu);
              wise_coupon_check = await MenuItemCoupon.findOne({
                menu_item_id: menu._id,
                coupon_id: coupon_id,
              });
              console.log("wise_coupon_check", wise_coupon_check);
              if (wise_coupon_check) {
                discount += coupon_check.is_percent
                  ? (parseFloat(coupon_check.discount_in_percent) / 100) * menu.item_total
                  : parseFloat(coupon_check.discount_in_amount);
                console.log("discount", discount);
                discount_value = coupon_check.is_percent
                  ? coupon_check.discount_in_percent
                  : coupon_check.discount_in_amount;
                if (discount > coupon_check.maximum_discount_amount) {
                  discount = coupon_check.maximum_discount_amount;
                } else {
                  discount = discount;
                }
                discount_type = coupon_check.is_percent ? "percent" : "amount";
              }
            }

            if (discount <= 0) {
              body.coupon_msg = coupon_name + " is not available!";
            }
          } else if (get_coupon_type === "subscription_wise") {
            wise_coupon_check = await SubscriptionTypeCoupon.findOne({
              subscription_type_id: subscription_type_id,
              coupon_id: coupon_id,
            });
            // return wise_coupon_check;
            if (wise_coupon_check) {
              discount += coupon_check.is_percent
                ? (parseFloat(coupon_check.discount_in_percent) / 100) * total
                : parseFloat(coupon_check.discount_in_amount);

              discount_value = coupon_check.is_percent
                ? coupon_check.discount_in_percent
                : coupon_check.discount_in_amount;
              if (discount > coupon_check.maximum_discount_amount) {
                discount = coupon_check.maximum_discount_amount;
              } else {
                discount = discount;
              }

              discount_type = coupon_check.is_percent ? "percent" : "amount";
            } else {
              body.coupon_msg = coupon_name + " is not available for this cuisine!";
            }
          } else {
            discount += coupon_check.is_percent
              ? (parseFloat(coupon_check.discount_in_percent) / 100) * total
              : parseFloat(coupon_check.discount_in_amount);

            discount_value = coupon_check.is_percent
              ? coupon_check.discount_in_percent
              : coupon_check.discount_in_amount;
            if (discount > coupon_check.maximum_discount_amount) {
              discount = coupon_check.maximum_discount_amount;
            } else {
              discount = discount;
            }

            discount_type = coupon_check.is_percent ? "percent" : "amount";
          }
        }
      }
    } else {
      body.coupon_msg = coupon_name + " is not available!";
    }
  }

  grand_total = total + total_sd + total_vat + delivery_charge - discount;
  body.pickup_time = res_zone_check[0]["pickup_time"];
  body.menu_data = menus;
  body.coupon_name = coupon_name;
  body.discount_type = discount_type;
  body.total = grand_total.toFixed(2);
  body.price = [
    {
      name: "subtotal",
      display: "Subtotal",
      value: total.toFixed(2),
    },
    {
      name: "total_vat",
      display: "VAT (inc.)",
      value: total_vat.toFixed(2),
    },
    {
      name: "total_sd",
      display: "SD (inc.)",
      value: total_sd.toFixed(2),
    },
    {
      name: "total_discount",
      display:
        discount_type === "percent" ? "Discount(" + discount_value + "%)" : "Discount",
      value: discount.toFixed(2),
    },
    {
      name: "discount_value",
      display: "Discount Value",
      value: discount_value.toFixed(2),
      discount_type: discount_type,
    },
    {
      name: "total",
      display: "Total",
      value: grand_total.toFixed(2),
    },
  ];
  const cart_update = await CartModel.findOneAndUpdate(
    { customer_id: user_id },
    {
      customer_id: user_id,
      branch_id: restaurant_id,
      coupon_id: coupon_id,
      user_lat: lat,
      user_long: long,
      total_amount: grand_total,
      cart_details: menu_data,
      cart_type: "pickup",
      created_by: user_id,
      updated_by: user_id,
    },
    {
      upsert: true,
      new: true,
      setDefaultsOnInsert: true,
      rawResult: true,
    }
  );
  if (cart_update && cart_update.lastErrorObject.updatedExisting == false) {
    await Send_Queue(cms_queue, "restaurant_queue", cart_update.value, "cart", "add");
    //   await Send_Central(cart_update, "cart", "add");
    console.log("Document Inserted");
  }
  if (cart_update && cart_update.lastErrorObject.updatedExisting == true) {
    await Send_Queue(cms_queue, "restaurant_queue", cart_update.value, "cart", "edit");
    //await Send_Central(cart_update, "cart", "edit");
    console.log("Document Updated");
  }
  if (!cart_update)
    return res.json({
      status: -1,
      msg: "Something went wrong",
    });
  /** Coupon check  End*/
  return res.json({
    status: 0,
    data: body,
  });
}
