import City from "../../models/Restaurant/City.js";
import Zone from "../../models/Zone/Zone.js";
import ZoneDeliveryCharge from "../../models/Zone/ZoneDeliveryCharge.js";
import Campaign from "../../models/Campaign/CampaignModel.js";
import Cuisine from "../../models/Cuisines/CuisineModel.js";
import Promotion from "../../models/Promotion/PromotionModel.js";
import PopUpBanner from "../../models/Promotion/PopUpBanner.js";
import Menu from "../../models/Restaurant/Menu.js";
import Category from "../../models/Restaurant/Category.js";
import Variation from "../../models/Restaurant/Variations.js";
import AddOnCategory from "../../models/Restaurant/AddOnCategory.js";
import AddOn from "../../models/Restaurant/AddOnList.js";
import Review from "../../models/Restaurant/Reviews.js";
import PaymentMethod from "../../models/Payment/PaymentMethodModel.js";
import RestaurentModel from "../../models/Restaurant/RestaurentModel.js";
import ParentRestaurants from "../../models/Restaurant/ParentRestaurant.js";
import MenuItemAndMenuItemTimeSlot from "../../models/Restaurant/Menu/MenuItemAndMenuItemTimeSlot.js";
import MenuItemTimeSlot from "../../models/Restaurant/Menu/MenuItemTimeSlot.js";
import CartModel from "../../models/Order/CartModel.js";
import OrderModel from "../../models/Order/Order.js";
import { Send_Central, Send_Queue } from "./RMQ.js";
import PointSetter from "../../models/Rewards/PointSetter.js";
import VoucherSetting from "../../models/Rewards/VoucherSetting.js";
import CouponModel from "../../models/Coupon/CouponModel.js";
import ZoneCoupon from "../../models/Coupon/ZoneCoupon.js";
import BranchCoupon from "../../models/Coupon/BranchCoupon.js";
import CuisineCoupon from "../../models/Coupon/CuisineCoupon.js";
import CategoryCoupon from "../../models/Coupon/CategoryCoupon.js";
import SubscriptionTypeCoupon from "../../models/Coupon/SubscriptionTypeCoupon.js";
import BrancAttributes from "../../models/BranchAttributes/BrancAttributes.js";
import SystemOption from "../../models/Faq & Setting/SystemOption.js";
import SystmeOnOffReason from "../../models/Faq & Setting/SystmeOnOffReason.js";
import FAQ from "../../models/Faq & Setting/Faq.js";
import PlatfromOperationTimeSlot from "../../models/Faq & Setting/PlatfromOperationTimeSlot.js";
import CustomerCoupon from "../../models/Coupon/CustomerCoupon.js";
import MenuItemCoupon from "../../models/Coupon/MenuItemCoupon.js";
import GradualInformation from "../../models/Coupon/GradualInformation.js";
import RevokedTokenModel from "../../models/RevokedToken.js";
import RewardLevel from "../../models/Rewards/RewardLevel.js";
import VoucherRequest from "../../models/Rewards/VoucherRequest.js";
import { create_index } from "./ElasticSearch.js";
import EarnBurnHistory from "../../models/Rewards/EarnBurnHistory.js";
import RestaurantUser from "../../models/RestaurantUser/RestaurantUser.js";
import DineInCard from "../../models/DineInCard/DineInCard.js";
import { autoRouting } from "./AutoRouting.js";
import { get_point } from "./Calculation.js";
const models = {
  City: City,
  Zone: Zone,
  FAQ: FAQ,
  Campaign: Campaign,
  Cuisine: Cuisine,
  Promotion: Promotion,
  PopUpBanner: PopUpBanner,
  MenuItem: Menu,
  Category: Category,
  Variation: Variation,
  AddOnCategory: AddOnCategory,
  AddOn: AddOn,
  Review: Review,
  PaymentMethod: PaymentMethod,
  Branch: RestaurentModel,
  Restaurant: ParentRestaurants,
  MenuItemTimeSlot: MenuItemTimeSlot,
  CartModel: CartModel,
  OrderModel: OrderModel,
  RewardPointSetting: PointSetter,
  VoucherSetting: VoucherSetting,
  Coupon: CouponModel,
  ZoneCoupon: ZoneCoupon,
  BranchCoupon: BranchCoupon,
  CuisineCoupon: CuisineCoupon,
  CategoryCoupon: CategoryCoupon,
  SubscriptionTypeCoupon: SubscriptionTypeCoupon,
  BranchAttribute: BrancAttributes,
  SystemOption: SystemOption,
  SystemOnOffReason: SystmeOnOffReason,
  PlatfromOperationTimeSlot: PlatfromOperationTimeSlot,
  RevokedTokenModel: RevokedTokenModel,
  RewardLevel: RewardLevel,
  VoucherRequest: VoucherRequest,
  EarnBurnHistory: EarnBurnHistory,
  CustomerCoupon: CustomerCoupon,
  RestaurantUser: RestaurantUser,
  DineInCard: DineInCard,
};
export const SocketService = async (Request, DataModel) => {
  try {
    let MODEL = models[DataModel];
    let data = await MODEL.findOneAndUpdate(
      { _id: Request._id },
      { $set: Request },
      { returnOriginal: false }
    );

    let status = data.order_status,
      socket_data = {};
    //   return { status: 'success', data: data };
    //    if (status === 'accepted' ||  status === 'ongoing' || status === 'preparing' || status === 'drop_off' || status === 'delivered' || status === 'confirm_drop_off' ) {
    if (data) {
      const order_id = data._id;
      // global.io.sockets.sockets.forEach((socket) => {
      //   const socketOrderId =
      //     socket.handshake.headers.cookie?.match(/order_id=([^;]*)/)?.[1];
      //   if (socketOrderId === order_id) {
      //     socket.join(`order-${socketOrderId}`);
      //     global.io.to(`order-${socketOrderId}`).emit("order-status", data);
      //   }
      // });

      if (data.rider_id) {
        let rider_details;
        rider_details = await Send_Queue(
          "main_rider_request",
          "restaurant_queue",
          {
            _id: data.rider_id,
            project: { _id: 1, first_name: 1, last_name: 1, mobile_number: 1, image: 1 },
          },
          "RiderModel",
          "get"
        );

        rider_details.data.rating = 3.2;
        data._doc.rider_details = rider_details.data ? rider_details.data : null;

        global.io.sockets.sockets.forEach((socket) => {
          const socketOrderId =
            socket.handshake.headers.cookie?.match(/order_id=([^;]*)/)?.[1];
          if (socketOrderId === order_id) {
            socket.join(`order-${socketOrderId}`);
            socket.once("order-status", (receivedData) => {
              console.log("Received order-status data:", receivedData);
            });
            socket.emit("order-status", data); // Pass the updated data object
            //   socket.disconnect();
          }
        });
      }

      return { status: "success", data: data };
    } else {
      return { status: "failed" };
    }
  } catch (error) {
    console.error(error);
    return { status: "failed" };
  }
};

export const CreateService = async (Request, DataModel) => {
  try {
    // fs.writeFileSync("./sampledata.json", JSON.stringify(Request), "utf-8");
    // let PostBody=Request.body;
    if (DataModel == "Zone") {
      let zone_delivery_charge_data = Request.zone_delivery_charges;
      let create_data = await ZoneDeliveryCharge.insertMany(zone_delivery_charge_data);

      let branches = Request.branches;
      branches.map(async (key, item) => {
        let updateRestaurant = await RestaurentModel.updateOne(
          { _id: key.branch_id },
          {
            $addToSet: {
              zone_id: { _id: key.zone_id },
            },
          }
        );
      });

      Request = {
        _id: Request._id,
        name: Request.name,
        radius: Request.radius,
        city_id: Request.city_id,
        is_active: Request.is_active,
        lat_long: Request.lat_long,
        created_at: Request.created_at,
        created_by: Request.created_by,
        updated_at: Request.updated_at,
        updated_by: Request.updated_by,
      };
    }

    if (DataModel == "MenuItem") {
      const indexing = await create_index(Request.menu_name,Request._id);
      console.log("Request", Request);

      const menu_item_time_map = Request.menu_available_times;
      if (menu_item_time_map) {
        let create_data = await MenuItemAndMenuItemTimeSlot.insertMany(
          menu_item_time_map
        );
      }
      // if (create_data) {
      delete Request["menu_available_times"];
      // }

      if (Request.has_variation == 1) {
        let variation_list = [];
        let addon_cat_list = [];
        let addons_list = [];
        let variations = Request.variations;
        if (variations) {
          for (let i = 0; i < variations.length; i++) {
            variation_list.push(variations[i]);
            if (variations[i].add_on_categories) {
              for (let j = 0; j < variations[i].add_on_categories.length; j++) {
                variations[i].add_on_categories[j].name =
                  variations[i].add_on_categories[j].add_on_category_name;
                addon_cat_list.push(variations[i].add_on_categories[j]);
                if (variations[i].add_on_categories[j].add_ons) {
                  for (
                    let k = 0;
                    k < variations[i].add_on_categories[j].add_ons.length;
                    k++
                  ) {
                    addons_list.push(variations[i].add_on_categories[j].add_ons[k]);
                  }
                }
              }
            }
          }
        }

        console.log("variation_list :", variation_list);
        console.log("addon_cat_list :", addon_cat_list);
        console.log("addons_list :", addons_list);

        try {
          let create_data = await Variation.insertMany(variation_list);
          create_data = await AddOnCategory.insertMany(addon_cat_list);
          create_data = await AddOn.insertMany(addons_list);
        } catch (err) {
          console.error("err :", err);
        }

        delete Request["variations"];
      }
    }

    if (DataModel == "Coupon") {
      console.log(Request);
      await BranchCoupon.insertMany(Request.branches);
      await CategoryCoupon.insertMany(Request.categories);
      await CustomerCoupon.insertMany(Request.customers);
      await MenuItemCoupon.insertMany(Request.menu_items);
      await SubscriptionTypeCoupon.insertMany(Request.subscription_types);
      await ZoneCoupon.insertMany(Request.zones);
      await GradualInformation.insertMany(Request.gradual_informations);
    }

    if (DataModel == "Branch" || DataModel == "Cuisine") {
      await create_index(Request.name);
      let MODEL = models[DataModel];
      try {
        let data = await MODEL.create(Request);
        if (data) return { status: "success", data: data };
      } catch (err) {
        console.error(err);
        return { status: "failed" };
      }
    }

    let MODEL = models[DataModel];
    try {
      let data = await MODEL.create(Request);
      if (data) return { status: "success", data: data };
    } catch (err) {
      console.error(err);
      return { status: "failed" };
    }
  } catch (error) {
    return { status: "fail" };
  }
};

export const UpdateService = async (Request, DataModel) => {
  try {
    if (DataModel == "Zone") {
      let zone_delivery_charge_data = Request.zone_delivery_charges;
      let delete_delivery_charge = await ZoneDeliveryCharge.deleteMany({
        zone_id: Request._id,
      });

      let create_data = await ZoneDeliveryCharge.insertMany(zone_delivery_charge_data);

      let branches = Request.branches;
      branches.map(async (key, item) => {
        let updateRestaurant = await RestaurentModel.updateOne(
          { _id: key.branch_id },
          {
            $addToSet: {
              zone_id: { _id: key.zone_id },
            },
          }
        );
      });

      Request = {
        _id: Request._id,
        name: Request.name,
        radius: Request.radius,
        city_id: Request.city_id,
        is_active: Request.is_active,
        lat_long: Request.lat_long,
        created_at: Request.created_at,
        created_by: Request.created_by,
        updated_at: Request.updated_at,
        updated_by: Request.updated_by,
      };
    }

    if (DataModel == "MenuItem") {
      const menu_item_time_map = Request.menu_available_times;
      let delete_data = await MenuItemAndMenuItemTimeSlot.deleteMany({
        menu_item_id: Request._id,
      });

      let create_data = await MenuItemAndMenuItemTimeSlot.insertMany(menu_item_time_map);

      // if (create_data) {
      delete Request["menu_available_times"];
      // }

      if (Request.has_variation == 1) {
        let variation_list = [];
        let addon_cat_list = [];
        let addons_list = [];
        let variations = Request.variations;
        if (variations) {
          for (let i = 0; i < variations.length; i++) {
            variation_list.push(variations[i]);
            if (variations[i].add_on_categories) {
              for (let j = 0; j < variations[i].add_on_categories.length; j++) {
                variations[i].add_on_categories[j].name =
                  variations[i].add_on_categories[j].add_on_category_name;
                addon_cat_list.push(variations[i].add_on_categories[j]);
                if (variations[i].add_on_categories[j].add_ons) {
                  for (
                    let k = 0;
                    k < variations[i].add_on_categories[j].add_ons.length;
                    k++
                  ) {
                    addons_list.push(variations[i].add_on_categories[j].add_ons[k]);
                  }
                }
              }
            }
          }
        }

        console.log("variation_list :", variation_list);
        console.log("addon_cat_list :", addon_cat_list);
        console.log("addons_list :", addons_list);

        try {
          let delete_data = await Variation.deleteMany({ menu_id: Request._id });
          let create_data = await Variation.insertMany(variation_list);
          create_data = await AddOnCategory.insertMany(addon_cat_list);
          create_data = await AddOn.insertMany(addons_list);
        } catch (err) {
          console.error("err :", err);
        }

        delete Request["variations"];
      }
    }

    if (DataModel == "Coupon") {
      // Delete previous data
      await BranchCoupon.deleteMany({ coupon_id: Request._id });
      await CategoryCoupon.deleteMany({ coupon_id: Request._id });
      await CustomerCoupon.deleteMany({ coupon_id: Request._id });
      await MenuItemCoupon.deleteMany({ coupon_id: Request._id });
      await SubscriptionTypeCoupon.deleteMany({ coupon_id: Request._id });
      await ZoneCoupon.deleteMany({ coupon_id: Request._id });
      await GradualInformation.deleteMany({ coupon_id: Request._id });

      // Insert data
      await BranchCoupon.insertMany(Request.branches);
      await CategoryCoupon.insertMany(Request.categories);
      await CustomerCoupon.insertMany(Request.customers);
      await MenuItemCoupon.insertMany(Request.menu_items);
      await SubscriptionTypeCoupon.insertMany(Request.subscription_types);
      await ZoneCoupon.insertMany(Request.zones);
      await GradualInformation.insertMany(Request.gradual_informations);
    }

    if (DataModel == "OrderModel") {
      let data = await OrderModel.findOneAndUpdate(
        { _id: Request._id },
        { $set: Request },
        { returnOriginal: false }
      );
      if (data.order_status === "accepted") {
        let rest_id = data.branch_id;
        let order_id = data._id;
        let zone_id = data.zone_id;
        const rest_details = await RestaurentModel.findById(rest_id, {
          name: 1,
          location: 1,
        });
        let rest_name = rest_details.name;
        let rest_lat = parseFloat(rest_details.location.coordinates[1]);
        let rest_long = parseFloat(rest_details.location.coordinates[0]);
        await autoRouting(order_id, zone_id, rest_name, rest_lat, rest_long);
      }
    }

    let MODEL = models[DataModel];
    try {
      console.log("DataModel", DataModel);
      let data = await MODEL.findOneAndUpdate(
        { _id: Request._id },
        { $set: Request },
        { returnOriginal: false }
      );
      console.log("DATA", data);

      //  Send_Central(data,'customer','edit')

      if (data) return { status: "success", data: data };
    } catch (err) {
      console.error(err.toString());
      return { status: "failed", err: err.toString() };
    }
  } catch (error) {
    return { status: "failed" };
  }
};

export const UpdateByCondition = async (Request, DataModel) => {
  try {
    let MODEL = models[DataModel];
    let condition = Request.condition;
    let update_data = Request.data;
    let data = await MODEL.updateOne(condition, update_data);
    if (data) return { status: "success", data: data };
  } catch (error) {
    return { status: "failed", err: error.toString() };
  }
};

export const DeleteService = async (Request, DataModel) => {
  try {
    if (DataModel == "Zone") {
      let delete_delivery_charge = await ZoneDeliveryCharge.deleteMany({
        zone_id: Request._id,
      });

      let updateRestaurant = await RestaurentModel.updateMany(
        { "zone_id._id": Request._id },
        {
          $pull: {
            zone_id: { _id: Request._id },
          },
        }
      );
    }

    if (DataModel == "MenuItem") {
      const menu_item_time_map = Request.menu_item_and_menu_item_time_slots;
      const delete_data = await MenuItemAndMenuItemTimeSlot.deleteMany({
        menu_item_id: Request._id,
      });
    }

    let MODEL = models[DataModel];
    let data = await MODEL.deleteMany({ _id: Request._id });

    if (data) return { status: "success" };
  } catch (error) {
    return { status: "failed" };
  }
};

export const GetService = async (Request, DataModel) => {
  try {
    return new Promise(async (resolve, reject) => {
      let MODEL = models[DataModel];
      let data = await MODEL.findOne(Request);
      if (data) resolve({ data: data });
      reject({
        status: "Failed",
      });
    });
  } catch (error) {
    return { status: "Failed Fetch" };
  }
};

export const GetCustomerPoint = async (Request, DataModel) => {
  try {
    return new Promise(async (resolve, reject) => {
      let MODEL = models[DataModel];
      let data = await get_point(Request.subscription_type_id);
      if (data) resolve(data);
      reject({
        status: "Failed",
      });
    });
  } catch (error) {
    return { status: "Failed Fetch" };
  }
};

export const GetServiceWithJoin = async (Request, DataModel) => {
  try {
    console.log("GetServiceWithJoin Request:", Request);
    return new Promise(async (resolve, reject) => {
      let MODEL = models[DataModel];
      const data = await MODEL.aggregate([Request]);
      if (data && data.length > 0) {
        resolve({ data: data.shift() });
      } else {
        reject({ status: "No data found" });
      }
    });
  } catch (error) {
    console.error("Error in GetServiceWithJoin:", error.toString());
    return { status: "Failed Fetch", err: error.toString() };
  }
};
