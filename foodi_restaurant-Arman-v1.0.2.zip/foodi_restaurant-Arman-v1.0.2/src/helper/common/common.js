import { Send_Queue } from "./RMQ.js";
import Order from "../../models/Order/Order.js";

export async function riderOrderCount(rider_json) {
  try {
    const data = await Order.aggregate([
      {
        $match: {
          rider_id: { $in: Object.keys(rider_json) },
          order_status: { $in: ["assigned", "preparing", "ongoing"] },
        },
      },
      {
        $group: {
          _id: "$rider_id",
          count: { $sum: 1 },
        },
      },
      {
        $project: {
          rider_id: "$_id",
          count: 1,
          _id: 0,
        },
      },
    ]);

    return data;
  } catch (error) {
    console.error("Error fetching user data:", error);
    throw new Error("Failed to fetch rider order count data");
  }
}
export async function userData(user_id) {
  try {
    const data = await Send_Queue(
      "main_user_request",
      "restaurant_queue",
      { _id: user_id },
      "UserModel",
      "get"
    );

    return data.data;
  } catch (error) {
    console.error("Error fetching user data:", error);
    throw new Error("Failed to fetch rider data");
  }
}

export async function riderData(rider_id) {
  try {
    const data = await Send_Queue(
      "main_rider_request",
      "restaurant_queue",
      { _id: rider_id },
      "RiderModel",
      "get"
    );

    return data.data;
  } catch (error) {
    console.error("Error fetching user data:", error);
    throw new Error("Failed to fetch user data");
  }
}
