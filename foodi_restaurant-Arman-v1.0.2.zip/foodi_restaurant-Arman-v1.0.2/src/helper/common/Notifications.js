import admin from "firebase-admin";

import serviceAccount from "../../../serviceAccountKey.json" assert { type: "json" };
import serviceAccountPortal from "../../../serviceAccountKeyPortal.json" assert { type: "json" };

const firstApp = admin.initializeApp(
  {
    credential: admin.credential.cert(serviceAccount),
  },
  "firstApp"
);

const portalApp = admin.initializeApp(
  {
    credential: admin.credential.cert(serviceAccountPortal),
  },
  "portalApp"
);

export const sendNotifications = async (message) => {
  try {
    const response = await firstApp.messaging().send(message);
    console.log("Successfully sent message:", response);
    return { status: "success", data: response };
  } catch (error) {
    return { status: "failed", error: error.toString() };
  }
};
export const sendMuiltiNotifications = async (message) => {
  try {
    const response = await portalApp.messaging().sendMulticast(message);
    console.log("Successfully sent message:", response);
    return { status: "success", data: response.responses };
  } catch (error) {
    return { status: "failed", error: error.toString() };
  }
};
