import dotenv from "dotenv";
import axios from "axios";
dotenv.config();
const url = process.env.ELASTIC_URL;

export const create_index = async (msg,id) => {
  try {
    const insertData = {
      message: msg,
        id:id
    };
    const searchQuery = {
      query: {
        bool: {
          must: [{ match: { id: insertData.id } }],
        },
      },
    };
    const searchResponse = await axios.post(`${url}_search`, searchQuery);

    if (searchResponse.data.hits.total > 0) {
      const existingData = searchResponse.data.hits.hits[0]._source;
      return existingData;
    } else {
      const insertResponse = await axios.post(`${url}/foodi`, insertData);
      console.log(insertResponse.data);
      return insertResponse.data;
    }
  } catch (error) {
    return false;
  }
};
