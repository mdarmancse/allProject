import { redis_get_all } from "../redis.js";
import Order from "../../models/Order/Order.js";
import { Send_Queue } from "./RMQ.js";
import Zone from "../../models/Zone/Zone.js";
import SystemOption from "../../models/Faq & Setting/SystemOption.js";
import { v4 as uuidv4 } from "uuid";
import { riderOrderCount } from "./common.js";
export async function autoRouting(order_id, zone_id, rest_name, lat, long) {
  try {
    const system_options = await SystemOption.getSystemOption();
    const is_auto_routing = JSON.parse(system_options.is_auto_routing);
    if (is_auto_routing === true) {
      const order_data = {
        _id: order_id,
        lat: lat,
        long: long,
      };
      let riders_redis_data = await redis_get_all("rider_location");
      const check_riders = await Send_Queue(
        "main_rider_request",
        "restaurant_queue",
        { rider_json: riders_redis_data, zone_id: zone_id },
        "RiderModel",
        "checkRider"
      );

      const rider_order_count = await riderOrderCount(riders_redis_data);
      const check_rider_ids = new Set(check_riders.data.map((rider) => rider._id));
      for (const check_rider of check_riders.data) {
        for (const rider of rider_order_count) {
          if (!check_rider.is_available && rider.count >= check_rider.rider_max_order) {
            delete riders_redis_data[check_rider._id];
          }
        }
      }
      for (const rider_id in riders_redis_data) {
        if (!check_rider_ids.has(rider_id)) {
          delete riders_redis_data[rider_id];
        }
      }
      const MAX_EXECUTION_COUNT = JSON.parse(system_options.max_iteration_of_rider);
      const zone_radius = JSON.parse(system_options.rider_assign_radius);
      const SET_TIME_OUT = JSON.parse(system_options.iteration_interval) * 1000;
      let iterationCount = 0;
      let riderAccepted = false;
      let allocatedRiderId;

      while (iterationCount < MAX_EXECUTION_COUNT && !riderAccepted) {
        iterationCount++;
        const riders_redis_data_parse = {};
        for (let riderId in riders_redis_data) {
          const riderDataString = riders_redis_data[riderId];
          const riderData = JSON.parse(JSON.parse(riderDataString));
          riders_redis_data_parse[riderId] = {
            lat: riderData.lat,
            long: riderData.long,
            executionCount: 0,
          };
        }

        const targetLat = order_data.lat;
        const targetLon = order_data.long;
        let nearestRiders = [];
        if (riders_redis_data_parse) {
          nearestRiders = Object.entries(riders_redis_data_parse)
            .map(([riderId, riderData]) => {
              const { lat, long } = riderData;
              return {
                riderId,
                distance: calculateDistance(targetLat, targetLon, lat, long),
                executionCount: riderData.executionCount,
              };
            })
            .filter((rider) => rider.distance.distance <= zone_radius)
            .filter((rider) => rider.executionCount <= MAX_EXECUTION_COUNT) // Filter out riders with exceeded execution count
            .sort(
              (rider1, rider2) => rider1.distance.distance - rider2.distance.distance
            );
        }

        if (nearestRiders.length > 0) {
          const allocatedRider = nearestRiders[0];
          allocatedRiderId = allocatedRider.riderId;

          await allocateRiderToOrder(order_id, allocatedRider.riderId);

          const order = await Order.findOne({ _id: order_id });
          riderAccepted = order.rider_accepted;

          let rider_socket_body = {
            _id: uuidv4(),
            rider_id: allocatedRiderId,
            order_id: order_id,
            order_status: "assigned",
            customer_name: order.customer_name,
            branch_name: rest_name,
          };
          console.log("rider_socket_body", rider_socket_body);

          const socket_add = await Send_Queue(
            "main_rider_request",
            "restaurant_queue",
            rider_socket_body,
            "RidersOrder",
            "socket_add"
          );

          if (riderAccepted) {
            return {
              status: 1,
              msg: "Rider allocated successfully",
              riderId: allocatedRiderId,
            };
            break;
          }

          await new Promise((resolve) => setTimeout(resolve, SET_TIME_OUT));

          if (!riderAccepted) {
            await Send_Queue(
              "main_rider_request",
              "restaurant_queue",
              {
                _id: socket_add.data._id,
                order_status: "cancel_by_rider",
              },
              "RidersOrder",
              "edit"
            );
          }

          const updatedOrder = await Order.findOne({ _id: order_id });
          riderAccepted = updatedOrder.rider_accepted;

          if (!riderAccepted) {
            delete riders_redis_data[allocatedRider.riderId];
          }

          riders_redis_data_parse[allocatedRider.riderId].executionCount++;
        }
      }

      if (riderAccepted) {
        return {
          status: 1,
          msg: "Rider allocated successfully",
          riderId: allocatedRiderId,
        };
      } else {
        await allocateRiderToOrder(order_id, null);
        return { status: 1, msg: "No available riders" };
      }
    } else {
      return { status: 1, msg: "Auto Routing not available" };
    }
  } catch (err) {
    console.error(err);
    return { status: -1, msg: "Server error", err: err.toString() };
  }
}

export async function allocateRiderToOrder(orderId, riderId) {
  try {
    const updatedOrder = await Order.findByIdAndUpdate(
      orderId,
      { rider_id: riderId },
      { new: true }
    );

    const riderAccepted = updatedOrder.rider_accepted;

    return { updatedOrder, riderAccepted };
  } catch (err) {
    console.error(err);
    throw new Error("Failed to allocate rider to order");
  }
}
// Function to calculate distance between coordinates
function calculateDistance(lat1, lon1, lat2, lon2) {
  const R = 6371; // Radius of the Earth in kilometers
  const dLat = degToRad(lat2 - lat1);
  const dLon = degToRad(lon2 - lon1);

  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(degToRad(lat1)) *
      Math.cos(degToRad(lat2)) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const distance = R * c;

  const p1 = { x: lat1, y: lon1 };
  const p2 = { x: lat2, y: lon2 };
  const x = p1.x - p2.x;
  const y = p1.y - p2.y;
  const radius = Math.sqrt(x * x + y * y);

  return { distance: distance, radius: radius };
}
function degToRad(degrees) {
  return degrees * (Math.PI / 180);
}
