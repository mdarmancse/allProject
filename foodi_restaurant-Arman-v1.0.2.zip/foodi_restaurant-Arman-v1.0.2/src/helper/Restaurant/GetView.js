import RestaurentModel from "../../models/Restaurant/RestaurentModel.js";
import MenuModel from "../../models/Restaurant/Menu.js";
import RestaurantDistance from "../../helper/Restaurant/RestaurantDistance.js";
import { res_basic_data } from "../../utility/const.js";
import moment from "moment";
import { SYSTEM_TIMEZONE } from "../../consts/defaults.js";

const GetView = async (rest_id, user_lat, user_long, user_id) => {
  try {
    let restaurant, populer_menu;

    restaurant = await RestaurentModel.aggregate([
      { $match: { _id: rest_id, is_delivery: true, is_active: true } },
      {
        $lookup: {
          from: "favourite_restaurants",
          localField: "_id",
          foreignField: "branch_id",
          pipeline: [{ $match: { customer_id: user_id, is_delivery: true } }],
          as: "is_favourite",
        },
      },
      {
        $lookup: {
          from: "branch_coupons",
          localField: "_id",
          foreignField: "branch_id",
          pipeline: [
            {
              $lookup: {
                from: "coupons",
                localField: "coupon_id",
                foreignField: "_id",
                pipeline: [
                  {
                    $match: {
                      is_active: true,
                      is_delivery: true,
                      start_time: {
                        $lte: moment()
                          .add(SYSTEM_TIMEZONE.HOURS, "hours")
                          .add(SYSTEM_TIMEZONE.MINUTES, "minutes")
                          .toDate(),
                      },
                      end_time: {
                        $gte: moment()
                          .add(SYSTEM_TIMEZONE.HOURS, "hours")
                          .add(SYSTEM_TIMEZONE.MINUTES, "minutes")
                          .toDate(),
                      },
                    },
                  },
                  {
                    $sort: {
                      created_at: -1,
                    },
                  },
                  {
                    $limit: 2,
                  },
                  {
                    $project: {
                      _id: 1,
                      name: 1,
                      description: 1,
                    },
                  },
                ],
                as: "branch_coupons",
              },
            },
            { $unwind: "$branch_coupons" },
            {
              $project: {
                branch_coupons: 1,
              },
            },
          ],
          as: "coupons",
        },
      },
      {
        $lookup: {
          from: "branch_coupons",
          localField: "_id",
          foreignField: "branch_id",
          pipeline: [
            {
              $lookup: {
                from: "coupons",
                localField: "coupon_id",
                foreignField: "_id",
                pipeline: [
                  {
                    $match: {
                      is_active: true,
                      is_delivery: true,
                      start_time: {
                        $lte: moment()
                          .add(SYSTEM_TIMEZONE.HOURS, "hours")
                          .add(SYSTEM_TIMEZONE.MINUTES, "minutes")
                          .toDate(),
                      },
                      end_time: {
                        $gte: moment()
                          .add(SYSTEM_TIMEZONE.HOURS, "hours")
                          .add(SYSTEM_TIMEZONE.MINUTES, "minutes")
                          .toDate(),
                      },
                    },
                  },
                  {
                    $sort: {
                      created_at: -1,
                    },
                  },

                  {
                    $project: {
                      _id: 1,
                      name: 1,
                      description: 1,
                    },
                  },
                ],
                as: "branch_coupons",
              },
            },
            { $unwind: "$branch_coupons" },
            {
              $project: {
                _id: 0,
                branch_coupons: 1,
              },
            },
            {
              $limit: 1,
            },
          ],
          as: "promo_code",
        },
      },
      {
        $lookup: {
          from: "reviews",
          localField: "_id",
          foreignField: "rest_id",
          pipeline: [
            {
              $group: {
                _id: "$rest_id",
                avg: { $avg: "$rating" },
                no_review: { $sum: 1 },
              },
            },
            {
              $project: {
                _id: 0,
                avg: { $round: ["$avg", 1] },
                no_review: 1,
              },
            },
          ],
          as: "rating",
        },
      },

      {
        $lookup: {
          from: "categories",
          localField: "_id",
          foreignField: "restaurant_id",

          pipeline: [
            {
              $match: { is_active: true },
            },
            {
              $lookup: {
                from: "restaurant_menus",
                localField: "_id",
                foreignField: "category_id",

                pipeline: [
                  {
                    $match: {
                      menu_time_slots_map: { $ne: [] },
                      is_active: true,
                      is_delivery: true,
                      restaurant_id: rest_id,
                    },
                  },
                  //Menu Timing Check
                  {
                    $lookup: {
                      from: "menu_item_and_menu_item_time_slots",
                      localField: "_id",
                      foreignField: "menu_item_id",
                      as: "menu_time_slots_map",
                      pipeline: [
                        {
                          $match: {
                            menu_time_slots: { $ne: [] },
                          },
                        },
                        {
                          $lookup: {
                            from: "menu_item_time_slots",
                            localField: "menu_item_time_slot_id",
                            foreignField: "_id",
                            as: "menu_time_slots",
                            pipeline: [
                              {
                                $set: {
                                  start: {
                                    $dateFromParts: {
                                      isoWeekYear: {
                                        $isoWeekYear: moment()
                                          .add(SYSTEM_TIMEZONE.HOURS, "hours")
                                          .toDate(),
                                      },
                                      isoWeek: {
                                        $isoWeek: moment()
                                          .add(SYSTEM_TIMEZONE.HOURS, "hours")
                                          .toDate(),
                                      },
                                      isoDayOfWeek: {
                                        $isoDayOfWeek: moment()
                                          .add(SYSTEM_TIMEZONE.HOURS, "hours")
                                          .toDate(),
                                      },
                                      hour: "$start_time.hour",
                                      minute: "$start_time.minute",
                                    },
                                  },
                                  close: {
                                    $dateFromParts: {
                                      isoWeekYear: {
                                        $isoWeekYear: moment()
                                          .add(SYSTEM_TIMEZONE.HOURS, "hours")
                                          .toDate(),
                                      },
                                      isoWeek: {
                                        $isoWeek: moment()
                                          .add(SYSTEM_TIMEZONE.HOURS, "hours")
                                          .toDate(),
                                      },
                                      isoDayOfWeek: {
                                        $isoDayOfWeek: moment()
                                          .add(SYSTEM_TIMEZONE.HOURS, "hours")
                                          .toDate(),
                                      },
                                      hour: "$end_time.hour",
                                      minute: "$end_time.minute",
                                    },
                                  },
                                },
                              },

                              {
                                $set: {
                                  is_aval: {
                                    $cond: {
                                      if: {
                                        $and: [
                                          {
                                            $lte: [
                                              "$start",
                                              moment()
                                                .add(SYSTEM_TIMEZONE.HOURS, "hours")
                                                .toDate(),
                                            ],
                                          },
                                          {
                                            $gt: [
                                              "$close",
                                              moment()
                                                .add(SYSTEM_TIMEZONE.HOURS, "hours")
                                                .toDate(),
                                            ],
                                          },
                                        ],
                                      },
                                      then: true,
                                      else: false,
                                    },
                                  },
                                },
                              },
                              {
                                $match: {
                                  is_aval: { $ne: false },
                                },
                              },
                            ],
                          },
                        },
                        {
                          $addFields: {
                            menu_slot_time: { $arrayElemAt: ["$menu_time_slots", 0] },
                          },
                        },
                        {
                          $group: {
                            _id: "$menu_item_id",
                            is_active: { $first: "$is_active" },
                            menu_time_slots: { $first: "$menu_slot_time" },
                          },
                        },

                        {
                          $project: {
                            _id: 1,
                            name: 1,
                            is_active: 1,
                            menu_time_slots: 1,
                          },
                        },
                      ],
                    },
                  },

                  {
                    $lookup: {
                      from: "variations",
                      localField: "_id",
                      foreignField: "menu_id",

                      pipeline: [
                        {
                          $lookup: {
                            from: "addon_category",
                            localField: "_id",
                            foreignField: "variation_id",
                            pipeline: [
                              {
                                $lookup: {
                                  from: "addon_list",
                                  localField: "_id",
                                  foreignField: "variation_and_add_on_category_id",

                                  as: "add_on_list",
                                },
                              },
                            ],
                            as: "add_on_category",
                          },
                        },
                      ],

                      as: "variations",
                    },
                  },
                  {
                    $addFields: {
                      menu_slot: { $arrayElemAt: ["$menu_time_slots_map", 0] },
                    },
                  },
                  {
                    $project: {
                      _id: 1,
                      category_id: 1,
                      restaurant_id: 1,
                      menu_name: 1,
                      menu_price: 1,
                      description: 1,
                      image: 1,
                      is_populer: 1,
                      has_variation: 1,
                      check_add_ons: 1,
                      variation_group_name: 1,
                      variation_group_desc: 1,
                      is_active: 1,
                      sd: 1,
                      vat: 1,
                      variations: 1,
                      is_available: {
                        $cond: {
                          if: {
                            $and: [
                              { $ifNull: ["$menu_slot", false] },
                              { $eq: ["$menu_slot.is_active", true] },
                              { $eq: ["$menu_slot.menu_time_slots.is_aval", true] },
                            ],
                          },
                          then: true,
                          else: false,
                        },
                      },
                    },
                  },
                  {
                    $match: {
                      is_available: { $ne: false },
                    },
                  },
                ],

                as: "menu_data",
              },
            },
            {
              $match: { menu_data: { $ne: [] } },
            },
          ],

          as: "categories",
        },
      },

      {
        $project: {
          ...res_basic_data,
          coupons: "$coupons.branch_coupons",
          promo_code: "$promo_code.branch_coupons",
        },
      },
    ]);

    populer_menu = await MenuModel.aggregate([
      {
        $match: {
          restaurant_id: rest_id,
          is_popular: true,
          is_active: true,
          is_delivery: true,
          menu_time_slots_map: { $ne: [] },
        },
      },
      //Menu Timing Check
      {
        $lookup: {
          from: "menu_item_and_menu_item_time_slots",
          localField: "_id",
          foreignField: "menu_item_id",
          as: "menu_time_slots_map",
          pipeline: [
            {
              $match: {
                menu_time_slots: { $ne: [] },
              },
            },
            {
              $lookup: {
                from: "menu_item_time_slots",
                localField: "menu_item_time_slot_id",
                foreignField: "_id",
                as: "menu_time_slots",
                pipeline: [
                  {
                    $set: {
                      start: {
                        $dateFromParts: {
                          isoWeekYear: {
                            $isoWeekYear: moment()
                              .add(SYSTEM_TIMEZONE.HOURS, "hours")
                              .toDate(),
                          },
                          isoWeek: {
                            $isoWeek: moment()
                              .add(SYSTEM_TIMEZONE.HOURS, "hours")
                              .toDate(),
                          },
                          isoDayOfWeek: {
                            $isoDayOfWeek: moment()
                              .add(SYSTEM_TIMEZONE.HOURS, "hours")
                              .toDate(),
                          },
                          hour: "$start_time.hour",
                          minute: "$start_time.minute",
                        },
                      },
                      close: {
                        $dateFromParts: {
                          isoWeekYear: {
                            $isoWeekYear: moment()
                              .add(SYSTEM_TIMEZONE.HOURS, "hours")
                              .toDate(),
                          },
                          isoWeek: {
                            $isoWeek: moment()
                              .add(SYSTEM_TIMEZONE.HOURS, "hours")
                              .toDate(),
                          },
                          isoDayOfWeek: {
                            $isoDayOfWeek: moment()
                              .add(SYSTEM_TIMEZONE.HOURS, "hours")
                              .toDate(),
                          },
                          hour: "$end_time.hour",
                          minute: "$end_time.minute",
                        },
                      },
                    },
                  },

                  {
                    $set: {
                      is_aval: {
                        $cond: {
                          if: {
                            $and: [
                              {
                                $lte: [
                                  "$start",
                                  moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
                                ],
                              },
                              {
                                $gt: [
                                  "$close",
                                  moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
                                ],
                              },
                            ],
                          },
                          then: true,
                          else: false,
                        },
                      },
                    },
                  },
                  {
                    $match: {
                      is_aval: { $ne: false },
                    },
                  },
                ],
              },
            },
            {
              $addFields: {
                menu_slot_time: { $arrayElemAt: ["$menu_time_slots", 0] },
              },
            },
            {
              $group: {
                _id: "$menu_item_id",
                is_active: { $first: "$is_active" },
                menu_time_slots: { $first: "$menu_slot_time" },
              },
            },

            {
              $project: {
                _id: 1,
                name: 1,
                is_active: 1,
                menu_time_slots: 1,
              },
            },
          ],
        },
      },

      {
        $lookup: {
          from: "variations",
          localField: "_id",
          foreignField: "menu_id",

          pipeline: [
            {
              $lookup: {
                from: "addon_category",
                localField: "_id",
                foreignField: "variation_id",
                pipeline: [
                  {
                    $lookup: {
                      from: "addon_list",
                      localField: "_id",
                      foreignField: "variation_and_add_on_category_id",

                      as: "add_on_list",
                    },
                  },
                ],
                as: "add_on_category",
              },
            },
          ],

          as: "variations",
        },
      },
      {
        $addFields: {
          menu_slot: { $arrayElemAt: ["$menu_time_slots_map", 0] },
        },
      },
      {
        $project: {
          _id: 1,
          category_id: 1,
          restaurant_id: 1,
          menu_name: 1,
          menu_price: 1,
          description: 1,
          image: 1,
          is_populer: 1,
          has_variation: 1,
          check_add_ons: 1,
          variation_group_name: 1,
          variation_group_desc: 1,
          is_active: 1,
          sd: 1,
          vat: 1,
          variations: 1,
          is_available: {
            $cond: {
              if: {
                $and: [
                  { $ifNull: ["$menu_slot", false] },
                  { $eq: ["$menu_slot.is_active", true] },
                  { $eq: ["$menu_slot.menu_time_slots.is_aval", true] },
                ],
              },
              then: true,
              else: false,
            },
          },
        },
      },
      {
        $match: {
          is_available: { $ne: false },
        },
      },
    ]);

    console.log("length", populer_menu);

    let populer = {
      _id: -1,
      category_name: "Popular",
      menu_data: populer_menu,
    };
      if (restaurant && restaurant.length > 0) {
          if (populer_menu.length > 0) {
              restaurant[0].categories.splice(0, 0, populer);
          }
      }

    let rest_lat = parseFloat(restaurant[0].location.coordinates[1]);
    let rest_long = parseFloat(restaurant[0].location.coordinates[0]);
    let distance = await RestaurantDistance(user_lat, user_long, rest_lat, rest_long);
    return {
      distance: distance.distance.text,
      restaurant: restaurant[0],
    };
  } catch (error) {
    console.log(error);
    return false;
  }
};
export default GetView;
