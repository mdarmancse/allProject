import MenuModel from "../../models/Restaurant/Menu.js";

import Order from "../../models/Order/Order.js";
import { getZone } from "../zones/GetZone.js";
import crud_helper from "../common/crud_helper.js";
import RestaurentModel from "../../models/Restaurant/RestaurentModel.js";
import CartModel from "../../models/Order/CartModel.js";
import { coupon_val_check, DeliveryCharge } from "../common/Calculation.js";
import CouponModel from "../../models/Coupon/CouponModel.js";
import { Send_Queue } from "../common/RMQ.js";
import CustomerCoupon from "../../models/Coupon/CustomerCoupon.js";
import BranchCoupon from "../../models/Coupon/BranchCoupon.js";
import ZoneCoupon from "../../models/Coupon/ZoneCoupon.js";
import CuisineCoupon from "../../models/Coupon/CuisineCoupon.js";
import GradualInformation from "../../models/Coupon/GradualInformation.js";
import CategoryCoupon from "../../models/Coupon/CategoryCoupon.js";
import MenuItemCoupon from "../../models/Coupon/MenuItemCoupon.js";
import SystemOption from "../../models/Faq & Setting/SystemOption.js";
const cms_queue = process.env.CMS_QUEUE_NAME;
export const GetCartData = async (body) => {
  try {
    const system_options = await SystemOption.getSystemOption();
    const SYSTEM_MAX_ORDER_VALUE = JSON.parse(system_options.max_order_value);
    const SYSTEM_MIN_ORDER_VALUE = JSON.parse(system_options.min_order_value);

    const user_id = body.id;
    const restaurant_id = body.restaurant_id;
    const lat = body.lat;
    const long = body.long;
    const menu_data = body.menu_data;
    let coupon_name = body.coupon_name,
      error = "",
      total = 0,
      total_vat = 0,
      total_sd = 0,
      discount = 0,
      discount_type = "",
      menus = "",
      discount_value = 0,
      grand_total = 0,
      delivery_charge,
      wise_coupon_check,
      coupon_id,
      min_order_value;
    body.auto_applied_coupon = "";
    let zone_id = await getZone(body.lat, body.long);
    if (!zone_id) {
      return {
        status: -1,
        msg: "Failed to fetch zone",
      };
    }

    if (zone_id.length < 1) {
      return {
        status: -1,
        msg: "No service available for this zone.",
      };
    }
    const res_zone_check = await crud_helper.findActive(RestaurentModel, {
      _id: restaurant_id,
      "zone_id._id": zone_id[0]._id,
    });

    if (res_zone_check.length === 0) {
      return {
        status: -1,
        msg: "Restaurant deactivated or deleted or working hours ends",
      };
    }

    let rest_lat = parseFloat(res_zone_check[0].location.coordinates[1]);
    let rest_long = parseFloat(res_zone_check[0].location.coordinates[0]);
    min_order_value = res_zone_check[0].min_order_value;

    let cuisines = res_zone_check[0].cuisines;

    let rest_calc = await CartModel.findOne({
      customer_id: user_id,
      branch_id: restaurant_id,
      user_lat: body.lat,
      user_long: body.long,
    });

    if (rest_calc) {
      delivery_charge = rest_calc.delivery_charge;
    } else {
      delivery_charge = await DeliveryCharge(
        zone_id[0]._id,
        rest_lat,
        rest_long,
        lat,
        long
      );
      if (delivery_charge.delivery_charge > 0) {
        delivery_charge = delivery_charge.delivery_charge;
      } else {
        return {
          status: -1,
          msg: "Sorry..! You are out of delivery area!",
        };
      }
    }
    let order_data = await GetOrderData(restaurant_id, menu_data);

    if (order_data.length === 0) {
      return {
        status: -1,
        msg: "Sorry,no menus are currently available !",
      };
    }

    const sum_data = order_data.reduce(
      (ac, cur) => {
        //TODO: check coupon_id and category_id in CategoryCoupon and discount add in cur.item_total
        ac.total_item_total += cur.item_total;
        ac.total_sd += cur.item_sd;
        ac.total_vat += cur.item_vat;
        return ac;
      },
      {
        total_item_total: 0,
        total_sd: 0,
        total_vat: 0,
      }
    );
    menus = order_data;
    total = sum_data.total_item_total;
    total_sd = sum_data.total_sd;
    total_vat = sum_data.total_vat;
    if (error)
      return {
        msg: error,
        status: -1,
      };
    let cat_list = [];

    if (total < SYSTEM_MIN_ORDER_VALUE) {
      return {
        status: -1,
        msg: `Sorry..! Your food price should be greater than ${SYSTEM_MIN_ORDER_VALUE}`,
      };
    }
    if (total < min_order_value) {
      return {
        status: -1,
        msg: `Sorry..! Your food price should be greater than ${min_order_value}`,
      };
    }
    if (SYSTEM_MAX_ORDER_VALUE < total) {
      return {
        status: -1,
        msg: `Sorry..! Your food price should be less than ${SYSTEM_MAX_ORDER_VALUE}`,
      };
    }
    for (const order_data_key in order_data) {
      const menu = order_data[order_data_key];
      cat_list.push(menu.category_id);
    }

    let auto_apply_coupon = await CouponModel.getAutoApplyCoupons({
      restaurant_id,
      user_id,
      zone_id,
      cuisines,
      cat_list,
      is_delivery: true,
    });

    if (auto_apply_coupon?.length > 0) {
      let coupon_check = auto_apply_coupon[0];
      if (coupon_check.name == coupon_name) {
        coupon_name = "";
      }
      let coupon_id = coupon_check._id;
      let coupon_count = await Order.find({
        coupon_id: coupon_id,
        customer_id: body.id,
      }).count();

      if (coupon_check.use_limit && coupon_count > coupon_check.use_limit) {
        body.coupon_msg = coupon_check.name + " limit is over!";
      } else {
        let get_coupon_type = coupon_check.coupon_type_name;
        console.log("get_coupon_type :", get_coupon_type);
        let minimum_order_amount = coupon_check.minimum_order_amount;
        let diff = minimum_order_amount - total;

        if (minimum_order_amount >= total) {
          //Check Min order value
          //   body.coupon_msg = "Add TK " + diff + " to use this voucher";
        } else {
          body.auto_applied_coupon_name = coupon_check.name;

          //Check type wise validation
          if (get_coupon_type == "user_wise") {
            wise_coupon_check = await CustomerCoupon.findOne({
              customer_id: body.id,
              coupon_id: coupon_id,
            });
            if (wise_coupon_check) {
              // if (coupon_check.maximum_discount_amount)
              discount += coupon_check.is_percent
                ? (parseFloat(coupon_check.discount_in_percent) / 100) * total
                : parseFloat(coupon_check.discount_in_amount);

              discount_value = coupon_check.is_percent
                ? coupon_check.discount_in_percent
                : coupon_check.discount_in_amount;
              if (discount > coupon_check.maximum_discount_amount) {
                discount = coupon_check.maximum_discount_amount;
              } else {
                discount = discount;
              }

              discount_type = coupon_check.is_percent ? "percent" : "amount";
            } else {
              //   body.coupon_msg = coupon_name + " is not available for you!";
            }
          } else if (get_coupon_type == "branch_wise") {
            wise_coupon_check = await BranchCoupon.findOne({
              branch_id: restaurant_id,
              coupon_id: coupon_id,
            });
            // return wise_coupon_check;
            if (wise_coupon_check) {
              discount += coupon_check.is_percent
                ? (parseFloat(coupon_check.discount_in_percent) / 100) * total
                : parseFloat(coupon_check.discount_in_amount);

              discount_value = coupon_check.is_percent
                ? coupon_check.discount_in_percent
                : coupon_check.discount_in_amount;
              if (discount > coupon_check.maximum_discount_amount) {
                discount = coupon_check.maximum_discount_amount;
              } else {
                discount = discount;
              }

              discount_type = coupon_check.is_percent ? "percent" : "amount";
            } else {
              //   body.coupon_msg = coupon_name + " is not available for this restaurant!";
            }
          } else if (get_coupon_type == "zone_wise") {
            wise_coupon_check = await ZoneCoupon.findOne({
              zone_id: zone_id,
              coupon_id: coupon_id,
            });
            // return wise_coupon_check;
            if (wise_coupon_check) {
              discount += coupon_check.is_percent
                ? (parseFloat(coupon_check.discount_in_percent) / 100) * total
                : parseFloat(coupon_check.discount_in_amount);

              discount_value = coupon_check.is_percent
                ? coupon_check.discount_in_percent
                : coupon_check.discount_in_amount;
              if (discount > coupon_check.maximum_discount_amount) {
                discount = coupon_check.maximum_discount_amount;
              } else {
                discount = discount;
              }

              discount_type = coupon_check.is_percent ? "percent" : "amount";
            } else {
              //   body.coupon_msg = coupon_name + " is not available in this zone!";
            }
          } else if (get_coupon_type == "cuisine_wise") {
            wise_coupon_check = await CuisineCoupon.aggregate([
              {
                $match: {
                  coupon_id: coupon_id,
                  cuisine_id: {
                    $in: cuisines ? cuisines.map((cs) => cs.cuisine_id) : [],
                  },
                },
              },
            ]);
            // return wise_coupon_check;
            if (wise_coupon_check) {
              discount += coupon_check.is_percent
                ? (parseFloat(coupon_check.discount_in_percent) / 100) * total
                : parseFloat(coupon_check.discount_in_amount);

              discount_value = coupon_check.is_percent
                ? coupon_check.discount_in_percent
                : coupon_check.discount_in_amount;
              if (discount > coupon_check.maximum_discount_amount) {
                discount = coupon_check.maximum_discount_amount;
              } else {
                discount = discount;
              }

              discount_type = coupon_check.is_percent ? "percent" : "amount";
            } else {
              //   body.coupon_msg = coupon_name + " is not available for this cuisine!";
            }
          } else if (get_coupon_type == "gradual_wise") {
            let grad_coupon_count = await Order.find({
              branch_id: restaurant_id,
              coupon_id: coupon_id,
              customer_id: body.id,
            }).count();

            wise_coupon_check = await GradualInformation.findOne({
              coupon_id: coupon_id,
            }).sort({
              _id: -1,
            });

            if (wise_coupon_check) {
              let sequence = wise_coupon_check.sequence;
              let new_seq = grad_coupon_count + 1;
              if (sequence == new_seq) {
                discount += coupon_check.is_percent
                  ? (parseFloat(coupon_check.discount_in_percent) / 100) * total
                  : parseFloat(coupon_check.discount_in_amount);

                discount_value = coupon_check.is_percent
                  ? coupon_check.discount_in_percent
                  : coupon_check.discount_in_amount;
                if (discount > coupon_check.maximum_discount_amount) {
                  discount = coupon_check.maximum_discount_amount;
                } else {
                  discount = discount;
                }
              } else {
                // body.coupon_msg = coupon_name + " is not available for you!";
              }
              discount_type = coupon_check.is_percent ? "percent" : "amount";
            } else {
              //   body.coupon_msg = coupon_name + " is not available for you!";
            }
          } else if (get_coupon_type == "category_wise") {
            for (const order_data_key in order_data) {
              const menu = order_data[order_data_key];
              console.log("menud", menu);
              wise_coupon_check = await CategoryCoupon.findOne({
                category_id: menu.category_id,
                coupon_id: coupon_id,
              });
              console.log("wise_coupon_check", wise_coupon_check);
              if (wise_coupon_check) {
                discount += coupon_check.is_percent
                  ? (parseFloat(coupon_check.discount_in_percent) / 100) * menu.item_total
                  : parseFloat(coupon_check.discount_in_amount);
                console.log("discount", discount);
                discount_value = coupon_check.is_percent
                  ? coupon_check.discount_in_percent
                  : coupon_check.discount_in_amount;
                if (discount > coupon_check.maximum_discount_amount) {
                  discount = coupon_check.maximum_discount_amount;
                } else {
                  discount = discount;
                }
                //   discount_type = coupon_check.is_percent ? "percent" : "amount";
              }

              if (discount <= 0) {
                // body.coupon_msg = coupon_name + " is not available !";
              }
            }
          } else if (get_coupon_type == "menu_item_wise") {
            for (const order_data_key in order_data) {
              const menu = order_data[order_data_key];
              console.log("menud", menu);
              wise_coupon_check = await MenuItemCoupon.findOne({
                menu_item_id: menu._id,
                coupon_id: coupon_id,
              });
              console.log("wise_coupon_check", wise_coupon_check);
              if (wise_coupon_check) {
                discount += coupon_check.is_percent
                  ? (parseFloat(coupon_check.discount_in_percent) / 100) * menu.item_total
                  : parseFloat(coupon_check.discount_in_amount);
                console.log("discount", discount);
                discount_value = coupon_check.is_percent
                  ? coupon_check.discount_in_percent
                  : coupon_check.discount_in_amount;
                if (discount > coupon_check.maximum_discount_amount) {
                  discount = coupon_check.maximum_discount_amount;
                } else {
                  discount = discount;
                }
                //   discount_type = coupon_check.is_percent ? "percent" : "amount";
              }
            }

            if (discount <= 0) {
              //   body.coupon_msg = coupon_name + " is not available!";
            }
          } else {
            discount += coupon_check.is_percent
              ? (parseFloat(coupon_check.discount_in_percent) / 100) * total
              : parseFloat(coupon_check.discount_in_amount);

            discount_value = coupon_check.is_percent
              ? coupon_check.discount_in_percent
              : coupon_check.discount_in_amount;
            if (discount > coupon_check.maximum_discount_amount) {
              discount = coupon_check.maximum_discount_amount;
            } else {
              discount = discount;
            }

            discount_type = coupon_check.is_percent ? "percent" : "amount";
          }
        }
      }
    }

    if (coupon_name) {
      let c_name = coupon_name.toUpperCase();
      let coupon_check = await coupon_val_check(c_name);

      if (coupon_check) {
        coupon_id = coupon_check._id;

        let coupon_count = await Order.find({
          coupon_id: coupon_id,
          customer_id: body.id,
        }).count();

        if (coupon_check.use_limit > 0 && coupon_count > coupon_check.use_limit) {
          body.coupon_msg = coupon_name + " limit is over!";
        } else {
          let get_coupon_type = coupon_check.coupon_type_name;
          let minimum_order_amount = coupon_check.minimum_order_amount;
          let diff = minimum_order_amount - total;

          if (minimum_order_amount >= total) {
            //Check Min order value
            body.coupon_msg = "Add TK " + diff + " to use this voucher";
          } else {
            //Check type wise validation
            if (get_coupon_type == "user_wise") {
              wise_coupon_check = await CustomerCoupon.findOne({
                customer_id: body.id,
                coupon_id: coupon_id,
              });
              if (wise_coupon_check) {
                // if (coupon_check.maximum_discount_amount)
                discount += coupon_check.is_percent
                  ? (parseFloat(coupon_check.discount_in_percent) / 100) * total
                  : parseFloat(coupon_check.discount_in_amount);

                discount_value = coupon_check.is_percent
                  ? coupon_check.discount_in_percent
                  : coupon_check.discount_in_amount;
                if (discount > coupon_check.maximum_discount_amount) {
                  discount = coupon_check.maximum_discount_amount;
                } else {
                  discount = discount;
                }

                discount_type = coupon_check.is_percent ? "percent" : "amount";
              } else {
                body.coupon_msg = coupon_name + " is not available for you!";
              }
            } else if (get_coupon_type == "branch_wise") {
              wise_coupon_check = await BranchCoupon.findOne({
                branch_id: restaurant_id,
                coupon_id: coupon_id,
              });
              // return wise_coupon_check;
              if (wise_coupon_check) {
                discount += coupon_check.is_percent
                  ? (parseFloat(coupon_check.discount_in_percent) / 100) * total
                  : parseFloat(coupon_check.discount_in_amount);

                discount_value = coupon_check.is_percent
                  ? coupon_check.discount_in_percent
                  : coupon_check.discount_in_amount;
                if (discount > coupon_check.maximum_discount_amount) {
                  discount = coupon_check.maximum_discount_amount;
                } else {
                  discount = discount;
                }

                discount_type = coupon_check.is_percent ? "percent" : "amount";
              } else {
                body.coupon_msg = coupon_name + " is not available for this restaurant!";
              }
            } else if (get_coupon_type == "zone_wise") {
              wise_coupon_check = await ZoneCoupon.findOne({
                zone_id: zone_id,
                coupon_id: coupon_id,
              });
              // return wise_coupon_check;
              if (wise_coupon_check) {
                discount += coupon_check.is_percent
                  ? (parseFloat(coupon_check.discount_in_percent) / 100) * total
                  : parseFloat(coupon_check.discount_in_amount);

                discount_value = coupon_check.is_percent
                  ? coupon_check.discount_in_percent
                  : coupon_check.discount_in_amount;
                if (discount > coupon_check.maximum_discount_amount) {
                  discount = coupon_check.maximum_discount_amount;
                } else {
                  discount = discount;
                }

                discount_type = coupon_check.is_percent ? "percent" : "amount";
              } else {
                body.coupon_msg = coupon_name + " is not available in this zone!";
              }
            } else if (get_coupon_type == "cuisine_wise") {
              wise_coupon_check = await CuisineCoupon.aggregate([
                {
                  $match: {
                    coupon_id: coupon_id,
                    cuisine_id: {
                      $in: cuisines ? cuisines.map((cs) => cs.cuisine_id) : [],
                    },
                  },
                },
              ]);
              // return wise_coupon_check;
              if (wise_coupon_check) {
                discount += coupon_check.is_percent
                  ? (parseFloat(coupon_check.discount_in_percent) / 100) * total
                  : parseFloat(coupon_check.discount_in_amount);

                discount_value = coupon_check.is_percent
                  ? coupon_check.discount_in_percent
                  : coupon_check.discount_in_amount;
                if (discount > coupon_check.maximum_discount_amount) {
                  discount = coupon_check.maximum_discount_amount;
                } else {
                  discount = discount;
                }

                discount_type = coupon_check.is_percent ? "percent" : "amount";
              } else {
                body.coupon_msg = coupon_name + " is not available for this cuisine!";
              }
            } else if (get_coupon_type == "gradual_wise") {
              let grad_coupon_count = await Order.find({
                branch_id: restaurant_id,
                coupon_id: coupon_id,
                customer_id: body.id,
              }).count();

              wise_coupon_check = await GradualInformation.findOne({
                coupon_id: coupon_id,
              }).sort({
                _id: -1,
              });

              if (wise_coupon_check) {
                let sequence = wise_coupon_check.sequence;
                let new_seq = grad_coupon_count + 1;
                if (sequence == new_seq) {
                  discount += coupon_check.is_percent
                    ? (parseFloat(coupon_check.discount_in_percent) / 100) * total
                    : parseFloat(coupon_check.discount_in_amount);

                  discount_value = coupon_check.is_percent
                    ? coupon_check.discount_in_percent
                    : coupon_check.discount_in_amount;
                  if (discount > coupon_check.maximum_discount_amount) {
                    discount = coupon_check.maximum_discount_amount;
                  } else {
                    discount = discount;
                  }
                } else {
                  body.coupon_msg = coupon_name + " is not available for you!";
                }
                discount_type = coupon_check.is_percent ? "percent" : "amount";
              } else {
                body.coupon_msg = coupon_name + " is not available for you!";
              }
            } else if (get_coupon_type == "category_wise") {
              for (const order_data_key in order_data) {
                const menu = order_data[order_data_key];
                console.log("menud", menu);
                wise_coupon_check = await CategoryCoupon.findOne({
                  category_id: menu.category_id,
                  coupon_id: coupon_id,
                });
                console.log("wise_coupon_check", wise_coupon_check);
                if (wise_coupon_check) {
                  discount += coupon_check.is_percent
                    ? (parseFloat(coupon_check.discount_in_percent) / 100) *
                      menu.item_total
                    : parseFloat(coupon_check.discount_in_amount);
                  console.log("discount", discount);
                  discount_value = coupon_check.is_percent
                    ? coupon_check.discount_in_percent
                    : coupon_check.discount_in_amount;
                  if (discount > coupon_check.maximum_discount_amount) {
                    discount = coupon_check.maximum_discount_amount;
                  } else {
                    discount = discount;
                  }
                  //   discount_type = coupon_check.is_percent ? "percent" : "amount";
                }

                if (discount <= 0) {
                  body.coupon_msg = coupon_name + " is not available !";
                }
              }
            } else if (get_coupon_type == "menu_item_wise") {
              for (const order_data_key in order_data) {
                const menu = order_data[order_data_key];
                console.log("menud", menu);
                wise_coupon_check = await MenuItemCoupon.findOne({
                  menu_item_id: menu._id,
                  coupon_id: coupon_id,
                });
                console.log("wise_coupon_check", wise_coupon_check);
                if (wise_coupon_check) {
                  discount += coupon_check.is_percent
                    ? (parseFloat(coupon_check.discount_in_percent) / 100) *
                      menu.item_total
                    : parseFloat(coupon_check.discount_in_amount);
                  console.log("discount", discount);
                  discount_value = coupon_check.is_percent
                    ? coupon_check.discount_in_percent
                    : coupon_check.discount_in_amount;
                  if (discount > coupon_check.maximum_discount_amount) {
                    discount = coupon_check.maximum_discount_amount;
                  } else {
                    discount = discount;
                  }
                  //   discount_type = coupon_check.is_percent ? "percent" : "amount";
                }
              }

              if (discount <= 0) {
                body.coupon_msg = coupon_name + " is not available!";
              }
            } else {
              discount += coupon_check.is_percent
                ? (parseFloat(coupon_check.discount_in_percent) / 100) * total
                : parseFloat(coupon_check.discount_in_amount);

              discount_value = coupon_check.is_percent
                ? coupon_check.discount_in_percent
                : coupon_check.discount_in_amount;
              if (discount > coupon_check.maximum_discount_amount) {
                discount = coupon_check.maximum_discount_amount;
              } else {
                discount = discount;
              }

              discount_type = coupon_check.is_percent ? "percent" : "amount";
            }
          }
        }
      } else {
        body.coupon_msg = coupon_name + " is not available!";
      }
    }

    grand_total = total + total_sd + total_vat + delivery_charge - discount;
    body.delivery_time = res_zone_check[0]["delivery_time"];
    body.rest_lat = rest_lat;
    body.rest_long = rest_long;
    body.menu_data = menus;
    body.coupon_name = coupon_name;
    body.discount_type = discount_type;
    body.total = grand_total.toFixed(2);
    body.price = [
      {
        name: "subtotal",
        display: "Subtotal",
        value: total.toFixed(2),
      },
      {
        name: "total_vat",
        display: "VAT (inc.)",
        value: total_vat.toFixed(2),
      },
      {
        name: "total_sd",
        display: "SD (inc.)",
        value: total_sd.toFixed(2),
      },
      {
        name: "total_discount",
        display:
          discount_type === "percent" ? "Discount(" + discount_value + "%)" : "Discount",
        value: discount.toFixed(2),
      },
      {
        name: "delivery_charge",
        display: "Delivery Charge",
        value: delivery_charge.toFixed(2),
      },
      {
        name: "total",
        display: "Total",
        value: grand_total.toFixed(2),
      },
    ];
    const cart_update = await CartModel.findOneAndUpdate(
      {
        customer_id: user_id,
      },
      {
        customer_id: user_id,
        branch_id: restaurant_id,
        coupon_id: coupon_id,
        user_lat: lat,
        user_long: long,
        delivery_charge: delivery_charge,
        total_amount: grand_total,
        cart_details: menu_data,
        cart_type: "delivery",
        created_by: user_id,
        updated_by: user_id,
      },
      {
        upsert: true,
        new: true,
        setDefaultsOnInsert: true,
        rawResult: true,
      }
    );
    if (cart_update && cart_update.lastErrorObject.updatedExisting == false) {
      await Send_Queue(cms_queue, "restaurant_queue", cart_update.value, "cart", "add");
      console.log("Document Inserted");
    }
    if (cart_update && cart_update.lastErrorObject.updatedExisting == true) {
      await Send_Queue(cms_queue, "restaurant_queue", cart_update.value, "cart", "edit");
      console.log("Document Updated");
    }

    return { cart_update: cart_update, body: body };
  } catch (err) {
    return {
      status: -1,
      msg: "Server Error occurred",
      err: err.toString(),
    };
  }
};

export const GetOrderData = async (rest_id, menu_data) => {
  try {
    let results = [];
    let get_data = await Promise.all(
      Object.values(menu_data).map(async (menu) => {
        const listIds = menu.variations.reduce((listAcc, variation) => {
          if (variation.add_on_category) {
            const currListIds = variation.add_on_category.reduce((itemAcc, category) => {
              if (category.add_on_list) {
                const currItemIds = category.add_on_list.map((item) => item._id);
                return itemAcc.concat(currItemIds);
              } else {
                return itemAcc;
              }
            }, []);
            return listAcc.concat(currListIds);
          } else {
            return listAcc;
          }
        }, []);
        console.log("listids", listIds);
        const result = await MenuModel.aggregate([
          {
            $match: {
              //  is_active: true,
              menu_time_slots_map: { $ne: [] },
              restaurant_id: rest_id,
              _id: menu._id,
            },
          },
          {
            $project: {
              _id: 1,
              category_id: 1,
              restaurant_id: 1,
              menu_name: 1,
              recipe_time: 1,
              menu_price: 1,
              image: 1,
              vat: 1,
              sd: 1,
              is_active: 1,
            },
          },

          //Menu Timing Check
          {
            $lookup: {
              from: "menu_item_and_menu_item_time_slots",
              localField: "_id",
              foreignField: "menu_item_id",
              as: "menu_time_slots_map",
              pipeline: [
                {
                  $match: {
                    menu_time_slots: { $ne: [] },
                  },
                },
                {
                  $lookup: {
                    from: "menu_item_time_slots",
                    localField: "menu_item_time_slot_id",
                    foreignField: "_id",
                    as: "menu_time_slots",
                    pipeline: [
                      {
                        $set: {
                          start: {
                            $dateFromParts: {
                              isoWeekYear: { $isoWeekYear: new Date() },
                              isoWeek: { $isoWeek: new Date() },
                              isoDayOfWeek: { $isoDayOfWeek: new Date() },
                              hour: "$start_time.hour",
                              minute: "$start_time.minute",
                            },
                          },
                          close: {
                            $dateFromParts: {
                              isoWeekYear: { $isoWeekYear: new Date() },
                              isoWeek: { $isoWeek: new Date() },
                              isoDayOfWeek: { $isoDayOfWeek: new Date() },
                              hour: "$end_time.hour",
                              minute: "$end_time.minute",
                            },
                          },
                        },
                      },
                      {
                        $match: {
                          $expr: {
                            $and: [
                              {
                                $lte: ["$start", new Date()],
                              },
                              {
                                $gt: ["$end", new Date()],
                              },
                            ],
                          },
                          //   start: { $lte: new Date() },
                          //   end: { $gt: new Date() },
                        },
                      },
                    ],
                  },
                },
                {
                  $group: {
                    _id: "$menu_item_id",
                  },
                },
              ],
            },
          },

          //Variation Check
          {
            $lookup: {
              from: "variations",
              localField: "_id",
              foreignField: "menu_id",
              pipeline: [
                {
                  $match: {
                    //is_active: true,
                    _id: {
                      $in: menu.variations
                        ? menu.variations.map((variation) => variation._id)
                        : [],
                    },
                  },
                },
                {
                  $lookup: {
                    from: "addon_category",
                    localField: "_id",
                    foreignField: "variation_id",
                    pipeline: [
                      {
                        $match: {
                          //_id:{$in:menu.variations ?menu.variations.map(variation => variation._id) : []}
                          variation_id: {
                            $in: menu.variations
                              ? menu.variations.map((variation) => variation._id)
                              : [],
                          },
                        },
                      },
                      {
                        $lookup: {
                          from: "addon_list",
                          localField: "_id",
                          foreignField: "variation_and_add_on_category_id",
                          pipeline: [
                            // {
                            //     $match: {
                            //         _id: {
                            //             $in: [menu.variations && menu.variations.length > 0 ? menu.variations.reduce((listAcc, variation) =>
                            //                 listAcc.concat(variation.add_on_category?.reduce((itemAcc, category) =>
                            //                         itemAcc.concat(category.add_on_list?.map(item => item._id) ?? []) ?? [])
                            //                     , []) ?? []) : []]
                            //         }
                            //     }
                            // },
                            {
                              $match: {
                                _id: { $in: listIds.length > 0 ? listIds : [] },
                              },
                            },

                            {
                              $project: {
                                _id: 1,
                                add_on_id: "$_id",
                                order_add_on_category_details_id:
                                  "df22a969-b4f3-4b01-abbc-1af69b5e4d01",
                                add_ons_name: 1,
                                addoncat_id: 1,
                                variation_and_add_on_category_id: 1,
                                add_ons_price: 1,
                                is_active: 1,
                              },
                            },
                          ],
                          as: "add_on_list",
                        },
                      },
                      {
                        $project: {
                          _id: 1,
                          add_on_category_id: 1,
                          order_variation_details_id:
                            "df22a969-b4f3-4b01-abbc-1af69b5e4d01",
                          name: 1,
                          add_on_list: 1,
                          is_active: 1,
                        },
                      },
                    ],
                    as: "add_on_category",
                  },
                },
                {
                  $project: {
                    _id: "$_id",
                    variation_id: "$_id",
                    order_menu_item_details_id: "df22a969-b4f3-4b01-abbc-1af69b5e4d01",
                    variation_name: 1,
                    variation_price: 1,
                    is_active: 1,
                    add_on_category: 1,
                  },
                },
              ],

              as: "variations",
            },
          },
          {
            $sort: {
              menu_price: 1,
            },
          },

          {
            $project: {
              _id: "$_id",
              category_id: "$category_id",
              restaurant_id: "$restaurant_id",
              menu_name: "$menu_name",
              menu_price: "$menu_price",
              recipe_time: "$recipe_time",
              image: "$image",
              variations: "$variations",
              vat: "$vat",
              sd: "$sd",
              is_active: "$is_active",
              menu_time_slots_map: "$menu_time_slots_map",
            },
          },
          {
            $addFields: {
              item_total: {
                $cond: {
                  if: { $gt: [{ $size: "$variations" }, 0] },
                  then: {
                    $multiply: [
                      {
                        $sum: {
                          $concatArrays: [
                            {
                              $map: {
                                input: "$variations",
                                as: "v",
                                in: "$$v.variation_price",
                              },
                            },
                            {
                              $map: {
                                input: {
                                  $reduce: {
                                    input: "$variations.add_on_category.add_on_list",
                                    initialValue: [],
                                    in: { $concatArrays: ["$$value", "$$this"] },
                                  },
                                },
                                as: "aol",
                                in: { $sum: "$$aol.add_ons_price" },
                              },
                            },
                          ],
                        },
                      },
                      menu.quantity,
                    ],
                  },
                  else: {
                    $cond: {
                      if: {
                        $and: [
                          { $eq: ["$is_active", true] },
                          { $size: "$menu_time_slots_map" },
                        ],
                      },
                      then: { $multiply: ["$menu_price", menu.quantity] },
                      else: 0,
                    },
                  },
                },
              },
              quantity: menu.quantity,
            },
          },
          {
            $group: {
              _id: null,
              menu_data: { $push: "$$ROOT" },
            },
          },
          {
            $project: {
              _id: 0,
              menu_data: {
                $map: {
                  input: "$menu_data",
                  as: "md",
                  in: {
                    _id: "$$md._id", //for cms
                    menu_item_id: "$$md._id",
                    order_id: "df22a969-b4f3-4b01-abbc-1af69b5e4d01", //for cms
                    category_id: "$$md.category_id",
                    restaurant_id: "$$md.restaurant_id",
                    menu_name: "$$md.menu_name",
                    menu_price: "$$md.menu_price",
                    recipe_time: "$$md.recipe_time",
                    image: "$$md.image",
                    quantity: "$$md.quantity",
                    variations: "$$md.variations",
                    is_active: "$$md.is_active",
                    is_available: {
                      $cond: {
                        if: { $size: "$$md.menu_time_slots_map" },
                        then: true,
                        else: false,
                      },
                    },
                    item_total: "$$md.item_total",
                    item_sd: {
                      $multiply: [
                        "$$md.item_total",
                        {
                          $divide: ["$$md.sd", 100],
                        },
                      ],
                    },
                    item_vat: {
                      $multiply: [
                        "$$md.item_total",
                        {
                          $divide: ["$$md.vat", 100],
                        },
                      ],
                    },
                  },
                },
              },
            },
          },
          {
            $project: {
              _id: 0,
              menu_data: 1,
            },
          },
          { $project: { menu_data: { $arrayElemAt: ["$menu_data", 0] } } },

          { $unwind: "$menu_data" },
          { $replaceRoot: { newRoot: "$menu_data" } },
        ]);

        if(result.length >0){
            results.push(result[0]);
        }
      })
    );
    return results;
  } catch (error) {
    return { status: "fail", data: error.toString() };
  }
};

export const GetUserOrderList = async (customer_id) => {
  try {
    let get_data;

    get_data = await Order.aggregate([
      {
        $match: { customer_id: customer_id, order_details: { $exists: true, $ne: null } },
      },

      {
        $facet: {
          ongoing: [
            {
              $match: {
                order_status: { $nin: ["delivered", "cancel", "not_delivered"] },
              },
            },
            {
              $lookup: {
                from: "restaurents",
                localField: "branch_id",
                foreignField: "_id",
                pipeline: [
                  {
                    $project: {
                      _id: 1,
                      name: 1,
                      image: 1,
                      delivery_time: 1,
                      pickup_time: 1,
                    },
                  },
                ],
                as: "restaurants",
              },
            },
            {
              $lookup: {
                from: "reviews",
                localField: "_id",
                foreignField: "order_id",
                pipeline: [
                  {
                    $project: {
                      order_id: 1,
                      rating: 1,
                    },
                  },
                ],
                as: "reviews",
              },
            },
            { $sort: { created_at: -1 } },
            {
              $project: {
                _id: 1,

                restaurants: 1,

                created_at: {
                  $dateToString: {
                    format: "%Y-%m-%d %H:%M",
                    date: "$created_at",
                    timezone: "Asia/Dhaka",
                  },
                },
                menu_names: {
                  $reduce: {
                    input: "$order_details",
                    initialValue: "",
                    in: {
                      $cond: {
                        if: { $eq: ["$$value", ""] },
                        then: "$$this.menu_name",
                        else: { $concat: ["$$value", ", ", "$$this.menu_name"] },
                      },
                    },
                  },
                },
                order_details: 1,
                order_status: 1,
                payment_method_id: 1,
                total_amount: { $round: ["$total_amount", 2] },
                sub_total: { $round: ["$sub_total", 2] },
                delivery_charge: { $round: ["$delivery_charge", 2] },
                total_vat: { $round: ["$value_added_tax_inclusive", 2] },
                total_sd: { $round: ["$supplementary_duty", 2] },
                discount_amount: { $round: ["$discount_amount", 2] },
                address: 1,
                order_type: 1,
                rider_id: { $ifNull: ["$rider_id", null] },
                rating: {
                  $cond: {
                    if: { $gt: [{ $size: "$reviews" }, 0] },
                    then: { $arrayElemAt: ["$reviews.rating", 0] },
                    else: null,
                  },
                },

                is_rated: {
                  $cond: {
                    if: { $gt: [{ $size: "$reviews" }, 0] },
                    then: 1,
                    else: 0,
                  },
                },
              },
            },
          ],
          previous: [
            {
              $match: {
                order_status: { $in: ["delivered", "cancel", "not_delivered"] },
              },
            },

            {
              $lookup: {
                from: "restaurents",
                localField: "branch_id",
                foreignField: "_id",
                pipeline: [
                  {
                    $project: {
                      _id: 1,
                      name: 1,
                      image: 1,
                      delivery_time: 1,
                      pickup_time: 1,
                    },
                  },
                ],
                as: "restaurants",
              },
            },
            {
              $lookup: {
                from: "reviews",
                localField: "_id",
                foreignField: "order_id",
                pipeline: [
                  {
                    $project: {
                      order_id: 1,
                      rating: 1,
                    },
                  },
                ],
                as: "reviews",
              },
            },
            { $sort: { created_at: -1 } },
            {
              $project: {
                _id: 1,
                restaurants: 1,
                order_status: 1,
                payment_method_id: 1,
                rider_id: { $ifNull: ["$rider_id", null] },
                total_amount: { $round: ["$total_amount", 2] },
                sub_total: { $round: ["$sub_total", 2] },
                delivery_charge: { $round: ["$delivery_charge", 2] },
                total_vat: { $round: ["$value_added_tax_inclusive", 2] },
                total_sd: { $round: ["$supplementary_duty", 2] },
                discount_amount: { $round: ["$discount_amount", 2] },
                address: 1,
                order_type: 1,
                created_at: {
                  $dateToString: {
                    format: "%Y-%m-%d %H:%M",
                    date: "$created_at",
                    timezone: "Asia/Dhaka",
                  },
                },
                menu_names: {
                  $reduce: {
                    input: "$order_details",
                    initialValue: "",
                    in: {
                      $cond: {
                        if: { $eq: ["$$value", ""] },
                        then: "$$this.menu_name",
                        else: { $concat: ["$$value", ", ", "$$this.menu_name"] },
                      },
                    },
                  },
                },
                order_details: 1,
                rating: {
                  $cond: {
                    if: { $gt: [{ $size: "$reviews" }, 0] },
                    then: { $arrayElemAt: ["$reviews.rating", 0] },
                    else: null,
                  },
                },

                is_rated: {
                  $cond: {
                    if: { $gt: [{ $size: "$reviews" }, 0] },
                    then: 1,
                    else: 0,
                  },
                },
              },
            },
          ],
        },
      },
    ]);

    return get_data;
  } catch (error) {
    return { status: "fail", data: error.toString() };
  }
};
export const GetOrderDetails = async (order_id, customer_id) => {
  try {
    let get_data;

    get_data = await Order.aggregate([
      {
        $match: {
          _id: order_id,
          customer_id: customer_id,
          order_details: { $exists: true, $ne: null },
        },
      },
      {
        $lookup: {
          from: "restaurents",
          localField: "branch_id",
          foreignField: "_id",
          pipeline: [
            {
              $project: {
                _id: 0,
                name: 1,
                image: 1,
                delivery_time: 1,
                pickup_time: 1,
              },
            },
          ],
          as: "restaurants",
        },
      },
      {
        $project: {
          _id: 0,
          order_id: "$_id",
          restaurants: "$restaurants",
          order_type: "$order_type",
          sub_total: { $round: ["$sub_total", 2] },
          total_amount: { $round: ["$total_amount", 2] },
          total_vat: { $round: ["$value_added_tax_inclusive", 2] },
          total_sd: { $round: ["$supplementary_duty", 2] },
          discount_amount: { $round: ["$discount_amount", 2] },
          created_at: {
            $dateToString: {
              format: "%Y-%m-%d %H:%M",
              date: "$created_at",
              timezone: "Asia/Dhaka",
            },
          },
          order_status: 1,
          rest_name: { $arrayElemAt: ["$restaurants.name", 0] },
          delivery_time: 1,
          address: 1,
          order_details: 1,
          rider_id: { $ifNull: ["$rider_id", null] },
          // order_details: {
          //     $cond: {
          //         if: {
          //             $in: [
          //                 "$order_status",
          //                 ["delivered", "cancel", "not_delivered"]
          //             ]
          //         },
          //         then: "$order_details",
          //         else: "$$REMOVE"
          //     }
          // }
        },
      },
    ]);

    return get_data[0];
  } catch (error) {
    return { status: "fail", data: error.toString() };
  }
};
export const GetOngoingOrder = async (customer_id) => {
  try {
    let get_data;

    get_data = await Order.aggregate([
      {
        $match: { customer_id: customer_id, order_details: { $exists: true, $ne: null } },
      },

      {
        $match: {
          order_status: { $nin: ["delivered", "cancel", "not_delivered"] },
        },
      },
      {
        $lookup: {
          from: "restaurents",
          localField: "branch_id",
          foreignField: "_id",
          pipeline: [
            {
              $project: {
                _id: 1,
                name: 1,
                delivery_time: 1,
              },
            },
          ],
          as: "restaurants",
        },
      },
      {
        $lookup: {
          from: "reviews",
          localField: "rest_id",
          foreignField: "branch_id",
          pipeline: [
            {
              $project: {
                _id: 1,
                rating: 1,
              },
            },
          ],
          as: "reviews",
        },
      },
      {
        $project: {
          _id: 0,
          order_id: "$_id",
          sub_total: { $round: ["$sub_total", 2] },
          delivery_charge: { $round: ["$delivery_charge", 2] },
          discount_amount: { $round: ["$discount_amount", 2] },
          total_vat: { $round: ["$value_added_tax_inclusive", 2] },
          total_sd: { $round: ["$supplementary_duty", 2] },
          total_amount: { $round: ["$total_amount", 2] },
          created_at: {
            $dateToString: {
              format: "%Y-%m-%d %H:%M",
              date: "$created_at",
              timezone: "Asia/Dhaka",
            },
          },
          order_status: 1,
          rest_name: { $arrayElemAt: ["$restaurants.name", 0] },
          delivery_time: { $arrayElemAt: ["$restaurants.delivery_time", 0] },
          address: 1,
          order_details: 1,
        },
      },
      {
        $sort: { created_at: -1 },
      },
      {
        $limit: 1,
      },
    ]);

    return get_data;
  } catch (error) {
    return { status: "fail", data: error.toString() };
  }
};

// export const GetOrderData= async (rest_id,menu_data) => {
//
//     const addOnCategoryIds = menu_data.reduce((acc, curr) => {
//         if (curr.variations) {
//             const variationIds = curr.variations.map(variation => variation._id);
//             const listIds = curr.variations.reduce((listAcc, variation) => {
//                 if (variation.add_on_category) {
//                     const currListIds = variation.add_on_category.reduce((itemAcc, category) => {
//                         if (category.add_on_list) {
//                             const currItemIds = category.add_on_list.map(item => item._id);
//                             return itemAcc.concat(currItemIds);
//                         } else {
//                             return itemAcc;
//                         }
//                     }, []);
//                     return listAcc.concat(currListIds);
//                 } else {
//                     return listAcc;
//                 }
//             }, []);
//             if (variationIds && listIds) {
//                 const variationAddOns = {variationIds, listIds};
//                 return acc.concat(variationAddOns);
//             }
//         }
//         return acc;
//     }, []);
//
//
//     try{
//         const get_data = await MenuModel.aggregate([
//             {
//                 $match: {
//                     //  is_active: true,
//                     menu_time_slots_map: { $ne: [] },
//                     restaurant_id: rest_id,
//                     _id: { $in: menu_data.map(md => md._id) }
//
//                 }
//             },
//             {
//                 $project:{_id:1,menu_name:1,menu_price:1,vat:1,sd:1,is_active:1}
//             },
//
//             //Menu Timing Check
//             {
//                 $lookup: {
//                     from: "menu_item_and_menu_item_time_slots",
//                     localField: "_id",
//                     foreignField: "menu_item_id",
//                     as: "menu_time_slots_map",
//                     pipeline: [
//                         {
//                             $match: {
//                                 menu_time_slots: { $ne: [] },
//                             },
//                         },
//                         {
//                             $lookup: {
//                                 from: "menu_item_time_slots",
//                                 localField: "menu_item_time_slot_id",
//                                 foreignField: "_id",
//                                 as: "menu_time_slots",
//                                 pipeline: [
//                                     {
//                                         $set: {
//                                             start: {
//                                                 $dateFromParts: {
//                                                     isoWeekYear: { $isoWeekYear: new Date() },
//                                                     isoWeek: { $isoWeek: new Date() },
//                                                     isoDayOfWeek: { $isoDayOfWeek: new Date() },
//                                                     hour: "$start_time.hour",
//                                                     minute: "$start_time.minute",
//                                                 },
//                                             },
//                                             close: {
//                                                 $dateFromParts: {
//                                                     isoWeekYear: { $isoWeekYear: new Date() },
//                                                     isoWeek: { $isoWeek: new Date() },
//                                                     isoDayOfWeek: { $isoDayOfWeek: new Date() },
//                                                     hour: "$end_time.hour",
//                                                     minute: "$end_time.minute",
//                                                 },
//                                             },
//                                         },
//                                     },
//                                     {
//                                         $match: {
//                                             $expr: {
//                                                 $and: [
//                                                     {
//                                                         $lte: ["$start", new Date()],
//                                                     },
//                                                     {
//                                                         $gt: ["$end", new Date()],
//                                                     },
//                                                 ],
//                                             },
//                                             //   start: { $lte: new Date() },
//                                             //   end: { $gt: new Date() },
//                                         },
//                                     },
//                                 ],
//                             },
//                         },
//                         {
//                             $group: {
//                                 _id: "$menu_item_id",
//                             },
//                         },
//                     ],
//                 },
//             },
//
//             //Variation Check
//             {
//                 $lookup: {
//                     from: 'variations',
//                     localField: '_id',
//                     foreignField: 'menu_id',
//                     pipeline: [
//                         {
//                             $match: {
//                                 //is_active: true,
//                                 _id: { $in: addOnCategoryIds.length > 0?addOnCategoryIds[0]['variationIds']:[]}
//                             },
//                         },
//                         {
//                             $lookup: {
//                                 from: 'addon_category',
//                                 localField: '_id',
//                                 foreignField: 'variation_id',
//                                 pipeline: [
//                                     {
//                                         $lookup: {
//                                             from: 'addon_list',
//                                             localField: '_id',
//                                             foreignField: 'addoncat_id',
//                                             pipeline: [
//                                                 {
//                                                     $match: {
//                                                         _id: { $in: addOnCategoryIds.length > 0?addOnCategoryIds[0]['listIds']:[]}
//                                                     },
//                                                 },
//                                                 {
//                                                     $project:{_id:1,add_ons_name:1,add_ons_price:1,is_active:1}
//                                                 },
//                                             ],
//                                             as: 'add_on_list',
//                                         },
//                                     },
//                                     {
//                                         $project:{_id:1,name:1,add_on_list:1,is_active:1}
//                                     },
//                                 ],
//                                 as: 'add_on_category',
//                             },
//                         },
//                         {
//                             $project:{
//                                 _id:1,
//                                 variation_name:1,
//                                 variation_price:1,
//                                 is_active:1,
//                                 add_on_category:1,
//
//
//
//                             }
//                         },
//                     ],
//
//                     as: 'variations'
//
//                 }
//
//             },
//
//
//
//             {
//                 $project: {
//                     _id: '$_id',
//                     menu_name: '$menu_name',
//                     menu_price: '$menu_price',
//                     variations: '$variations',
//                     vat: '$vat',
//                     sd: '$sd',
//                     is_active: '$is_active',
//                     menu_time_slots_map: '$menu_time_slots_map',
//                     quantity: {
//                         $sum: {
//                             $map: {
//                                 input: {
//                                     $filter: {
//                                         input: menu_data,
//                                         as: 'md',
//                                         cond: { $eq: ['$$md._id', '$_id'] }
//                                     }
//                                 },
//                                 as: 'md',
//                                 in: '$$md.quantity'
//                             }
//                         }
//                     },
//
//                 }
//             },
//             {
//                 $addFields: {
//
//                     item_total: {
//                         $cond: {
//
//                             if: { $gt: [ { $size: "$variations" }, 0 ] },
//                             then: {
//                                 $multiply: [
//                                     {
//                                         $sum: {
//                                             $concatArrays: [
//                                                 { $map: { input: "$variations", as: "v", in: "$$v.variation_price" } },
//                                                 {
//                                                     $map: {
//                                                         input: { $reduce: { input: "$variations.add_on_category.add_on_list", initialValue: [], in: { $concatArrays: [ "$$value", "$$this" ] } } },
//                                                         as: "aol",
//                                                         in: { $sum: "$$aol.add_ons_price" }
//                                                     }
//                                                 }
//                                             ]
//                                         }
//                                     },
//                                     "$quantity"
//                                 ]
//                             },
//                             else: {
//                                 $cond: {
//                                     if: { $and: [ { $eq: [ "$is_active", true ] }, { $size: "$menu_time_slots_map" } ] },
//                                     then: { $multiply: [ "$menu_price", "$quantity" ] },
//                                     else: 0
//                                 }
//                             }
//                         }
//                     },
//
//                 }
//             },
//
//             {
//                 $group: {
//                     _id: null,
//                     menu_data: { $push: '$$ROOT' },
//
//                 }
//             },
//
//
//
//             {
//                 $project: {
//                     _id:0,
//                     menu_data: {
//                         $map: {
//                             input: '$menu_data',
//                             as: 'md',
//                             in: {
//                                 _id: '$$md._id',
//                                 menu_name: '$$md.menu_name',
//                                 menu_price: '$$md.menu_price',
//                                 quantity: '$$md.quantity',
//                                 variations: '$$md.variations',
//                                 is_active: '$$md.is_active',
//                                 is_available: {     $cond: {
//                                         if: { $size: "$$md.menu_time_slots_map" },
//                                         then: true,
//                                         else: false
//                                     } },
//                                 item_total: '$$md.item_total',
//                                 item_sd:{
//                                     $multiply: [
//                                         "$$md.item_total",
//                                         {
//                                             $divide: [
//                                                 "$$md.sd",
//                                                 100
//                                             ]
//                                         }
//                                     ]
//                                 },
//                                 item_vat:{
//                                     $multiply: [
//                                         "$$md.item_total",
//                                         {
//                                             $divide: [
//                                                 "$$md.vat",
//                                                 100
//                                             ]
//                                         }
//                                     ]
//                                 }
//
//                             }
//                         }
//                     }
//                 }
//             },
//             {
//                 $project:{
//                     menu_data: 1,
//                     total_item_total: {
//                         $sum: '$menu_data.item_total'
//                     }  ,
//                     total_sd: {
//                         $sum: '$menu_data.item_sd'
//                     }  ,
//                     total_vat: {
//                         $sum: '$menu_data.item_vat'
//                     }
//                 }
//             }
//
//
//         ]);
//
//
//         return get_data;
//
//     }
//     catch (error) {
//         return {status: "fail", data: error.toString()}
//     }
// };
