import redis from "ioredis";
import Queue from "bull";
import dotenv from "dotenv";
import moment from "moment";
import { SYSTEM_TIMEZONE } from "../consts/defaults.js";
import Menu from "../models/Restaurant/Menu.js";
import RestaurentModel from "../models/Restaurant/RestaurentModel.js";
import { Send_Queue } from "./common/RMQ.js";
dotenv.config();
const cms_queue = process.env.CMS_QUEUE_NAME;
const models = {
  RestaurentModel: RestaurentModel,
  Menu: Menu,
};
const redis_client = redis.createClient({
  host: process.env.REDIS_URL,
  port: process.env.REDIS_PORT,
  password: process.env.REDIS_PASS,
  enableOfflineQueue: false,
});
const redisConfig = {
  redis: {
    host: process.env.REDIS_URL,
    port: process.env.REDIS_PORT,
    password: process.env.REDIS_PASS,
  },
};
export const orderQueue = new Queue("order allocations", redisConfig);
export const reactivationQueue = new Queue("reactivationQueue", redisConfig);

export const redis_set = (key, id, data) => {
  console.log("host", process.env.REDIS_URL);
  return redis_client.hset(key, id, JSON.stringify(data));
};

export const redis_get = (key, id) => {
  return redis_client.hget(key, id);
};

export const redis_get_all = (key) => {
  return redis_client.hgetall(key);
};

export const redis_delete_by_id = (key, id) => {
  return redis_client.del(key, id);
};

export const redis_delete = (key) => {
  return redis_client.del(key);
};

export const calculateDelay = (deactivationDate) => {
  if (!deactivationDate) {
    return 0;
  }

  const currentDate = moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate();
  console.log("currentDate", currentDate);
  const delay = deactivationDate.getTime() - currentDate.getTime();

  return Math.max(delay, 0);
};
export const handleReactivationJob = async (job) => {
  const { id, model } = job.data;
  let data;

  console.log("model", model);
  try {
    if (model) {
      let MODEL = models[model];

      if (model === "RestaurentModel") {
        data = await MODEL.findOneAndUpdate(
          { _id: id },
          {
            $set: {
              is_active: true,
              is_busy: false,
              deactivation_date: null,
            },
          },
          { new: true }
        );
        let branch_data = {
          _id: data._id,
          is_active: data.is_active,
          is_busy: data.is_busy,
          deactivation_date: data.deactivation_date,
          updated_at: data.updated_at,
          updated_by: data.updated_by,
        };
        let cms_data = {
          branch: {
            data: branch_data,
            method: "edit",
          },
          branch_closing_issue: {
            data: null,
            method: "add",
          },
        };

        await Send_Queue(
          cms_queue,
          "restaurant_queue",
          cms_data,
          "branch",
          "change_status"
        );
      } else if (model === "Menu") {
        data = await MODEL.findOneAndUpdate(
          { _id: id },
          {
            $set: {
              is_active: true,
              deactivation_date: null,
            },
          },
          { new: true }
        );
        let cms_data = {
          _id: data._id,
          is_active: data.is_active,
          deactivation_date: data.deactivation_date,
          updated_at: data.updated_at,
          updated_by: data.updated_by,
        };

        await Send_Queue(cms_queue, "restaurant_queue", cms_data, "menu", "edit");
      }

      if (!data) {
        console.log(` ID ${_id} not found`);
        return;
      }

      console.log(`ID ${id} reactivated successfully`);
    }
  } catch (err) {
    console.error(`Error reactivating  ID ${id}:`, err);
  }
};
