import Zone from "../../models/Zone/Zone.js";
import { res_basic_data } from "../../utility/const.js";

export const getZone = async (lat, long) => {
  try {
    let get_zone;

    get_zone = await Zone.aggregate([
      {
        $match: {
          lat_long: {
            $geoIntersects: {
              $geometry: {
                type: "Point",
                coordinates: [long, lat],
              },
            },
          },
        },
      },
      { $project: { _id: 1, name: 1 } },
      { $match: { name: { $exists: true, $ne: null } } },
    ]);

    console.log(get_zone);

    return get_zone;
  } catch (err) {
    console.error(err);
    return false;
  }
};
