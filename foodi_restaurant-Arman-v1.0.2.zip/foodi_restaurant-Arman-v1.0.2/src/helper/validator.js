import Validator from "validatorjs";

export const couponBasicRules = {
  customer_id: "required",
  coupon_name: "required",
};
export const favBasicRules = {
  customer_id: "required",
  branch_id: "required",
};
export const reviewBasicRules = {
  id: "required",
  order_id: "required",
};
export const orderBasicRules = {
  id: "required",
  address: "required",
};
export const pickUporderBasicRules = {
  id: "required",
};

export const validator = async (body, rules, customMessages, callback) => {
  const validation = new Validator(body, rules, customMessages);
  validation.passes(() => callback(null, true));
  validation.fails(() => callback(validation.errors, false));
};
