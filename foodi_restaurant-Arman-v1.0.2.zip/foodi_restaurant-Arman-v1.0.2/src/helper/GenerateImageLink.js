import axios from "axios";
import * as dotenv from "dotenv";
import fs from "fs";
import FormData from "form-data";

dotenv.config();

const GOOGLE_API_KEY = process.env.GOOGLE_API_KEY;

const GenerateImageLink = async (imagePath) => {
  try {
    const data = new FormData();
    data.append("image", fs.createReadStream(imagePath));
    let config = {
      method: "post",
      maxBodyLength: Infinity,
      url: "http://18.138.164.11:5166/Image",
      headers: {
        ...data.getHeaders(),
      },
      data: data,
    };

    const response = await axios.request(config);
    return response.data ? response.data : null;
  } catch (error) {
    console.error(error);
    throw new Error(error.toString());
  }
};

export default GenerateImageLink;
