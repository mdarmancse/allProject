import jwt from "jsonwebtoken";
import { blacklist } from "../helper/blacklist.js";
import { isTokenRevoked } from "../utility/functions.js";
import RestaurantUser from "../models/RestaurantUser/RestaurantUser.js";

const optional_routes = [
  "/api/v1/restaurant/restaurant_view",
  "/api/v1/restaurant/campaign/details",
  "/api/v1/restaurant/nearby",
  "/api/v1/restaurant/similar",
  "/api/v1/restaurant/getPromotions",
  "/api/v1/restaurant/popular",
  "/api/v1/restaurant/cuisine_details",
  "/api/v1/restaurant/search",
  "/api/v1/restaurant/cart/add",
  "/api/v1/restaurant/review/get",

  "/api/v1/restaurant/pickup/restaurant_view",
  "/api/v1/restaurant/pickup/campaign/details",
  "/api/v1/restaurant/pickup/nearby",
  "/api/v1/restaurant/pickup/getPromotions",
  "/api/v1/restaurant/pickup/search",
  "/api/v1/restaurant/pickup/cart/add",

  "/api/v1/restaurant/dine/restaurant_view",
  "/api/v1/restaurant/dine/campaign/details",
  "/api/v1/restaurant/dine/cuisine_details",
  "/api/v1/restaurant/dine/nearby",
  "/api/v1/restaurant/dine/search",
  "/api/v1/restaurant/dine/similar",
];

export default async (req, res, next) => {
  try {
    let role_name;

    const bearerHeader = req.headers["authorization"];

    if (typeof bearerHeader !== "undefined") {
      const bearer = bearerHeader.split(" ");
      const bearerToken = bearer[1];

      try {
        const decoded = jwt.verify(bearerToken, "foodi@#$2020");
        const isRevoked = await isTokenRevoked(bearerToken);
        console.log("isRevoked", isRevoked);

        if (isRevoked) {
          return res.status(401).json({
            status: -1,
            msg: "Your session has expired. Please log in again.",
          });
        }

        const id = decoded.data.id;
        if (id) {
          role_name = await RestaurantUser.getRoleByUserId(id);
        }
        console.log("ROLES", role_name);
        req.body.id = id;
        if (typeof role_name !== "undefined") {
          req.body.role_name = role_name.role_name ? role_name.role_name : null;
          req.body.role_id = role_name.role_id ? role_name.role_id : null;
        }

        next();
      } catch (err) {
        res.status(401).json({ status: "Unauthorized" });
      }
    } else {
      if (optional_routes.includes(req.originalUrl)) {
        next();
      } else {
        res.status(401).json({ status: "Access Denied" });
      }
    }
  } catch (err) {
    res.status(500).json({ status: "Server Error" });
  }
};
