/** Delivery part*/
import {
  your_restaurant,
  restaurant_view,
  getPromotions,
  getCuisines,
  cuisine_details,
  fetch_popupbanner,
  restaurant_nearby_get,
  restaurant_popular_get,
  get_review_rating,
  add_review,
  add_favourite_rest,
  favourite_restaurant,
  popular_menu,
  rest_seeder,
  decrypt_deep_link,
  add_helpful,
} from "./controllers/delivery/RestaurentController";
import {
  fetch_campaign,
  getCampaignDetails,
} from "./controllers/delivery/CampaignController";
import { cartAdd } from "./controllers/delivery/CartController";

import {
  redeem_voucher,
  rewards_voucher_list,
  save_voucher,
  user_coupon_list,
} from "./controllers/delivery/CouponController";
import {
  add_order,
  order_details,
  re_order,
  user_order_list,
  ongoing_order,
  delivery_charge,
} from "./controllers/delivery/OrderController";
import { search } from "./controllers/delivery/SearchController";

/** PickUp part*/
import {
  pick_restaurant_view,
  pick_getPromotions,
  pick_restaurant_nearby_get,
} from "./controllers/pickup/RestaurentController";
import {
  pick_fetch_campaign,
  pick_getCampaignDetails,
} from "./controllers/pickup/CampaignController";
import { pick_cartAdd } from "./controllers/pickup/CartController";

import { pick_add_order } from "./controllers/pickup/OrderController";

import { pick_search } from "./controllers/pickup/SearchController";

/** Dine part*/
import {
  dine_restaurant_view,
  dine_restaurant_nearby_get,
} from "./controllers/dinein/RestaurentController";
import {
  dine_fetch_campaign,
  dine_getCampaignDetails,
} from "./controllers/dinein/CampaignController";
import { dine_search } from "./controllers/dinein/SearchController";
import { dine_getFaq } from "./controllers/dinein/FaqController";

/** Paths **/
const paths = {
  /** Delivery part*/
  your_restaurant: your_restaurant,
  restaurant_view: restaurant_view,
  fetch_campaign: fetch_campaign,
  getPromotions: getPromotions,
  getCuisines: getCuisines,
  getCampaignDetails: getCampaignDetails,
  cuisine_details: cuisine_details,
  fetch_popupbanner: fetch_popupbanner,
  restaurant_nearby_get: restaurant_nearby_get,
  restaurant_popular_get: restaurant_popular_get,
  save_voucher: save_voucher,
  user_coupon_list: user_coupon_list,
  get_review_rating: get_review_rating,
  add_review: add_review,
  add_favourite_rest: add_favourite_rest,
  cartAdd: cartAdd,
  add_order: add_order,
  user_order_list: user_order_list,
  favourite_restaurant: favourite_restaurant,
  popular_menu: popular_menu,
  order_details: order_details,
  rewards_voucher_list: rewards_voucher_list,
  redeem_voucher: redeem_voucher,
  re_order: re_order,
  rest_seeder: rest_seeder,
  decrypt_deep_link: decrypt_deep_link,
  ongoing_order: ongoing_order,
  search: search,
  delivery_charge: delivery_charge,
  add_helpful: add_helpful,

  /** PickUp part*/
  pick_fetch_campaign: pick_fetch_campaign,
  pick_getCampaignDetails: pick_getCampaignDetails,
  pick_getPromotions: pick_getPromotions,
  pick_restaurant_view: pick_restaurant_view,
  pick_restaurant_nearby_get: pick_restaurant_nearby_get,
  pick_cartAdd: pick_cartAdd,
  pick_add_order: pick_add_order,
  pick_search: pick_search,

  /** DineIn part*/
  dine_fetch_campaign: dine_fetch_campaign,
  dine_getCampaignDetails: dine_getCampaignDetails,
  dine_restaurant_view: dine_restaurant_view,
  dine_restaurant_nearby_get: dine_restaurant_nearby_get,
  dine_search: dine_search,
  dine_getFaq: dine_getFaq,
};

export default async (path, body) => {
  let response;
  try {
    response = paths[path](body);
    if (response) return response;
  } catch (err) {
    console.error(err);
    return {
      status: -1,
      msg: "Gateway not found",
    };
  }
};
