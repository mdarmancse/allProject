import { Router } from "express";

import Auth from "../middleware/AuthVerifier.js";
const router = Router();
import dotenv from "dotenv";
import {
  add_favourite_rest,
  add_helpful,
  add_review,
  cuisine_details,
  decrypt_deep_link,
  favourite_restaurant,
  fetch_popupbanner,
  get_review_rating,
  get_zone,
  getAttributes,
  getCuisines,
  getPromotions,
  popular_menu,
  rest_seeder,
  restaurant_nearby_get,
  restaurant_popular_get,
  restaurant_view,
  your_restaurant,
} from "../controllers/delivery/RestaurentController.js";
import {
  fetch_campaign,
  getCampaignDetails,
} from "../controllers/delivery/CampaignController.js";
import {
  redeem_voucher,
  rewards_voucher_list,
  save_voucher,
  user_coupon_list,
} from "../controllers/delivery/CouponController.js";
import { cartAdd } from "../controllers/delivery/CartController.js";
import {
  add_order,
  autoRouting,
  delivery_charge,
  getRedisRider,
  hitMap,
  ongoing_order,
  order_details,
  orderCountByCunstomer,
  re_order,
  user_order_list,
} from "../controllers/delivery/OrderController.js";
import {
  create_index,
  deleteSearch,
  search,
  search_data,
  search_suggest,
  searchItem,
} from "../controllers/delivery/SearchController.js";
dotenv.config();

router.post("/nearby", Auth, restaurant_nearby_get);
router.post("/favourite", Auth, favourite_restaurant);
router.post("/popular", Auth, restaurant_popular_get);
router.post("/getCuisines", getCuisines);
router.get("/getAttributes", getAttributes);
router.post("/cuisine_details", Auth, cuisine_details);
router.get("/fetch_campaign", fetch_campaign);
router.post("/campaign/details", Auth, getCampaignDetails);
router.post("/your_restaurant", Auth, your_restaurant);
router.post("/restaurant_view", Auth, restaurant_view);
router.post("/getPromotions", Auth, getPromotions);
router.post("/save_voucher", Auth, save_voucher);
router.get("/user_coupon_list", Auth, user_coupon_list);
router.post("/review/get", Auth, get_review_rating);
router.post("/cart/add", Auth, cartAdd);
router.post("/review/add", Auth, add_review);
router.post("/review/helpful", Auth, add_helpful);
router.post("/add_favourite_rest", Auth, add_favourite_rest);
router.post("/fetch_popupbanner", fetch_popupbanner);
router.post("/order/add", Auth, add_order);
router.get("/order/list", Auth, user_order_list);
router.post("/order/details", Auth, order_details);
router.post("/popular_menu", popular_menu);
router.get("/rewards_voucher_list", Auth, rewards_voucher_list);
router.post("/redeem_voucher", Auth, redeem_voucher);
router.post("/order/re_order", Auth, re_order);
router.post("/rest_seeder", Auth, rest_seeder);
router.post("/deep_link", decrypt_deep_link);
router.get("/order/ongoing", Auth, ongoing_order);
router.post("/search", Auth, search);
router.post("/delivery_charge", Auth, delivery_charge);
router.post("/hitMap", Auth, hitMap);
router.post("/zone/get", get_zone);

router.post("/search/create_index", create_index);
router.get("/search/suggest/:value", search_suggest);
router.delete("/search/delete/:id", deleteSearch);
router.post("/search/data", search_data);
router.get("/order/assign", autoRouting);
router.get("/rider/redis/get", getRedisRider);

router.get("/search-item", searchItem);
router.get("/order-count/:userId", orderCountByCunstomer);

export default router;
