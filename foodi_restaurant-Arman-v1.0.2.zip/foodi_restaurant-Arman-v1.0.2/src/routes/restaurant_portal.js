import { Router } from "express";

import Auth from "../middleware/AuthVerifier.js";
const router = Router();
import dotenv from "dotenv";
import {
  changeStatus,
  getAcceptedOrder,
  getNewOrder,
  getOrderDetails,
  getOrderList,
  getRecentOrder,
} from "../controllers/RestaurantPortal/OrderController.js";
import {
  addRestReview,
  addRestReviewReason,
  changeRestaurantStatus,
  getBranchList,
  getParentRestList,
  getRestaurantDetails,
  restaurantStatus,
  updateRestaurant,
} from "../controllers/RestaurantPortal/RestaurantController.js";
import multer from "multer";
import {
  getRestaurantMenu,
  getRestaurantMenuSearch,
  menuDeactivation,
  menuReactivation,
} from "../controllers/RestaurantPortal/MenuController.js";
import { getRestaurantCategory } from "../controllers/RestaurantPortal/CategoryController.js";
import {
  login,
  logout,
  performance,
} from "../controllers/RestaurantPortal/HomeController.js";
dotenv.config();

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, "uploads/");
  },
  filename: function (req, file, cb) {
    cb(null, file.fieldname + "-" + Date.now());
  },
});

const upload = multer({
  storage: storage,
  // fileFilter: function (req, file, cb) {
  //     if (!file.mimetype.startsWith('image/')) {
  //         return cb(new Error('Only image files are allowed!'))
  //     }
  //     cb(null, true)
  // }
});
//
router.post("/login", login);
router.post("/logout", Auth, logout);
router.post("/order/list", Auth, getOrderList);
router.post("/order/new", Auth, getNewOrder);
router.post("/order/accepted", Auth, getAcceptedOrder);
router.post("/order/recent", Auth, getRecentOrder);
router.post("/order/details", Auth, getOrderDetails);
router.post("/order/change_status", Auth, changeStatus);
router.post("/order/review/add", Auth, addRestReview);
router.post("/order/review/add_reason", Auth, addRestReviewReason);
router.post("/restaurant/branch/list", Auth, getBranchList);
router.post("/restaurant/details", Auth, getRestaurantDetails);
router.post("/restaurant/parent", Auth, getParentRestList);
router.get("/restaurant/status/:rest_id", Auth, restaurantStatus);
router.post("/restaurant/performance", Auth, performance);
router.post("/restaurant/menu", Auth, getRestaurantMenu);
router.post("/restaurant/category", Auth, getRestaurantCategory);
router.post("/restaurant/menu/search", Auth, getRestaurantMenuSearch);
router.post("/restaurant/menu/deactivate", Auth, menuDeactivation);
router.post("/restaurant/menu/reactivate", Auth, menuReactivation);
router.post("/restaurant/change_status", Auth, changeRestaurantStatus);
router.put(
  "/restaurant/edit",
  upload.fields([
    { name: "image", maxCount: 1 },
    { name: "cover_image", maxCount: 1 },
  ]),
  Auth,
  updateRestaurant
);

export default router;
