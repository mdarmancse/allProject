import { Router } from "express";
import Auth from "../middleware/AuthVerifier.js";
const router = Router();
import dotenv from "dotenv";
import {
  pick_add_favourite_rest,
  pick_favourite_restaurant,
  pick_getPromotions,
  pick_restaurant_nearby_get,
  pick_restaurant_view,
} from "../controllers/pickup/RestaurentController.js";
import {
  pick_fetch_campaign,
  pick_getCampaignDetails,
} from "../controllers/pickup/CampaignController.js";
import { pick_cartAdd } from "../controllers/pickup/CartController.js";
import { pick_add_order } from "../controllers/pickup/OrderController.js";
import { pick_search } from "../controllers/pickup/SearchController.js";
dotenv.config();

router.post("/favourite", Auth, pick_favourite_restaurant);
router.post("/add_favourite_rest", Auth, pick_add_favourite_rest);
router.post("/nearby", Auth, pick_restaurant_nearby_get);
router.post("/campaign/details", pick_getCampaignDetails);
router.post("/restaurant_view", Auth, pick_restaurant_view);
router.post("/getPromotions", Auth, pick_getPromotions);
router.get("/fetch_campaign", pick_fetch_campaign);
router.post("/cart/add", Auth, pick_cartAdd);
router.post("/order/add", Auth, pick_add_order);
router.post("/search", Auth, pick_search);

export default router;
