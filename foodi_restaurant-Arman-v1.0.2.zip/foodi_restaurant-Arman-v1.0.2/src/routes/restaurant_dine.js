import { Router } from "express";
import Auth from "../middleware/AuthVerifier.js";
const router = Router();
import dotenv from "dotenv";
import {
  dine_cuisine_details,
  dine_getCuisines,
  dine_restaurant_nearby_get,
  dine_restaurant_view,
  dine_similar_restaurants,
} from "../controllers/dinein/RestaurentController.js";
import {
  dine_fetch_campaign,
  dine_getCampaignDetails,
} from "../controllers/dinein/CampaignController.js";
import { dine_getFaq } from "../controllers/dinein/FaqController.js";
import { dine_search } from "../controllers/dinein/SearchController.js";
import {
  dine_check_coupon,
  dine_redeem_voucher,
} from "../controllers/dinein/CouponController.js";

dotenv.config();

router.post("/check_coupon", Auth, dine_check_coupon);
router.post("/redeem_voucher", Auth, dine_redeem_voucher);
router.post("/nearby", Auth, dine_restaurant_nearby_get);
router.post("/similar", Auth, dine_similar_restaurants);
router.post("/campaign/details", Auth, dine_getCampaignDetails);
router.post("/restaurant_view", Auth, dine_restaurant_view);
router.get("/fetch_campaign", dine_fetch_campaign);
router.post("/getCuisines", dine_getCuisines);
router.post("/cuisine_details", Auth, dine_cuisine_details);
router.post("/search", Auth, dine_search);
router.get("/getFaq", dine_getFaq);

export default router;
