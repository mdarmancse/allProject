import Express, { json, urlencoded } from "express";
import * as mongoose from "mongoose";
import { Rcv_Central } from "./helper/common/RMQ";
import { connect as rmq_connect } from "amqplib";
import resolvePath from "./paths";
import methodOverride from "method-override";

import restaurantRouter from "./routes/restaurant_delivery";
import pickupRouter from "./routes/restaurant_pickup";
import dineRouter from "./routes/restaurant_dine";
import portalRouter from "./routes/restaurant_portal";

import MongoSanitize from "express-mongo-sanitize";
import RateLimit from "express-rate-limit";
import Helmet from "helmet";
import Hpp from "hpp";
import Cors from "cors";
import XssClean from "xss-clean";

import fs from "fs";
import { handleReactivationJob, reactivationQueue } from "./helper/redis";
import { getSystemOption } from "./controllers/RestaurantPortal/HomeController";

const errorLogStream = fs.createWriteStream("error.log", { flags: "a" });

const URI = process.env.DB_URI;
const DB_USER_NAME = process.env.DB_USER_NAME;
const DB_PASSWORD = process.env.DB_PASSWORD;
const RABBIT_MQ = process.env.RABBIT_MQ;

const app = new Express();
//Security Middleware Implementation //Always implement before route
app.use(MongoSanitize());
app.use(Helmet());
app.use(Hpp());
app.use(Cors());
app.use(XssClean());
app.use(json({ limit: "50mb" }));
app.use(urlencoded({ limit: "50mb", extended: false }));
//Request Rate Limit Implementation

const limiter = RateLimit({
  windowMs: 15 * 60 * 1000,
  max: 100,
});

// Send the message using the FCM SDK

//Apply for all request
//app.use(limiter);
// Error-handling middleware function
// app.use((err, req, res, next) => {
//     console.error(err);
//     res.status(500).send('Something broke!');
// });
function logErrors(err, req, res, next) {
  console.error(err.stack);
  errorLogStream.write(err.stack + "\n");
  next(err);
}

function errorHandler(err, req, res, next) {
  res.status(500);
  res.render("error", { error: err });
}

function clientErrorHandler(err, req, res, next) {
  if (err) {
    res.status(500).send({ error: "Something failed!" });
  }
}
app.use(methodOverride());
app.use(logErrors);
app.use(errorHandler);
app.use(clientErrorHandler);
// CSP
app.use(function (req, res, next) {
  res.setHeader("Content-Security-Policy", "script-src 'unsafe-inline';");
  next();
});
//Route
app.get("/api/v1/system/option/get", getSystemOption);
app.use("/api/v1/restaurant", restaurantRouter);
app.use("/api/v1/restaurant/pickup", pickupRouter);
app.use("/api/v1/restaurant/dine", dineRouter);
app.use("/api/v1/restaurant/portal", portalRouter);

async function connect() {
  try {
    const conn = await rmq_connect(RABBIT_MQ);
    conn.on("error", (err) => {
      console.error("Error connecting to RMQ: ", err);
      // Add any additional error handling code here
    });

    const channel = await conn.createChannel();
    const requestQueue = "restaurent_request";
    channel.assertQueue(requestQueue, { durable: false });
    const interRequestQueue = "main_restaurant_request";
    channel.assertQueue(interRequestQueue, { durable: false });
    // channel.prefetch(1);

    channel.consume(requestQueue, async (msg) => {
      const body = JSON.parse(msg.content.toString());
      const path = msg.properties.headers.path;

      console.log("path", path);
      const response = await resolvePath(path, body);
      console.log("Received Reply", response);
      channel.sendToQueue(msg.properties.replyTo, Buffer.from(JSON.stringify(response)), {
        correlationId: msg.properties.correlationId,
      });
      channel.ack(msg);
    });

    // channel.prefetch(1);

    channel.consume(interRequestQueue, async (msg) => {
      console.log(msg);
      const body = JSON.parse(msg.content.toString());
      const method = msg.properties.messageId;
      const modelName = msg.properties.contentType;

      console.log("modelName", modelName);
      console.log("body", body);
      const response = await Rcv_Central(body, modelName, method);
      console.log("response", response);

      setTimeout(() => {
        try {
          channel.sendToQueue(
            msg.properties.replyTo,
            Buffer.from(JSON.stringify(response)),
            { correlationId: msg.properties.correlationId }
          );
          channel.ack(msg);
        } catch (err) {
          console.error(err);
          channel.sendToQueue(
            msg.properties.replyTo,
            Buffer.from(
              JSON.stringify({
                status: -1,
                msg: "Service failed to respond.",
              })
            ),
            { correlationId: msg.properties.correlationId }
          );
          channel.ack(msg);
        }
      }, 500);
    });
  } catch (err) {
    console.error("Error connecting to RMQ: ", err);
  }
}

connect();
reactivationQueue.process(async (job) => {
  await handleReactivationJob(job);
});

let OPTIONS = {
  user: DB_USER_NAME,
  pass: DB_PASSWORD,
  autoIndex: true,
};
// let OPTIONS={user:'',pass:''};
mongoose.connect(URI, OPTIONS, (error) => {
  console.log("Connection Success");
  console.log(error);
});

mongoose.set("debug", (collectionName, method, query, doc) => {
  console.log(`${collectionName}.${method}`, JSON.stringify(query), doc);
});

//Undefined Route
app.use("*", (req, res) => {
  res.status(404).json({ status: "Fail", data: "Not Found" });
});

export default app;
