import RevokedTokenModel from "../models/RevokedToken.js";
import jwt from "jsonwebtoken";

const isTokenRevoked = async (token) => {
  // Check if the token exists in the revoked tokens collection
  const revokedToken = await RevokedTokenModel.findOne({ token: token });
  return revokedToken !== null;
};
const generateToken = async (data) => {
  var token = await jwt.sign(
    {
      exp: Math.floor(Date.now() / 1000) + 60 * 60 * 24 * 30,
      data: data,
    },
    "foodi@#$2020"
  );
  return token;
};

export { isTokenRevoked, generateToken };
