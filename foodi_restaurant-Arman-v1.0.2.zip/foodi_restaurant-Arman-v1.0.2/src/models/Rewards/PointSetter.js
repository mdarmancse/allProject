import mongoose from "mongoose";
import { v4 as uuidv4 } from "uuid";

const DataSchema = new mongoose.Schema(
  {
    _id: {
      type: String,
      // default: () => uuidv4().replace(/\-/g, ""),
    },
    per_point_value: { type: Number, default: 0 },
    subscription_type_id: { type: String, default: null },
    is_active: { type: Boolean, default: true },
    created_at: { type: Date, default: null },
    created_by: { type: String, default: null },
    updated_at: { type: Date, default: null },
    updated_by: { type: String, default: null },
  },
  {
    collection: "point_setter",
    //  timestamps: true,
    versionKey: false,
  }
);

const PointSetter = mongoose.model("point_setter", DataSchema);
export default PointSetter;
