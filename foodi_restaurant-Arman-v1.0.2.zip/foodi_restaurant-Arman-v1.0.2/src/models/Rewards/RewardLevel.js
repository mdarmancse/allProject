import mongoose from "mongoose";
import { v4 as uuidv4 } from "uuid";
import { res_basic_data } from "../../utility/const.js";

const DataSchema = new mongoose.Schema(
  {
    _id: {
      type: String,
      //default: () => uuidv4().replace(/\-/g, ""),
    },
    name: { type: String, default: null },
    threshold_value: { type: Number, default: null },
    is_active: { type: Boolean, default: true },
    created_at: { type: Date, default: null },
    created_by: { type: String, default: null },
    updated_at: { type: Date, default: null },
    updated_by: { type: String, default: null },
  },
  {
    collection: "reward_level",
    //  timestamps: true,
    versionKey: false,
  }
);
DataSchema.statics.getRewardLevel = async function (total_current_point, total_point) {
  try {
    const data = await this.aggregate([
      {
        $facet: {
          less_than_total_point: [
            {
              $match: {
                threshold_value: { $lte: total_point },
                is_active: true,
              },
            },
            {
              $sort: { threshold_value: -1 },
            },
            {
              $limit: 1,
            },
          ],
          greater_than_total_point: [
            {
              $match: {
                threshold_value: { $gt: total_point },
                is_active: true,
              },
            },
            {
              $sort: { threshold_value: 1 },
            },
            {
              $limit: 1,
            },
          ],
        },
      },
      {
        $project: {
          result: {
            $concatArrays: ["$less_than_total_point", "$greater_than_total_point"],
          },
        },
      },
      {
        $unwind: "$result",
      },
      {
        $replaceRoot: { newRoot: "$result" },
      },
      {
        $limit: 1,
      },
      {
        $addFields: {
          completion_percentage: {
            $min: [
              100,
              {
                $multiply: [{ $divide: [total_current_point, "$threshold_value"] }, 100],
              },
            ],
          },
        },
      },

      {
        $project: {
          _id: 1,
          name: 1,
          threshold_value: 1,
          is_active: 1,
          completion_percentage: 1,
        },
      },
    ]);

    return data;
  } catch (err) {
    console.log("err :", err);
    return false;
  }
};

const RewardModel = mongoose.model("reward_level", DataSchema);
export default RewardModel;
