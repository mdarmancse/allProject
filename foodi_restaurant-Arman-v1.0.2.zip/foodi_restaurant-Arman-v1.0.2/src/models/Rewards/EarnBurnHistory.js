import mongoose from "mongoose";
import { v4 as uuidv4 } from "uuid";
import moment from "moment";
import { SYSTEM_TIMEZONE } from "../../consts/defaults.js";

const DataSchema = new mongoose.Schema(
  {
    _id: {
      type: String,
      default: () => uuidv4(),
    },
    point: { type: Number, default: 0 },
    cost: { type: Number, default: 0 },
    per_point_value: { type: Number, default: 0 },
    type: { type: String, default: null, enum: ["Earn", "Burn"] },
    description: { type: String, default: null },
    voucher_id: { type: String, default: null },
    order_id: { type: String, default: null },
    customer_id: { type: String, default: null },
    is_active: { type: Boolean, default: true },
    created_at: {
      type: Date,
      default: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
    },
    created_by: { type: String, default: null },
    updated_at: {
      type: Date,
      default: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
    },
    updated_by: { type: String, default: null },
  },
  {
    collection: "earn_burn_history",
    //  timestamps: true,
    versionKey: false,
  }
);

const EarnBurnHistory = mongoose.model("earn_burn_history", DataSchema);
export default EarnBurnHistory;
