import mongoose from "mongoose";
import { v4 as uuidv4 } from "uuid";

const DataSchema = new mongoose.Schema(
  {
    _id: {
      type: String,
      //default: () => uuidv4().replace(/\-/g, ""),
    },
    name: { type: String },
    image: { type: String, default: null },

    type: { type: String, default: "in_app", enum: ["in_app", "out_app"] },
    voucher_amount: { type: Number, default: 0 },
    voucher_cost_in_point: { type: Number, default: 0.0 },
    validity_time: { type: Number, default: 0 },
    notes: { type: String, default: null },
    description: { type: String, default: null },
    restaurants: [
      {
        res_id: { type: String },
      },
    ],
    is_delivery: { type: Boolean, default: true },
    is_pickup: { type: Boolean, default: false },
    is_dine: { type: Boolean, default: false },
    is_active: { type: Boolean, default: true },
    created_at: { type: Date, default: null },
    created_by: { type: String, default: null },
    updated_at: { type: Date, default: null },
    updated_by: { type: String, default: null },
  },
  {
    collection: "voucher_settings",
    //  timestamps: true,
    versionKey: false,
  }
);

const VoucherSetting = mongoose.model("voucher_settings", DataSchema);
export default VoucherSetting;
