import mongoose from "mongoose";

const DataSchema = new mongoose.Schema(
  {
    _id: {
      type: String,
      //default: () => uuidv4().replace(/\-/g, ""),
    },
    name: { type: String },
    is_active: { type: Boolean, default: true },
    created_at: { type: Date, default: null },
    created_by: { type: String, default: null },
    updated_at: { type: Date, default: null },
    updated_by: { type: String, default: null },
  },
  {
    collection: "payment_methods",
    //  timestamps: true,
    versionKey: false,
  }
);

const PaymentMethod = mongoose.model("payment_methods", DataSchema);
export default PaymentMethod;
