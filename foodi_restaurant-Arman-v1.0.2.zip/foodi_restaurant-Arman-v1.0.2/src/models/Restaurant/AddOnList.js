import mongoose from "mongoose";
import { v4 as uuidv4 } from "uuid";

const DataSchema = mongoose.Schema(
  {
    _id: {
      type: String,
      // default: () => uuidv4().replace(/\-/g, ""),
    },
    addoncat_id: { type: String },
    add_ons_name: { type: String },
    add_ons_price: { type: Number, default: 0 },
    max_choice: { type: Number, default: 0 },
    is_multiple: { type: Boolean, default: false },
    variation_and_add_on_category_id: { type: String, default: null },
    is_active: { type: Boolean, default: true },
    created_at: { type: Date, default: null },
    created_by: { type: String, default: null },
    updated_at: { type: Date, default: null },
    updated_by: { type: String, default: null },
  },
  {
    collection: "addon_list",
    versionKey: false,
  }
);

const addon_list = mongoose.model("addon_list", DataSchema);
export default addon_list;
