import mongoose from "mongoose";

const DataSchema = new mongoose.Schema(
  {
    _id: {
      type: String,
    },
    name: { type: String, default: null },
    branch_id: { type: String, default: null },
    start_time: {
      hour: { type: Number },
      minute: { type: Number },
    },
    end_time: {
      hour: { type: Number },
      minute: { type: Number },
    },
    is_active: { type: Boolean, default: true },
    created_at: { type: Date, default: null },
    created_by: { type: String, default: null },
    updated_at: { type: Date, default: null },
    updated_by: { type: String, default: null },
  },
  {
    collection: "menu_item_time_slots",
    // timestamps: true,
    versionKey: false,
  }
);

const MenuItemTimeSlot = mongoose.model("menu_item_time_slots", DataSchema);
export default MenuItemTimeSlot;
