import mongoose from "mongoose";

const DataSchema = new mongoose.Schema(
  {
    _id: {
      type: String,
    },
    menu_item_id: { type: String },
    menu_item_time_slot_id: { type: String },
    is_active: { type: Boolean, default: true },
    created_at: { type: Date, default: null },
    created_by: { type: String, default: null },
    updated_at: { type: Date, default: null },
    updated_by: { type: String, default: null },
  },
  {
    collection: "menu_item_and_menu_item_time_slots",
    // timestamps: true,
    versionKey: false,
  }
);

const MenuItemAndMenuItemTimeSlot = mongoose.model(
  "menu_item_and_menu_item_time_slots",
  DataSchema
);
export default MenuItemAndMenuItemTimeSlot;
