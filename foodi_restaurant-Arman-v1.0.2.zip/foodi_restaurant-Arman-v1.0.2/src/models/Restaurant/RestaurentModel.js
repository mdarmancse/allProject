import mongoose from "mongoose";
// import { v4 as uuidv4 } from "uuid";
import { res_basic_data } from "../../utility/const.js";
import moment from "moment";
import { SYSTEM_TIMEZONE } from "../../consts/defaults.js";

const DataSchema = new mongoose.Schema(
  {
    _id: {
      type: String,
      // default: () => uuidv4().replace(/\-/g, ""),
    },
    parent_restaurant_id: { type: String },
    zone_id: [
      {
        _id: { type: String },
      },
    ],
    location: {
      type: {
        type: String,
        default: "Point",
        enum: ["Point"],
        // index: "2dsphere",
      },
      coordinates: [],
    },
    cuisines: [
      {
        _id: { type: String, default: null },
        branch_id: { type: String, default: null },
        cuisine_id: { type: String },
      },
    ],
    attributes: [
      {
        _id: { type: String, default: null },
        branch_id: { type: String, default: null },
        branch_attribute_id: { type: String },
      },
    ],
    name: { type: String, default: null },
    slug: { type: String, default: null },
    phone_number: { type: String, default: null },
    email: { type: String, default: null },
    address: { type: String, default: null },
    share_link: { type: String, default: null },
    price_range: { type: String, default: null },
    image: { type: String, default: null },
    is_veg: { type: Boolean, default: true },
    zonal_admin: { type: String, default: null },
    popularity_sort_value: { type: String, default: null },
    is_popular: { type: Number, default: 0 },
    vat: { type: Number, default: 0 },
    sd: { type: Number, default: 0 },
    min_order_value: { type: Number, default: 0 },
    branch_admin: { type: String, default: null },
    central_admin: { type: String, default: null },
    working_hours: [
      {
        _id: { type: String, default: null },
        branch_id: { type: String, default: null },
        // 1 for Monday and 7 for Sunday
        day: {
          type: Number,
          min: 1,
          max: 7,
        },
        open_hour: { type: Number, min: 0, max: 23 },
        open_minute: { type: Number, min: 0, max: 59 },
        close_hour: { type: Number, min: 0, max: 23 },
        close_minute: { type: Number, min: 0, max: 59 },
      },
    ],
    is_take_pre_order: { type: Boolean, default: false },
    commission: { type: Number, default: null },
    delivery_charge: { type: Number, default: null },
    delivery_time: { type: Number, default: null },
    pickup_time: { type: Number, default: null },
    deactivation_date: { type: Date, default: null },
    logo: { type: String, default: null },
    cover_image: { type: String, default: null },
    currency: { type: String, default: null },
    // menu_card_images:[],
    // ambience_card_images:[],
    // food_card_images:[],
    is_delivery: { type: Boolean, default: true },
    is_pickup: { type: Boolean, default: false },
    is_dine: { type: Boolean, default: false },
    is_busy: { type: Boolean, default: false },
    is_active: { type: Boolean, default: true },
    created_at: { type: Date, default: null },
    created_by: { type: String, default: null },
    updated_at: { type: Date, default: null },
    updated_by: { type: String, default: null },
  },
  {
    collection: "restaurents",
    versionKey: false,
  }
);

DataSchema.statics.getNearbyRestaurant = async function (
  zone_id,
  user_id,
  long,
  lat,
  lim,
  page = 1
) {
  console.log("ZONEID", zone_id);
  let limit = lim > 0 ? lim : 100;
  try {
    const data = await this.aggregate([
      {
        $geoNear: {
          near: { type: "Point", coordinates: [long, lat] },
          distanceField: "distance",
          //maxDistance: 10000,
          query: { is_active: true, is_delivery: true, "zone_id._id": zone_id },
        },
      },
      { $unwind: "$working_hours" },
      {
        $set: {
          open: {
            $dateFromParts: {
              isoWeekYear: {
                $isoWeekYear: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
              },
              isoWeek: {
                $isoWeek: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
              },
              isoDayOfWeek: "$working_hours.day",
              hour: "$working_hours.open_hour",
              minute: "$working_hours.open_minute",
            },
          },
          close: {
            $dateFromParts: {
              isoWeekYear: {
                $isoWeekYear: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
              },
              isoWeek: {
                $isoWeek: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
              },
              isoDayOfWeek: "$working_hours.day",
              hour: "$working_hours.close_hour",
              minute: "$working_hours.close_minute",
            },
          },
        },
      },
      {
        $set: {
          is_open: {
            $cond: {
              if: {
                $and: [
                  {
                    $lte: [
                      "$open",
                      moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
                    ],
                  },
                  {
                    $gt: [
                      "$close",
                      moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
                    ],
                  },
                ],
              },
              then: 1,
              else: 0,
            },
          },
        },
      },

      {
        $group: {
          _id: "$_id",
          is_open: { $max: "$is_open" },
          name: { $first: "$name" },
          image: { $first: "$image" },
          cover_image: { $first: "$cover_image" },
          address: { $first: "$address" },
          delivery_time: { $first: "$delivery_time" },
          delivery_charge: { $first: "$delivery_charge" },
          is_favourite: { $first: "$is_favourite" },
          coupons: { $first: "$coupons" },
          rating: { $first: "$rating" },
          price_range: { $first: "$price_range" },
          is_take_pre_order: { $first: "$is_take_pre_order" },
          cuisines: { $first: "$cuisines" },
          distance: { $first: "$distance" },
          open: { $last: "$open" },
        },
      },
      {
        $lookup: {
          from: "favourite_restaurants",
          localField: "_id",
          foreignField: "branch_id",
          pipeline: [{ $match: { customer_id: user_id, is_delivery: true } }],
          as: "is_favourite",
        },
      },
      {
        $lookup: {
          from: "cuisines",
          localField: "cuisines.cuisine_id",
          foreignField: "_id",
          as: "cuisines",
          pipeline: [
            {
              $match: {
                is_active: true,
                is_delivery: true,
              },
            },
            {
              $project: {
                status: 0,
                image: 0,
              },
            },
          ],
        },
      },

      {
        $lookup: {
          from: "branch_coupons",
          localField: "_id",
          foreignField: "branch_id",
          pipeline: [
            {
              $lookup: {
                from: "coupons",
                localField: "coupon_id",
                foreignField: "_id",
                pipeline: [
                  {
                    $match: {
                      is_active: true,
                      start_time: {
                        $lte: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
                      },
                      end_time: {
                        $gte: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
                      },
                    },
                  },
                  {
                    $sort: {
                      created_at: -1,
                    },
                  },
                  {
                    $limit: 2,
                  },
                  {
                    $project: {
                      _id: 1,
                      name: 1,
                      description: 1,
                    },
                  },
                ],
                as: "branch_coupons",
              },
            },
            {
              $limit: 2,
            },
            { $unwind: "$branch_coupons" },
            {
              $project: {
                branch_coupons: 1,
              },
            },
          ],
          as: "coupons",
        },
      },
      {
        $lookup: {
          from: "reviews",
          localField: "_id",
          foreignField: "rest_id",
          pipeline: [
            {
              $group: {
                _id: "$rest_id",
                avg: { $avg: "$rating" },
                no_review: { $sum: 1 },
              },
            },
            {
              $project: {
                _id: 0,
                avg: { $round: ["$avg", 1] },
                no_review: 1,
              },
            },
          ],
          as: "rating",
        },
      },
      { $sort: { distance: 1, _id: -1 } },
      {
        $match: {
          is_open: { $ne: 0 },
        },
      },

      {
        $project: {
          ...res_basic_data,
          coupons: "$coupons.branch_coupons",
          distance: 1,
        },
      },
    ])
      .skip(limit * (page - 1))
      .limit(limit);
    return data;
  } catch (err) {
    console.error(err);
    return false;
  }
};

DataSchema.statics.dine_getSimilarRestaurant = async function (
  zone_id,
  user_id,
  rest_id,
  cuisine_id,
  long,
  lat,
  lim,
  page = 1
) {
  let limit = lim > 0 ? lim : 15;
  // $not: [ { $eq: [ '$_id', rest_id ] } ]
  try {
    const data = await this.aggregate([
      {
        $geoNear: {
          near: { type: "Point", coordinates: [long, lat] },
          distanceField: "distance",
          //maxDistance: 10000,
          query: {
            is_active: true,
            is_dine: true,
            "zone_id._id": zone_id,
            _id: { $ne: rest_id },
            "cuisines.cuisine_id": { $in: cuisine_id },
          },
        },
      },
      { $unwind: "$working_hours" },
      {
        $set: {
          open: {
            $dateFromParts: {
              isoWeekYear: {
                $isoWeekYear: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
              },
              isoWeek: {
                $isoWeek: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
              },
              isoDayOfWeek: "$working_hours.day",
              hour: "$working_hours.open_hour",
              minute: "$working_hours.open_minute",
            },
          },
          close: {
            $dateFromParts: {
              isoWeekYear: {
                $isoWeekYear: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
              },
              isoWeek: {
                $isoWeek: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
              },
              isoDayOfWeek: "$working_hours.day",
              hour: "$working_hours.close_hour",
              minute: "$working_hours.close_minute",
            },
          },
        },
      },
      {
        $set: {
          is_open: {
            $cond: {
              if: {
                $and: [
                  {
                    $lte: [
                      "$open",
                      moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
                    ],
                  },
                  {
                    $gt: [
                      "$close",
                      moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
                    ],
                  },
                ],
              },
              then: 1,
              else: 0,
            },
          },
        },
      },

      {
        $lookup: {
          from: "favourite_restaurants",
          localField: "_id",
          foreignField: "branch_id",
          pipeline: [{ $match: { customer_id: user_id, is_dine: true } }],
          as: "is_favourite",
        },
      },
      {
        $lookup: {
          from: "cuisines",
          localField: "cuisines.cuisine_id",
          foreignField: "_id",
          as: "cuisines",
          pipeline: [
            {
              $match: {
                is_active: true,
                is_dine: true,
                // _id:{ $in: cuisine_id }
              },
            },
            {
              $project: {
                image: 0,
              },
            },
          ],
        },
      },

      {
        $lookup: {
          from: "branch_coupons",
          localField: "_id",
          foreignField: "branch_id",
          pipeline: [
            {
              $lookup: {
                from: "coupons",
                localField: "coupon_id",
                foreignField: "_id",
                pipeline: [
                  {
                    $match: {
                      is_active: true,
                      start_time: {
                        $lte: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
                      },
                      end_time: {
                        $gte: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
                      },
                    },
                  },
                  {
                    $sort: {
                      created_at: -1,
                    },
                  },
                  {
                    $limit: 2,
                  },
                  {
                    $project: {
                      _id: 1,
                      name: 1,
                      description: 1,
                    },
                  },
                ],
                as: "branch_coupons",
              },
            },
            {
              $limit: 2,
            },
            { $unwind: "$branch_coupons" },
            {
              $project: {
                branch_coupons: 1,
              },
            },
          ],
          as: "coupons",
        },
      },
      {
        $lookup: {
          from: "reviews",
          localField: "_id",
          foreignField: "rest_id",
          pipeline: [
            {
              $group: {
                _id: "$rest_id",
                avg: { $avg: "$rating" },
                no_review: { $sum: 1 },
              },
            },
            {
              $project: {
                _id: 0,
                avg: { $round: ["$avg", 1] },
                no_review: 1,
              },
            },
          ],
          as: "rating",
        },
      },

      {
        $group: {
          _id: "$_id",
          is_open: { $max: "$is_open" },
          name: { $first: "$name" },
          image: { $first: "$image" },
          cover_image: { $first: "$cover_image" },
          address: { $first: "$address" },
          delivery_time: { $first: "$delivery_time" },
          delivery_charge: { $first: "$delivery_charge" },
          is_favourite: { $first: "$is_favourite" },
          coupons: { $first: "$coupons" },
          rating: { $first: "$rating" },
          price_range: { $first: "$price_range" },
          is_take_pre_order: { $first: "$is_take_pre_order" },
          cuisines: { $first: "$cuisines" },
          distance: { $first: "$distance" },
        },
      },
      { $sort: { distance: 1, _id: -1 } },
      {
        $match: {
          is_open: { $ne: 0 },
        },
      },
      {
        $project: {
          ...res_basic_data,
          coupons: "$coupons.branch_coupons",
          distance: 1,
        },
      },
    ])
      .skip(limit * (page - 1))
      .limit(limit);
    return data;
  } catch (err) {
    console.error(err);
    return false;
  }
};

DataSchema.statics.getPopularRestaurants = async function (
  zone_id,
  user_id,
  long,
  lat,
  lim,
  page = 1
) {
  try {
    console.log("ZONEID", zone_id);
    let limit = lim > 0 ? lim : 15;
    const data = await this.aggregate([
      {
        $geoNear: {
          near: { type: "Point", coordinates: [long, lat] },
          distanceField: "distance",
          //maxDistance: 10000,
          query: {
            is_active: true,
            is_delivery: true,
            is_popular: 1,
            "zone_id._id": zone_id,
          },
        },
      },
      { $unwind: "$working_hours" },
      {
        $set: {
          open: {
            $dateFromParts: {
              isoWeekYear: {
                $isoWeekYear: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
              },
              isoWeek: {
                $isoWeek: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
              },
              isoDayOfWeek: "$working_hours.day",
              hour: "$working_hours.open_hour",
              minute: "$working_hours.open_minute",
            },
          },
          close: {
            $dateFromParts: {
              isoWeekYear: {
                $isoWeekYear: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
              },
              isoWeek: {
                $isoWeek: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
              },
              isoDayOfWeek: "$working_hours.day",
              hour: "$working_hours.close_hour",
              minute: "$working_hours.close_minute",
            },
          },
        },
      },
      {
        $set: {
          is_open: {
            $cond: {
              if: {
                $and: [
                  {
                    $lte: [
                      "$open",
                      moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
                    ],
                  },
                  {
                    $gt: [
                      "$close",
                      moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
                    ],
                  },
                ],
              },
              then: 1,
              else: 0,
            },
          },
        },
      },

      {
        $group: {
          _id: "$_id",
          is_open: { $max: "$is_open" },
          name: { $first: "$name" },
          image: { $first: "$image" },
          cover_image: { $first: "$cover_image" },
          address: { $first: "$address" },
          delivery_time: { $first: "$delivery_time" },
          delivery_charge: { $first: "$delivery_charge" },
          is_favourite: { $first: "$is_favourite" },
          coupons: { $first: "$coupons" },
          rating: { $first: "$rating" },
          price_range: { $first: "$price_range" },
          is_take_pre_order: { $first: "$is_take_pre_order" },
          cuisines: { $first: "$cuisines" },
          distance: { $first: "$distance" },
        },
      },
      {
        $lookup: {
          from: "favourite_restaurants",
          localField: "_id",
          foreignField: "branch_id",
          pipeline: [{ $match: { customer_id: user_id, is_delivery: true } }],
          as: "is_favourite",
        },
      },
      {
        $lookup: {
          from: "cuisines",
          localField: "cuisines.cuisine_id",
          foreignField: "_id",
          as: "cuisines",
          pipeline: [
            {
              $match: {
                is_active: true,
                is_delivery: true,
              },
            },
            {
              $project: {
                status: 0,
                image: 0,
              },
            },
          ],
        },
      },
      {
        $lookup: {
          from: "branch_coupons",
          localField: "_id",
          foreignField: "branch_id",
          pipeline: [
            {
              $lookup: {
                from: "coupons",
                localField: "coupon_id",
                foreignField: "_id",
                pipeline: [
                  {
                    $match: {
                      is_active: true,
                      start_time: {
                        $lte: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
                      },
                      end_time: {
                        $gte: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
                      },
                    },
                  },
                  {
                    $sort: {
                      created_at: -1,
                    },
                  },
                  {
                    $limit: 2,
                  },
                  {
                    $project: {
                      _id: 1,
                      name: 1,
                      description: 1,
                    },
                  },
                ],
                as: "branch_coupons",
              },
            },
            {
              $limit: 2,
            },
            { $unwind: "$branch_coupons" },
            {
              $project: {
                branch_coupons: 1,
              },
            },
          ],
          as: "coupons",
        },
      },
      {
        $lookup: {
          from: "reviews",
          localField: "_id",
          foreignField: "rest_id",
          pipeline: [
            {
              $group: {
                _id: "$rest_id",
                avg: { $avg: "$rating" },
                no_review: { $sum: 1 },
              },
            },
            {
              $project: {
                _id: 0,
                avg: { $round: ["$avg", 1] },
                no_review: 1,
              },
            },
          ],
          as: "rating",
        },
      },
      { $sort: { distance: 1, _id: -1 } },
      {
        $match: {
          is_open: { $ne: 0 },
        },
      },
      {
        $project: {
          ...res_basic_data,
          coupons: "$coupons.branch_coupons",
          is_open: 1,
          distance: 1,
        },
      },
    ])
      .skip(limit * (page - 1))
      .limit(limit);
    return data;
  } catch (err) {
    console.error(err);
    return false;
  }
};

DataSchema.statics.getSearchResult = async function (
  query,
  sort_by,
  cuisine_id,
  attribute_id,
  price_range,
  lat,
  long,
  zone_id,
  user_id,
  lim,
  page = 1
) {
  let sort_stage = { $sort: { _id: 1 } };
  if (sort_by === "rating") {
    sort_stage = { $sort: { "rating.avg": -1 } };
  } else if (sort_by === "delivery_time") {
    sort_stage = { $sort: { delivery_time: 1 } };
  } else if (sort_by === "distance") {
    sort_stage = { $sort: { distance: 1 } };
  } else {
    sort_stage = { $sort: { _id: 1 } };
  }

  let match_stage = {};

  cuisine_id && cuisine_id.length > 0
    ? (match_stage = { ...match_stage, "cuisines._id": { $in: cuisine_id } })
    : match_stage;
  attribute_id && attribute_id.length > 0
    ? (match_stage = {
        ...match_stage,
        "attributes.branch_attribute_id": { $in: attribute_id },
      })
    : match_stage;
  price_range
    ? (match_stage = { ...match_stage, price_range: price_range })
    : match_stage;
  let limit = lim > 0 ? lim : 15;
  try {
    const data = await this.aggregate([
      {
        $geoNear: {
          near: { type: "Point", coordinates: [long, lat] },
          distanceField: "distance",
          //maxDistance: 10000,
          query: { is_active: true, is_delivery: true, "zone_id._id": zone_id },
        },
      },

      { $unwind: "$working_hours" },
      {
        $set: {
          open: {
            $dateFromParts: {
              isoWeekYear: {
                $isoWeekYear: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
              },
              isoWeek: {
                $isoWeek: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
              },
              isoDayOfWeek: "$working_hours.day",
              hour: "$working_hours.open_hour",
              minute: "$working_hours.open_minute",
            },
          },
          close: {
            $dateFromParts: {
              isoWeekYear: {
                $isoWeekYear: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
              },
              isoWeek: {
                $isoWeek: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
              },
              isoDayOfWeek: "$working_hours.day",
              hour: "$working_hours.close_hour",
              minute: "$working_hours.close_minute",
            },
          },
        },
      },
      {
        $set: {
          is_open: {
            $cond: {
              if: {
                $and: [
                  {
                    $lte: [
                      "$open",
                      moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
                    ],
                  },
                  {
                    $gt: [
                      "$close",
                      moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
                    ],
                  },
                ],
              },
              then: 1,
              else: 0,
            },
          },
        },
      },

      {
        $lookup: {
          from: "favourite_restaurants",
          localField: "_id",
          foreignField: "branch_id",
          pipeline: [{ $match: { customer_id: user_id, is_delivery: true } }],
          as: "is_favourite",
        },
      },
      {
        $lookup: {
          from: "cuisines",
          localField: "cuisines.cuisine_id",
          foreignField: "_id",
          as: "cuisines",
          pipeline: [
            {
              $match: {
                is_active: true,
                is_delivery: true,
              },
            },
            {
              $project: {
                image: 0,
              },
            },
          ],
        },
      },
      {
        $lookup: {
          from: "branch_coupons",
          localField: "_id",
          foreignField: "branch_id",
          pipeline: [
            {
              $lookup: {
                from: "coupons",
                localField: "coupon_id",
                foreignField: "_id",
                pipeline: [
                  {
                    $match: {
                      is_active: true,
                      start_time: {
                        $lte: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
                      },
                      end_time: {
                        $gte: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
                      },
                    },
                  },
                  {
                    $sort: {
                      created_at: -1,
                    },
                  },
                  {
                    $limit: 2,
                  },
                  {
                    $project: {
                      _id: 1,
                      name: 1,
                      description: 1,
                    },
                  },
                ],
                as: "branch_coupons",
              },
            },
            {
              $limit: 2,
            },
            { $unwind: "$branch_coupons" },
            {
              $project: {
                branch_coupons: 1,
              },
            },
          ],
          as: "coupons",
        },
      },
      {
        $lookup: {
          from: "reviews",
          localField: "_id",
          foreignField: "rest_id",
          pipeline: [
            {
              $group: {
                _id: "$rest_id",
                avg: { $avg: "$rating" },
                no_review: { $sum: 1 },
              },
            },
            {
              $project: {
                _id: 0,
                avg: { $round: ["$avg", 1] },
                no_review: 1,
              },
            },
          ],
          as: "rating",
        },
      },
      {
        $lookup: {
          from: "restaurant_menus",
          localField: "_id",
          foreignField: "restaurant_id",
          as: "menus",
          pipeline: [
            { $match: { menu_name: { $regex: query, $options: "i" }, is_active: true } },
          ],
        },
      },
      {
        $match: {
          "zone_id._id": zone_id,

          $or: [
            { name: { $regex: query, $options: "i" } },
            { "menus.menu_name": { $regex: query, $options: "i" } },
            { "cuisines.name": { $regex: query, $options: "i" } },
          ],
          ...match_stage,
        },
      },
      {
        $group: {
          _id: "$_id",
          is_open: { $max: "$is_open" },
          name: { $first: "$name" },
          image: { $first: "$image" },
          cover_image: { $first: "$cover_image" },
          address: { $first: "$address" },
          delivery_time: { $first: "$delivery_time" },
          delivery_charge: { $first: "$delivery_charge" },
          is_favourite: { $first: "$is_favourite" },
          coupons: { $first: "$coupons" },
          rating: { $first: "$rating" },
          price_range: { $first: "$price_range" },
          is_take_pre_order: { $first: "$is_take_pre_order" },
          cuisines: { $first: "$cuisines" },
          distance: { $first: "$distance" },
          menus: { $first: "$menus" },
        },
      },
      sort_stage,
      {
        $project: {
          ...res_basic_data,
          coupons: "$coupons.branch_coupons",
          menus: 1,
          distance: 1,
        },
      },
    ])
      .skip(limit * (page - 1))
      .limit(limit);
    return data;
  } catch (err) {
    console.log("err :", err);
    return false;
  }
};

/**Pick Up **/

DataSchema.statics.pick_getNearbyRestaurant = async function (
  zone_id,
  user_id,
  long,
  lat,
  lim,
  page = 1
) {
  try {
    let limit = lim > 0 ? lim : 15;
    const data = await this.aggregate([
      {
        $geoNear: {
          near: { type: "Point", coordinates: [long, lat] },
          distanceField: "distance",
          //maxDistance: 10000,
          query: { is_active: true, is_pickup: true, "zone_id._id": zone_id },
        },
      },
      { $unwind: "$working_hours" },
      {
        $set: {
          open: {
            $dateFromParts: {
              isoWeekYear: {
                $isoWeekYear: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
              },
              isoWeek: {
                $isoWeek: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
              },
              isoDayOfWeek: "$working_hours.day",
              hour: "$working_hours.open_hour",
              minute: "$working_hours.open_minute",
            },
          },
          close: {
            $dateFromParts: {
              isoWeekYear: {
                $isoWeekYear: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
              },
              isoWeek: {
                $isoWeek: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
              },
              isoDayOfWeek: "$working_hours.day",
              hour: "$working_hours.close_hour",
              minute: "$working_hours.close_minute",
            },
          },
        },
      },
      {
        $set: {
          is_open: {
            $cond: {
              if: {
                $and: [
                  {
                    $lte: [
                      "$open",
                      moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
                    ],
                  },
                  {
                    $gt: [
                      "$close",
                      moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
                    ],
                  },
                ],
              },
              then: 1,
              else: 0,
            },
          },
        },
      },

      {
        $group: {
          _id: "$_id",
          is_open: { $max: "$is_open" },
          name: { $first: "$name" },
          image: { $first: "$image" },
          cover_image: { $first: "$cover_image" },
          address: { $first: "$address" },
          delivery_time: { $first: "$delivery_time" },
          delivery_charge: { $first: "$delivery_charge" },
          is_favourite: { $first: "$is_favourite" },
          coupons: { $first: "$coupons" },
          rating: { $first: "$rating" },
          price_range: { $first: "$price_range" },
          is_take_pre_order: { $first: "$is_take_pre_order" },
          cuisines: { $first: "$cuisines" },
          distance: { $first: "$distance" },
        },
      },
      {
        $lookup: {
          from: "favourite_restaurants",
          localField: "_id",
          foreignField: "branch_id",
          pipeline: [{ $match: { customer_id: user_id, is_pickup: true } }],
          as: "is_favourite",
        },
      },
      {
        $lookup: {
          from: "cuisines",
          localField: "cuisines.cuisine_id",
          foreignField: "_id",
          as: "cuisines",
          pipeline: [
            {
              $match: {
                is_active: true,
                is_pickup: true,
              },
            },
            {
              $project: {
                status: 0,
                image: 0,
              },
            },
          ],
        },
      },

      {
        $lookup: {
          from: "branch_coupons",
          localField: "_id",
          foreignField: "branch_id",
          pipeline: [
            {
              $lookup: {
                from: "coupons",
                localField: "coupon_id",
                foreignField: "_id",
                pipeline: [
                  {
                    $match: {
                      is_active: true,
                      is_pickup: true,
                      start_time: {
                        $lte: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
                      },
                      end_time: {
                        $gte: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
                      },
                    },
                  },
                  {
                    $sort: {
                      created_at: -1,
                    },
                  },
                  {
                    $limit: 2,
                  },
                  {
                    $project: {
                      _id: 1,
                      name: 1,
                      description: 1,
                    },
                  },
                ],
                as: "branch_coupons",
              },
            },
            {
              $limit: 2,
            },
            { $unwind: "$branch_coupons" },
            {
              $project: {
                branch_coupons: 1,
              },
            },
          ],
          as: "coupons",
        },
      },
      {
        $lookup: {
          from: "reviews",
          localField: "_id",
          foreignField: "rest_id",
          pipeline: [
            {
              $group: {
                _id: "$rest_id",
                avg: { $avg: "$rating" },
                no_review: { $sum: 1 },
              },
            },
            {
              $project: {
                _id: 0,
                avg: { $round: ["$avg", 1] },
                no_review: 1,
              },
            },
          ],
          as: "rating",
        },
      },
      { $sort: { distance: 1, _id: -1 } },
      {
        $match: {
          is_open: { $ne: 0 },
        },
      },
      {
        $project: {
          ...res_basic_data,
          coupons: "$coupons.branch_coupons",
          distance: 1,
        },
      },
    ])
      .skip(limit * (page - 1))
      .limit(limit);
    return data;
  } catch (err) {
    console.error(err);
    return false;
  }
};
DataSchema.statics.pick_getSearchResult = async function (
  query,
  sort_by,
  cuisine_id,
  attribute_id,
  price_range,
  lat,
  long,
  zone_id,
  user_id,
  lim,
  page = 1
) {
  let limit = lim > 0 ? lim : 15;
  let sort_stage = { $sort: { _id: 1 } };
  if (sort_by === "rating") {
    sort_stage = { $sort: { "rating.avg": -1 } };
  } else if (sort_by === "delivery_time") {
    sort_stage = { $sort: { delivery_time: 1 } };
  } else if (sort_by === "distance") {
    sort_stage = { $sort: { distance: 1 } };
  } else {
    sort_stage = { $sort: { _id: 1 } };
  }

  let match_stage = {};

  cuisine_id && cuisine_id.length > 0
    ? (match_stage = { ...match_stage, "cuisines._id": { $in: cuisine_id } })
    : match_stage;
  attribute_id && attribute_id.length > 0
    ? (match_stage = {
        ...match_stage,
        "attributes.branch_attribute_id": { $in: attribute_id },
      })
    : match_stage;
  price_range
    ? (match_stage = { ...match_stage, price_range: price_range })
    : match_stage;

  try {
    const data = await this.aggregate([
      {
        $geoNear: {
          near: { type: "Point", coordinates: [long, lat] },
          distanceField: "distance",
          //maxDistance: 10000,
          query: { is_active: true, is_pickup: true, "zone_id._id": zone_id },
        },
      },

      { $unwind: "$working_hours" },
      {
        $set: {
          open: {
            $dateFromParts: {
              isoWeekYear: {
                $isoWeekYear: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
              },
              isoWeek: {
                $isoWeek: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
              },
              isoDayOfWeek: "$working_hours.day",
              hour: "$working_hours.open_hour",
              minute: "$working_hours.open_minute",
            },
          },
          close: {
            $dateFromParts: {
              isoWeekYear: {
                $isoWeekYear: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
              },
              isoWeek: {
                $isoWeek: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
              },
              isoDayOfWeek: "$working_hours.day",
              hour: "$working_hours.close_hour",
              minute: "$working_hours.close_minute",
            },
          },
        },
      },
      {
        $set: {
          is_open: {
            $cond: {
              if: {
                $and: [
                  {
                    $lte: [
                      "$open",
                      moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
                    ],
                  },
                  {
                    $gt: [
                      "$close",
                      moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
                    ],
                  },
                ],
              },
              then: 1,
              else: 0,
            },
          },
        },
      },

      {
        $lookup: {
          from: "favourite_restaurants",
          localField: "_id",
          foreignField: "branch_id",
          pipeline: [{ $match: { customer_id: user_id, is_pickup: true } }],
          as: "is_favourite",
        },
      },
      {
        $lookup: {
          from: "cuisines",
          localField: "cuisines.cuisine_id",
          foreignField: "_id",
          as: "cuisines",
          pipeline: [
            {
              $match: {
                is_active: true,
                is_pickup: true,
              },
            },
            {
              $project: {
                status: 0,
                image: 0,
              },
            },
          ],
        },
      },
      {
        $lookup: {
          from: "branch_coupons",
          localField: "_id",
          foreignField: "branch_id",
          pipeline: [
            {
              $lookup: {
                from: "coupons",
                localField: "coupon_id",
                foreignField: "_id",
                pipeline: [
                  {
                    $match: {
                      is_active: true,
                      start_time: {
                        $lte: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
                      },
                      end_time: {
                        $gte: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
                      },
                    },
                  },
                  {
                    $sort: {
                      created_at: -1,
                    },
                  },
                  {
                    $limit: 2,
                  },
                  {
                    $project: {
                      _id: 1,
                      name: 1,
                      description: 1,
                    },
                  },
                ],
                as: "branch_coupons",
              },
            },
            {
              $limit: 2,
            },
            { $unwind: "$branch_coupons" },
            {
              $project: {
                branch_coupons: 1,
              },
            },
          ],
          as: "coupons",
        },
      },
      {
        $lookup: {
          from: "reviews",
          localField: "_id",
          foreignField: "rest_id",
          pipeline: [
            {
              $group: {
                _id: "$rest_id",
                avg: { $avg: "$rating" },
                no_review: { $sum: 1 },
              },
            },
            {
              $project: {
                _id: 0,
                avg: { $round: ["$avg", 1] },
                no_review: 1,
              },
            },
          ],
          as: "rating",
        },
      },
      {
        $lookup: {
          from: "restaurant_menus",
          localField: "_id",
          foreignField: "restaurant_id",
          as: "menus",
          pipeline: [
            { $match: { menu_name: { $regex: query, $options: "i" }, is_active: true } },
          ],
        },
      },
      {
        $match: {
          is_active: true,
          is_pickup: true,
          "zone_id._id": zone_id,
          $or: [
            { name: { $regex: query, $options: "i" } },
            { "menus.menu_name": { $regex: query, $options: "i" } },
          ],
          ...match_stage,
        },
      },
      {
        $group: {
          _id: "$_id",
          is_open: { $max: "$is_open" },
          name: { $first: "$name" },
          image: { $first: "$image" },
          cover_image: { $first: "$cover_image" },
          address: { $first: "$address" },
          delivery_time: { $first: "$delivery_time" },
          delivery_charge: { $first: "$delivery_charge" },
          is_favourite: { $first: "$is_favourite" },
          coupons: { $first: "$coupons" },
          rating: { $first: "$rating" },
          price_range: { $first: "$price_range" },
          is_take_pre_order: { $first: "$is_take_pre_order" },
          cuisines: { $first: "$cuisines" },
          distance: { $first: "$distance" },
        },
      },
      sort_stage,
      {
        $project: {
          ...res_basic_data,
          coupons: "$coupons.branch_coupons",
          menus: 1,
          distance: 1,
        },
      },
    ])
      .skip(limit * (page - 1))
      .limit(limit);
    return data;
  } catch (err) {
    console.log("err :", err);
    return false;
  }
};
/** Dine In **/
DataSchema.statics.dine_getNearbyRestaurant = async function (
  zone_id,
  user_id,
  long,
  lat,
  lim,
  page = 1
) {
  try {
    let limit = lim > 0 ? lim : 15;
    const data = await this.aggregate([
      {
        $geoNear: {
          near: { type: "Point", coordinates: [long, lat] },
          distanceField: "distance",
          //maxDistance: 10000,
          query: { is_active: true, is_dine: true, "zone_id._id": zone_id },
        },
      },
      { $unwind: "$working_hours" },
      {
        $set: {
          open: {
            $dateFromParts: {
              isoWeekYear: {
                $isoWeekYear: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
              },
              isoWeek: {
                $isoWeek: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
              },
              isoDayOfWeek: "$working_hours.day",
              hour: "$working_hours.open_hour",
              minute: "$working_hours.open_minute",
            },
          },
          close: {
            $dateFromParts: {
              isoWeekYear: {
                $isoWeekYear: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
              },
              isoWeek: {
                $isoWeek: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
              },
              isoDayOfWeek: "$working_hours.day",
              hour: "$working_hours.close_hour",
              minute: "$working_hours.close_minute",
            },
          },
        },
      },
      {
        $set: {
          is_open: {
            $cond: {
              if: {
                $and: [
                  {
                    $lte: [
                      "$open",
                      moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
                    ],
                  },
                  {
                    $gt: [
                      "$close",
                      moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
                    ],
                  },
                ],
              },
              then: 1,
              else: 0,
            },
          },
        },
      },

      {
        $group: {
          _id: "$_id",
          is_open: { $max: "$is_open" },
          name: { $first: "$name" },
          image: { $first: "$image" },
          cover_image: { $first: "$cover_image" },
          address: { $first: "$address" },
          delivery_time: { $first: "$delivery_time" },
          delivery_charge: { $first: "$delivery_charge" },
          is_favourite: { $first: "$is_favourite" },
          coupons: { $first: "$coupons" },
          rating: { $first: "$rating" },
          price_range: { $first: "$price_range" },
          is_take_pre_order: { $first: "$is_take_pre_order" },
          cuisines: { $first: "$cuisines" },
          //  distance: { $first: "$distance" },
        },
      },
      {
        $lookup: {
          from: "favourite_restaurants",
          localField: "_id",
          foreignField: "branch_id",
          pipeline: [{ $match: { customer_id: user_id, is_dine: true } }],
          as: "is_favourite",
        },
      },
      {
        $lookup: {
          from: "cuisines",
          localField: "cuisines.cuisine_id",
          foreignField: "_id",
          as: "cuisines",
          pipeline: [
            {
              $match: {
                is_active: true,
                is_dine: true,
              },
            },
            {
              $project: {
                status: 0,
                image: 0,
              },
            },
          ],
        },
      },

      {
        $lookup: {
          from: "branch_coupons",
          localField: "_id",
          foreignField: "branch_id",
          pipeline: [
            {
              $lookup: {
                from: "coupons",
                localField: "coupon_id",
                foreignField: "_id",
                pipeline: [
                  {
                    $match: {
                      is_active: true,
                      is_pickup: true,
                      start_time: {
                        $lte: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
                      },
                      end_time: {
                        $gte: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
                      },
                    },
                  },
                  {
                    $sort: {
                      created_at: -1,
                    },
                  },
                  {
                    $limit: 2,
                  },
                  {
                    $project: {
                      _id: 1,
                      name: 1,
                      description: 1,
                    },
                  },
                ],
                as: "branch_coupons",
              },
            },
            {
              $limit: 2,
            },
            { $unwind: "$branch_coupons" },
            {
              $project: {
                branch_coupons: 1,
              },
            },
          ],
          as: "coupons",
        },
      },
      {
        $lookup: {
          from: "reviews",
          localField: "_id",
          foreignField: "rest_id",
          pipeline: [
            {
              $group: {
                _id: "$rest_id",
                avg: { $avg: "$rating" },
                no_review: { $sum: 1 },
              },
            },
            {
              $project: {
                _id: 0,
                avg: { $round: ["$avg", 1] },
                no_review: 1,
              },
            },
          ],
          as: "rating",
        },
      },
      { $sort: { distance: 1, _id: -1 } },
      {
        $match: {
          is_open: { $ne: 0 },
        },
      },
      {
        $project: {
          ...res_basic_data,
          coupons: "$coupons.branch_coupons",
          distance: 1,
        },
      },
    ])
      .skip(limit * (page - 1))
      .limit(limit);
    return data;
  } catch (err) {
    console.error(err);
    return false;
  }
};

DataSchema.statics.dine_getSearchResult = async function (
  query,
  sort_by,
  cuisine_id,
  attribute_id,
  price_range,
  lat,
  long,
  zone_id,
  user_id,
  lim,
  page = 1
) {
  let limit = lim > 0 ? lim : 15;
  let sort_stage = { $sort: { _id: 1 } };
  if (sort_by === "rating") {
    sort_stage = { $sort: { "rating.avg": -1 } };
  } else if (sort_by === "delivery_time") {
    sort_stage = { $sort: { delivery_time: 1 } };
  } else if (sort_by === "distance") {
    sort_stage = { $sort: { distance: 1 } };
  } else {
    sort_stage = { $sort: { _id: 1 } };
  }

  let match_stage = {};

  cuisine_id && cuisine_id.length > 0
    ? (match_stage = { ...match_stage, "cuisines._id": { $in: cuisine_id } })
    : match_stage;
  attribute_id && attribute_id.length > 0
    ? (match_stage = {
        ...match_stage,
        "attributes.branch_attribute_id": { $in: attribute_id },
      })
    : match_stage;
  price_range
    ? (match_stage = { ...match_stage, price_range: price_range })
    : match_stage;

  try {
    const data = await this.aggregate([
      {
        $geoNear: {
          near: { type: "Point", coordinates: [long, lat] },
          distanceField: "distance",
          //maxDistance: 10000,
          query: { is_active: true, is_dine: true, "zone_id._id": zone_id },
        },
      },

      { $unwind: "$working_hours" },
      {
        $set: {
          open: {
            $dateFromParts: {
              isoWeekYear: {
                $isoWeekYear: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
              },
              isoWeek: {
                $isoWeek: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
              },
              isoDayOfWeek: "$working_hours.day",
              hour: "$working_hours.open_hour",
              minute: "$working_hours.open_minute",
            },
          },
          close: {
            $dateFromParts: {
              isoWeekYear: {
                $isoWeekYear: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
              },
              isoWeek: {
                $isoWeek: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
              },
              isoDayOfWeek: "$working_hours.day",
              hour: "$working_hours.close_hour",
              minute: "$working_hours.close_minute",
            },
          },
        },
      },
      {
        $set: {
          is_open: {
            $cond: {
              if: {
                $and: [
                  {
                    $lte: [
                      "$open",
                      moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
                    ],
                  },
                  {
                    $gt: [
                      "$close",
                      moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
                    ],
                  },
                ],
              },
              then: 1,
              else: 0,
            },
          },
        },
      },

      {
        $lookup: {
          from: "favourite_restaurants",
          localField: "_id",
          foreignField: "branch_id",
          pipeline: [{ $match: { customer_id: user_id, is_dine: true } }],
          as: "is_favourite",
        },
      },
      {
        $lookup: {
          from: "cuisines",
          localField: "cuisines.cuisine_id",
          foreignField: "_id",
          as: "cuisines",
          pipeline: [
            {
              $match: {
                is_active: true,
                is_dine: true,
              },
            },
            {
              $project: {
                status: 0,
                image: 0,
              },
            },
          ],
        },
      },
      {
        $lookup: {
          from: "branch_coupons",
          localField: "_id",
          foreignField: "branch_id",
          pipeline: [
            {
              $lookup: {
                from: "coupons",
                localField: "coupon_id",
                foreignField: "_id",
                pipeline: [
                  {
                    $match: {
                      is_active: true,
                      start_time: {
                        $lte: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
                      },
                      end_time: {
                        $gte: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
                      },
                    },
                  },
                  {
                    $sort: {
                      created_at: -1,
                    },
                  },
                  {
                    $limit: 2,
                  },
                  {
                    $project: {
                      _id: 1,
                      name: 1,
                      description: 1,
                    },
                  },
                ],
                as: "branch_coupons",
              },
            },
            {
              $limit: 2,
            },
            { $unwind: "$branch_coupons" },
            {
              $project: {
                branch_coupons: 1,
              },
            },
          ],
          as: "coupons",
        },
      },
      {
        $lookup: {
          from: "reviews",
          localField: "_id",
          foreignField: "rest_id",
          pipeline: [
            {
              $group: {
                _id: "$rest_id",
                avg: { $avg: "$rating" },
                no_review: { $sum: 1 },
              },
            },
            {
              $project: {
                _id: 0,
                avg: { $round: ["$avg", 1] },
                no_review: 1,
              },
            },
          ],
          as: "rating",
        },
      },
      {
        $lookup: {
          from: "restaurant_menus",
          localField: "_id",
          foreignField: "restaurant_id",
          as: "menus",
          pipeline: [
            { $match: { menu_name: { $regex: query, $options: "i" }, is_active: true } },
          ],
        },
      },
      {
        $match: {
          is_active: true,
          is_dine: true,
          "zone_id._id": zone_id,
          $or: [
            { name: { $regex: query, $options: "i" } },
            { "menus.menu_name": { $regex: query, $options: "i" } },
          ],
          ...match_stage,
        },
      },
      {
        $group: {
          _id: "$_id",
          is_open: { $max: "$is_open" },
          name: { $first: "$name" },
          image: { $first: "$image" },
          cover_image: { $first: "$cover_image" },
          address: { $first: "$address" },
          delivery_time: { $first: "$delivery_time" },
          delivery_charge: { $first: "$delivery_charge" },
          is_favourite: { $first: "$is_favourite" },
          coupons: { $first: "$coupons" },
          rating: { $first: "$rating" },
          price_range: { $first: "$price_range" },
          is_take_pre_order: { $first: "$is_take_pre_order" },
          cuisines: { $first: "$cuisines" },
          distance: { $first: "$distance" },
        },
      },
      sort_stage,
      {
        $project: {
          ...res_basic_data,
          coupons: "$coupons.branch_coupons",
          menus: 1,
          distance: 1,
        },
      },
    ])
      .skip(limit * (page - 1))
      .limit(limit);
    return data;
  } catch (err) {
    console.log("err :", err);
    return false;
  }
};

DataSchema.statics.getRestaurantDetails = async function (rest_id) {
  try {
    const data = await this.aggregate([
      {
        $match: {
          _id: rest_id,
        },
      },
      {
        $lookup: {
          from: "parent_restaurants",
          localField: "parent_restaurant_id",
          foreignField: "_id",
          as: "parent_restaurants",
          pipeline: [
            {
              $lookup: {
                from: "restaurant_users",
                localField: "central_admin",
                foreignField: "_id",
                as: "central_admin",
                pipeline: [
                  {
                    $project: {
                      name: {
                        $concat: ["$first_name", "$last_name"],
                      },
                    },
                  },
                ],
              },
            },
            {
              $project: {
                name: 1,
                central_admin: { $arrayElemAt: ["$central_admin.name", 0] },
              },
            },
          ],
        },
      },
      {
        $lookup: {
          from: "restaurant_users",
          localField: "branch_admin",
          foreignField: "_id",
          as: "branch_admins",
          pipeline: [
            {
              $project: {
                name: {
                  $concat: ["$first_name", "$last_name"],
                },
              },
            },
          ],
        },
      },
      {
        $project: {
          _id: 1,
          name: 1,
          mobile_number: 1,
          email: 1,
          address: 1,
          price_range: 1,
          image: 1,
          cover_image: 1,
          min_order_value: 1,
          is_take_pre_order: 1,
          commission: 1,
          delivery_charge: 1,
          delivery_time: 1,
          pickup_time: 1,
          phone_number: 1,
          is_delivery: 1,
          is_pickup: 1,
          is_dine: 1,
          location: 1,
          is_popular: 1,
          zonal_admin: { $ifNull: ["$zonal_admin", null] },
          central_admin: { $arrayElemAt: ["$parent_restaurants.central_admin", 0] },
          branch_admins: { $arrayElemAt: ["$branch_admins", 0] },
          parent_restaurant_name: { $arrayElemAt: ["$parent_restaurants.name", 0] },
          working_hours: "$working_hours",
          timing: {
            $map: {
              input: [
                { day: 1 },
                { day: 2 },
                { day: 3 },
                { day: 4 },
                { day: 5 },
                { day: 6 },
                { day: 7 },
              ],
              as: "hour",
              in: {
                day: {
                  $switch: {
                    branches: [
                      { case: { $eq: ["$$hour.day", 1] }, then: "Monday" },
                      { case: { $eq: ["$$hour.day", 2] }, then: "Tuesday" },
                      { case: { $eq: ["$$hour.day", 3] }, then: "Wednesday" },
                      { case: { $eq: ["$$hour.day", 4] }, then: "Thursday" },
                      { case: { $eq: ["$$hour.day", 5] }, then: "Friday" },
                      { case: { $eq: ["$$hour.day", 6] }, then: "Saturday" },
                      { case: { $eq: ["$$hour.day", 7] }, then: "Sunday" },
                    ],
                    default: null,
                  },
                },
                day_number: "$$hour.day",
                slots: {
                  $filter: {
                    input: "$working_hours",
                    cond: { $eq: ["$$this.day", "$$hour.day"] },
                  },
                },
              },
            },
          },
        },
      },
      {
        $project: {
          _id: 1,
          name: 1,
          mobile_number: 1,
          email: 1,
          address: 1,
          price_range: 1,
          image: 1,
          cover_image: 1,
          min_order_value: 1,
          is_take_pre_order: 1,
          commission: 1,
          delivery_charge: 1,
          delivery_time: 1,
          pickup_time: 1,
          phone_number: 1,
          is_delivery: 1,
          is_pickup: 1,
          is_dine: 1,
          location: 1,
          zonal_admin: 1,
          central_admin: { $ifNull: ["$central_admin", null] },
          branch_admin: { $ifNull: ["$branch_admins.name", null] },
          working_hours: 1,
          parent_restaurant_name: 1,
          is_popular: 1,
          timing: {
            $map: {
              input: "$timing",
              as: "hour",
              in: {
                day: "$$hour.day",
                day_number: "$$hour.day_number",
                slots: {
                  $map: {
                    input: "$$hour.slots",
                    as: "slot",
                    in: {
                      open_time: {
                        $concat: [
                          { $toString: "$$slot.open_hour" },
                          ".",
                          { $toString: "$$slot.open_minute" },
                        ],
                      },
                      close_time: {
                        $concat: [
                          { $toString: "$$slot.close_hour" },
                          ".",
                          { $toString: "$$slot.close_minute" },
                        ],
                      },
                    },
                  },
                },
                status: {
                  $cond: {
                    if: { $eq: [{ $size: "$$hour.slots" }, 0] },
                    then: "Closed",
                    else: "Open",
                  },
                },
              },
            },
          },
        },
      },
    ]);

    return data.shift();
  } catch (err) {
    console.log("err :", err);
    return false;
  }
};
DataSchema.statics.getRestaurantStatus = async function (rest_id) {
  try {
    const data = await this.aggregate([
      {
        $match: {
          _id: rest_id,
        },
      },
      { $unwind: "$working_hours" },
      {
        $set: {
          open: {
            $dateFromParts: {
              isoWeekYear: {
                $isoWeekYear: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
              },
              isoWeek: {
                $isoWeek: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
              },
              isoDayOfWeek: "$working_hours.day",
              hour: "$working_hours.open_hour",
              minute: "$working_hours.open_minute",
            },
          },
          close: {
            $dateFromParts: {
              isoWeekYear: {
                $isoWeekYear: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
              },
              isoWeek: {
                $isoWeek: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
              },
              isoDayOfWeek: "$working_hours.day",
              hour: "$working_hours.close_hour",
              minute: "$working_hours.close_minute",
            },
          },
          is_active: "$is_active",
        },
      },
      {
        $set: {
          is_open: {
            $cond: {
              if: {
                $and: [
                  {
                    $lte: [
                      "$open",
                      moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
                    ],
                  },
                  {
                    $gt: [
                      "$close",
                      moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
                    ],
                  },
                  { $eq: ["$is_active", true] },
                ],
              },
              then: true,
              else: false,
            },
          },
        },
      },
      {
        $group: {
          _id: "$_id",
          is_open: { $max: "$is_open" },
          name: { $first: "$name" },
          address: { $first: "$address" },
          is_busy: { $first: "$is_busy" },
        },
      },
      {
        $project: {
          _id: 1,
          is_open: 1,
          name: 1,
          address: 1,
          is_busy: 1,
          status: {
            $cond: [
              { $eq: ["$is_open", true] },
              "open",
              {
                $cond: [{ $eq: ["$is_busy", true] }, "busy", "close"],
              },
            ],
          },
        },
      },
    ]);

    return data.shift();
  } catch (err) {
    console.log("err :", err);
    return false;
  }
};

DataSchema.statics.getBranchList = async function (check_id, lim, page = 1) {
  let limit = lim > 0 ? lim : 0;
  const skip = limit * (page - 1);

  try {
    const data = await this.aggregate([
      {
        $match: {
          $or: [
            {
              central_admin: check_id,
            },
            {
              branch_admin: check_id,
            },
          ],
        },
      },
      {
        $facet: {
          branch_data: [
            {
              $lookup: {
                from: "parent_restaurants",
                localField: "parent_restaurant_id",
                foreignField: "_id",
                as: "parent_restaurants",
                pipeline: [
                  {
                    $project: {
                      name: 1,
                      central_admin: 1,
                    },
                  },
                ],
              },
            },

            {
              $sort: { created_at: -1 },
            },

            {
              $project: {
                _id: 1,
                parent_restaurant_name: { $arrayElemAt: ["$parent_restaurants.name", 0] },
                name: 1,
                is_active: 1,
                is_popular: 1,
              },
            },

            { $skip: skip },
            ...(limit > 0 ? [{ $limit: limit }] : []),
          ],
          totalCount: [
            {
              $lookup: {
                from: "parent_restaurants",
                localField: "parent_restaurant_id",
                foreignField: "_id",
                as: "parent_restaurants",
                pipeline: [
                  {
                    $project: {
                      name: 1,
                      central_admin: 1,
                    },
                  },
                ],
              },
            },
            { $count: "total" },
          ],
        },
      },
      {
        $project: {
          totalCount: { $arrayElemAt: ["$totalCount.total", 0] },
          branch_data: 1,
        },
      },
    ]);

    return data.shift();
  } catch (err) {
    console.log("err :", err);
    return false;
  }
};

const RestaurentModel = mongoose.model("restaurents", DataSchema);
export default RestaurentModel;
