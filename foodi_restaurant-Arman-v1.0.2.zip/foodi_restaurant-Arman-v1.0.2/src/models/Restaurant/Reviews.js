import mongoose from "mongoose";
import { v4 as uuidv4 } from "uuid";
import moment from "moment";
import { SYSTEM_TIMEZONE } from "../../consts/defaults.js";

const DataSchema = mongoose.Schema(
  {
    _id: {
      type: String,
      default: () => uuidv4(),
    },
    rest_id: { type: String, default: null },
    rider_id: { type: String, default: null },
    rider_name: { type: String, default: "Unknown Name" },
    user_id: { type: String },
    review: { type: String, default: null },
    rider_review: { type: String, default: null },
    name: { type: String, default: "Unknown Name" },
    order_id: { type: String },
    rating: { type: Number, default: null, enum: [1, 2, 3, 4, 5] },
    rider_rating: { type: Number, default: null, enum: [1, 2, 3, 4, 5] },
    is_active: { type: Boolean, default: true },
    created_at: {
      type: Date,
      default: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
    },
    created_by: { type: String, default: null },
    updated_at: {
      type: Date,
      default: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
    },
    updated_by: { type: String, default: null },
  },
  { versionKey: false }
);

const Reviews = mongoose.model("reviews", DataSchema);
export default Reviews;
