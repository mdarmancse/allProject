import mongoose from "mongoose";
import { v4 as uuidv4 } from "uuid";

const DataSchema = new mongoose.Schema(
  {
    _id: {
      type: String,
      default: () => uuidv4().replace(/\-/g, ""),
    },
    category_name: { type: String },
    restaurant_id: { type: String },
    image: { type: String },
    priority_number: { type: Number },
    is_active: { type: Boolean, default: true },
    created_at: { type: Date, default: null },
    created_by: { type: String, default: null },
    updated_at: { type: Date, default: null },
    updated_by: { type: String, default: null },
  },
  { collection: "categories", versionKey: false }
);
DataSchema.statics.getRestaurantCategory = async function (rest_id, lim, page = 1) {
  let limit = lim > 0 ? lim : 0;
  const skip = limit * (page - 1);

  try {
    const data = await this.aggregate([
      {
        $match: {
          restaurant_id: rest_id,
        },
      },

      {
        $lookup: {
          from: "restaurant_menus",
          localField: "_id",
          foreignField: "category_id",
          pipeline: [
            {
              $match: {
                restaurant_id: rest_id,
              },
            },
            {
              $lookup: {
                from: "variations",
                localField: "_id",
                foreignField: "menu_id",
                pipeline: [
                  {
                    $lookup: {
                      from: "addon_category",
                      localField: "_id",
                      foreignField: "variation_id",
                      pipeline: [
                        {
                          $lookup: {
                            from: "addon_list",
                            localField: "_id",
                            foreignField: "variation_and_add_on_category_id",
                            as: "add_on_list",
                          },
                        },
                      ],
                      as: "add_on_category",
                    },
                  },
                ],
                as: "variations",
              },
            },
            {
              $project: {
                _id: 1,
                category_id: 1,
                restaurant_id: 1,
                menu_name: 1,
                menu_price: 1,
                description: 1,
                image: 1,
                is_populer: 1,
                has_variation: 1,
                check_add_ons: 1,
                variation_group_name: 1,
                variation_group_desc: 1,
                is_active: 1,
                sd: 1,
                vat: 1,
                variations: 1,
              },
            },
          ],
          as: "menu_data",
        },
      },
      {
        $sort: { created_at: -1 },
      },
      {
        $project: {
          _id: 0,
          cat_id: "$_id",
          name: "$category_name",
          numberOfItems: { $size: "$menu_data" },
          unavailable: {
            $size: {
              $filter: {
                input: "$menu_data",
                as: "menu",
                cond: { $eq: ["$$menu.is_active", false] },
              },
            },
          },
        },
      },
      { $skip: skip },
      ...(limit > 0 ? [{ $limit: limit }] : []),
    ]);
    const sum_data = data.reduce(
      (ac, cur) => {
        ac.unavailable += cur.unavailable ? cur.unavailable : 0;
        return ac;
      },
      { unavailable: 0 }
    );
    // console.log('DATA',data)

    const returnData = {
      totalUnavailable: sum_data.unavailable,
      data,
    };

    return returnData;
  } catch (err) {
    console.log("err :", err);
    return false;
  }
};

// DataSchema.statics.getRestaurantMenu = async function (
//     cat_id,
//     rest_id,
//     lim,
//     page = 1
// ) {
//     let limit = lim > 0 ? lim : 0;
//     const skip = limit * (page - 1);
//
//     try {
//         const data = await this.aggregate([
//             {
//                 $match: {
//                     _id: cat_id,
//                     restaurant_id: rest_id,
//                 }
//             },
//
//
//             {
//                 $lookup: {
//                     from: "restaurant_menus",
//                     localField: "_id",
//                     foreignField: "category_id",
//                     pipeline: [
//                         {
//                             $match: {
//                                 restaurant_id: rest_id,
//                             },
//                         },
//                         {
//                             $lookup: {
//                                 from: "variations",
//                                 localField: "_id",
//                                 foreignField: "menu_id",
//                                 pipeline: [
//                                     {
//                                         $lookup: {
//                                             from: "addon_category",
//                                             localField: "_id",
//                                             foreignField: "variation_id",
//                                             pipeline: [
//                                                 {
//                                                     $lookup: {
//                                                         from: "addon_list",
//                                                         localField: "_id",
//                                                         foreignField: "variation_and_add_on_category_id",
//                                                         as: "add_on_list",
//                                                     },
//                                                 },
//                                             ],
//                                             as: "add_on_category",
//                                         },
//                                     },
//                                 ],
//                                 as: "variations",
//                             },
//                         },
//                         {
//                             $project: {
//                                 _id: 1,
//                                 category_id: 1,
//                                 restaurant_id: 1,
//                                 menu_name: 1,
//                                 menu_price: 1,
//                                 description: 1,
//                                 image: 1,
//                                 is_populer: 1,
//                                 has_variation: 1,
//                                 check_add_ons: 1,
//                                 variation_group_name: 1,
//                                 variation_group_desc: 1,
//                                 is_active: 1,
//                                 sd: 1,
//                                 vat: 1,
//                                 variations: 1,
//                             },
//                         },
//                     ],
//                     as: "menu_data",
//                 },
//             },
//             {
//                 $sort: { created_at: -1 }
//             },
//             {
//                 $project: {
//                     _id: 1,
//                     category_name: 1,
//                     numberOfItems: { $size: "$menu_data" },
//                     menu_data: 1,
//                     unavailable: {
//                         $size: {
//                             $filter: {
//                                 input: "$menu_data",
//                                 as: "menu",
//                                 cond: { $eq: ["$$menu.is_active", false] }
//                             }
//                         }
//                     },
//                 },
//             },
//             { $skip: skip },
//             ...(limit > 0 ? [{ $limit: limit }] : [])
//         ]);
//         const sum_data = data.reduce(
//             (ac, cur) => {
//                 ac.unavailable += cur.unavailable ? cur.unavailable : 0;
//                 return ac;
//             },
//             { unavailable: 0 }
//         );
//         // console.log('DATA',data)
//
//             const returnData={
//                 totalUnavailable:sum_data.unavailable,
//                 data
//             }
//
//         return returnData;
//     } catch (err) {
//         console.log("err :", err);
//         return false;
//     }
// };

DataSchema.statics.getRestaurantMenuSearch = async function (
  rest_id,
  query,
  unavailable,
  lim,
  page = 1
) {
  //console.log("IS_ACTIVE",is_active)
  let limit = lim > 0 ? lim : 0;
  const skip = limit * (page - 1);

  try {
    const data = await this.aggregate([
      {
        $lookup: {
          from: "restaurant_menus",
          localField: "_id",
          foreignField: "category_id",
          pipeline: [
            {
              $match: {
                is_active: unavailable === false ? true : false,
                restaurant_id: rest_id,

                ...(query ? { menu_name: { $regex: query, $options: "i" } } : {}),

                // $or: [
                //     { menu_name: { $regex: `${query}`, $options: "i" } }
                // ],
                // is_active:false
              },
            },
            {
              $lookup: {
                from: "variations",
                localField: "_id",
                foreignField: "menu_id",
                pipeline: [
                  {
                    $lookup: {
                      from: "addon_category",
                      localField: "_id",
                      foreignField: "variation_id",
                      pipeline: [
                        {
                          $lookup: {
                            from: "addon_list",
                            localField: "_id",
                            foreignField: "variation_and_add_on_category_id",
                            as: "add_on_list",
                          },
                        },
                      ],
                      as: "add_on_category",
                    },
                  },
                ],
                as: "variations",
              },
            },
            {
              $project: {
                _id: 1,
                category_id: 1,
                restaurant_id: 1,
                menu_name: 1,
                menu_price: 1,
                description: 1,
                image: 1,
                is_populer: 1,
                has_variation: 1,
                check_add_ons: 1,
                variation_group_name: 1,
                variation_group_desc: 1,
                is_active: 1,
                sd: 1,
                vat: 1,
                variations: 1,
              },
            },
          ],
          as: "menu_data",
        },
      },
      {
        $sort: { created_at: -1 },
      },
      {
        $match: {
          restaurant_id: rest_id,

          // ...(query ? { category_name: { $regex: query, $options: "i" } } : {}),
          // ...(query ? { "menu_data.menu_name": { $regex: query, $options: "i" } } : {}),
          //{ category_name: { $regex: `${query}`, $options: "i" } },
          //{ "menu_data.menu_name": { $regex: `${query}`, $options: "i" } }
        },
      },
      {
        $match: {
          menu_data: { $ne: [] },
        },
      },
      {
        $project: {
          _id: 1,
          category_name: 1,
          numberOfItems: { $size: "$menu_data" },
          menu_data: 1,
        },
      },
      { $skip: skip },
      ...(limit > 0 ? [{ $limit: limit }] : []),
    ]);

    return data;
  } catch (err) {
    console.log("err :", err);
    return false;
  }
};
const Category = mongoose.model("categories", DataSchema);
export default Category;
