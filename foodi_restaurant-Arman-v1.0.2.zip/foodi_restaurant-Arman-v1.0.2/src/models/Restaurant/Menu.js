import mongoose from "mongoose";
import { v4 as uuidv4 } from "uuid";
import moment from "moment";

const DataSchema = new mongoose.Schema(
  {
    _id: {
      type: String,
      default: () => uuidv4(),
    },
    menu_group_id: { type: String, default: null },
    slug: { type: String },
    category_id: { type: String },
    restaurant_id: { type: String },
    menu_name: { type: String },
    menu_price: { type: Number, default: 0 },
    pickup_menu_price: { type: Number, default: 0 },
    description: { type: String },
    is_popular: { type: Boolean, default: false },
    has_variation: { type: Number, default: 0 },
    variation_group_name: { type: String, default: null },
    variation_group_desc: { type: String, default: null },
    image: { type: String },
    recipe_time: { type: Number, default: 0 },
    vat: { type: Number, default: 0 },
    sd: { type: Number, default: 0 },
    deactivation_date: { type: Date, default: null },
    //check_add_ons: { type: Number, default: 0 },
    is_delivery: { type: Boolean, default: true },
    is_pickup: { type: Boolean, default: false },
    is_dine: { type: Boolean, default: false },
    is_active: { type: Boolean, default: true },
    created_at: { type: Date, default: null },
    created_by: { type: String, default: null },
    updated_at: { type: Date, default: null },
    updated_by: { type: String, default: null },
  },
  {
    collection: "restaurant_menus",
    versionKey: false,
  }
);
DataSchema.statics.getRestaurantMenu = async function (cat_id, check_id, lim, page = 1) {
  let limit = lim > 0 ? lim : 0;
  const skip = limit * (page - 1);

  try {
    const data = await this.aggregate([
      {
        $match: {
          ...(cat_id ? { category_id: cat_id } : {}),
        },
      },
      {
        $facet: {
          totalCount: [
            {
              $lookup: {
                from: "restaurents",
                localField: "restaurant_id",
                foreignField: "_id",
                as: "branch",
                pipeline: [
                  {
                    $match: {
                      $or: [{ central_admin: check_id }, { branch_admin: check_id }],
                    },
                  },
                  {
                    $project: {
                      _id: 1,
                      name: 1,
                      phone_number: 1,
                      address: 1,
                      parent_restaurant_id: 1,
                      central_admin: 1,
                      branch_admin: 1,
                    },
                  },
                ],
              },
            },
            {
              $match: {
                $or: [
                  { "branch.central_admin": check_id },
                  { "branch.branch_admin": check_id },
                ],
              },
            },
            { $count: "total" },
          ],
          menu_data: [
            {
              $lookup: {
                from: "restaurents",
                localField: "restaurant_id",
                foreignField: "_id",
                as: "branch",
                pipeline: [
                  {
                    $match: {
                      $or: [{ central_admin: check_id }, { branch_admin: check_id }],
                    },
                  },
                  {
                    $project: {
                      _id: 1,
                      name: 1,
                      phone_number: 1,
                      address: 1,
                      parent_restaurant_id: 1,
                      central_admin: 1,
                      branch_admin: 1,
                    },
                  },
                ],
              },
            },
            {
              $match: {
                $or: [
                  { "branch.central_admin": check_id },
                  { "branch.branch_admin": check_id },
                ],
              },
            },
            {
              $sort: { created_at: -1 },
            },
            {
              $project: {
                _id: 0,
                menu_id: "$_id",
                name: "$menu_name",
                branch_id: { $arrayElemAt: ["$branch._id", 0] },
                branch_name: { $arrayElemAt: ["$branch.name", 0] },
                branch_mobile_number: { $arrayElemAt: ["$branch.phone_number", 0] },
                branch_address: { $arrayElemAt: ["$branch.address", 0] },
                category_id: "$category_id",
                is_active: 1,
              },
            },
            { $skip: skip },
            ...(limit > 0 ? [{ $limit: limit }] : []),
          ],
        },
      },
      {
        $project: {
          totalCount: { $arrayElemAt: ["$totalCount.total", 0] },
          menu_data: 1,
        },
      },
    ]);

    return data.shift();
  } catch (err) {
    console.log("err :", err);
    return false;
  }
};

DataSchema.statics.getUnavailableMenu = async function (rest_id, last_days = 7) {
  try {
    const fromDate = moment().subtract(last_days, "days").startOf("day");
    const data = await this.aggregate([
      {
        $match: {
          restaurant_id: rest_id,
        },
      },
      {
        $group: {
          _id: null,
          unavailableCount: {
            $sum: { $cond: [{ $eq: ["$is_active", false] }, 1, 0] },
          },
          totalCount: { $sum: 1 },
        },
      },
      {
        $project: {
          _id: 0,
          unavailableMenuPercentage: {
            $multiply: [{ $divide: ["$unavailableCount", "$totalCount"] }, 100],
          },
        },
      },
    ]);

    return data.shift();
  } catch (err) {
    console.log("err :", err);
    return false;
  }
};
DataSchema.statics.checkIfMenuAvailable = async function (menu_id) {
  try {
    const data = this.aggregate([
      {
        $match: {
          _id: menu_id,
          menu_time_slots_map: { $ne: [] },
        },
      },
      {
        $lookup: {
          from: "menu_item_and_menu_item_time_slots",
          localField: "_id",
          foreignField: "menu_item_id",
          as: "menu_time_slots_map",
          pipeline: [
            {
              $match: {
                menu_time_slots: { $ne: [] },
              },
            },
            {
              $lookup: {
                from: "menu_item_time_slots",
                localField: "menu_item_time_slot_id",
                foreignField: "_id",
                as: "menu_time_slots",
                pipeline: [
                  {
                    $set: {
                      start: {
                        $dateFromParts: {
                          isoWeekYear: { $isoWeekYear: new Date() },
                          isoWeek: { $isoWeek: new Date() },
                          isoDayOfWeek: { $isoDayOfWeek: new Date() },
                          hour: "$start_time.hour",
                          minute: "$start_time.minute",
                        },
                      },
                      close: {
                        $dateFromParts: {
                          isoWeekYear: { $isoWeekYear: new Date() },
                          isoWeek: { $isoWeek: new Date() },
                          isoDayOfWeek: { $isoDayOfWeek: new Date() },
                          hour: "$end_time.hour",
                          minute: "$end_time.minute",
                        },
                      },
                    },
                  },
                  {
                    $match: {
                      $expr: {
                        $and: [
                          {
                            $lte: ["$start", new Date()],
                          },
                          {
                            $gt: ["$end", new Date()],
                          },
                        ],
                      },
                      //   start: { $lte: new Date() },
                      //   end: { $gt: new Date() },
                    },
                  },
                ],
              },
            },
            {
              $group: {
                _id: "$menu_item_id",
              },
            },
          ],
        },
      },
    ]);

    return data;
  } catch (err) {
    console.error(err);
    return false;
  }
};

const Menu = mongoose.model("restaurant_menus", DataSchema);
export default Menu;
