import mongoose from "mongoose";
import { v4 as uuidv4 } from "uuid";
import moment from "moment";
import { SYSTEM_TIMEZONE } from "../../consts/defaults.js";
const DataSchema = new mongoose.Schema(
  {
    _id: {
      type: String,
      default: () => uuidv4(),
    },
    rest_id: { type: String },
    rider_id: { type: String },
    additional_notes: { type: String, default: null },
    order_id: { type: String },
    rating: { type: String, default: "good", enum: ["good", "bad"] },
    good_issues: {
      rider_on_time: { type: Boolean, default: false },
      respectful: { type: Boolean, default: false },
      proper_attire: { type: Boolean, default: false },
      follow_pickup_instructions: { type: Boolean, default: false },
      carried_bag: { type: Boolean, default: false },
      checked_order_content: { type: Boolean, default: false },
      good_communication: { type: Boolean, default: false },
      other: { type: Boolean, default: false },
    },
    bad_issues: {
      late: { type: Boolean, default: false },
      too_early: { type: Boolean, default: false },
      inappropriate_appearance: { type: Boolean, default: false },
      forgot_item: { type: Boolean, default: false },
      ignore_instructions: { type: Boolean, default: false },
      no_social_distancing: { type: Boolean, default: false },
      unprofessional: { type: Boolean, default: false },
      bad_weather: { type: Boolean, default: false },
      other: { type: Boolean, default: false },
    },
    is_active: { type: Boolean, default: true },
    created_at: {
      type: Date,
      default: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
    },
    created_by: { type: String, default: null },
    updated_at: {
      type: Date,
      default: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
    },
    updated_by: { type: String, default: null },
  },
  {
    collection: "restaurant_reviews",
    versionKey: false,
  }
);

const RestaurantReviews = mongoose.model("restaurant_reviews", DataSchema);
export default RestaurantReviews;
