import mongoose from "mongoose";
import { v4 as uuidv4 } from "uuid";
import moment from "moment";
import { SYSTEM_TIMEZONE } from "../../consts/defaults.js";
const DataSchema = new mongoose.Schema(
  {
    _id: {
      type: String,
      default: () => uuidv4(),
    },
    branch_id: { type: String },
    comment: { type: String, default: null },
    close_reason: { type: String, default: null },
    created_at: {
      type: Date,
      default: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
    },
    created_by: { type: String, default: null },
    updated_at: {
      type: Date,
      default: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
    },
    updated_by: { type: String, default: null },
  },
  {
    collection: "branch_close_issue",
    versionKey: false,
  }
);

const BranchCloseReason = mongoose.model("branch_close_reason", DataSchema);
export default BranchCloseReason;
