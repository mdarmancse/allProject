import mongoose from "mongoose";
import { v4 as uuidv4 } from "uuid";

const DataSchema = mongoose.Schema(
  {
    _id: {
      type: String,
      // default: () => uuidv4().replace(/\-/g, ""),
    },
    add_on_category_id: {
      type: String,
    },
    variation_id: { type: String },
    name: { type: String },
    cat_is_multiple: { type: Number, default: 0 },
    cat_max_choice: { type: Number, default: 0 },
    priority_number: { type: Number, default: 0 },
    language_slug: { type: String },
    add_on_category_desc: { type: String },
    is_active: { type: Boolean, default: true },
    created_at: { type: Date, default: null },
    created_by: { type: String, default: null },
    updated_at: { type: Date, default: null },
    updated_by: { type: String, default: null },
  },
  {
    collection: "addon_category",
    versionKey: false,
  }
);

const addon_category = mongoose.model("addon_category", DataSchema);
export default addon_category;
