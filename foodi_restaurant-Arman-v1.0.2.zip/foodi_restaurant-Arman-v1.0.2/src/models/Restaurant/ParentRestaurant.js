import mongoose from "mongoose";
import { v4 as uuidv4 } from "uuid";

const DataSchema = new mongoose.Schema(
  {
    _id: {
      type: String,
      // default: () => uuidv4().replace(/\-/g, ""),
    },
    name: { type: String, default: null },
    central_admin: { type: String, default: null },
    logo: { type: String, default: null },
    cover_image: { type: String, default: null },
    currency: { type: String, default: null },
    is_active: { type: Boolean, default: true },
    created_at: { type: Date, default: null },
    created_by: { type: String, default: null },
    updated_at: { type: Date, default: null },
    updated_by: { type: String, default: null },
  },
  {
    collection: "parent_restaurants",
    // timestamps: true,
    versionKey: false,
  }
);
DataSchema.statics.getParentRestList = async function (check_id, lim, page = 1) {
  let limit = lim > 0 ? lim : 0;
  const skip = limit * (page - 1);

  try {
    const data = await this.aggregate([
      {
        $match: {
          central_admin: check_id,
        },
      },
      {
        $sort: { created_at: -1 },
      },
      {
        $project: {
          _id: 1,
          name: 1,
          is_active: 1,
        },
      },
      { $skip: skip },
      ...(limit > 0 ? [{ $limit: limit }] : []),
    ]);

    return data;
  } catch (err) {
    console.log("err :", err);
    return false;
  }
};

const ParentRestaurants = mongoose.model("parent_restaurants", DataSchema);
export default ParentRestaurants;
