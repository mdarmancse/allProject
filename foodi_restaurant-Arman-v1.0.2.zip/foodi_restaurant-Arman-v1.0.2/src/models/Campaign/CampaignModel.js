import mongoose from "mongoose";
import { v4 as uuidv4 } from "uuid";
import { res_basic_data } from "../../utility/const.js";

const DataSchema = new mongoose.Schema(
  {
    _id: {
      type: String,
    },
    name: { type: String, default: null },
    image: { type: String, default: null },
    description: { type: String, default: null },
    start_date: { type: Date, default: null },
    end_date: { type: Date, default: null },
    restaurants: [
      {
        _id: { type: String },
        campaign_id: { type: String },
        res_id: { type: String },
      },
    ],
    sort_value: { type: Number, default: 0 },
    is_active: { type: Boolean, default: true },
    is_delivery: { type: Boolean, default: true },
    is_pickup: { type: Boolean, default: false },
    is_dine: { type: Boolean, default: false },
    created_at: { type: Date, default: null },
    created_by: { type: String, default: null },
    updated_at: { type: Date, default: null },
    updated_by: { type: String, default: null },
  },
  {
    collection: "campaigns",
    //  timestamps: true,
    versionKey: false,
  }
);

DataSchema.statics.getCampaignRestaurants = async function (
  campaign_id,
  zone_id,
  user_id,
  limit = 15,
  page = 1
) {
  try {
    const data = await this.aggregate([
      {
        $match: {
          _id: campaign_id,
          is_active: true,
          is_delivery: true,
          end_date: { $gte: new Date() },
        },
      },
      {
        $lookup: {
          from: "restaurents",
          localField: "restaurants.res_id",
          foreignField: "_id",
          pipeline: [
            { $match: { "zone_id._id": zone_id, is_active: true } },
            { $unwind: "$working_hours" },
            {
              $set: {
                open: {
                  $dateFromParts: {
                    isoWeekYear: { $isoWeekYear: new Date() },
                    isoWeek: { $isoWeek: new Date() },
                    isoDayOfWeek: "$working_hours.day",
                    hour: "$working_hours.open_hour",
                    minute: "$working_hours.open_minute",
                  },
                },
                close: {
                  $dateFromParts: {
                    isoWeekYear: { $isoWeekYear: new Date() },
                    isoWeek: { $isoWeek: new Date() },
                    isoDayOfWeek: "$working_hours.day",
                    hour: "$working_hours.close_hour",
                    minute: "$working_hours.close_minute",
                  },
                },
              },
            },
            {
              $set: {
                is_open: {
                  $cond: {
                    if: {
                      $and: [
                        {
                          $lte: ["$open", new Date()],
                        },
                        {
                          $gt: ["$close", new Date()],
                        },
                      ],
                    },
                    then: 1,
                    else: 0,
                  },
                },
              },
            },

            {
              $group: {
                _id: "$_id",
                is_open: { $max: "$is_open" },
                name: { $first: "$name" },
                image: { $first: "$image" },
                cover_image: { $first: "$cover_image" },
                address: { $first: "$address" },
                delivery_time: { $first: "$delivery_time" },
                delivery_charge: { $first: "$delivery_charge" },
                is_favourite: { $first: "$is_favourite" },
                coupons: { $first: "$coupons" },
                rating: { $first: "$rating" },
                price_range: { $first: "$price_range" },
                is_take_pre_order: { $first: "$is_take_pre_order" },
                cuisines: { $first: "$cuisines" },
              },
            },
            {
              $lookup: {
                from: "favourite_restaurants",
                localField: "_id",
                foreignField: "branch_id",
                pipeline: [{ $match: { customer_id: user_id, is_delivery: true } }],
                as: "is_favourite",
              },
            },
            {
              $lookup: {
                from: "cuisines",
                localField: "cuisines.cuisine_id",
                foreignField: "_id",
                as: "cuisines",
                pipeline: [
                  {
                    $match: {
                      is_active: true,
                      is_delivery: true,
                    },
                  },
                  {
                    $project: {
                      status: 0,
                      image: 0,
                    },
                  },
                ],
              },
            },
            {
              $lookup: {
                from: "branch_coupons",
                localField: "_id",
                foreignField: "branch_id",
                pipeline: [
                  {
                    $lookup: {
                      from: "coupons",
                      localField: "coupon_id",
                      foreignField: "_id",
                      pipeline: [
                        {
                          $match: {
                            is_active: true,
                            start_time: {
                              $lte: new Date(),
                            },
                            end_time: {
                              $gte: new Date(),
                            },
                          },
                        },
                        {
                          $sort: {
                            created_at: -1,
                          },
                        },
                        {
                          $limit: 2,
                        },
                        {
                          $project: {
                            _id: 1,
                            name: 1,
                          },
                        },
                      ],
                      as: "branch_coupons",
                    },
                  },
                  {
                    $limit: 2,
                  },
                  { $unwind: "$branch_coupons" },
                  {
                    $project: {
                      branch_coupons: 1,
                    },
                  },
                ],
                as: "coupons",
              },
            },

            {
              $lookup: {
                from: "reviews",
                localField: "_id",
                foreignField: "rest_id",
                pipeline: [
                  {
                    $group: {
                      _id: "$rest_id",
                      avg: { $avg: "$rating" },
                      no_review: { $sum: 1 },
                    },
                  },
                  {
                    $project: {
                      _id: 0,
                      avg: { $round: ["$avg", 1] },
                      no_review: 1,
                    },
                  },
                ],
                as: "rating",
              },
            },
            {
              $project: {
                ...res_basic_data,
                coupons: "$coupons.branch_coupons",
                is_open: 1,
              },
            },
          ],
          as: "restaurants",
        },
      },
      {
        $project: {
          _id: 1,
          name: 1,
          image: 1,
          start_date: 1,
          end_date: 1,
          restaurants: "$restaurants",
        },
      },
    ])
      .skip(limit * (page - 1))
      .limit(limit);
    return data;
  } catch (err) {
    console.error(err);
    return false;
  }
};

DataSchema.statics.pick_getCampaignRestaurants = async function (
  campaign_id,
  zone_id,
  user_id,
  lim,
  page = 1
) {
  try {
    let limit = lim > 0 ? lim : 15;
    const data = await this.aggregate([
      {
        $match: {
          _id: campaign_id,
          is_active: true,
          is_pickup: true,
          start_date: {
            $lte: new Date(),
          },
          end_date: {
            $gte: new Date(),
          },
        },
      },
      {
        $lookup: {
          from: "restaurents",
          localField: "restaurants.res_id",
          foreignField: "_id",
          pipeline: [
            { $match: { "zone_id._id": zone_id, is_pickup: true, is_active: true } },
            { $unwind: "$working_hours" },
            {
              $set: {
                open: {
                  $dateFromParts: {
                    isoWeekYear: { $isoWeekYear: new Date() },
                    isoWeek: { $isoWeek: new Date() },
                    isoDayOfWeek: "$working_hours.day",
                    hour: "$working_hours.open_hour",
                    minute: "$working_hours.open_minute",
                  },
                },
                close: {
                  $dateFromParts: {
                    isoWeekYear: { $isoWeekYear: new Date() },
                    isoWeek: { $isoWeek: new Date() },
                    isoDayOfWeek: "$working_hours.day",
                    hour: "$working_hours.close_hour",
                    minute: "$working_hours.close_minute",
                  },
                },
              },
            },
            {
              $set: {
                is_open: {
                  $cond: {
                    if: {
                      $and: [
                        {
                          $lte: ["$open", new Date()],
                        },
                        {
                          $gt: ["$close", new Date()],
                        },
                      ],
                    },
                    then: 1,
                    else: 0,
                  },
                },
              },
            },

            {
              $group: {
                _id: "$_id",
                is_open: { $max: "$is_open" },
                name: { $first: "$name" },
                image: { $first: "$image" },
                cover_image: { $first: "$cover_image" },
                address: { $first: "$address" },
                delivery_time: { $first: "$delivery_time" },
                delivery_charge: { $first: "$delivery_charge" },
                is_favourite: { $first: "$is_favourite" },
                coupons: { $first: "$coupons" },
                rating: { $first: "$rating" },
                price_range: { $first: "$price_range" },
                is_take_pre_order: { $first: "$is_take_pre_order" },
                cuisines: { $first: "$cuisines" },
              },
            },
            {
              $lookup: {
                from: "favourite_restaurants",
                localField: "_id",
                foreignField: "branch_id",
                pipeline: [{ $match: { customer_id: user_id, is_pickup: true } }],
                as: "is_favourite",
              },
            },
            {
              $lookup: {
                from: "cuisines",
                localField: "cuisines.cuisine_id",
                foreignField: "_id",
                as: "cuisines",
                pipeline: [
                  {
                    $match: {
                      is_active: true,
                      is_pickup: true,
                    },
                  },
                  {
                    $project: {
                      status: 0,
                      image: 0,
                    },
                  },
                ],
              },
            },
            {
              $lookup: {
                from: "branch_coupons",
                localField: "_id",
                foreignField: "branch_id",
                pipeline: [
                  {
                    $lookup: {
                      from: "coupons",
                      localField: "coupon_id",
                      foreignField: "_id",
                      pipeline: [
                        {
                          $match: {
                            is_active: true,
                            start_time: {
                              $lte: new Date(),
                            },
                            end_time: {
                              $gte: new Date(),
                            },
                          },
                        },
                        {
                          $sort: {
                            created_at: -1,
                          },
                        },
                        {
                          $limit: 2,
                        },
                        {
                          $project: {
                            _id: 1,
                            name: 1,
                          },
                        },
                      ],
                      as: "branch_coupons",
                    },
                  },
                  {
                    $limit: 2,
                  },
                  { $unwind: "$branch_coupons" },
                  {
                    $project: {
                      branch_coupons: 1,
                    },
                  },
                ],
                as: "coupons",
              },
            },

            {
              $lookup: {
                from: "reviews",
                localField: "_id",
                foreignField: "rest_id",
                pipeline: [
                  {
                    $group: {
                      _id: "$rest_id",
                      avg: { $avg: "$rating" },
                      no_review: { $sum: 1 },
                    },
                  },
                  {
                    $project: {
                      _id: 0,
                      avg: { $round: ["$avg", 1] },
                      no_review: 1,
                    },
                  },
                ],
                as: "rating",
              },
            },
            {
              $project: {
                ...res_basic_data,
                coupons: "$coupons.branch_coupons",
                is_open: 1,
              },
            },
          ],
          as: "restaurants",
        },
      },
      {
        $project: {
          _id: 1,
          name: 1,
          image: 1,
          start_date: 1,
          end_date: 1,
          restaurants: "$restaurants",
        },
      },
    ])
      .skip(limit * (page - 1))
      .limit(limit);
    return data;
  } catch (err) {
    console.error(err);
    return false;
  }
};

DataSchema.statics.dine_getCampaignRestaurants = async function (
  campaign_id,
  zone_id,
  user_id,
  lim,
  page = 1
) {
  try {
    let limit = lim > 0 ? lim : 15;
    const data = await this.aggregate([
      {
        $match: {
          _id: campaign_id,
          is_active: true,
          is_dine: true,
          start_date: {
            $lte: new Date(),
          },
          end_date: {
            $gte: new Date(),
          },
        },
      },
      {
        $lookup: {
          from: "restaurents",
          localField: "restaurants.res_id",
          foreignField: "_id",
          pipeline: [
            { $match: { "zone_id._id": zone_id, is_active: true, is_dine: true } },
            { $unwind: "$working_hours" },
            {
              $set: {
                open: {
                  $dateFromParts: {
                    isoWeekYear: { $isoWeekYear: new Date() },
                    isoWeek: { $isoWeek: new Date() },
                    isoDayOfWeek: "$working_hours.day",
                    hour: "$working_hours.open_hour",
                    minute: "$working_hours.open_minute",
                  },
                },
                close: {
                  $dateFromParts: {
                    isoWeekYear: { $isoWeekYear: new Date() },
                    isoWeek: { $isoWeek: new Date() },
                    isoDayOfWeek: "$working_hours.day",
                    hour: "$working_hours.close_hour",
                    minute: "$working_hours.close_minute",
                  },
                },
              },
            },
            {
              $set: {
                is_open: {
                  $cond: {
                    if: {
                      $and: [
                        {
                          $lte: ["$open", new Date()],
                        },
                        {
                          $gt: ["$close", new Date()],
                        },
                      ],
                    },
                    then: 1,
                    else: 0,
                  },
                },
              },
            },

            {
              $group: {
                _id: "$_id",
                is_open: { $max: "$is_open" },
                name: { $first: "$name" },
                image: { $first: "$image" },
                cover_image: { $first: "$cover_image" },
                address: { $first: "$address" },
                delivery_time: { $first: "$delivery_time" },
                delivery_charge: { $first: "$delivery_charge" },
                is_favourite: { $first: "$is_favourite" },
                coupons: { $first: "$coupons" },
                rating: { $first: "$rating" },
                price_range: { $first: "$price_range" },
                is_take_pre_order: { $first: "$is_take_pre_order" },
                cuisines: { $first: "$cuisines" },
              },
            },
            {
              $lookup: {
                from: "favourite_restaurants",
                localField: "_id",
                foreignField: "branch_id",
                pipeline: [{ $match: { customer_id: user_id, is_dine: true } }],
                as: "is_favourite",
              },
            },
            {
              $lookup: {
                from: "cuisines",
                localField: "cuisines.cuisine_id",
                foreignField: "_id",
                as: "cuisines",
                pipeline: [
                  {
                    $match: {
                      is_active: true,
                      is_dine: true,
                    },
                  },
                  {
                    $project: {
                      status: 0,
                      image: 0,
                    },
                  },
                ],
              },
            },
            {
              $lookup: {
                from: "branch_coupons",
                localField: "_id",
                foreignField: "branch_id",
                pipeline: [
                  {
                    $lookup: {
                      from: "coupons",
                      localField: "coupon_id",
                      foreignField: "_id",
                      pipeline: [
                        {
                          $match: {
                            is_active: true,
                            start_time: {
                              $lte: new Date(),
                            },
                            end_time: {
                              $gte: new Date(),
                            },
                          },
                        },
                        {
                          $sort: {
                            created_at: -1,
                          },
                        },
                        {
                          $limit: 2,
                        },
                        {
                          $project: {
                            _id: 1,
                            name: 1,
                          },
                        },
                      ],
                      as: "branch_coupons",
                    },
                  },
                  {
                    $limit: 2,
                  },
                  { $unwind: "$branch_coupons" },
                  {
                    $project: {
                      branch_coupons: 1,
                    },
                  },
                ],
                as: "coupons",
              },
            },

            {
              $lookup: {
                from: "reviews",
                localField: "_id",
                foreignField: "rest_id",
                pipeline: [
                  {
                    $group: {
                      _id: "$rest_id",
                      avg: { $avg: "$rating" },
                      no_review: { $sum: 1 },
                    },
                  },
                  {
                    $project: {
                      _id: 0,
                      avg: { $round: ["$avg", 1] },
                      no_review: 1,
                    },
                  },
                ],
                as: "rating",
              },
            },
            {
              $project: {
                ...res_basic_data,
                coupons: "$coupons.branch_coupons",
                is_open: 1,
              },
            },
          ],
          as: "restaurants",
        },
      },
      {
        $project: {
          _id: 1,
          name: 1,
          image: 1,
          start_date: 1,
          end_date: 1,
          restaurants: "$restaurants",
        },
      },
    ])
      .skip(limit * (page - 1))
      .limit(limit);
    return data;
  } catch (err) {
    console.error(err);
    return false;
  }
};

const CampaignModel = mongoose.model("campaigns", DataSchema);
export default CampaignModel;
