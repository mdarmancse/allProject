import mongoose from "mongoose";
import { v4 as uuidv4 } from "uuid";
import { res_basic_data } from "../../utility/const.js";

const colorValidator = (v) => /^#([0-9a-f]{3}){1,2}$/i.test(v); //Match length of 3 or 6 hex value

const CuisineSchema = new mongoose.Schema(
  {
    _id: {
      type: String,
      default: () => uuidv4().replace(/\-/g, ""),
    },
    name: { type: String },
    image: { type: String },
    color: {
      bg: { type: String, validate: [colorValidator, "Not a valid color"] },
      fg: { type: String, validate: [colorValidator, "Not a valid color"] },
    },
    is_delivery: { type: Boolean, default: true },
    is_pickup: { type: Boolean, default: false },
    is_dine: { type: Boolean, default: false },
    is_active: { type: Boolean, default: true },
    created_at: { type: Date, default: null },
    created_by: { type: String, default: null },
    updated_at: { type: Date, default: null },
    updated_by: { type: String, default: null },
  },
  {
    collection: "cuisines",
    // timestamps: true,
    versionKey: false,
  }
);

CuisineSchema.statics.getActiveCuisines = async function (zone_id) {
  // console.log(zone_id);
  try {
    const data = await this.aggregate([
      {
        $match: {
          is_active: true,
          $or: [{ is_delivery: true }, { is_pickup: true }],
        },
      },
      {
        $lookup: {
          from: "restaurents",
          localField: "_id",
          foreignField: "cuisines.cuisine_id",
          pipeline: [
            {
              $match: {
                is_active: true,
                // $or: [
                //     { is_delivery: true },
                //     { is_pickup: true },
                // ],
                "zone_id._id": zone_id[0]._id,
              },
            },
          ],
          as: "restaurants",
        },
      },
      {
        $match: {
          restaurants: { $ne: [] },
        },
      },
      {
        $project: {
          _id: 1,
          name: 1,
          image: 1,
          color: 1,
        },
      },
    ]);

    console.log("Data after $match stage:", data);

    return data;
  } catch (err) {
    console.error(err);
    return false;
  }
};

CuisineSchema.statics.getActiveCuisinesNameId = async function (zone_id) {
  try {
    const data = await this.aggregate([
      {
        $match: {
          is_active: true,
          $or: [{ is_delivery: true }, { is_pickup: true }],
        },
      },
      {
        $lookup: {
          from: "restaurents",
          localField: "_id",
          foreignField: "cuisines.cuisine_id",
          pipeline: [
            {
              $match: {
                is_active: true,
                "zone_id._id": zone_id[0]._id,
              },
            },
          ],
          as: "restaurants",
        },
      },
      {
        $match: {
          restaurants: { $ne: [] },
        },
      },
      {
        $project: {
          _id: 1,
          name: 1,
        },
      },
    ]);

    return data;
  } catch (err) {
    console.error(err);
    return false;
  }
};

CuisineSchema.statics.getCuisineRestaurants = async function (
  zone_id,
  user_id,
  cuisine_id,
  lim,
  page = 1
) {
  try {
    let limit = lim > 0 ? lim : 15;
    const data = await this.aggregate([
      {
        $match: {
          _id: cuisine_id,
          is_active: true,
          $or: [{ is_delivery: true }, { is_pickup: true }],
        },
      },
      {
        $lookup: {
          from: "restaurents",
          foreignField: "cuisines.cuisine_id",
          localField: "_id",
          pipeline: [
            { $match: { "zone_id._id": zone_id, status: 1 } },
            { $unwind: "$working_hours" },
            {
              $set: {
                open: {
                  $dateFromParts: {
                    isoWeekYear: { $isoWeekYear: new Date() },
                    isoWeek: { $isoWeek: new Date() },
                    isoDayOfWeek: "$working_hours.day",
                    hour: "$working_hours.open_hour",
                    minute: "$working_hours.open_minute",
                  },
                },
                close: {
                  $dateFromParts: {
                    isoWeekYear: { $isoWeekYear: new Date() },
                    isoWeek: { $isoWeek: new Date() },
                    isoDayOfWeek: "$working_hours.day",
                    hour: "$working_hours.close_hour",
                    minute: "$working_hours.close_minute",
                  },
                },
              },
            },
            {
              $set: {
                is_open: {
                  $cond: {
                    if: {
                      $and: [
                        {
                          $lte: ["$open", new Date()],
                        },
                        {
                          $gt: ["$close", new Date()],
                        },
                      ],
                    },
                    then: 1,
                    else: 0,
                  },
                },
              },
            },

            {
              $group: {
                _id: "$_id",
                is_open: { $max: "$is_open" },
                name: { $first: "$name" },
                image: { $first: "$image" },
                cover_image: { $first: "$cover_image" },
                address: { $first: "$address" },
                delivery_time: { $first: "$delivery_time" },
                delivery_charge: { $first: "$delivery_charge" },
                is_favourite: { $first: "$is_favourite" },
                coupons: { $first: "$coupons" },
                rating: { $first: "$rating" },
                price_range: { $first: "$price_range" },
                is_take_pre_order: { $first: "$is_take_pre_order" },
                cuisines: { $first: "$cuisines" },
              },
            },
            {
              $lookup: {
                from: "favourite_restaurants",
                localField: "_id",
                foreignField: "branch_id",
                pipeline: [{ $match: { customer_id: user_id } }],
                as: "is_favourite",
              },
            },
            {
              $lookup: {
                from: "cuisines",
                localField: "cuisines.cuisine_id",
                foreignField: "_id",
                as: "cuisines",
                pipeline: [
                  {
                    $match: {
                      is_active: true,
                    },
                  },
                  {
                    $project: {
                      status: 0,
                      image: 0,
                    },
                  },
                ],
              },
            },
            {
              $lookup: {
                from: "branch_coupons",
                localField: "_id",
                foreignField: "branch_id",
                pipeline: [
                  {
                    $lookup: {
                      from: "coupons",
                      localField: "coupon_id",
                      foreignField: "_id",
                      pipeline: [
                        {
                          $match: {
                            is_active: true,
                            start_time: {
                              $lte: new Date(),
                            },
                            end_time: {
                              $gte: new Date(),
                            },
                          },
                        },
                        {
                          $sort: {
                            created_at: -1,
                          },
                        },
                        {
                          $limit: 2,
                        },
                        {
                          $project: {
                            _id: 1,
                            name: 1,
                          },
                        },
                      ],
                      as: "branch_coupons",
                    },
                  },
                  {
                    $limit: 2,
                  },
                  { $unwind: "$branch_coupons" },
                  {
                    $project: {
                      branch_coupons: 1,
                    },
                  },
                ],
                as: "coupons",
              },
            },
            {
              $lookup: {
                from: "reviews",
                localField: "_id",
                foreignField: "rest_id",
                pipeline: [
                  {
                    $group: {
                      _id: "$rest_id",
                      avg: { $avg: "$rating" },
                      no_review: { $sum: 1 },
                    },
                  },
                  {
                    $project: {
                      _id: 0,
                      avg: { $round: ["$avg", 1] },
                      no_review: 1,
                    },
                  },
                ],
                as: "rating",
              },
            },
            {
              $project: {
                ...res_basic_data,
                coupons: "$coupons.branch_coupons",
                is_open: 1,
              },
            },
          ],
          as: "restaurants",
        },
      },
      {
        $project: {
          _id: 1,
          name: 1,
          restaurants: "$restaurants",
        },
      },
    ])
      .skip(limit * (page - 1))
      .limit(limit);
    return data;
  } catch (err) {
    console.error(err);
    return false;
  }
};

/* Dine In */
CuisineSchema.statics.dine_getActiveCuisines = async function (zone_id) {
  try {
    const data = await this.aggregate([
      {
        $match: {
          is_active: true,
          is_dine: true,
        },
      },
      {
        $lookup: {
          from: "restaurents",
          localField: "_id",
          foreignField: "cuisines.cuisine_id",
          pipeline: [
            {
              $match: {
                is_active: true,
                is_dine: true,
                "zone_id._id": zone_id[0]._id,
              },
            },
          ],
          as: "restaurants",
        },
      },
      {
        $match: {
          restaurants: { $ne: [] },
        },
      },
      {
        $project: {
          _id: 1,
          name: 1,
          image: 1,
          color: 1,
        },
      },
    ]);
    return data;
  } catch (err) {
    console.error(err);
    return false;
  }
};

CuisineSchema.statics.dine_getCuisineRestaurants = async function (
  zone_id,
  user_id,
  cuisine_id,
  lim,
  page = 1
) {
  try {
    let limit = lim > 0 ? lim : 15;
    const data = await this.aggregate([
      {
        $match: {
          _id: cuisine_id,
          is_active: true,
          is_dine: true,
        },
      },
      {
        $lookup: {
          from: "restaurents",
          foreignField: "cuisines.cuisine_id",
          localField: "_id",
          pipeline: [
            { $match: { "zone_id._id": zone_id, is_active: true, is_dine: true } },
            { $unwind: "$working_hours" },
            {
              $set: {
                open: {
                  $dateFromParts: {
                    isoWeekYear: { $isoWeekYear: new Date() },
                    isoWeek: { $isoWeek: new Date() },
                    isoDayOfWeek: "$working_hours.day",
                    hour: "$working_hours.open_hour",
                    minute: "$working_hours.open_minute",
                  },
                },
                close: {
                  $dateFromParts: {
                    isoWeekYear: { $isoWeekYear: new Date() },
                    isoWeek: { $isoWeek: new Date() },
                    isoDayOfWeek: "$working_hours.day",
                    hour: "$working_hours.close_hour",
                    minute: "$working_hours.close_minute",
                  },
                },
              },
            },
            {
              $set: {
                is_open: {
                  $cond: {
                    if: {
                      $and: [
                        {
                          $lte: ["$open", new Date()],
                        },
                        {
                          $gt: ["$close", new Date()],
                        },
                      ],
                    },
                    then: 1,
                    else: 0,
                  },
                },
              },
            },

            {
              $group: {
                _id: "$_id",
                is_open: { $max: "$is_open" },
                name: { $first: "$name" },
                image: { $first: "$image" },
                cover_image: { $first: "$cover_image" },
                address: { $first: "$address" },
                delivery_time: { $first: "$delivery_time" },
                delivery_charge: { $first: "$delivery_charge" },
                is_favourite: { $first: "$is_favourite" },
                coupons: { $first: "$coupons" },
                rating: { $first: "$rating" },
                price_range: { $first: "$price_range" },
                is_take_pre_order: { $first: "$is_take_pre_order" },
                cuisines: { $first: "$cuisines" },
              },
            },
            {
              $lookup: {
                from: "favourite_restaurants",
                localField: "_id",
                foreignField: "branch_id",
                pipeline: [{ $match: { customer_id: user_id } }],
                as: "is_favourite",
              },
            },
            {
              $lookup: {
                from: "cuisines",
                localField: "cuisines.cuisine_id",
                foreignField: "_id",
                as: "cuisines",
                pipeline: [
                  {
                    $match: {
                      is_active: true,
                    },
                  },
                  {
                    $project: {
                      status: 0,
                      image: 0,
                    },
                  },
                ],
              },
            },
            {
              $lookup: {
                from: "branch_coupons",
                localField: "_id",
                foreignField: "branch_id",
                pipeline: [
                  {
                    $lookup: {
                      from: "coupons",
                      localField: "coupon_id",
                      foreignField: "_id",
                      pipeline: [
                        {
                          $match: {
                            is_active: true,
                            start_time: {
                              $lte: new Date(),
                            },
                            end_time: {
                              $gte: new Date(),
                            },
                          },
                        },
                        {
                          $sort: {
                            created_at: -1,
                          },
                        },
                        {
                          $limit: 2,
                        },
                        {
                          $project: {
                            _id: 1,
                            name: 1,
                          },
                        },
                      ],
                      as: "branch_coupons",
                    },
                  },
                  {
                    $limit: 2,
                  },
                  { $unwind: "$branch_coupons" },
                  {
                    $project: {
                      branch_coupons: 1,
                    },
                  },
                ],
                as: "coupons",
              },
            },
            {
              $lookup: {
                from: "reviews",
                localField: "_id",
                foreignField: "rest_id",
                pipeline: [
                  {
                    $group: {
                      _id: "$rest_id",
                      avg: { $avg: "$rating" },
                      no_review: { $sum: 1 },
                    },
                  },
                  {
                    $project: {
                      _id: 0,
                      avg: { $round: ["$avg", 1] },
                      no_review: 1,
                    },
                  },
                ],
                as: "rating",
              },
            },
            {
              $project: {
                ...res_basic_data,
                coupons: "$coupons.branch_coupons",
                is_open: 1,
              },
            },
          ],
          as: "restaurants",
        },
      },
      {
        $project: {
          _id: 1,
          name: 1,
          restaurants: "$restaurants",
        },
      },
    ])
      .skip(limit * (page - 1))
      .limit(limit);
    return data;
  } catch (err) {
    console.error(err);
    return false;
  }
};

const CuisineModel = mongoose.model("cuisines", CuisineSchema);
export default CuisineModel;
