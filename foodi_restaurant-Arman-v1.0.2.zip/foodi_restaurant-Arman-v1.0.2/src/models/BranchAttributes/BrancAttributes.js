import mongoose from "mongoose";
import { v4 as uuidv4 } from "uuid";
import { res_basic_data } from "../../utility/const.js";

const DataSchema = new mongoose.Schema(
  {
    _id: {
      type: String,
      default: () => uuidv4().replace(/\-/g, ""),
    },
    name: { type: String, default: null },
    is_active: { type: Boolean, default: true },
    created_at: { type: Date, default: null },
    created_by: { type: String, default: null },
    updated_at: { type: Date, default: null },
    updated_by: { type: String, default: null },
  },
  {
    collection: "branch_attributes",
    //  timestamps: true,
    versionKey: false,
  }
);
DataSchema.statics.getActiveAttributes = async function () {
  try {
    const data = await this.aggregate([
      {
        $match: {
          is_active: true,
        },
      },
      {
        $lookup: {
          from: "restaurents",
          localField: "_id",
          foreignField: "attributes.branch_attribute_id",
          pipeline: [
            {
              $match: {
                is_active: true,
              },
            },
          ],
          as: "restaurants",
        },
      },
      {
        $match: {
          restaurants: { $ne: [] },
        },
      },
      {
        $sort: { created_at: -1 },
      },
      {
        $project: {
          _id: 1,
          name: 1,
        },
      },
    ]);

    console.log("Data after $match stage:", data);

    return data;
  } catch (err) {
    console.error(err);
    return false;
  }
};

const BrancAttributes = mongoose.model("branch_attributes", DataSchema);
export default BrancAttributes;
