import mongoose from "mongoose";
import { v4 as uuidv4 } from "uuid";
import { res_basic_data } from "../../utility/const.js";

const DataSchema = new mongoose.Schema(
  {
    _id: {
      type: String,
      default: () => uuidv4(),
    },
    name: { type: String, default: null },
    description: { type: String, default: null },
    coupon_type_name: { type: String, default: null },
    coupon_type_id: { type: String, default: null },
    image: { type: String, default: null },
    use_limit: { type: Number, default: 0 },
    daily_use_limit: { type: Number, default: 0 },
    discount_in_amount: { type: Number, default: 0 },
    discount_in_percent: { type: Number, default: 0 },
    minimum_order_amount: { type: Number, default: 0 },
    maximum_discount_amount: { type: Number, default: 0 },
    total_coupon: { type: Number, default: null },
    start_time: { type: Date, default: null },
    end_time: { type: Date, default: null },
    valid_time_in_a_day_start: { type: String, default: null },
    valid_time_in_a_day_end: { type: String, default: null },
    is_percent: { type: Number, default: null },
    is_auto_apply: { type: Boolean, default: true },
    is_gradual: { type: Boolean, default: true },
    is_active: { type: Boolean, default: true },
    is_delivery: { type: Boolean, default: true },
    is_pickup: { type: Boolean, default: false },
    is_dine: { type: Boolean, default: false },
    created_at: { type: Date, default: null },
    created_by: { type: String, default: null },
    updated_at: { type: Date, default: null },
    updated_by: { type: String, default: null },
  },
  {
    collection: "coupons",
    //  timestamps: true,
    versionKey: false,
  }
);

// TODO: Check all types of coupon
DataSchema.statics.checkCoupon = async function (
  coupon_id,
  user_id = "",
  branch_id = "",
  zone_id = ""
) {
  try {
    const data = this.aggregate([
      {
        $match: {
          _id: coupon_id,
          is_active: true,
        },
      },
      {
        $lookup: {
          from: "coupon_types",
          localField: "coupon_type_id",
          foreignField: "_id",
          as: "coupon_type",
          pipeline: [],
        },
      },
      {
        $lookup: {
          from: "customer_coupon",
          localField: "_id",
          foreignField: "coupon_id",
          as: "customer_coupon",
          pipeline: [
            {
              $match: {
                customer_id: user_id,
                is_active: true,
              },
            },
          ],
        },
      },
    ]);

    return data;
  } catch (err) {
    console.error(err);
    return false;
  }
};

DataSchema.statics.getAutoApplyCoupons = async function ({
  branch_id = "",
  user_id = "",
  zone_id = "",
  cuisines = "",
  categories = [],
  is_delivery = null,
  is_pickup = null,
}) {
  try {
    const data = this.aggregate([
      {
        $match: {
          is_active: true,
          is_auto_apply: true,
          is_delivery: is_delivery ? true : false,
          is_pickup: is_pickup ? true : false,
        },
      },
      {
        $lookup: {
          from: "customer_coupon",
          localField: "_id",
          foreignField: "coupon_id",
          as: "customer_coupon",
          pipeline: [
            {
              $match: {
                customer_id: user_id,
              },
            },
          ],
        },
      },
      {
        $lookup: {
          from: "branch_coupons",
          localField: "_id",
          foreignField: "coupon_id",
          as: "branch_coupons",
          pipeline: [
            {
              $match: {
                branch_id: branch_id,
              },
            },
          ],
        },
      },
      {
        $lookup: {
          from: "zone_coupons",
          localField: "_id",
          foreignField: "coupon_id",
          as: "zone_coupons",
          pipeline: [
            {
              $match: {
                zone_id: zone_id,
              },
            },
          ],
        },
      },
      {
        $lookup: {
          from: "cuisine_coupons",
          localField: "_id",
          foreignField: "coupon_id",
          as: "cuisine_coupons",
          pipeline: [
            {
              $match: {
                cuisine_id: { $in: cuisines ? cuisines.map((cs) => cs.cuisine_id) : [] },
              },
            },
          ],
        },
      },
      {
        $lookup: {
          from: "category_coupons",
          localField: "_id",
          foreignField: "coupon_id",
          as: "category_coupons",
          pipeline: [
            {
              $match: {
                category_id: { $in: categories },
              },
            },
          ],
        },
      },
      {
        $sort: {
          created_at: -1,
        },
      },
    ]);

    return data;
  } catch (err) {
    console.error(err);
    return false;
  }
};

const CouponModel = mongoose.model("coupons", DataSchema);
export default CouponModel;
