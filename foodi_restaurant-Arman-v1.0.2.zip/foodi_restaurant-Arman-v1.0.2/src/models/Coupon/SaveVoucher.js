import mongoose from "mongoose";
import { v4 as uuidv4 } from "uuid";
import { res_basic_data } from "../../utility/const.js";
import moment from "moment";
import { SYSTEM_TIMEZONE } from "../../consts/defaults.js";

const DataSchema = new mongoose.Schema(
  {
    _id: {
      type: String,
      default: () => uuidv4(),
    },
    customer_id: { type: String },
    coupon_id: { type: String },
    is_active: { type: Boolean, default: true },
    created_at: {
      type: Date,
      default: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
    },
    created_by: { type: String, default: null },
    updated_at: {
      type: Date,
      default: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
    },
    updated_by: { type: String, default: null },
  },
  {
    collection: "save_vouchers",
    //  timestamps: true,
    versionKey: false,
  }
);

const SaveVouchers = mongoose.model("save_vouchers", DataSchema);
export default SaveVouchers;
