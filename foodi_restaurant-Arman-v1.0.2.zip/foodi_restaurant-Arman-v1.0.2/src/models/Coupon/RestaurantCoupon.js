import mongoose from "mongoose";
import { v4 as uuidv4 } from "uuid";
import { res_basic_data } from "../../utility/const.js";

const DataSchema = new mongoose.Schema(
  {
    _id: {
      type: String,
      //default: () => uuidv4().replace(/\-/g, ""),
    },
    restaurant_id: { type: String, default: null },
    coupon_id: { type: String, default: null },
    created_at: { type: Date, default: null },
    created_by: { type: String, default: null },
    updated_at: { type: Date, default: null },
    updated_by: { type: String, default: null },
  },
  {
    collection: "restaurant_coupon",
    //  timestamps: true,
    versionKey: false,
  }
);

const RestaurantCoupon = mongoose.model("restaurant_coupon", DataSchema);
export default RestaurantCoupon;
