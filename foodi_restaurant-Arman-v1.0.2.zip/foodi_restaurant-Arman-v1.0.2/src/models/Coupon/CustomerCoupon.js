import mongoose from "mongoose";
import { v4 as uuidv4 } from "uuid";
import { res_basic_data } from "../../utility/const.js";
import moment from "moment";
import { SYSTEM_TIMEZONE } from "../../consts/defaults.js";

const DataSchema = new mongoose.Schema(
  {
    _id: {
      type: String,
      default: () => uuidv4(),
    },
    customer_id: { type: String, default: null },
    coupon_id: { type: String, default: null },
    restaurant_id: { type: String, default: null },
    is_delivery: { type: Boolean, default: false },
    is_pickup: { type: Boolean, default: false },
    is_dine: { type: Boolean, default: false },
    created_at: {
      type: Date,
      default: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
    },
    created_by: { type: String, default: null },
    updated_at: {
      type: Date,
      default: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
    },
    updated_by: { type: String, default: null },
  },
  {
    collection: "customer_coupon",
    //  timestamps: true,
    versionKey: false,
  }
);

DataSchema.statics.dine_checkCoupon = async function (customer_id, rest_id) {
  try {
    const data = await this.aggregate([
      { $match: { customer_id: customer_id, restaurant_id: rest_id, is_dine: true } },
      { $sort: { created_at: -1 } },
      { $limit: 1 },
      {
        $lookup: {
          from: "coupons",
          localField: "coupon_id",
          foreignField: "_id",
          pipeline: [
            {
              $match: {
                is_active: true,
                is_dine: true,
                start_time: {
                  $lte: new Date(),
                },
                end_time: {
                  $gte: new Date(),
                },
              },
            },
            {
              $sort: {
                created_at: -1,
              },
            },
            {
              $limit: 1,
            },
            {
              $project: {
                _id: 1,
                name: 1,
                description: 1,
                start_time: 1,
                end_time: 1,
              },
            },
          ],
          as: "users_coupon",
        },
      },
      { $project: { users_coupon: { $arrayElemAt: ["$users_coupon", 0] } } },
      { $replaceRoot: { newRoot: "$users_coupon" } },
    ]);

    return data;
  } catch (err) {
    console.error(err);
    return false;
  }
};

const CustomerCoupon = mongoose.model("customer_coupon", DataSchema);
export default CustomerCoupon;
