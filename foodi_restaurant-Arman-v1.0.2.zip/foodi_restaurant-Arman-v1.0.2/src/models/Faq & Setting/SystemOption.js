import mongoose from "mongoose";
import { v4 as uuidv4 } from "uuid";
import { res_basic_data } from "../../utility/const.js";
const DataSchema = new mongoose.Schema(
  {
    _id: {
      type: String,
      //default: () => uuidv4(),
    },
    type: { type: String, default: null },
    name: { type: String, default: null },
    display_name: { type: String, default: null },
    value: { type: String, default: null },
    possible_value: { type: String, default: null },
    sytem_on_off_reson: { type: String, default: null },
    is_active: { type: Boolean, default: true },
    created_at: { type: Date, default: null },
    created_by: { type: String, default: null },
    updated_at: { type: Date, default: null },
    updated_by: { type: String, default: null },
  },
  {
    collection: "system_options",
    // timestamps: true,
    versionKey: false,
  }
);

DataSchema.statics.getSystemOption = async function () {
  try {
    const getData = await this.aggregate([
      {
        $match: { is_active: true },
      },
      {
        $group: {
          _id: null,
          data: { $push: { k: "$name", v: "$value" } },
        },
      },
      {
        $project: {
          _id: 0,
          system_option: { $arrayToObject: "$data" },
        },
      },
    ]);
    const data = getData.shift();
    return data.system_option;
  } catch (err) {
    console.error(err);
    return false;
  }
};

const SystemOption = mongoose.model("system_options", DataSchema);
export default SystemOption;
