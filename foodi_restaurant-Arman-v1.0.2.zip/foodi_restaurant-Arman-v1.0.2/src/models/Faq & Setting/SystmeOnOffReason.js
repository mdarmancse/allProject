import mongoose from "mongoose";
import { v4 as uuidv4 } from "uuid";

const FAQSchema = new mongoose.Schema(
  {
    _id: {
      type: String,
    },
    name: { type: String, default: null },
    description: { type: String, default: null },
    image: { type: String, default: null },
    is_active: { type: Boolean, default: true },
    is_delivery: { type: Boolean, default: false },
    is_pickup: { type: Boolean, default: false },
    is_dine: { type: Boolean, default: true },
    created_at: { type: Date, default: null },
    created_by: { type: String, default: null },
    updated_at: { type: Date, default: null },
    updated_by: { type: String, default: null },
  },
  {
    collection: "system_on_off_reason",
    // timestamps: true,
    versionKey: false,
  }
);

const SystemOnOffReason = mongoose.model("system_on_off_reason", FAQSchema);
export default SystemOnOffReason;
