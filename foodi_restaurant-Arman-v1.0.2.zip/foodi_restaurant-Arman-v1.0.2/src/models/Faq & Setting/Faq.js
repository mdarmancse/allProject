import mongoose from "mongoose";
import { v4 as uuidv4 } from "uuid";

const FAQSchema = new mongoose.Schema(
  {
    _id: {
      type: String,
      default: () => uuidv4(),
    },
    question: { type: String, default: null },
    answer: { type: String, default: null },
    is_active: { type: Boolean, default: true },
    is_delivery: { type: Boolean, default: false },
    is_pickup: { type: Boolean, default: false },
    is_dine: { type: Boolean, default: true },
    created_at: { type: Date, default: null },
    created_by: { type: String, default: null },
    updated_at: { type: Date, default: null },
    updated_by: { type: String, default: null },
  },
  {
    collection: "faq",
    // timestamps: true,
    versionKey: false,
  }
);

const FaqSchema = mongoose.model("faq", FAQSchema);
export default FaqSchema;
