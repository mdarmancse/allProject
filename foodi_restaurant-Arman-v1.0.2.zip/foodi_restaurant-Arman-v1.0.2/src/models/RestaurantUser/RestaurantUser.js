import mongoose from "mongoose";
import { v4 as uuidv4 } from "uuid";

const DataSchema = new mongoose.Schema(
  {
    _id: {
      type: String,
    },
    first_name: {
      type: String,
      default: null,
    },
    last_name: {
      type: String,
      default: null,
    },
    email: {
      type: String,
      default: null,
    },
    mobile_number: {
      type: String,
      default: null,
    },
    image: {
      type: String,
      default: null,
    },
    present_address: {
      type: String,
      default: null,
    },
    permanent_address: {
      type: String,
      default: null,
    },
    password_hash: {
      type: String,
      default: null,
    },
    password_salt: {
      type: String,
      default: null,
    },
    verification_token: {
      type: String,
      default: null,
    },
    verified_at: {
      type: Date,
      default: null,
    },
    password_reset_token: {
      type: String,
      default: null,
    },
    reset_token_expires: {
      type: Date,
      default: null,
    },
    role_id: {
      type: String,
      default: null,
    },
    device_id: {
      type: String,
      default: null,
    },
    web_device_id: {
      type: String,
      default: null,
    },
    is_active: { type: Boolean, default: true },
    created_at: { type: Date, default: null },
    created_by: { type: String, default: null },
    updated_at: { type: Date, default: null },
    updated_by: { type: String, default: null },
  },
  {
    collection: "restaurant_users",
    versionKey: false,
  }
);

DataSchema.statics.getRoleByUserId = async function (user_id) {
  try {
    const data = await this.aggregate([
      {
        $match: {
          _id: user_id,
        },
      },
      {
        $lookup: {
          from: "roles",
          localField: "role_id",
          foreignField: "_id",
          pipeline: [
            {
              $project: {
                _id: 1,
                name: 1,
              },
            },
          ],
          as: "roles",
        },
      },
      {
        $project: {
          role_id: { $arrayElemAt: ["$roles._id", 0] },
          role_name: { $arrayElemAt: ["$roles.name", 0] },
        },
      },
    ]);

    // console.log('DATA',data)

    return data.shift();
  } catch (err) {
    console.log("err :", err);
    return false;
  }
};

const RestaurantUser = mongoose.model("restaurant_users", DataSchema);
export default RestaurantUser;
