import mongoose from "mongoose";
import { v4 as uuidv4 } from "uuid";
import { res_basic_data } from "../../utility/const.js";
import moment from "moment";
import { SYSTEM_TIMEZONE } from "../../consts/defaults.js";

const PromotionSchema = new mongoose.Schema(
  {
    _id: {
      type: String,
    },
    name: { type: String },
    type: {
      type: String,
      enum: ["slider", "banner"],
      default: "slider",
    },
    restaurants: [
      {
        _id: { type: String },
        branch_id: { type: String },
        promotion_id: { type: String },
        res_id: { type: String },
      },
    ],
    start_date: { type: Date, default: null },
    end_date: { type: Date, default: null },
    is_active: { type: Boolean, default: true },
    is_delivery: { type: Boolean, default: true },
    is_pickup: { type: Boolean, default: false },
    is_dine: { type: Boolean, default: false },
    created_at: { type: Date, default: null },
    created_by: { type: String, default: null },
    updated_at: { type: Date, default: null },
    updated_by: { type: String, default: null },
  },
  {
    collection: "promotions",
    // timestamps: true,
    versionKey: false,
  }
);

PromotionSchema.statics.getZonePromotions = async function (zone_id, user_id) {
  try {
    const data = await this.aggregate([
      {
        $match: {
          is_active: true,
          is_delivery: true,
          start_date: {
            $lte: moment()
              .add(SYSTEM_TIMEZONE.HOURS, "hours")
              .add(SYSTEM_TIMEZONE.MINUTES, "minutes")
              .toDate(),
          },
          end_date: {
            $gte: moment()
              .add(SYSTEM_TIMEZONE.HOURS, "hours")
              .add(SYSTEM_TIMEZONE.MINUTES, "minutes")
              .toDate(),
          },
        },
      },
      {
        $lookup: {
          from: "restaurents",
          localField: "restaurants.res_id",
          foreignField: "_id",
          pipeline: [
            {
              $match: {
                is_active: true,
                is_delivery: true,
                "zone_id._id": zone_id,
              },
            },
            { $unwind: "$working_hours" },
            {
              $set: {
                open: {
                  $dateFromParts: {
                    isoWeekYear: { $isoWeekYear: new Date() },
                    isoWeek: { $isoWeek: new Date() },
                    isoDayOfWeek: "$working_hours.day",
                    hour: "$working_hours.open_hour",
                    minute: "$working_hours.open_minute",
                  },
                },
                close: {
                  $dateFromParts: {
                    isoWeekYear: { $isoWeekYear: new Date() },
                    isoWeek: { $isoWeek: new Date() },
                    isoDayOfWeek: "$working_hours.day",
                    hour: "$working_hours.close_hour",
                    minute: "$working_hours.close_minute",
                  },
                },
              },
            },
            {
              $set: {
                is_open: {
                  $cond: {
                    if: {
                      $and: [
                        {
                          $lte: ["$open", new Date()],
                        },
                        {
                          $gt: ["$close", new Date()],
                        },
                      ],
                    },
                    then: 1,
                    else: 0,
                  },
                },
              },
            },

            {
              $group: {
                _id: "$_id",
                is_open: { $max: "$is_open" },
                name: { $first: "$name" },
                image: { $first: "$image" },
                cover_image: { $first: "$cover_image" },
                address: { $first: "$address" },
                delivery_time: { $first: "$delivery_time" },
                delivery_charge: { $first: "$delivery_charge" },
                is_favourite: { $first: "$is_favourite" },
                coupons: { $first: "$coupons" },
                rating: { $first: "$rating" },
                price_range: { $first: "$price_range" },
                is_take_pre_order: { $first: "$is_take_pre_order" },
                cuisines: { $first: "$cuisines" },
              },
            },
            {
              $lookup: {
                from: "favourite_restaurants",
                localField: "_id",
                foreignField: "branch_id",
                pipeline: [{ $match: { customer_id: user_id, is_delivery: true } }],
                as: "is_favourite",
              },
            },
            {
              $lookup: {
                from: "cuisines",
                localField: "cuisines.cuisine_id",
                foreignField: "_id",
                as: "cuisines",
                pipeline: [
                  {
                    $match: {
                      is_active: true,
                      is_delivery: true,
                    },
                  },
                  {
                    $project: {
                      status: 0,
                      image: 0,
                    },
                  },
                ],
              },
            },
            {
              $lookup: {
                from: "branch_coupons",
                localField: "_id",
                foreignField: "branch_id",
                pipeline: [
                  {
                    $lookup: {
                      from: "coupons",
                      localField: "coupon_id",
                      foreignField: "_id",
                      pipeline: [
                        {
                          $match: {
                            is_active: true,
                            start_time: {
                              $lte: new Date(),
                            },
                            end_time: {
                              $gte: new Date(),
                            },
                          },
                        },
                        {
                          $sort: {
                            created_at: -1,
                          },
                        },

                        {
                          $project: {
                            _id: 1,
                            name: 1,
                            description: 1,
                          },
                        },
                      ],
                      as: "branch_coupons",
                    },
                  },
                  {
                    $limit: 2,
                  },
                  { $unwind: "$branch_coupons" },
                  {
                    $project: {
                      branch_coupons: 1,
                    },
                  },
                ],

                as: "coupons",
              },
            },
            {
              $lookup: {
                from: "reviews",
                localField: "_id",
                foreignField: "rest_id",
                pipeline: [
                  {
                    $group: {
                      _id: "$rest_id",
                      avg: { $avg: "$rating" },
                      no_review: { $sum: 1 },
                    },
                  },
                  {
                    $project: {
                      _id: 0,
                      avg: { $round: ["$avg", 1] },
                      no_review: 1,
                    },
                  },
                ],
                as: "rating",
              },
            },
            { $sort: { _id: -1 } },
            {
              $project: {
                ...res_basic_data,
                coupons: "$coupons.branch_coupons",
                is_open: 1,
              },
            },
          ],
          as: "restaurants",
        },
      },
      {
        $project: {
          _id: 1,
          name: 1,
          restaurants: "$restaurants",
        },
      },
    ]);
    return data;
  } catch (err) {
    console.error(err);
    return false;
  }
};
PromotionSchema.statics.pick_getZonePromotions = async function (zone_id, user_id) {
  try {
    const data = await this.aggregate([
      {
        $match: {
          is_active: true,
          is_pickup: true,
        },
      },
      {
        $lookup: {
          from: "restaurents",
          localField: "restaurants.res_id",
          foreignField: "_id",
          pipeline: [
            {
              $match: {
                is_active: true,
                is_pickup: true,
                "zone_id._id": zone_id,
              },
            },
            { $unwind: "$working_hours" },
            {
              $set: {
                open: {
                  $dateFromParts: {
                    isoWeekYear: { $isoWeekYear: new Date() },
                    isoWeek: { $isoWeek: new Date() },
                    isoDayOfWeek: "$working_hours.day",
                    hour: "$working_hours.open_hour",
                    minute: "$working_hours.open_minute",
                  },
                },
                close: {
                  $dateFromParts: {
                    isoWeekYear: { $isoWeekYear: new Date() },
                    isoWeek: { $isoWeek: new Date() },
                    isoDayOfWeek: "$working_hours.day",
                    hour: "$working_hours.close_hour",
                    minute: "$working_hours.close_minute",
                  },
                },
              },
            },
            {
              $set: {
                is_open: {
                  $cond: {
                    if: {
                      $and: [
                        {
                          $lte: ["$open", new Date()],
                        },
                        {
                          $gt: ["$close", new Date()],
                        },
                      ],
                    },
                    then: 1,
                    else: 0,
                  },
                },
              },
            },

            {
              $group: {
                _id: "$_id",
                is_open: { $max: "$is_open" },
                name: { $first: "$name" },
                image: { $first: "$image" },
                // location_long: { $first: { $arrayElemAt: [{ $addToSet: "$location.coordinates.0" }, 0] } },
                // location_lat: { $first: { $arrayElemAt: [{ $addToSet: "$location.coordinates.1" }, 0] } },
                cover_image: { $first: "$cover_image" },
                address: { $first: "$address" },
                delivery_time: { $first: "$delivery_time" },
                delivery_charge: { $first: "$delivery_charge" },
                is_favourite: { $first: "$is_favourite" },
                coupons: { $first: "$coupons" },
                rating: { $first: "$rating" },
                price_range: { $first: "$price_range" },
                is_take_pre_order: { $first: "$is_take_pre_order" },
                cuisines: { $first: "$cuisines" },
              },
            },
            {
              $lookup: {
                from: "favourite_restaurants",
                localField: "_id",
                foreignField: "branch_id",
                pipeline: [{ $match: { customer_id: user_id, is_pickup: true } }],
                as: "is_favourite",
              },
            },
            {
              $lookup: {
                from: "cuisines",
                localField: "cuisines.cuisine_id",
                foreignField: "_id",
                as: "cuisines",
                pipeline: [
                  {
                    $match: {
                      is_active: true,
                      is_pickup: true,
                    },
                  },
                  {
                    $project: {
                      status: 0,
                      image: 0,
                    },
                  },
                ],
              },
            },
            {
              $lookup: {
                from: "branch_coupons",
                localField: "_id",
                foreignField: "branch_id",
                pipeline: [
                  {
                    $lookup: {
                      from: "coupons",
                      localField: "coupon_id",
                      foreignField: "_id",
                      pipeline: [
                        {
                          $match: {
                            is_active: true,
                            start_time: {
                              $lte: new Date(),
                            },
                            end_time: {
                              $gte: new Date(),
                            },
                          },
                        },
                        {
                          $sort: {
                            created_at: -1,
                          },
                        },

                        {
                          $project: {
                            _id: 1,
                            name: 1,
                            description: 1,
                          },
                        },
                      ],
                      as: "branch_coupons",
                    },
                  },
                  {
                    $limit: 2,
                  },
                  { $unwind: "$branch_coupons" },
                  {
                    $project: {
                      branch_coupons: 1,
                    },
                  },
                ],
                as: "coupons",
              },
            },
            {
              $lookup: {
                from: "reviews",
                localField: "_id",
                foreignField: "rest_id",
                pipeline: [
                  {
                    $group: {
                      _id: "$rest_id",
                      avg: { $avg: "$rating" },
                      no_review: { $sum: 1 },
                    },
                  },
                  {
                    $project: {
                      _id: 0,
                      avg: { $round: ["$avg", 1] },
                      no_review: 1,
                    },
                  },
                ],
                as: "rating",
              },
            },
            { $sort: { _id: -1 } },
            {
              $project: {
                ...res_basic_data,
                coupons: "$coupons.branch_coupons",
                is_open: 1,
              },
            },
          ],
          as: "restaurants",
        },
      },
      {
        $project: {
          _id: 1,
          name: 1,
          restaurants: "$restaurants",
          // rest_long: "$restaurants.location_long",
          // rest_lat: "$restaurants.location_lat"
        },
      },
    ]);
    return data;
  } catch (err) {
    console.error(err);
    return false;
  }
};

const PromotionModel = mongoose.model("promotions", PromotionSchema);
export default PromotionModel;
