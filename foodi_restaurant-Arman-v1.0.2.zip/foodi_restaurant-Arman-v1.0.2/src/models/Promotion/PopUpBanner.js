import mongoose from "mongoose";
import { v4 as uuidv4 } from "uuid";
import { res_basic_data } from "../../utility/const.js";

const DataSchema = new mongoose.Schema(
  {
    _id: {
      type: String,
      // default: () => uuidv4().replace(/\-/g, ""),
    },
    title: { type: String, default: null },
    description: { type: String, default: null },
    image: { type: String },
    start_date: { type: Date, default: null },
    end_date: { type: Date, default: null },
    cancellable: { type: Number, default: 1 },
    redirection_type: {
      type: String,
      default: null,
      enum: ["restaurant", "campaign"],
    },
    is_redirect: { type: Boolean, default: false },
    restaurant_id: { type: String, default: null },
    campaign_id: { type: String, default: null },
    is_active: { type: Boolean, default: true },
    created_at: { type: Date, default: null },
    created_by: { type: String, default: null },
    updated_at: { type: Date, default: null },
    updated_by: { type: String, default: null },
  },
  {
    collection: "popup_bannner",
    versionKey: false,
  }
);

DataSchema.statics.getPopupBanner = async function (zone_id) {
  try {
    const data = await this.aggregate([
      {
        $match: {
          is_active: true,
          start_date: {
            $lte: new Date(),
          },
          end_date: {
            $gte: new Date(),
          },
        },
      },

      {
        $lookup: {
          from: "restaurents",
          localField: "restaurant_id",
          foreignField: "_id",
          pipeline: [
            {
              $match: { "zone_id._id": zone_id, is_active: true },
            },
            { $unwind: "$working_hours" },
            {
              $set: {
                open: {
                  $dateFromParts: {
                    isoWeekYear: { $isoWeekYear: new Date() },
                    isoWeek: { $isoWeek: new Date() },
                    isoDayOfWeek: "$working_hours.day",
                    hour: "$working_hours.open_hour",
                    minute: "$working_hours.open_minute",
                  },
                },
                close: {
                  $dateFromParts: {
                    isoWeekYear: { $isoWeekYear: new Date() },
                    isoWeek: { $isoWeek: new Date() },
                    isoDayOfWeek: "$working_hours.day",
                    hour: "$working_hours.close_hour",
                    minute: "$working_hours.close_minute",
                  },
                },
              },
            },
            {
              $set: {
                is_open: {
                  $cond: {
                    if: {
                      $and: [
                        {
                          $lte: ["$open", new Date()],
                        },
                        {
                          $gt: ["$close", new Date()],
                        },
                      ],
                    },
                    then: 1,
                    else: 0,
                  },
                },
              },
            },

            {
              $group: {
                _id: "$_id",
                is_open: { $max: "$is_open" },
              },
            },
            {
              $project: {
                _id: 1,
                is_open: { $ifNull: ["$is_open", null] },
              },
            },
          ],
          as: "restaurant",
        },
      },
      {
        $lookup: {
          from: "campaigns",
          localField: "campaign_id",
          foreignField: "_id",
          pipeline: [
            { $match: { is_active: true } },
            {
              $lookup: {
                from: "restaurents",
                localField: "restaurants.res_id",
                foreignField: "_id",
                pipeline: [
                  {
                    $match: { "zone_id._id": zone_id, is_active: true },
                  },
                  { $unwind: "$working_hours" },
                  {
                    $set: {
                      open: {
                        $dateFromParts: {
                          isoWeekYear: { $isoWeekYear: new Date() },
                          isoWeek: { $isoWeek: new Date() },
                          isoDayOfWeek: "$working_hours.day",
                          hour: "$working_hours.open_hour",
                          minute: "$working_hours.open_minute",
                        },
                      },
                      close: {
                        $dateFromParts: {
                          isoWeekYear: { $isoWeekYear: new Date() },
                          isoWeek: { $isoWeek: new Date() },
                          isoDayOfWeek: "$working_hours.day",
                          hour: "$working_hours.close_hour",
                          minute: "$working_hours.close_minute",
                        },
                      },
                    },
                  },
                  {
                    $set: {
                      is_open: {
                        $cond: {
                          if: {
                            $and: [
                              {
                                $lte: ["$open", new Date()],
                              },
                              {
                                $gt: ["$close", new Date()],
                              },
                            ],
                          },
                          then: 1,
                          else: 0,
                        },
                      },
                    },
                  },

                  {
                    $group: {
                      _id: "$_id",
                      is_open: { $max: "$is_open" },
                    },
                  },
                  {
                    $project: {
                      _id: 1,
                      is_open: { $ifNull: ["$is_open", null] },
                    },
                  },
                ],
                as: "restaurant",
              },
            },
          ],
          as: "campaigns",
        },
      },
      {
        $addFields: {
          campaign: { $arrayElemAt: ["$campaigns.restaurant", 0] },
        },
      },
      {
        $project: {
          _id: 1,
          title: 1,
          description: 1,
          image: 1,
          status: 1,
          cancellable: 1,
          redirection_type: 1,
          is_redirect: 1,
          restaurant_id: 1,
          start_date: 1,
          end_date: 1,
          campaign_id: 1,
          restaurant: {
            $cond: {
              if: { $eq: ["$redirection_type", "restaurant"] },
              then: { $arrayElemAt: ["$restaurant", 0] },
              else: null,
            },
          },
          campaign: {
            $cond: {
              if: { $eq: ["$redirection_type", "campaign"] },
              then: { $arrayElemAt: ["$campaign", 0] },
              else: null,
            },
          },
        },
      },
      {
        $match: {
          $or: [
            { redirection_type: { $ne: "restaurant" } },
            { restaurant: { $ne: null } },
          ],
        },
      },

      {
        $match: {
          $or: [{ redirection_type: { $ne: "campaign" } }, { campaign: { $ne: null } }],
        },
      },

      {
        $project: {
          _id: "$_id",
          title: "$title",
          description: "$description",
          image: "$image",
          cancellable: "$cancellable",
          redirection_type: "$redirection_type",
          is_redirect: "$is_redirect",
          restaurant_id: "$restaurant_id",
          campaign_id: "$campaign_id",
          start_date: "$start_date",
          end_date: "$end_date",
        },
      },
    ]);

    return data;
  } catch (err) {
    console.error(err);
    return false;
  }
};

const PopUpBanner = mongoose.model("popup_bannner", DataSchema);
export default PopUpBanner;
