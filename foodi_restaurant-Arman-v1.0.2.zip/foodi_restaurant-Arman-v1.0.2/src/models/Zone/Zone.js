import mongoose from "mongoose";
import { v4 as uuidv4 } from "uuid";
const DataSchema = mongoose.Schema(
  {
    _id: {
      type: String,
      // default: () => uuidv4().replace(/\-/g, ""),
    },
    name: { type: String },
    city_id: { type: String },
    radius: { type: Number },
    lat_long: {
      type: {
        type: String,
        default: "Polygon",
        enum: ["Point", "Polygon"],
      },
      coordinates: [],
    },
    is_active: { type: Boolean, default: true },
    created_at: { type: Date, default: null },
    created_by: { type: String, default: null },
    updated_at: { type: Date, default: null },
    updated_by: { type: String, default: null },
  },
  { versionKey: false }
);

const Zone = mongoose.model("zones", DataSchema);
export default Zone;
