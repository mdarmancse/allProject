import mongoose from "mongoose";
import { v4 as uuidv4 } from "uuid";
import { res_basic_data } from "../../utility/const.js";

const DataSchema = new mongoose.Schema(
  {
    _id: {
      type: String,
      //default: () => uuidv4().replace(/\-/g, ""),
    },
    menu_variation_or_add_on_id: { type: String },
    price: { type: Number, default: 0 },
    tax_in_amount: { type: Number, default: 0 },
    tax_in_percent: { type: Number, default: 0 },
    is_tax_in_percent: { type: Number, default: 0 },
    vat_in_amount: { type: Number, default: 0 },
    vat_in_percent: { type: Number, default: 0 },
    suplymentry_duty_in_amount: { type: Number, default: 0 },
    suplymentry_duty_in_percent: { type: Number, default: 0 },
    max_retail_price: { type: Number, default: 0 },
    is_vat_in_percent: { type: Boolean, default: null },
    is_MRP: { type: Boolean, default: null },
    created_at: { type: Date, default: null },
    created_by: { type: String, default: null },
    updated_at: { type: Date, default: null },
    updated_by: { type: String, default: null },
  },
  {
    collection: "cart_update_history",
    //  timestamps: true,
    versionKey: false,
  }
);

const CartUpdateHistory = mongoose.model("cart_update_history", DataSchema);
export default CartUpdateHistory;
