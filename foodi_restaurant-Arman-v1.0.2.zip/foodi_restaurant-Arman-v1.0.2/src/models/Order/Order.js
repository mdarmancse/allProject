import mongoose from "mongoose";
import { v4 as uuidv4 } from "uuid";
import { res_basic_data } from "../../utility/const.js";
import moment from "moment";
import { SYSTEM_TIMEZONE } from "../../consts/defaults.js";

const DataSchema = mongoose.Schema(
  {
    _id: {
      type: String,
      default: () => uuidv4(),
    },
    transaction_id: { type: String, default: null },
    payment_method_id: { type: String },
    customer_id: { type: String },
    branch_id: { type: String },
    zone_id: { type: String, default: null },
    user_lat: { type: Number, default: null },
    user_long: { type: Number, default: null },
    address: { type: String, default: null },
    instruction: { type: String, default: null },
    rider_id: { type: String, default: null },
    rider_first_name: { type: String, default: null },
    rider_mobile: { type: String, default: null },
    customer_name: { type: String, default: null },
    customer_mobile: { type: String, default: null },
    coupon_id: { type: String, default: null },
    order_details: [],
    sub_total: { type: Number, default: 0 },
    total_amount: { type: Number, default: 0 },
    value_added_tax_inclusive: { type: Number, default: 0 },
    supplementary_duty: { type: Number, default: 0 },
    discount_amount: { type: Number, default: 0 },
    discount_in_percent: { type: Number, default: 0 },
    delivery_charge: { type: Number, default: 0 },
    proof_image: { type: String, default: null },
    order_status: {
      type: String,
      default: "placed",
      enum: [
        "placed",
        "accepted",
        "assigned",
        "preparing",
        "ongoing",
        "delivered",
        "cancel",
        "not_delivered",
      ],
    },
    order_type: {
      type: String,
      default: "delivery",
      enum: ["delivery", "pickup", "dine_in"],
    },
    is_cutlery_needed: { type: Boolean, default: false },
    rider_accepted: { type: Boolean, default: false },
    arrived_vendor: { type: Boolean, default: false },
    arrived_customer: { type: Boolean, default: false },
    delivery_time: { type: Number, default: 0 },
    total_delivery_time: { type: Number, default: 0 },
    highest_recipe_time: { type: Number, default: 0 },
    avg_time: { type: Number, default: 0 },
    rest_cust_duration: { type: Number, default: 0 },
    payment_to_vendor: { type: Number, default: 0 },
    arrival_time: { type: String, default: null },
    is_pre_order: { type: Boolean, default: false },
    is_handover: { type: Boolean, default: false },
    is_verified: { type: Boolean, default: true },
    is_active: { type: Boolean, default: true },
    created_at: {
      type: Date,
      default: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
    },
    created_by: { type: String, default: null },
    updated_at: { type: Date, default: null },
    updated_by: {
      type: String,
      default: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
    },
  },
  { versionKey: false }
);
DataSchema.statics.getYourRestaurant = async function (
  zone_id,
  user_id,
  long,
  lat,
  lim,
  page = 1
) {
  try {
    let limit = lim > 0 ? lim : 15;
    const data = await this.aggregate([
      { $match: { customer_id: user_id, order_type: "delivery" } },

      {
        $lookup: {
          from: "restaurents",
          localField: "branch_id",
          foreignField: "_id",
          pipeline: [
            { $match: { is_active: true, is_delivery: true } },
            { $unwind: "$working_hours" },
            {
              $set: {
                open: {
                  $dateFromParts: {
                    isoWeekYear: { $isoWeekYear: new Date() },
                    isoWeek: { $isoWeek: new Date() },
                    isoDayOfWeek: "$working_hours.day",
                    hour: "$working_hours.open_hour",
                    minute: "$working_hours.open_minute",
                  },
                },
                close: {
                  $dateFromParts: {
                    isoWeekYear: { $isoWeekYear: new Date() },
                    isoWeek: { $isoWeek: new Date() },
                    isoDayOfWeek: "$working_hours.day",
                    hour: "$working_hours.close_hour",
                    minute: "$working_hours.close_minute",
                  },
                },
              },
            },
            {
              $set: {
                is_open: {
                  $cond: {
                    if: {
                      $and: [
                        {
                          $lte: ["$open", new Date()],
                        },
                        {
                          $gt: ["$close", new Date()],
                        },
                      ],
                    },
                    then: 1,
                    else: 0,
                  },
                },
              },
            },

            {
              $group: {
                _id: "$_id",
                is_open: { $max: "$is_open" },
                name: { $first: "$name" },
                image: { $first: "$image" },
                cover_image: { $first: "$cover_image" },
                address: { $first: "$address" },
                delivery_time: { $first: "$delivery_time" },
                delivery_charge: { $first: "$delivery_charge" },
                is_favourite: { $first: "$is_favourite" },
                coupons: { $first: "$coupons" },
                rating: { $first: "$rating" },
                price_range: { $first: "$price_range" },
                is_take_pre_order: { $first: "$is_take_pre_order" },
                cuisines: { $first: "$cuisines" },
              },
            },

            {
              $lookup: {
                from: "favourite_restaurants",
                localField: "_id",
                foreignField: "branch_id",
                pipeline: [{ $match: { customer_id: user_id, is_delivery: true } }],
                as: "is_favourite",
              },
            },
            {
              $lookup: {
                from: "cuisines",
                localField: "cuisines.cuisine_id",
                pipeline: [
                  {
                    $match: {
                      is_active: true,
                      is_delivery: true,
                    },
                  },
                  {
                    $project: {
                      status: 0,
                      image: 0,
                    },
                  },
                ],
                foreignField: "_id",
                as: "cuisines",
              },
            },

            {
              $lookup: {
                from: "branch_coupons",
                localField: "_id",
                foreignField: "branch_id",
                pipeline: [
                  {
                    $lookup: {
                      from: "coupons",
                      localField: "coupon_id",
                      foreignField: "_id",
                      pipeline: [
                        {
                          $match: {
                            is_active: true,
                            start_time: {
                              $lte: new Date(),
                            },
                            end_time: {
                              $gte: new Date(),
                            },
                          },
                        },
                        {
                          $sort: {
                            created_at: -1,
                          },
                        },

                        {
                          $project: {
                            _id: 1,
                            name: 1,
                            description: 1,
                          },
                        },
                      ],
                      as: "branch_coupons",
                    },
                  },
                  {
                    $limit: 2,
                  },
                  { $unwind: "$branch_coupons" },
                  {
                    $project: {
                      branch_coupons: 1,
                    },
                  },
                ],
                as: "coupons",
              },
            },
            {
              $lookup: {
                from: "reviews",
                localField: "_id",
                foreignField: "rest_id",
                pipeline: [
                  {
                    $group: {
                      _id: "$rest_id",
                      avg: { $avg: "$rating" },
                      no_review: { $sum: 1 },
                    },
                  },
                  {
                    $project: {
                      _id: 0,
                      avg: { $round: ["$avg", 1] },
                      no_review: 1,
                    },
                  },
                ],
                as: "rating",
              },
            },
            { $sort: { _id: -1 } },
            {
              $project: {
                ...res_basic_data,
                coupons: "$coupons.branch_coupons",
                is_open: 1,
              },
            },
          ],
          as: "your_restaurants",
        },
      },
      {
        $group: {
          _id: "$branch_id",
          firstDoc: { $first: "$$ROOT" },
        },
      },
      {
        $replaceRoot: { newRoot: "$firstDoc" },
      },
      { $project: { _id: 0, restaurants: { $arrayElemAt: ["$your_restaurants", 0] } } },

      { $unwind: "$restaurants" },
      { $replaceRoot: { newRoot: "$restaurants" } },
    ])
      .skip(limit * (page - 1))
      .limit(limit);
    return data;
  } catch (err) {
    console.error(err);
    return false;
  }
};

DataSchema.statics.getRestNewOrder = async function (rest_id, lim, page = 1) {
  let limit = lim > 0 ? lim : 0;
  const skip = limit * (page - 1);

  try {
    const data = await this.aggregate([
      {
        $match: {
          branch_id: rest_id,
          is_verified: true,
          order_status: "placed",
        },
      },
      {
        $sort: { created_at: -1 },
      },
      {
        $project: {
          _id: 0,
          id: "$_id",
          order_id: "$_id",
          numberOfItems: { $size: "$order_details" },
          time: "$delivery_time",
        },
      },

      { $skip: skip },
      ...(limit > 0 ? [{ $limit: limit }] : []),
    ]);

    // console.log('DATA',data)

    return data;
  } catch (err) {
    console.log("err :", err);
    return false;
  }
};

DataSchema.statics.getRestAcceptedOrder = async function (rest_id, lim, page = 1) {
  let limit = lim > 0 ? lim : 0;
  const skip = limit * (page - 1);

  try {
    const data = await this.aggregate([
      {
        $match: {
          branch_id: rest_id,
          order_status: { $in: ["accepted", "assigned"] },
        },
      },
      {
        $sort: { created_at: -1 },
      },
      {
        $project: {
          _id: 0,
          id: "$_id",
          order_id: "$_id",
          order_number: "$_id",
          price: "$total_amount",
          rider_time: {
            $cond: [
              {
                $and: [
                  { $eq: ["$order_status", "assigned"] },
                  { $eq: ["$rider_accepted", true] },
                ],
              },
              "$arrival_time",
              null,
            ],
          },
          rider_name: {
            $cond: [
              {
                $and: [
                  { $eq: ["$order_status", "assigned"] },
                  { $eq: ["$rider_accepted", true] },
                ],
              },
              "$rider_first_name",
              null,
            ],
          },
          rider_status: {
            $cond: [
              {
                $and: [
                  { $eq: ["$order_status", "assigned"] },
                  { $eq: ["$rider_accepted", true] },
                ],
              },
              "On the way",
              null,
            ],
          },
        },
      },

      { $skip: skip },
      ...(limit > 0 ? [{ $limit: limit }] : []),
    ]);

    // console.log('DATA',data)

    return data;
  } catch (err) {
    console.log("err :", err);
    return false;
  }
};

DataSchema.statics.getRestRecentOrder = async function (rest_id) {
  try {
    const data = await this.aggregate([
      {
        $match: {
          branch_id: rest_id,
          order_status: { $in: ["ongoing", "cancel", "delivered"] },
        },
      },
      {
        $addFields: {
          order_status_sort: {
            $cond: {
              if: { $eq: ["$order_status", "ongoing"] },
              then: 0,
              else: 1,
            },
          },
        },
      },
      {
        $sort: { order_status_sort: 1 },
      },
      {
        $facet: {
          todayOrder: [
            {
              $match: {
                $expr: {
                  $and: [
                    {
                      $gte: [
                        "$created_at",
                        moment()
                          .startOf("day")
                          .add(SYSTEM_TIMEZONE.HOURS, "hours")
                          .toDate(),
                      ],
                    },
                    {
                      $lte: [
                        "$created_at",
                        moment()
                          .endOf("day")
                          .add(SYSTEM_TIMEZONE.HOURS, "hours")
                          .toDate(),
                      ],
                    },
                  ],
                },
              },
            },
            {
              $lookup: {
                from: "restaurant_reviews",
                localField: "order_id",
                foreignField: "order_id",
                pipeline: [{ $match: { rest_id: rest_id } }],
                as: "is_rated",
              },
            },
            {
              $project: {
                _id: 0,
                id: "$_id",
                order_id: "$_id",
                order_number: "$_id",
                customer_name: { $ifNull: ["$customer_name", "Unknown Name"] },
                status: "$order_status",
                is_rated: {
                  $cond: {
                    if: { $gt: [{ $size: "$is_rated" }, 0] },
                    then: 1,
                    else: 0,
                  },
                },
                time: {
                  $dateToString: {
                    format: "%H:%M",
                    date: "$created_at",
                  },
                },
              },
            },
          ],
          yesterDayOrder: [
            {
              $match: {
                $expr: {
                  $and: [
                    {
                      $gte: [
                        "$created_at",
                        moment()
                          .startOf("day")
                          .subtract(1, "day")
                          .add(SYSTEM_TIMEZONE.HOURS, "hours")
                          .toDate(),
                      ],
                    },
                    {
                      $lte: [
                        "$created_at",
                        moment()
                          .endOf("day")
                          .subtract(1, "day")
                          .add(SYSTEM_TIMEZONE.HOURS, "hours")
                          .toDate(),
                      ],
                    },
                  ],
                },
              },
            },
            {
              $lookup: {
                from: "restaurant_reviews",
                localField: "_id",
                foreignField: "order_id",
                pipeline: [{ $match: { rest_id: rest_id } }],
                as: "is_rated",
              },
            },
            {
              $project: {
                _id: 0,
                id: "$_id",
                order_id: "$_id",
                order_number: "$_id",
                customer_name: { $ifNull: ["$customer_name", "Unknown Name"] },
                status: "$order_status",
                is_rated: {
                  $cond: {
                    if: { $gt: [{ $size: "$is_rated" }, 0] },
                    then: 1,
                    else: 0,
                  },
                },
                time: {
                  $dateToString: {
                    format: "%H:%M",
                    date: "$created_at",
                  },
                },
              },
            },
          ],
        },
      },
    ]);

    const shift_data = data.shift();
    const todayOrder = shift_data.todayOrder;
    const yesterDayOrder = shift_data.yesterDayOrder;

    const countByStatus = (orders, status) =>
      orders.reduce((count, order) => (order.status === status ? count + 1 : count), 0);

    const countToday = {
      cancelCount: countByStatus(todayOrder, "cancel"),
      completedCount: countByStatus(todayOrder, "delivered"),
      ongoingCount: countByStatus(todayOrder, "ongoing"),
    };

    const countYesterday = {
      cancelCount: countByStatus(yesterDayOrder, "cancel"),
      completedCount: countByStatus(yesterDayOrder, "delivered"),
      ongoingCount: countByStatus(yesterDayOrder, "ongoing"),
    };

    const returnData = {
      todayOrder: {
        ongoingCount: countToday.ongoingCount,
        completedCount: countToday.completedCount,
        cancelCount: countToday.cancelCount,
        data: todayOrder.length > 0 ? todayOrder : null,
      },
      yesterDayOrder: {
        ongoingCount: countYesterday.ongoingCount,
        completedCount: countYesterday.completedCount,
        cancelCount: countYesterday.cancelCount,
        data: yesterDayOrder.length > 0 ? yesterDayOrder : null,
      },
    };

    return returnData;
  } catch (err) {
    console.log("err :", err);
    return false;
  }
};

DataSchema.statics.getRestPerformance = async function (rest_id, last_days = 7) {
  try {
    const fromDate = moment().subtract(last_days, "days").startOf("day");

    const data = await this.aggregate([
      {
        $match: {
          branch_id: rest_id,
          created_at: {
            $gte: fromDate.toDate(),
          },
        },
      },
      {
        $facet: {
          totalOrder: [
            {
              $group: {
                _id: null,
                count: { $sum: 1 },
              },
            },
            {
              $project: {
                _id: 0,
                count: 1,
              },
            },
          ],
          totalAcceptance: [
            {
              $match: {
                order_status: "accepted",
              },
            },
            {
              $group: {
                _id: null,
                count: { $sum: 1 },
              },
            },
            {
              $project: {
                _id: 0,
                count: 1,
              },
            },
          ],
          totalCancel: [
            {
              $match: {
                order_status: "cancel",
              },
            },
            {
              $group: {
                _id: null,
                count: { $sum: 1 },
              },
            },
            {
              $project: {
                _id: 0,
                count: 1,
              },
            },
          ],
        },
      },
      {
        $project: {
          totalOrder: { $arrayElemAt: ["$totalOrder.count", 0] },
          totalAcceptance: { $arrayElemAt: ["$totalAcceptance.count", 0] },
          totalCancel: { $arrayElemAt: ["$totalCancel.count", 0] },
        },
      },
    ]);

    const result = {
      totalOrder: data[0].totalOrder || 0,
      // totalAcceptance: data[0].totalAcceptance || 0,
      // totalCancel: data[0].totalCancel || 0,
      totalAcceptance:
        (((data[0].totalAcceptance || 0) / (data[0].totalOrder || 1)) * 100).toFixed(2) +
        "%",
      totalCancel:
        (((data[0].totalCancel || 0) / (data[0].totalOrder || 1)) * 100).toFixed(2) + "%",
    };

    return result;
  } catch (err) {
    console.log("err :", err);
    return false;
  }
};

DataSchema.statics.getOrderList = async function (
  check_id,
  order_id,
  order_type,
  order_status,
  order_date,
  order_total,
  payment_method,
  branch_name,
  branch_mobile,
  customer_name,
  zone_name,
  rider_name,
  rider_number,
  is_active,
  is_handover,
  is_ascending,
  lim,
  page = 1
) {
  try {
    let limit = lim > 0 ? lim : 0;
    const skip = limit * (page - 1);
    const data = await this.aggregate([
      {
        $match: {
          ...(order_id ? { _id: { $regex: order_id, $options: "i" } } : {}),
          ...(order_type ? { order_type: order_type } : {}),
          ...(order_status ? { order_status: order_status } : {}),
          ...(order_total ? { order_total: order_total } : {}),
          ...(payment_method ? { payment_method: payment_method } : {}),
          ...(rider_name
            ? { rider_first_name: { $regex: rider_name, $options: "i" } }
            : {}),
          ...(customer_name
            ? { customer_name: { $regex: customer_name, $options: "i" } }
            : {}),
          ...(rider_number
            ? { rider_mobile: { $regex: rider_number, $options: "i" } }
            : {}),
          ...(is_active ? { is_active: is_active } : {}),
          ...(is_handover ? { is_handover: is_handover } : {}),
          ...(order_date
            ? {
                $expr: {
                  $and: [
                    {
                      $gte: [
                        "$created_at",
                        moment(order_date)
                          .startOf("day")
                          .add(SYSTEM_TIMEZONE.HOURS, "hours")
                          .toDate(),
                      ],
                    },
                    {
                      $lte: [
                        "$created_at",
                        moment(order_date)
                          .endOf("day")
                          .add(SYSTEM_TIMEZONE.HOURS, "hours")
                          .toDate(),
                      ],
                    },
                  ],
                },
              }
            : {}),
        },
      },
      {
        $facet: {
          orderData: [
            {
              $addFields: {
                order_status_sort: {
                  $cond: {
                    if: { $eq: ["$order_status", "placed"] },
                    then: 0,
                    else: 1,
                  },
                },
              },
            },
            {
              $lookup: {
                from: "restaurents",
                localField: "branch_id",
                foreignField: "_id",
                as: "branch",
                pipeline: [
                  {
                    $match: {
                      $or: [{ central_admin: check_id }, { branch_admin: check_id }],
                      ...(branch_name
                        ? { name: { $regex: branch_name, $options: "i" } }
                        : {}),
                      ...(branch_mobile
                        ? { phone_number: { $regex: branch_mobile, $options: "i" } }
                        : {}),
                    },
                  },

                  {
                    $project: {
                      _id: 1,
                      name: 1,
                      phone_number: 1,
                      address: 1,
                      parent_restaurant_id: 1,
                      branch_admin: 1,
                      central_admin: 1,
                    },
                  },
                ],
              },
            },
            {
              $lookup: {
                from: "zones",
                localField: "zone_id",
                foreignField: "_id",
                as: "zone",
                pipeline: [
                  {
                    $match: {
                      ...(zone_name
                        ? { name: { $regex: zone_name, $options: "i" } }
                        : {}),
                    },
                  },
                  {
                    $project: {
                      _id: 1,
                      name: 1,
                    },
                  },
                ],
              },
            },
            {
              $match: {
                $or: [
                  { "branch.central_admin": check_id },
                  { "branch.branch_admin": check_id },
                ],
              },
            },
            {
              $sort: {
                order_status_sort: 1,
                created_at: is_ascending === true ? 1 : -1,
              },
            },

            {
              $project: {
                _id: 1,
                order_type: 1,
                order_date: "$created_at",
                order_total: "$total_amount",
                branch_id: { $arrayElemAt: ["$branch._id", 0] },
                branch_name: { $arrayElemAt: ["$branch.name", 0] },
                branch_mobile_number: { $arrayElemAt: ["$branch.phone_number", 0] },
                branch_address: { $arrayElemAt: ["$branch.address", 0] },
                zone_name: { $arrayElemAt: ["$zone.name", 0] },
                zone_id: 1,
                rider_id: { $ifNull: ["$rider_id", null] },
                rider_name: { $ifNull: ["$rider_first_name", null] },
                rider_number: { $ifNull: ["$rider_mobile", null] },
                customer_name: { $ifNull: ["$customer_name", null] },
                is_handover: 1,
                is_active: 1,
                payment_method: 1,
                order_status: 1,
              },
            },
            { $skip: skip },
            ...(limit > 0 ? [{ $limit: limit }] : []),
          ],
          totalCount: [
            {
              $lookup: {
                from: "restaurents",
                localField: "branch_id",
                foreignField: "_id",
                as: "branch",
                pipeline: [
                  {
                    $match: {
                      $or: [{ central_admin: check_id }, { branch_admin: check_id }],
                      ...(branch_name
                        ? { name: { $regex: branch_name, $options: "i" } }
                        : {}),
                    },
                  },
                  {
                    $project: {
                      _id: 1,
                      parent_restaurant_id: 1,
                      branch_admin: 1,
                      central_admin: 1,
                    },
                  },
                ],
              },
            },
            {
              $match: {
                $or: [
                  { "branch.central_admin": check_id },
                  { "branch.branch_admin": check_id },
                ],
              },
            },
            { $count: "total" },
          ],
        },
      },
      {
        $project: {
          totalCount: { $arrayElemAt: ["$totalCount.total", 0] },
          orderData: 1,
        },
      },
    ]);

    return data.shift();
  } catch (err) {
    console.log("err :", err);
    return false;
  }
};

DataSchema.statics.getRestOrderDetails = async function (order_id, lim, page = 1) {
  let limit = lim > 0 ? lim : 0;
  const skip = limit * (page - 1);

  try {
    const data = await this.aggregate([
      {
        $match: {
          _id: order_id,
          //order_status: { $in: ["accepted", "placed"] },
        },
      },
      {
        $lookup: {
          from: "restaurents",
          localField: "branch_id",
          foreignField: "_id",
          pipeline: [
            {
              $project: {
                commission: 1,
                name: 1,
                address: 1,
              },
            },
          ],
          as: "restaurants",
        },
      },
      {
        $addFields: {
          restaurants: { $arrayElemAt: ["$restaurants", 0] },
        },
      },
      {
        $project: {
          _id: 0,
          id: "$_id",
          order_id: "$_id",
          coupon_id: { $ifNull: ["$coupon_id", null] },
          customer_id: "$customer_id",
          order_number: "$_id",
          price: "$total_amount",
          delivery_charge: "$delivery_charge",
          order_status: "$order_status",
          items: "$order_details",
          time: "$delivery_time",
          sub_total: "$sub_total",
          total_amount: "$total_amount",
          total_vat: "$value_added_tax_inclusive",
          discount_amount: "$discount_amount",
          discount_in_percent: "$discount_in_percent",
          total_sd: "$supplementary_duty",
          payment_to_vendor: "$payment_to_vendor",
          rider_time: {
            $cond: [
              {
                $and: [
                  { $eq: ["$order_status", "assigned"] },
                  { $eq: ["$rider_accepted", true] },
                ],
              },
              "$arrival_time",
              null,
            ],
          },
          rider_name: {
            $cond: [
              {
                $and: [
                  { $eq: ["$order_status", "assigned"] },
                  { $eq: ["$rider_accepted", true] },
                ],
              },
              "$rider_first_name",
              null,
            ],
          },
          rider_status: {
            $cond: [
              {
                $and: [
                  { $eq: ["$order_status", "assigned"] },
                  { $eq: ["$rider_accepted", true] },
                ],
              },
              "On the way",
              null,
            ],
          },
          commission: "$restaurants.commission",
          name: "$restaurants.name",
          address: "$restaurants.address",
          phone_number: "$restaurants.phone_number",
        },
      },

      { $skip: skip },
      ...(limit > 0 ? [{ $limit: limit }] : []),
    ]);

    // console.log('DATA',data)

    return data.shift();
  } catch (err) {
    console.log("err :", err);
    return false;
  }
};

const Orders = mongoose.model("order_masters", DataSchema);
export default Orders;
