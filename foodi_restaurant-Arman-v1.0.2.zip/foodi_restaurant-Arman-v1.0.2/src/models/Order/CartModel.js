import mongoose from "mongoose";
import { v4 as uuidv4 } from "uuid";
import moment from "moment";
import { SYSTEM_TIMEZONE } from "../../consts/defaults.js";
const date = new Date();
const DataSchema = new mongoose.Schema(
  {
    _id: {
      type: String,
      default: () => uuidv4(),
    },
    customer_id: { type: String },
    branch_id: { type: String },
    coupon_id: { type: String, default: null },
    user_lat: { type: Number, default: 0 },
    user_long: { type: Number, default: 0 },
    delivery_charge: { type: Number, default: 0 },
    bkash_token: { type: String, default: null },
    bkash_payment_id: { type: String, default: null },
    cart_details: [],
    total_amount: { type: Number, default: 0 },
    cart_type: {
      type: String,
      default: "delivery",
      enum: ["delivery", "pickup", "dine_in"],
    },
    is_active: { type: Boolean, default: true },
    created_at: {
      type: Date,
      default: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
    },
    created_by: { type: String, default: null },
    updated_at: {
      type: Date,
      default: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
    },
    updated_by: { type: String, default: null },
  },
  {
    collection: "cart_items",
    //  timestamps: true,
    versionKey: false,
  }
);

const CartModel = mongoose.model("cart_items", DataSchema);
export default CartModel;
