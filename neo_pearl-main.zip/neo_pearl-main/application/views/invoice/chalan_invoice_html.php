<?php
$CI = & get_instance();
$CI->load->model('Web_settings');
$Web_settings = $CI->Web_settings->retrieve_setting_editdata();
?>
<!--its for pos style css start-->


<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="header-icon">
            <i class="pe-7s-note2"></i>
        </div>
        <div class="header-title">
            <h1><?php echo display('invoice_details') ?></h1>
            <small><?php echo display('invoice_details') ?></small>
            <ol class="breadcrumb">
                <li><a href="#"><i class="pe-7s-home"></i> <?php echo display('home') ?></a></li>
                <li><a href="#"><?php echo display('invoice') ?></a></li>
                <li class="active"><?php echo display('invoice_details') ?></li>
            </ol>
        </div>
    </section>
    <!-- Main content -->
    <section class="content">
        <!-- Alert Message -->
        <?php
        $message = $this->session->userdata('message');
        if (isset($message)) {
            ?>
            <div class="alert alert-info alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <?php echo $message ?>
            </div>
            <?php
            $this->session->unset_userdata('message');
        }
        $error_message = $this->session->userdata('error_message');
        if (isset($error_message)) {
            ?>
            <div class="alert alert-danger alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <?php echo $error_message ?>
            </div>
            <?php
            $this->session->unset_userdata('error_message');
        }
        ?>
        <div class="row">
            <div class="col-sm-12">
                <div class="panel panel-bd">
                    <div id="printableArea">
                        <div class="panel-body">
                            <div class="row print_header">

                                <div class="col-sm-8 company-content">
                                    {company_info}
                                    <img src="<?php
                                    if (isset($Web_settings[0]['invoice_logo'])) {
                                        echo $Web_settings[0]['invoice_logo'];
                                    }
                                    ?>" class="img-bottom-m" alt="" >
                                    <br>
                                    <span class="label label-success-outline m-r-15 p-10" ><?php echo display('billing_from') ?></span>
                                    <address class="margin-top10">
                                        <strong class="company_name_p">{company_name}</strong><br>
                                        {address}<br>
                                        <abbr><b><?php echo display('mobile') ?>:</b></abbr> {mobile}<br>
                                        <abbr><b><?php echo display('email') ?>:</b></abbr>
                                        {email}<br>
                                        <abbr><b><?php echo display('website') ?>:</b></abbr>
                                        {website}<br>
                                        {/company_info}
                                        <abbr>{tax_regno}</abbr>
                                    </address>



                                </div>


                                <div class="col-sm-4 text-left invoice-address">
                                    <h2 class="m-t-0">Chalan</h2>
                                    <div>Chalan No: {invoice_no}</div>
                                    <div class="m-b-15"><?php echo display('billing_date') ?>: {final_date}</div>

                                    <span class="label label-success-outline m-r-15"><?php echo display('billing_to') ?></span>

                                    <address class="customer_name_p">
                                        <strong  class="c_name" >{customer_name} </strong><br>
                                        <?php if ($customer_address) { ?>
                                            {customer_address}
                                        <?php } ?>
                                        <br>
                                        <abbr><b><?php echo display('mobile') ?>:</b></abbr>
                                        <?php if ($customer_mobile) { ?>
                                            {customer_mobile}
                                        <?php }if ($customer_email) {
                                            ?>
                                            <br>
                                            <abbr><b><?php echo display('email') ?>:</b></abbr>
                                            {customer_email}
                                        <?php } ?>
                                    </address>
                                </div>
                            </div>




                            <table width="100%" class="table-striped">
                                <thead>
                                <tr class="pthead" >
                                    <td><?php echo display('sl'); ?></td>
                                    <td><?php echo display('product_name'); ?></td>
                                    <th  align="center"><?php if($is_unit !=0){ echo display('unit');
                                        }?></th>
                                    <td><?php  if($is_desc !=0){ echo display('item_description');} ?></td>
                                    <td><?php if($is_serial !=0){ echo display('serial_no');} ?></td>
                                    <td align="right"><?php echo display('quantity'); ?></td>

                                </tr>
                                </thead>
                                <tbody>
                                <?php
                                $sl =1;
                                $s_total = 0;
                                foreach($invoice_all_data as $invoice_data){?>
                                    <tr>
                                        <td colspan="9" class="minpos-bordertop"><nobr></nobr></td>
                                    </tr>
                                    <tr>
                                        <td align="left"><nobr><?php echo $sl;?></nobr></td>
                                        <td align="left"><nobr><?php echo html_escape($invoice_data['product_name']).'('.html_escape($invoice_data['product_model']).')';?></nobr></td>
                                        <td align="left"><nobr><?php echo html_escape($invoice_data['unit']);?></nobr></td>
                                        <td align="left"><nobr><?php echo html_escape($invoice_data['description']);?></nobr></td>
                                        <td align="left"><nobr><?php echo html_escape($invoice_data['serial_no']);?></nobr></td>
                                        <td align="right"><nobr><?php echo html_escape($invoice_data['quantity']);?></nobr></td>



                                    </tr>
                                    <?php $sl++; }?>
                                </tbody>
                                <tfoot>
                                <tr>
                                    <td colspan="10" class="minpos-bordertop"><nobr></nobr></td>
                                </tr>
                                <tr>
                                    <td colspan="10" class="minpos-bordertop"><nobr></nobr></td>
                                </tr>
                                <tr>
                                    <td align="left"><nobr></nobr></td>

                                </tr>






                                </tfoot>
                            </table>
                            <table class="table">
                                <tr>
                                    <td class="text-left" colspan="5"><b>Total Quantity:</b></td>
                                    <td align="right" ><b>{subTotal_quantity}</b></td>

                                </tr>

                                <tr>
                                    <td>{invoice_details}</td><td></td><td></td><td></td>
                                </tr>
                                <tr>

                                    <td> <b><?php echo display('sold_by')?> </b>: {users_name}<br>{company_info}
                                        Website: <a href="{website}">{website}</a>
                                        {/company_info}
                                    </td>
                                    <td class="text-right" colspan="2"> <div class="sig_div">
                                            <?php echo display('signature') ?>

                                        </div></td>

                                </tr>

                            </table>
                        </div>


                    </div>
                </div>
                <div class="panel-footer text-left">
                    <a  class="btn btn-danger" href="<?php echo base_url('Cinvoice'); ?>"><?php echo display('cancel') ?></a>
                    <a  class="btn btn-info" href="#" onclick="printDiv('printableArea')"><span class="fa fa-print"></span></a>

                </div>

            </div>
        </div> <!-- /.content-wrapper -->
</div>
</section>
</div>