<style type="text/css">
    .column1 {
        float: left;
        width: 50%;
    }
</style>
<!-- Product Report Start -->
<div class="content-wrapper">
    <section class="content-header">
        <div class="header-icon">
            <i class="pe-7s-note2"></i>
        </div>
        <div class="header-title">
            <h1>Purchase Cheque</h1>
            <small>Purchase Cheque Report</small>
            <ol class="breadcrumb">
                <li><a href="<?php echo base_url()?>"><i class="pe-7s-home"></i> <?php echo display('home') ?></a></li>
                <li><a href="#"><?php echo display('report') ?></a></li>
                <li class="active">Purchase Cheque Report</li>
            </ol>
        </div>
    </section>

    <section class="content">

        <div class="row">
            <div class="col-sm-12">


                <?php if($this->permission1->method('todays_sales_report','read')->access()){ ?>
                    <a href="<?php echo base_url('Admin_dashboard/todays_sales_report') ?>" class="btn btn-info m-b-5 m-r-2"><i class="ti-align-justify"> </i> <?php echo display('sales_report') ?> </a>
                <?php }?>
                <?php if($this->permission1->method('todays_purchase_report','read')->access()){ ?>
                    <a href="<?php echo base_url('Admin_dashboard/todays_purchase_report') ?>" class="btn btn-success m-b-5 m-r-2"><i class="ti-align-justify"> </i>  <?php echo display('purchase_report') ?> </a>
                <?php }?>
                <?php if($this->permission1->method('product_sales_reports_date_wise','read')->access()){ ?>
                    <a href="<?php echo base_url('Admin_dashboard/product_sales_reports_date_wise') ?>" class="btn btn-primary m-b-5 m-r-2"><i class="ti-align-justify"> </i>  <?php echo display('sales_report_product_wise') ?> </a>
                <?php }?>
                <?php if($this->permission1->method('todays_sales_report','read')->access() && $this->permission1->method('todays_purchase_report','read')->access()){ ?>
                    <a href="<?php echo base_url('Admin_dashboard/total_profit_report') ?>" class="btn btn-warning m-b-5 m-r-2"><i class="ti-align-justify"> </i>  <?php echo display('profit_report') ?> </a>
                <?php }?>



            </div>
        </div>

        <!-- Product report -->
        <div class="row">
            <div class="col-sm-12">
                <div class="panel panel-default">
                    <div class="panel-body">
                        <?php echo form_open('Admin_dashboard/product_sales_search_reports_cheque', array('class' => 'form-inline', 'method' => 'get')) ?>
                        <?php
                        $today = date('Y-m-d'); ?>

                        <div class="form-group">
                            <label class="" for="from_date"><?php echo display('start_date') ?></label>
                            <input type="text" name="from_date" class="form-control datepicker" id="from_date" value="<?php echo (!empty($from_date)?$from_date:$today)?>" placeholder="<?php echo display('start_date') ?>" >
                        </div>

                        <div class="form-group">
                            <label class="" for="to_date">Cheque End Date</label>
                            <input type="text" name="to_date" class="form-control datepicker" id="to_date" placeholder="<?php echo display('end_date') ?>" value="<?php echo (!empty($to_date)?$to_date:$today)?>">
                        </div>

                        <button type="submit" class="btn btn-success"><?php echo display('search') ?></button>
                        <a  class="btn btn-warning" href="#" onclick="printDiv('purchase_div')"><?php echo display('print') ?></a>

                        <a href="<?php echo base_url('accounts/credit_voucher') ?>" class="btn btn-info" style="margin-left: 150px"><i class="glyphicon glyphicon-share"> </i> <b>Credit Voucher</b> </a>


                        <?php echo form_close() ?>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade modal-success updateModal" id="updateProjectModal" role="dialog">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">

                        <a href="#" class="close" data-dismiss="modal">&times;</a>
                        <h3 class="modal-title">Manage Cheque</h3>
                    </div>

                    <div class="modal-body">
                        <div id="customeMessage" class="alert hide"></div>
                        <form method="post" id="ProjectEditForm" action="<?php echo base_url()?>Admin_dashboard/cheque_date_editted">
                            <div class="panel-body">
                                <input type ="hidden" name="csrf_test_name" id="" value="<?php echo $this->security->get_csrf_hash();?>">
                                <div class="form-group row">
                                    <input type="hidden" id="invoice_id" value="{invoice_id}" name="invoice_id">
                                    <input type="hidden" id="customer_id" value="{customer_id}" name="customer_id">
<!--                                    <input type="text" id="due_amount" value="{due_amount}" name="due_amount">-->
                                   <input type="hidden" id="paid_amount" value="{paid_amount}" name="paid_amount">
                                    <input type="hidden" id="invoice" value="{invoice}" name="invoice">
                                    <div class="column1">
                                        <label for="cheque_date" class="col-sm-3 col-form-label">Cheque Date</label>

                                        <input style="width: auto;" type="text" id="cheque_date" class="form-control datepicker" name="cheque_date" value="{cheque_date}"  />
                                    </div>
                                    <div class="column1">
                                        <label for="cheque_no" class="col-md-3 col-form-label">Cheque No.</label>

                                        <input style="width: auto;" type="text" id="cheque_no" class="form-control" name="cheque_no" value="{cheque_no}"  />
                                    </div>
                                    <div class="column1">
                                        <label for="due_amount" class="col-md-3 col-form-label">Due Amount</label>

                                        <input style="width: auto;" type="text" id="due_amount" class="form-control" name="due_amount" value="{due_amount}"  />
                                    </div>
                                    <div class="column1">
                                        <label for="credit_amount" class="col-md-3 col-form-label">Credit Amount</label>

                                        <input style="width: auto;" type="text" id="credit_amount" class="form-control" name="credit_amount" value=""  />
                                    </div>
                                    <!--       <div class="column1">
                                          <label for="customer_name" class="col-md-3 col-form-label">Customer Name</label>

                                              <input style="width: auto;" type="text" id="customer_name" class="form-control" name="customer_id" value="{customer_id}"  />
                                          </div> -->

                                </div>

                                <div class="form-group row">
                                    <label for="email" class="col-md-3 col-form-label">Change Status:</label>
                                    <div class="col-sm-6">
                                        <input style="" type="checkbox" name="status" class="status" checked />
                                        <input type="hidden" name="hidden_status" id="hidden_status" value="{status}" />
                                    </div>
                                </div>


                            </div>

                    </div>
                    <div class="modal-footer">
                        <a href="#" class="btn btn-danger" data-dismiss="modal">Close</a>
                        <button type="submit" id="ProjectUpdateConfirmBtn"  class="btn btn-success">Update</button>
                    </div>
                    <!--                    <div class="modal-footer">-->
                    <!---->
                    <!--                        <a href="#" class="btn btn-danger" data-dismiss="modal">Close</a>-->
                    <!---->
                    <!--                        <input type="submit" id="ProjectUpdateConfirmBtn" class="btn btn-success" value="Submit">-->
                    <!--                    </div>-->
                    <?php echo form_close() ?>
                </div><!-- /.modal-content -->
            </div><!-- /.modal-dialog -->
        </div>

        <div class="row">
            <div class="col-sm-12">
                <div class="panel panel-bd lobidrag">
                    <div class="panel-heading">
                        <div class="panel-title">
                            <h4>Sales Cheque Report</h4>
                        </div>
                    </div>
                    <div class="panel-body">
                        <div id="purchase_div" class="table-responsive">
                            <table class="print-table" width="100%">

                                <tr>
                                    <td align="left" class="print-table-tr">
                                        <img src="<?php echo $software_info[0]['logo'];?>" alt="logo">
                                    </td>
                                    <td align="center" class="print-cominfo">
                                                        <span class="company-txt">
                                                            <?php echo $company[0]['company_name'];?>

                                                        </span><br>
                                        <?php echo $company[0]['address'];?>
                                        <br>
                                        <?php echo $company[0]['email'];?>
                                        <br>
                                        <?php echo $company[0]['mobile'];?>

                                    </td>

                                    <td align="right" class="print-table-tr">
                                        <date>
                                            <?php echo display('date')?>: <?php
                                            echo date('d-M-Y');
                                            ?>
                                        </date>
                                    </td>
                                </tr>

                            </table>
                            <form id="editForm" method="post">
                                <div class="table-responsive">

                                    <table id="editable_table" class="table table-bordered table-striped table-hover">
                                        <thead>
                                        <tr>
                                            <th>Invoice ID</th>

                                            <th><?php echo display('customer_name') ?></th>
                                            <th>Bank Name</th>
                                            <th>Cheque No:</th>
                                            <th>Status</th>
                                            <th>Cheque End Date</th>
                                            <th>Action</th>
                                        </tr>
                                        </thead>
                                        <tbody>

                                        </tbody>
                                        <!--                                    <tfoot>-->
                                        <!--                                    <tr>-->
                                        <!--                                        <td colspan="4" align="right">&nbsp; <b>--><?php //echo display('total_ammount') ?><!--</b></td>-->
                                        <!--                                        <td class="text-right"><b>--><?php //echo (($position == 0) ? "$currency {sub_total}" : "{sub_total} $currency") ?><!--</b></td>-->
                                        <!--                                    </tr>-->
                                        <!--                                    </tfoot>-->
                                    </table>
                                </div>

                            </form>
                        </div>
                        <!--  <button type="button" onclick="get_cheque_report()">JS</button> -->
                        <div class="text-right"><?php echo $links ?></div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
<!-- Product Report End -->
<script>
    $(document).ready(function() {

        $('.status').bootstrapToggle({
            on: 'Due',
            off: 'Paid',
            onstyle: 'danger',
            offstyle: 'success'
        });

        $('.status').change(function(){
            if($(this).prop('checked'))
            {
                $('#hidden_status').val('2');
            }
            else
            {
                $('#hidden_status').val('1');
            }
        });

        var table= $('#editable_table').DataTable({
            "responsive" : true,
            "autoWidth"  : false,
            "processing" : true,
            "Paginate": true,
            "ajax": {
                url : "<?php echo base_url() ?>Admin_dashboard/get_items",
                type : 'GET'
            },
            "columns":[
                {"data":"invoice_id"},
                {"data":"customer_name"},
                {"data":"bank_id"},
                {"data":"cheque_no"},
                {"data":"status"},
                {"data":"cheque_date"},
                {"data":"action","searchable":false,"orderable":false}
            ],
        });

//     $.noConflict();
//         var table = $('#editable_table').dataTable(
//     {
//         "responsive" : true,
//         "autoWidth"  : false,
//         "processing" : true,"serverSide": true,
//         "ajax":
//             {
//                 "url":"<?php echo base_url() ?>Admin_dashboard/get_items",
//                 "dataType":"json",
//                 "type":"GET",
//             },
//         "columns":[
//         {"data":"invoice_id"},
//         {"data":"customer_name"},
//         {"data":"bank_id"},
//         {"data":"cheque_no"},
//         {"data":"status"},
//         {"data":"cheque_date"},
//         {"data":"action","searchable":false,"orderable":false}
//     ],

// });


        $('#editable_table').on('click', '.date-edit', function(){
            var invoice_id = $(this).attr('data');
            $('#updateProjectModal').modal('show');
            console.log(invoice_id);

            $.ajax({
                type: 'ajax',
                method: 'get',
                url: '<?php echo base_url() ?>Admin_dashboard/cheque_date_update',
                data: {invoice_id: invoice_id},
                async: false,
                dataType: 'json',
                success: function(data){
                    $('input[name=invoice_id]').val(data.invoice_id);
                    $('input[name=cheque_date').val(data.cheque_date);
                    $('input[name=cheque_no').val(data.cheque_no);
                     $('input[name=customer_id').val(data.customer_id);
                    // $('input[name=due_amount').val(data.due_amount);
                     $('input[name=paid_amount').val(data.paid_amount);
                    var due=data.due_amount;
                    var paid=data.paid_amount;
                    $('input[name=due_amount').val(due-paid)
                    $('input[name=invoice').val(data.invoice);
                    $('input[name=hidden_status').val(data.status);

                    console.log(due);
                },
                error: function(){
                    alert('Could not displaying data');
                }
            });
        });

        $("#ProjectEditForm").on('submit',function(event)
        {
            event.preventDefault();
            // var form= $("#ProjectEditForm");

            var hidden_status = $('#hidden_status').val();
            var cheque_date = $('#cheque_date').val();
            var invoice_id= $('#invoice_id').val();
            var customer_id= $('#customer_id').val();
            var cheque_no= $('#cheque_no').val();
            var due_amount= $('#due_amount').val();
            var paid_amount=$('#paid_amount').val();
            var credit_amount=$('#credit_amount').val();
            var invoice= $('#invoice').val();
            var csrf_test_name = $('[name="csrf_test_name"]').val();
            console.log(cheque_date);
            console.log(invoice_id);
            //$('#ProjectEditForm').modal('hide');
            $.ajax({
                method: 'POST',
                url: "<?php echo base_url()?>Admin_dashboard/cheque_date_editted",
                dataType:'json',
                async:false,
                data:{invoice_id:invoice_id,csrf_test_name:csrf_test_name,cheque_date:cheque_date,hidden_status:hidden_status,cheque_no:cheque_no,customer_id:customer_id,due_amount:due_amount,paid_amount:paid_amount,credit_amount:credit_amount,invoice:invoice},
                success:function(data)
                {

                    console.log(data);
                    table.ajax.reload( null, false);
                    $('[name="invoice_id"]').val("");
                    $('[name="cheque_date"]').val("");
                    $('[name="customer_id"]').val("");
                    $('[name="cheque_no"]').val("");
                    $('[name="credit_amount"]').val("");
                    $('[name="due_amount"]').val("");
                    $('[name="paid_amount"]').val("");
                    $('[name="invoice"]').val("");
                    $('[name="hidden_status"]').val("");

                    // $('[name="price_edit"]').val("");
                    $('.updateModal').modal('hide');
                    toastr[data.type](data.message);
                    //table.ajax.reload();
                },


            });

        });
    });




</script>