<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Products extends CI_Model {

    public function __construct() {
        parent::__construct();
    }

    //Count Product
    public function count_product() {
        return $this->db->count_all("product_information");
    }

    //Product List
    public function product_list($per_page, $page) {
        $query = $this->db->select('supplier_information.*,product_information.*,supplier_product.*')
                ->from('product_information')
                ->join('supplier_product', 'product_information.product_id = supplier_product.product_id', 'left')
                ->join('supplier_information', 'supplier_information.supplier_id = supplier_product.supplier_id', 'left')
                ->order_by('product_information.product_name', 'asc')
                ->limit($per_page, $page)
                ->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return false;
    }

    //All Product List
    public function all_product_list() {
        $query = $this->db->select('supplier_information.*,product_information.*,supplier_product.*')
                ->from('product_information')
                ->join('supplier_product', 'product_information.product_id = supplier_product.product_id', 'left')
                ->join('supplier_information', 'supplier_information.supplier_id = supplier_product.supplier_id', 'left')
                ->order_by('product_information.product_id', 'desc')
                ->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return false;
    }

    public function getProductList($postData=null){

         $response = array();

         ## Read value
         $draw = $postData['draw'];
         $start = $postData['start'];
         $rowperpage = $postData['length']; // Rows display per page
         $columnIndex = $postData['order'][0]['column']; // Column index
         $columnName = $postData['columns'][$columnIndex]['data']; // Column name
         $columnSortOrder = $postData['order'][0]['dir']; // asc or desc
         $searchValue = $postData['search']['value']; // Search value

         ## Search
         $searchQuery = "";
         if($searchValue != ''){
            $searchQuery = " (a.product_name like '%".$searchValue."%' or a.category_id like '%".$searchValue."%' or a.price like'%".$searchValue."%' or c.supplier_price like'%".$searchValue."%' or m.supplier_name like'%".$searchValue."%') ";
         }

         ## Total number of records without filtering
         $this->db->select('count(*) as allcount');
         $this->db->from('product_information a');
         $this->db->join('supplier_product c','c.product_id = a.product_id','left');
         $this->db->join('supplier_information m','m.supplier_id = c.supplier_id','left');
          if($searchValue != '')
         $this->db->where($searchQuery);
         $records = $this->db->get()->result();
         $totalRecords = $records[0]->allcount;

         ## Total number of record with filtering
         $this->db->select('count(*) as allcount');
         $this->db->from('product_information a');
         $this->db->join('supplier_product c','c.product_id = a.product_id','left');
         $this->db->join('supplier_information m','m.supplier_id = c.supplier_id','left');
         if($searchValue != '')
            $this->db->where($searchQuery);
         $records = $this->db->get()->result();
         $totalRecordwithFilter = $records[0]->allcount;

         ## Fetch records
         $this->db->select("a.*,
                a.product_name,
                a.product_id,
                a.ptype_id,
                a.image,
                c.supplier_price,
                c.supplier_id,
                m.supplier_name,
                d.category_name,

                ");
         $this->db->from('product_information a');
         $this->db->join('supplier_product c','c.product_id = a.product_id','left');
         $this->db->join('supplier_information m','m.supplier_id = c.supplier_id','left');
         $this->db->join('tiles_size d','d.category_id = a.size_id','left');
         if($searchValue != '')
         $this->db->where($searchQuery);
         $this->db->order_by($columnName, $columnSortOrder);
         $this->db->limit($rowperpage, $start);
         $records = $this->db->get()->result();
         $data = array();
         $sl =1;

         foreach($records as $record ){
          $button = '';
          $base_url = base_url();
          $jsaction = "return confirm('Are You Sure ?')";
            $image = '<img src="'.$record->image.'" class="img img-responsive" height="50" width="50">';
           if($this->permission1->method('manage_product','delete')->access()){

           $button .= '<a href="'.$base_url.'Cproduct/product_delete/'.$record->product_id.'" class="btn btn-xs btn-danger "  onclick="'.$jsaction.'"><i class="fa fa-trash"></i></a>';
         }

         $button .='  <a href="'.$base_url.'Cqrcode/qrgenerator/'.$record->product_id.'" class="btn btn-success btn-xs" data-toggle="tooltip" data-placement="left" title="'.display('qr_code').'"><i class="fa fa-qrcode" aria-hidden="true"></i></a>';

         $button .='  <a href="'.$base_url.'Cbarcode/barcode_print/'.$record->product_id.'" class="btn btn-warning btn-xs" data-toggle="tooltip" data-placement="left" title="'.display('barcode').'"><i class="fa fa-barcode" aria-hidden="true"></i></a>';
      if($this->permission1->method('manage_product','update')->access()){
         $button .=' <a href="'.$base_url.'Cproduct/product_update_form/'.$record->product_id.'" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="left" title="'. display('update').'"><i class="fa fa-pencil" aria-hidden="true"></i></a>';
     }

        if(($record->ptype_id) == 1){
            $type = 'Tiles';
        }else{
            $type = 'Sanitary';
        }

         $product_name = '<a href="'.$base_url.'Cproduct/product_details/'.$record->product_id.'">'.$record->product_name.'</a>';
         $supplier = '<a href="'.$base_url.'Csupplier/supplier_ledger_info/'.$record->supplier_id.'">'.$record->supplier_name.'</a>';

            $data[] = array(
                'sl'               =>$sl,
                'product_name'     =>$product_name,
                //'product_model'    =>$record->product_model,
                'category'    =>$record->category_name,
                'supplier_name'    =>$supplier,
                'price'            =>$record->price,
                'purchase_p'       =>$record->supplier_price,
                'image'            =>$image,
                'button'           =>$button,
                'type'             =>$type

            );
            $sl++;
         }

         ## Response
         $response = array(
            "draw" => intval($draw),
            "iTotalRecords" => $totalRecordwithFilter,
            "iTotalDisplayRecords" => $totalRecords,
            "aaData" => $data
         );

         return $response;
    }

    //Product List
    public function product_list_count() {
        $query = $this->db->select('supplier_information.*,product_information.*,supplier_product.*')
                ->from('product_information')
                ->join('supplier_product', 'product_information.product_id = supplier_product.product_id', 'left')
                ->join('supplier_information', 'supplier_information.supplier_id = supplier_product.supplier_id', 'left')
                ->order_by('product_information.product_name', 'asc')
                ->get();
        if ($query->num_rows() > 0) {
            return $query->num_rows();
        }
        return false;
    }

    //Product tax list
    public function retrieve_product_tax() {
        $result = $this->db->select('*')
                ->from('tax_information')
                ->get()
                ->result();

        return $result;
    }

    //Tax selected item
    public function tax_selected_item($tax_id) {
        $result = $this->db->select('*')
                ->from('tax_information')
                ->where('tax_id', $tax_id)
                ->get()
                ->result();

        return $result;
    }

    //Product generator id check
    public function product_id_check($product_id) {
        $query = $this->db->select('*')
                ->from('product_information')
                ->where('product_id', $product_id)
                ->get();
        if ($query->num_rows() > 0) {
            return true;
        } else {
            return false;
        }
    }

    //Count Product
    public function product_entry($data) {
            $this->db->insert('product_information', $data);
            $this->db->select('*');
            $this->db->from('product_information');
            $this->db->where('status', 1);
            $query = $this->db->get();
            foreach ($query->result() as $row) {
                $json_product[] = array('label' => $row->product_name . "-(" . $row->product_model . ")", 'value' => $row->product_id);
            }
            $cache_file = './my-assets/js/admin_js/json/product.json';
            $productList = json_encode($json_product);
            file_put_contents($cache_file, $productList);
            return TRUE;

    }

    //Retrieve Product Edit Data
    public function retrieve_product_editdata($product_id) {
        $this->db->select('*');
        $this->db->from('product_information');
        $this->db->where('product_id', $product_id);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return false;
    }

    // Supplier product information
    public function supplier_product_editdata($product_id) {
        $this->db->select('a.*,b.*');
        $this->db->from('supplier_product a');
        $this->db->join('supplier_information b', 'a.supplier_id=b.supplier_id');
        $this->db->where('a.product_id', $product_id);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return false;
    }

//selected supplier product
    public function supplier_selected($product_id) {
        $this->db->select('*');
        $this->db->from('supplier_product');
        $this->db->where('product_id', $product_id);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return false;
    }

    //Retrieve company Edit Data
    public function retrieve_company() {
        $this->db->select('*');
        $this->db->from('company_information');
        $this->db->limit('1');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return false;
    }

    //Update Categories
    public function update_product($data, $product_id) {
            $this->db->where('product_id', $product_id);
            $this->db->update('product_information', $data);
            $this->db->select('*');
            $this->db->from('product_information');
            $this->db->where('status', 1);
            $query = $this->db->get();
            foreach ($query->result() as $row) {
                $json_product[] = array('label' => $row->product_name . "-(" . $row->product_model . ")", 'value' => $row->product_id);
            }
            $cache_file = './my-assets/js/admin_js/json/product.json';
            $productList = json_encode($json_product);
            file_put_contents($cache_file, $productList);
            return true;

    }


    public function check_calculaton($product_id){
        $this->db->select('*');
        $this->db->from('product_purchase_details');
        $this->db->where('product_id', $product_id);
        $query = $this->db->get();
        return $query->num_rows();
    }

    // Delete Product Item
    public function delete_product($product_id) {


            $this->db->where('product_id', $product_id);
            $this->db->delete('product_information');
            $this->db->where('product_id', $product_id);
            $this->db->delete('supplier_product');
            return true;

    }

    //Product By Search
    public function product_search_item($product_id) {

        $query = $this->db->select('supplier_information.*,product_information.*,supplier_product.*')
                ->from('product_information')
                ->join('supplier_product', 'product_information.product_id = supplier_product.product_id', 'left')
                ->join('supplier_information', 'supplier_product.supplier_id = supplier_information.supplier_id', 'left')
                ->order_by('product_information.product_id', 'desc')
                ->where('product_information.product_id', $product_id)
                ->get();

        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return false;
    }

    //Duplicate Entry Checking
    public function product_model_search($product_model) {
        $this->db->select('*');
        $this->db->from('product_information');
        $this->db->where('product_model', $product_model);
        $query = $this->db->get();
        return $this->db->affected_rows();
    }

    //Product Details
    public function product_details_info($product_id) {
        $this->db->select('*');
        $this->db->from('product_information');
        $this->db->where('product_id', $product_id);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return false;
    }

    // Product Purchase Report
    public function product_purchase_info($product_id) {
        $this->db->select('a.*,b.*,sum(b.quantity) as quantity,sum(b.total_amount) as total_amount,c.supplier_name');
        $this->db->from('product_purchase a');
        $this->db->join('product_purchase_details b', 'b.purchase_id = a.purchase_id');
        $this->db->join('supplier_information c', 'c.supplier_id = a.supplier_id');
        $this->db->where('b.product_id', $product_id);
        $this->db->order_by('a.purchase_id', 'asc');
        $this->db->group_by('a.purchase_id');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return false;
    }

    // Invoice Data for specific data
    public function invoice_data($product_id) {
        $this->db->select('a.*,b.*,c.customer_name');
        $this->db->from('invoice a');
        $this->db->join('invoice_details b', 'b.invoice_id = a.invoice_id');
        $this->db->join('customer_information c', 'c.customer_id = a.customer_id');
        $this->db->where('b.product_id', $product_id);
        $this->db->order_by('a.invoice_id', 'asc');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return false;
    }

    public function previous_stock_data($product_id, $startdate) {

        $this->db->select('date,sum(quantity) as quantity');
        $this->db->from('product_report');
        $this->db->where('product_id', $product_id);
        $this->db->where('date <=', $startdate);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return false;
    }

    public function insert_product_tiles()
    {
        $CI = &get_instance();
        $CI->load->library('lproduct');
        $CI->load->library('lproduct');

        $product_id = (!empty($this->input->post('product_id', TRUE)) ? $this->input->post('product_id', TRUE) : date('YmdHis'));
        $check_product = $this->db->select('*')->from('product_information')->where('product_id', $product_id)->get()->num_rows();
        if ($check_product > 0) {
            $this->session->set_userdata(array('error_message' => display('already_exists')));
            redirect(base_url('Cproduct'));
        }
        $product_id_two = $this->input->post('$product_id_two', TRUE);
        $sup_price = $this->input->post('supplier_price', TRUE);
        $s_id = $this->input->post('supplier_id', TRUE);
        $product_model = $this->input->post('model', TRUE);
        for ($i = 0, $n = count($s_id); $i < $n; $i++) {
            $supplier_price = $sup_price[$i];
            $supp_id = $s_id[$i];

            $supp_prd = array(
                'product_id'     => $product_id,
                'product_id_two'     => $product_id_two,

                'supplier_id'    => $supp_id,
                'supplier_price' => $supplier_price,
                'products_model' => $product_model = $this->input->post('model', TRUE)
            );

            $this->db->insert('supplier_product', $supp_prd);
        }

        //Supplier check
        if ($this->input->post('supplier_id', TRUE) == null) {
            $this->session->set_userdata(array('error_message' => display('please_select_supplier')));
            redirect(base_url('Cproduct'));
        }

        if ($_FILES['image']['name']) {
            //Chapter chapter add start
            $config['upload_path']   = './my-assets/image/product/';
            $config['allowed_types'] = 'gif|jpg|png|jpeg|JPEG|GIF|JPG|PNG';
            $config['encrypt_name']  = TRUE;

            $this->load->library('upload', $config);
            if (!$this->upload->do_upload('image')) {
                $error = array('error' => $this->upload->display_errors());
                $this->session->set_userdata(array('error_message' => $this->upload->display_errors()));
                redirect(base_url('Cproduct'));
            } else {

                $imgdata = $this->upload->data();
                $image = $config['upload_path'] . $imgdata['file_name'];
                $config['image_library']  = 'gd2';
                $config['source_image']   = $image;
                $config['create_thumb']   = false;
                $config['maintain_ratio'] = TRUE;
                $config['width']          = 100;
                $config['height']         = 100;
                $this->load->library('image_lib', $config);
                $this->image_lib->resize();
                $image_url = base_url() . $image;
            }
        }

        $price = $this->input->post('price', TRUE);

        $tax_percentage = $this->input->post('tax', TRUE);
        $tax = $tax_percentage / 100;

        $tablecolumn = $this->db->list_fields('tax_collection');
        $num_column = count($tablecolumn) - 4;
        if ($num_column > 0) {
            $taxfield = [];
            for ($i = 0; $i < $num_column; $i++) {
                $taxfield[$i] = 'tax' . $i;
            }
            foreach ($taxfield as $key => $value) {
                $data[$value] = $this->input->post($value) / 100;
            }
        }

        $data['product_id']   = $product_id;
        $data['product_id_two']   = $product_id_two;
        $data['product_name'] = $this->input->post('product_name', TRUE);
        $data['size_id']  = $this->input->post('category_id', TRUE);
        $data['brand_id']  = $this->input->post('brand_id', TRUE);
        $data['grade']  = $this->input->post('ptype_id', TRUE); //ptype_id is grade, really
        $data['group_code']  = $this->input->post('group_code', TRUE);
        // $data['labour_charge']  = $this->input->post('labour_charge',TRUE);
        $data['ptype_id']  = 1;
        // $data['shelf_id']  = $this->input->post('shelf_id',TRUE);
        $data['unit']         = $this->input->post('unit', TRUE);
        $data['tax']          = 0;
        $data['serial_no']    = $this->input->post('serial_no', TRUE);
        $data['re_order_level']    = $this->input->post('re_order_level', TRUE);
        $data['price']        = $price;
        // $data['product_model']= $this->input->post('model',TRUE);
        $data['product_details'] = $this->input->post('description', TRUE);
        $data['image']        = (!empty($image_url) ? $image_url : base_url('my-assets/image/product.png'));
        $data['status']       = 1;
        // echo '<pre';print_r($data);exit();
        $result = $CI->lproduct->insert_product($data);
    }

    public function insert_product_sanitary()
    {
        $CI = &get_instance();
        $CI->load->library('lproduct');
        $product_id = (!empty($this->input->post('product_id_sanitary', TRUE)) ? $this->input->post('product_id_sanitary', TRUE) : date('YmdHis'));
        $check_product = $this->db->select('*')->from('product_information')->where('product_id', $product_id)->get()->num_rows();
        if ($check_product > 0) {
            $this->session->set_userdata(array('error_message' => display('already_exists')));
            redirect(base_url('Cproduct'));
        }
        // $product_id_two = $this->input->post('$product_id_two_sanitary', TRUE);
        $sup_price = $this->input->post('supplier_price_sanitary', TRUE);
        $s_id = $this->input->post('supplier_id_sanitary', TRUE);
        // $product_model = $this->input->post('model_sanitary', TRUE);
        for ($i = 0, $n = count($s_id); $i < $n; $i++) {
            $supplier_price = $sup_price[$i];
            $supp_id = $s_id[$i];

            $supp_prd = array(
                'product_id'     => $product_id,
                // 'product_id_two'     => $product_id_two,

                'supplier_id'    => $supp_id,
                'supplier_price' => $supplier_price,
                // 'products_model' => $product_model = $this->input->post('model', TRUE)
            );

            $this->db->insert('supplier_product', $supp_prd);
        }

        //Supplier check
        if ($this->input->post('supplier_id_sanitary', TRUE) == null) {
            $this->session->set_userdata(array('error_message' => display('please_select_supplier')));
            redirect(base_url('Cproduct'));
        }

        if ($_FILES['image']['name']) {
            //Chapter chapter add start
            $config['upload_path']   = './my-assets/image/product/';
            $config['allowed_types'] = 'gif|jpg|png|jpeg|JPEG|GIF|JPG|PNG';
            $config['encrypt_name']  = TRUE;

            $this->load->library('upload', $config);
            if (!$this->upload->do_upload('image')) {
                $error = array('error' => $this->upload->display_errors());
                $this->session->set_userdata(array('error_message' => $this->upload->display_errors()));
                redirect(base_url('Cproduct'));
            } else {

                $imgdata = $this->upload->data();
                $image = $config['upload_path'] . $imgdata['file_name'];
                $config['image_library']  = 'gd2';
                $config['source_image']   = $image;
                $config['create_thumb']   = false;
                $config['maintain_ratio'] = TRUE;
                $config['width']          = 100;
                $config['height']         = 100;
                $this->load->library('image_lib', $config);
                $this->image_lib->resize();
                $image_url = base_url() . $image;
            }
        }

        $price = $this->input->post('price_sanitary', TRUE);

        $tax_percentage = $this->input->post('tax_sanitary', TRUE);
        $tax = $tax_percentage / 100;

        $tablecolumn = $this->db->list_fields('tax_collection');
        $num_column = count($tablecolumn) - 4;
        if ($num_column > 0) {
            $taxfield = [];
            for ($i = 0; $i < $num_column; $i++) {
                $taxfield[$i] = 'tax' . $i;
            }
            foreach ($taxfield as $key => $value) {
                $data[$value] = $this->input->post($value) / 100;
            }
        }

        $data['product_id']   = $product_id;
        // $data['product_id_two']   = $product_id_two;
        $data['product_name'] = $this->input->post('product_name_sanitary', TRUE);
        $data['category_id']  = $this->input->post('category_id_sanitary', TRUE);
        $data['brand_id']  = $this->input->post('brand_id_sanitary', TRUE);
        // $data['labour_charge']  = $this->input->post('labour_charge',TRUE);
        $data['ptype_id']  = 2;
        // $data['shelf_id']  = $this->input->post('shelf_id',TRUE);
        $data['unit']         = $this->input->post('unit_sanitary', TRUE);
        $data['tax']          = 0;
        $data['serial_no']    = $this->input->post('serial_no_sanitary', TRUE);
        $data['re_order_level']    = $this->input->post('re_order_level_sanitary', TRUE);
        $data['price']        = $price;
        // $data['product_model']= $this->input->post('model',TRUE);
        $data['product_details'] = $this->input->post('description_sanitary', TRUE);
        $data['image']        = (!empty($image_url) ? $image_url : base_url('my-assets/image/product.png'));
        $data['status']       = 1;
        // echo '<pre';print_r($data);exit();
        $result = $CI->lproduct->insert_product($data);

        if($result == 1){
            $this->session->set_userdata(array('message' => display('successfully_added')));
        }else{
            $this->session->set_userdata(array('error_message' => "Product already exists."));
        }
    }


}
