<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Lshelf {

    //Retrieve  category List	
    public function category_list() {
        $CI = & get_instance();
        $CI->load->model('Shelf');
        $category_list = $CI->Shelf->category_list();  //It will get only Credit categorys
        $i = 0;
        $total = 0;
        if (!empty($category_list)) {
            foreach ($category_list as $k => $v) {
                $i++;
                $category_list[$k]['sl'] = $i + $CI->uri->segment(3);
            }
        }
        $data = array(
            'title'         => "Manage Shelf",
            'category_list' => $category_list,
        );
        $categoryList = $CI->parser->parse('shelf/category', $data, true);
        return $categoryList;
    }

    //Sub Category Add
    public function category_add_form() {
        $CI = & get_instance();
        $CI->load->model('Shelf');
         $category_list = $CI->Shelf->category_list();  //It will get only Credit categorys
        $i = 0;
        $total = 0;
        if (!empty($category_list)) {
            foreach ($category_list as $k => $v) {
                $i++;
                $category_list[$k]['sl'] = $i + $CI->uri->segment(3);
            }
        }
        $data = array(
            'title'         => 'Shelf',
            'category_list' => $category_list,
        );
        $categoryForm = $CI->parser->parse('shelf/add_category_form', $data, true);
        return $categoryForm;
    }

    //category Edit Data
    public function category_edit_data($category_id) {
        $CI = & get_instance();
        $CI->load->model('Shelf');
        $category_detail = $CI->Shelf->retrieve_category_editdata($category_id);

        $data = array(
            'title'         => 'Shelf Edit',
            'shelf_id'   => $category_detail[0]['shelf_id'],
            'shelf_number' => $category_detail[0]['shelf_number'],
            'status'        => $category_detail[0]['status']
        );
        $chapterList = $CI->parser->parse('shelf/edit_category_form', $data, true);
        return $chapterList;
    }

}

?>