<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Lcategory {

    //Retrieve  category List
    public function category_list() {
        $CI = & get_instance();
        $CI->load->model('Categories');
        $category_list = $CI->Categories->category_list();  //It will get only Credit categorys
        $i = 0;
        $total = 0;
        if (!empty($category_list)) {
            foreach ($category_list as $k => $v) {
                $i++;
                $category_list[$k]['sl'] = $i + $CI->uri->segment(3);
            }
        }
        $data = array(
            'title'         => 'Manage Size',
            'category_list' => $category_list,
        );
        $categoryList = $CI->parser->parse('category/category', $data, true);
        return $categoryList;
    }

    //Sub Category Add
    public function category_add_form() {
        $CI = & get_instance();
        $CI->load->model('Size');
         $category_list = $CI->Categories->category_list();  //It will get only Credit categorys
        $i = 0;
        $total = 0;
        if (!empty($category_list)) {
            foreach ($category_list as $k => $v) {
                $i++;
                $category_list[$k]['sl'] = $i + $CI->uri->segment(3);
            }
        }
        $data = array(
            'title'         => "Size",
            'category_list' => $category_list,
        );
        $categoryForm = $CI->parser->parse('category/add_category_form', $data, true);
        return $categoryForm;
    }

    public function size_add_form() {
        $CI = & get_instance();
        $CI->load->model('Size');
         $category_list = $CI->Size->category_list();  //It will get only Credit categorys
        $i = 0;
        $total = 0;
        if (!empty($category_list)) {
            foreach ($category_list as $k => $v) {
                $i++;
                $category_list[$k]['sl'] = $i + $CI->uri->segment(3);
            }
        }
        $data = array(
            'title'         => "Size",
            'category_list' => $category_list,
        );
        $categoryForm = $CI->parser->parse('category/add_size_form', $data, true);
        return $categoryForm;
    }

    //category Edit Data
    public function category_edit_data($category_id) {
        $CI = & get_instance();
        $CI->load->model('Categories');
        $category_detail = $CI->Categories->retrieve_category_editdata($category_id);

        $data = array(
            'title'         => "Size Edit",
            'category_id'   => $category_detail[0]['category_id'],
            'category_name' => $category_detail[0]['category_name'],
            // 'value' => $category_detail[0]['value'],
            // 'sqft' => $category_detail[0]['sqft'],
            // 'sqpc' => $category_detail[0]['sqpc'],
            'status'        => $category_detail[0]['status']
        );
        $chapterList = $CI->parser->parse('category/edit_category_form', $data, true);
        return $chapterList;
    }

    public function size_edit_data($category_id) {
        $CI = & get_instance();
        $CI->load->model('Size');
        $category_detail = $CI->Size->retrieve_category_editdata($category_id);

        $data = array(
            'title'         => "Size Edit",
            'category_id'   => $category_detail[0]['category_id'],
            'category_name' => $category_detail[0]['category_name'],
            'value' => $category_detail[0]['value'],
            'sqft' => $category_detail[0]['sqft'],
            'sqpc' => $category_detail[0]['sqpc'],
            'status'        => $category_detail[0]['status']
        );
        $chapterList = $CI->parser->parse('category/edit_size_form', $data, true);
        return $chapterList;
    }

}

?>