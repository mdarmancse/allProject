<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Lmtype {

    //Retrieve  category List	
    public function category_list() {
        $CI = & get_instance();
        $CI->load->model('Mtype');
        $category_list = $CI->Mtype->category_list();  //It will get only Credit categorys
        $i = 0;
        $total = 0;
        if (!empty($category_list)) {
            foreach ($category_list as $k => $v) {
                $i++;
                $category_list[$k]['sl'] = $i + $CI->uri->segment(3);
            }
        }
        $data = array(
            'title'         => "Manage Material Type",
            'category_list' => $category_list,
        );
        $categoryList = $CI->parser->parse('material_type/Mtype', $data, true);
        return $categoryList;
    }

    //Sub Category Add
    public function category_add_form() {
        $CI = & get_instance();
        $CI->load->model('Mtype');
         $category_list = $CI->Mtype->category_list();  //It will get only Credit categorys
        $i = 0;
        $total = 0;
        if (!empty($category_list)) {
            foreach ($category_list as $k => $v) {
                $i++;
                $category_list[$k]['sl'] = $i + $CI->uri->segment(3);
            }
        }
        $data = array(
            'title'         => "Material Type",
            'category_list' => $category_list,
        );
        $categoryForm = $CI->parser->parse('material_type/add_ptype', $data, true);
        return $categoryForm;
    }

    //category Edit Data
    public function category_edit_data($ptype_id) {
        $CI = & get_instance();
        $CI->load->model('Mtype');
        $category_detail = $CI->Mtype->retrieve_category_editdata($ptype_id);

        $data = array(
            'title'         => "Material Type Edit",
            'ptype_id'   => $category_detail[0]['ptype_id'],
            'ptype_name' => $category_detail[0]['ptype_name'],
            'status'        => $category_detail[0]['status']
        );
        $chapterList = $CI->parser->parse('material_type/edit_ptype_form', $data, true);
        return $chapterList;
    }

}

?>