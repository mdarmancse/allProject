import { Router } from "express";
import Auth from "../middleware/AuthVerifier";
import IncludeRequest from "../middleware/IncludeRequest";
import SSLController from "../controller/SSLController";
import BkashController from "../controller/BkashController";
import NagadController from "../controller/NagadController";
import UpayController from "../controller/UpayController";
const router = Router();

router
  .post("/ssl/init", Auth, IncludeRequest, SSLController.init)
  .post("/ssl/success", IncludeRequest, SSLController.success)
  .post("/ssl/cancel", IncludeRequest, SSLController.cancel)
  .post("/ssl/fail", IncludeRequest, SSLController.fail)

  .post("/bkash/init", Auth, IncludeRequest, BkashController.grant)
  .get("/bkash/callback", IncludeRequest, BkashController.callback)
  .get("/bkash/express/callback", IncludeRequest, BkashController.express_callback)
  .post("/bkash/agreement/create", Auth, IncludeRequest, BkashController.createAgreement)
  .post("/bkash/agreement/save", Auth, BkashController.saveAgreement)
  .post("/bkash/agreement/cancel", Auth, IncludeRequest, BkashController.cancelAgreement)
  .post("/bkash/agreement/get", Auth, IncludeRequest, BkashController.getAgreement)

  .post("/nagad/init", Auth, IncludeRequest, NagadController.init)
  .post("/nagad/callback", IncludeRequest, NagadController.callback)

  .post("/upay/init", Auth, IncludeRequest, UpayController.init)
  .post("/upay/redirect", IncludeRequest, UpayController.redirect);

export default router;
