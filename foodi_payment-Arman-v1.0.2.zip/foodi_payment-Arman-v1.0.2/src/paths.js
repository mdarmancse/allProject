import BkashController from "./controller/BkashController";
import NagadController from "./controller/NagadController";
import SSLController from "./controller/SSLController";
import UpayController from "./controller/UpayController";

const paths = {
  "ssl/init": SSLController.init,
  "ssl/success": SSLController.success,
  "ssl/cancel": SSLController.cancel,
  "ssl/fail": SSLController.fail,
  "bkash/init": BkashController.grant,
  "bkash/callback": BkashController.callback,
  "bkash/agreement/create": BkashController.createAgreement,
  "bkash/agreement/cancel": BkashController.cancelAgreement,
  "bkash/agreement/save": BkashController.saveAgreement,
  "bkash/agreement/get": BkashController.getAgreement,
  "nagad/init": NagadController.init,
  "nagad/callback": NagadController.callback,
  "upay/init": UpayController.init,
  "upay/redirect": UpayController.redirect,
};

export default async (path, body) => {
  let response;
  try {
    response = paths[path](body);
    if (response) return response;
  } catch (err) {
    console.error(err);
    return {
      status: -1,
      msg: "Gateway not found",
    };
  }
};
