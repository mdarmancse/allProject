import mongoose from "mongoose";
import { v4 as uuidv4 } from "uuid";
const BkashAgreementSchema = new mongoose.Schema(
  {
    _id: {
      type: String,
      default: () => uuidv4(),
    },
    user_id: {
      type: String,
      required: true,
    },
    msisdn: {
      type: String,
      required: true,
    },
    agreement_id: {
      type: String,
      required: true,
    },

    is_active: { type: Boolean, default: true },
    created_at: { type: Date, default: new Date() },
    created_by: { type: String, default: null },
    updated_at: { type: Date, default: new Date() },
    updated_by: { type: String, default: null },
  },
  {
    collection: "bkash_agreements",
    //  timestamps: true,
    versionKey: false,
  }
);

const BkashAgreementModel = mongoose.model("bkash_agreements", BkashAgreementSchema);
export default BkashAgreementModel;
