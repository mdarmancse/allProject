const models = {};

export const CreateService = async (Request, DataModel) => {
  try {
    let MODEL = models[DataModel];
    let data = await MODEL.create(Request);
    if (data) return { status: "success", data: data };
  } catch (error) {
    return { status: "fail" };
  }
};

export const UpdateService = async (Request, DataModel) => {
  try {
    console.log("Request", Request);
    let MODEL = models[DataModel];
    let data = await MODEL.updateOne({ _id: Request._id }, Request);
    if (data) return { status: "success", data: data };
  } catch (error) {
    return { status: "Update Fail" };
  }
};

export const DeleteService = async (Request, DataModel) => {
  try {
    let MODEL = models[DataModel];
    let data = await MODEL.deleteMany({ _id: Request._id });
    if (data) return { status: "Delete Success" };
  } catch (error) {
    return { status: "Delete Failed" };
  }
};
