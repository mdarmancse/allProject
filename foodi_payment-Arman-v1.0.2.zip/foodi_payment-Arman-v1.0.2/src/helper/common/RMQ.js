import { connect as rabbitMQ_connect } from "amqplib";
import { CreateService, DeleteService, UpdateService } from "./CRUD";
import { v4 as uuidv4 } from "uuid";
import dotenv from "dotenv";
dotenv.config();
const RABBIT_MQ = process.env.RABBIT_MQ;

var reply;
export const Send_Central = async (data, TableName, Method) => {
  console.log("data :", data);
  const reply_queue = "user_queue" + uuidv4();
  const request_Queue = "central_queue";
  try {
    await rabbitMQ_connect(RABBIT_MQ).then((conn) => {
      conn.createChannel().then((channel) => {
        const correlationId = uuidv4();
        console.log("corr id:", correlationId);
        try {
          channel.sendToQueue(request_Queue, Buffer.from(JSON.stringify(data)), {
            correlationId,
            contentType: TableName,
            messageId: Method,
            replyTo: reply_queue,
          });
          console.log(`Send Request:`, JSON.stringify(data));
        } catch (err) {
          console.log(err);
          return {
            status: -1,
            msg: "Server faced some problem",
          };
        }

        channel.assertQueue(reply_queue, { durable: false, autoDelete: true });
        const a = channel.consume(
          reply_queue,
          (msg) => {
            console.log("msg :", msg);

            if (msg.properties.correlationId === correlationId) {
              try {
                let reply = JSON.parse(msg.content.toString());
                console.log(`Received reply:`, reply);
              } catch (err) {
                console.error(err);
              }
            }
            conn.close();
          },
          { noAck: true }
        );
      });
    });
  } catch (error) {
    return { status: "Failed" };
  }
};

export const Rcv_Central = async (data, ModelName, Method) => {
  let results = {};
  try {
    if (Method === "add") {
      results = await CreateService(data, ModelName);

      //  console.log("results",results.toString())
      return { status: "success" };
    }
    if (Method === "edit") {
      results = await UpdateService(data, ModelName);
      return { status: "success" };
    }
    if (Method === "delete") {
      results = await DeleteService(data, ModelName);
      return { status: "success" };
    }
  } catch (e) {
    return { status: "failed" };
  }
};

export const rq_rply_q = async (
  requestQueue,
  replyQueue = replyQueue,
  body,
  TableName,
  Method
) => {
  return new Promise(async (resolve, reject) => {
    const conn = await rabbitMQ_connect(RABBIT_MQ);
    const channel = await conn.createChannel();

    replyQueue = "payment_queue_" + uuidv4();

    const correlationId = uuidv4();
    console.log("corr id:", correlationId);
    try {
      channel.sendToQueue(requestQueue, Buffer.from(JSON.stringify(body)), {
        correlationId,
        contentType: TableName,
        messageId: Method,
        replyTo: replyQueue,
      });
    } catch (err) {
      console.log(err);
      reject({
        status: -1,
        msg: "Server faced some problems",
      });
    }

    channel.assertQueue(replyQueue, { durable: false, autoDelete: true });
    channel.consume(
      replyQueue,
      (msg) => {
        if (msg.properties.correlationId === correlationId) {
          let reply = JSON.parse(msg.content.toString());
          console.log(`Received reply:`, reply);
          resolve(reply);
          channel.close();
          conn.close();
        }
      },
      { noAck: true }
    );
  });
};

export const Send_Queue = async (
  requestQueue,
  reply_queue,
  data,
  TableName,
  Method
  // callback
) => {
  // let response_data;
  //   return new Promise(async (resolve, reject) => {

  // } )
  return rq_rply_q(requestQueue, reply_queue, data, TableName, Method);
  // return response_data;
};
