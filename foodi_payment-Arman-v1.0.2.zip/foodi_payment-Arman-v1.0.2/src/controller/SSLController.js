import * as crypto from "crypto";
import { Send_Queue } from "../helper/common/RMQ";
import moment from "moment";
const SSL_API_URL = process.env.SSL_API_URL;
const SSL_VALIDATION_URL = process.env.SSL_VALIDATION_URL;
const SSL_STORE_ID = process.env.SSL_STORE_ID;
const SSL_STORE_PASSWORD = process.env.SSL_STORE_PASSWORD;
let SSL_SUCCESS_URL = process.env.SSL_SUCCESS_URL;
let SSL_FAIL_URL = process.env.SSL_FAIL_URL;
let SSL_CANCEL_URL = process.env.SSL_CANCEL_URL;

const init = async (req, res, next) => {
  let body = req.body,
    userUpdate,
    total_amount,
    cart_details,
    customer_mobile,
    customer_name,
    transaction_id,
    is_premium_user,
    subsPayment;
  // SSL_SUCCESS_URL = `${req.headers.base_url}/api/v1/payment/ssl/success`;
  let subscription_type_id = body.subscription_type_id;
  let user_id = body.id;
  const SSL_SUCCESS_URL = `${req.headers.base_url}/api/v1/payment/ssl/success?subscription_type_id=${subscription_type_id}&user_id=${user_id}`;

  //console.log(SSL_SUCCESS_URL)
  try {
    const user_data = await Send_Queue(
      "main_user_request",
      "payment_queue",
      { _id: body.id },
      "UserModel",
      "get"
    );

    if (!user_data.data) {
      return res.json({ status: -1, msg: "User Data Not found" });
    }
    if (body.subscription_type_id) {
      const subs_data = await Send_Queue(
        "main_user_request",
        "payment_queue",
        { _id: body.subscription_type_id },
        "SubscriptionType",
        "get"
      );

      if (!subs_data || !subs_data.data) {
        return res.json({
          status: -1,
          msg: "Sorry ! No subscription found with this id",
        });
      }
      total_amount = subs_data.data.subscription_fee;
    } else {
      const cart_data = await Send_Queue(
        "main_restaurant_request",
        "payment_queue",
        { customer_id: body.id },
        "CartModel",
        "get"
      );
      if (!cart_data || !cart_data.data) {
        return res.json({
          status: -1,
          msg: "Add menu to cart first",
        });
      }
      total_amount = cart_data.data.total_amount;
      cart_details = cart_data.data.cart_details;
    }
    customer_mobile = user_data.data.mobile ? user_data.data.mobile : null;
    customer_name = `${user_data.data.firstName} ${user_data.data.lastName}`;
    transaction_id = Date.now();

    let request_data = {
      store_id: SSL_STORE_ID,
      store_passwd: SSL_STORE_PASSWORD,
      total_amount: total_amount,
      currency: "BDT",
      tran_id: transaction_id,
      success_url: SSL_SUCCESS_URL,
      fail_url: SSL_FAIL_URL,
      cancel_url: SSL_CANCEL_URL,
      cus_name: customer_name,
      cus_email: "",
      cus_add1: "Dhaka",
      cus_add2: "Dhaka",
      cus_city: "Dhaka",
      cus_state: "Dhaka",
      cus_postcode: "1000",
      cus_country: "Bangladesh",
      cus_phone: customer_mobile,
      cus_fax: "",
      ship_name: "foodibd",
      ship_add1: "Dhaka",
      ship_add2: "Dhaka",
      ship_city: "Dhaka",
      ship_state: "Dhaka",
      ship_postcode: "1000",
      ship_country: "Bangladesh",
      shipping_method: "No",
      // value_a : "ref001",
      emi_option: 0,
      cart: JSON.stringify(cart_details),
      product_amount: 100,
      product_category: "Food",
      product_profile: "physical-goods",
      product_name: "product_name",
      vat: "5",
      discount_amount: "5",
      convenience_fee: "5",
    };

    const fdata = new FormData();
    for (const rq_data in request_data) {
      fdata.append(rq_data, request_data[rq_data] ? request_data[rq_data] : "");
    }
    // let request_headers = {
    //   "Content-Type": "application/json",
    // };

    let response = await fetch(SSL_API_URL, {
      method: "post",
      mode: "cors",
      cache: "no-cache",
      credentials: "same-origin",
      redirect: "follow",
      // referrer: "no-referrer",
      // headers: request_headers,
      body: fdata,
    });
    let result = await response.json();
    console.log("result :", result);

    if (result.status === "SUCCESS") {
      return res.json({
        status: 0,
        data: {
          url: result.GatewayPageURL,
        },
        msg: result.status,
      });
    } else {
      return res.json({
        status: -1,
        msg: result.status,
        data: result.failedreason,
      });
    }
  } catch (err) {
    console.error(err);
    return res.status(500).json({ status: -1, msg: "Server error", err: err.toString() });
  }
};

const success = async (req, res) => {
  try {
    let body = req.body,
      subsPayment,
      userUpdate,
      is_premium_user,
      subscription_expire_date_time,
      subscription_type_name;
    const subscription_type_id = body.query.subscription_type_id;
    const user_id = body.query.user_id;
    console.log("Query", body.query);
    let val_id = body.val_id;
    let url = `${SSL_VALIDATION_URL}?val_id=${val_id}&store_id=${SSL_STORE_ID}&store_passwd=${SSL_STORE_PASSWORD}&v=1&format=json`;
    let request_headers = {
      "Content-Type": "application/json",
    };
    let response = await fetch(url, {
      method: "get",
      headers: request_headers,
    });

    let result = await response.json();
    console.log("result :", result);
    console.log("subscription_type_id :", subscription_type_id);
    if (result.status === "VALID") {
      const nonce = crypto.randomBytes(16).toString("base64");
      if (subscription_type_id) {
        const subs_data = await Send_Queue(
          "main_user_request",
          "payment_queue",
          { _id: subscription_type_id },
          "SubscriptionType",
          "get"
        );
        is_premium_user = subs_data.data.is_premium;
        subscription_type_name = subs_data.data.name;
        let expiry_day = subs_data.data.subscribe_for_in_days;
        subscription_expire_date_time = moment().add(expiry_day, "days").toDate();
        subsPayment = await Send_Queue(
          "main_user_request",
          "payment_queue",
          {
            condition: {
              customer_id: user_id,
              subscription_type_id: subscription_type_id,
            },
            data: {
              customer_id: user_id,
              amount: body.amount,
              transaction_id: body.tran_id,
              subscription_type_id: subscription_type_id,
              created_by: user_id,
              updated_by: user_id,
            },
          },
          "SubscriptionPayment",
          "edit_add_condition"
        );
        userUpdate = await Send_Queue(
          "main_user_request",
          "payment_queue",
          {
            _id: user_id,
            subscription_type_id: subscription_type_id,
            subscription_expire_date_time: subscription_expire_date_time,
            created_by: user_id,
            updated_by: user_id,
          },
          "UserModel",
          "edit"
        );
      }
      let html = `
  <!DOCTYPE html>
  <html lang="en">
  <head>
  <meta http-equiv="Content-Security-Policy" content="script-src 'unsafe-inline' 'nonce-${nonce}'">
  </head>
  `;
      html += "<h1>Success</h1>";
      html += `<script nonce="${nonce}" type="text/javascript">
  data = {
      "message" : "PaymentSuccess",
      "transaction_id" : "${result.tran_id}",
           "active_status": true,
        "subscription_type_id": "${subscription_type_id}",
        "subscription_type_name":  "${subscription_type_name}",
         "is_premium_user": ${is_premium_user},

      "val_id" : "${result.val_id}",
      "status" : 0,
  }
  window.ReactNativeWebView.postMessage(JSON.stringify(data));
</script>`;
      html += "</html>";
      return res.send(html);
    } else {
      const nonce = crypto.randomBytes(16).toString("base64");

      let html = `
  <!DOCTYPE html>
  <html lang="en">
  <head>
  <meta http-equiv="Content-Security-Policy" content="script-src 'unsafe-inline' 'nonce-${nonce}'">
  </head>
  `;
      html += "<h1>Invalid</h1>";
      html += `<script nonce="${nonce}" type="text/javascript">
  data = {
      "message" : "Invalid Transaction",
      "status" : -1,
  }
  window.ReactNativeWebView.postMessage(JSON.stringify(data));
</script>`;
      html += "</html>";

      return res.send(html);
    }
  } catch (err) {
    console.error(err);
  }
};

const fail = async (req, res) => {
  const nonce = crypto.randomBytes(16).toString("base64");

  let html = `
  <!DOCTYPE html>
  <html lang="en">
  <head>
  <meta http-equiv="Content-Security-Policy" content="script-src 'unsafe-inline' 'nonce-${nonce}'">
  </head>
  `;
  html += "<h1>Failed</h1>";
  html += `<script nonce="${nonce}" type="text/javascript">
  data = {
      "message" : "Failed",
      "status" : -1,
  }
  window.ReactNativeWebView.postMessage(JSON.stringify(data));
</script>`;
  html += "</html>";
  return res.send(html);
};

const cancel = async (req, res) => {
  const nonce = crypto.randomBytes(16).toString("base64");

  let html = `
  <!DOCTYPE html>
  <html lang="en">
  <head>
  <meta http-equiv="Content-Security-Policy" content="script-src 'unsafe-inline' 'nonce-${nonce}'">
  </head>
  `;
  html += "<h1>Cancelled</h1>";
  html += `<script nonce="${nonce}" type="text/javascript">
  data = {
      "message" : "Cancelled",
      "status" : -1,
  }
  window.ReactNativeWebView.postMessage(JSON.stringify(data));
</script>`;
  html += "</html>";
  return res.send(html);
};

export default {
  init,
  success,
  fail,
  cancel,
};
