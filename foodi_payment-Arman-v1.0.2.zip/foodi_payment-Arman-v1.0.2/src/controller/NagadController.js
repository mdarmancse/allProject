import * as crypto from "crypto";
import * as nagad_pg from "nagad-payment-gateway";
import { Send_Queue } from "../helper/common/RMQ";
const NAGAD_URI = process.env.NAGAD_URI;
let NAGAD_CALLBACK_URL = process.env.NAGAD_CALLBACK_URL;
const NAGAD_MERCHANT_ID = process.env.NAGAD_MERCHANT_ID;
const NAGAD_MERCHANT_NUMBER = process.env.NAGAD_MERCHANT_NUMBER;
const NAGAD_MERCHANT_PRIVATE_KEY = process.env.NAGAD_MERCHANT_PRIVATE_KEY;
const NAGAD_PG_PUBLIC_KEY = process.env.NAGAD_PG_PUBLIC_KEY;
const NAGAD_MERCHANT_PRIVATE_KEY_PATH = process.env.NAGAD_MERCHANT_PRIVATE_KEY_PATH;
const NAGAD_PG_PUBLIC_KEY_PATH = process.env.NAGAD_PG_PUBLIC_KEY_PATH;

const init = async (req, res, next) => {
  let body = req.body,
    total_amount;
  const subscription_type_id = body.subscription_type_id;
  const user_id = body.id;
  try {
    NAGAD_CALLBACK_URL = `${body.headers.base_url}/api/v1/payment/nagad/callback?subscription_id=${subscription_type_id}&user_id=${user_id}`;
    const config = {
      apiVersion: "v-0.2.0",
      baseURL: NAGAD_URI,
      callbackURL: NAGAD_CALLBACK_URL,
      merchantID: NAGAD_MERCHANT_ID,
      merchantNumber: NAGAD_MERCHANT_NUMBER,
      privKey: NAGAD_MERCHANT_PRIVATE_KEY_PATH,
      pubKey: NAGAD_PG_PUBLIC_KEY_PATH,
      isPath: true,
    };

    const nagad = new nagad_pg.NagadGateway(config);
    if (body.subscription_type_id) {
      const subs_data = await Send_Queue(
        "main_user_request",
        "payment_queue",
        { _id: body.subscription_type_id },
        "SubscriptionType",
        "get"
      );
      if (!subs_data || !subs_data.data) {
        return res.json({
          status: -1,
          msg: "Sorry ! No subscription found with this id",
        });
      }
      total_amount = subs_data.data.subscription_fee;
    } else {
      const cart_data = await Send_Queue(
        "main_restaurant_request",
        "payment_queue",
        { customer_id: body.id },
        "CartModel",
        "get"
      );
      if (!cart_data || !cart_data.data) {
        return res.json({
          status: -1,
          msg: "Add menu to cart first",
        });
      }
      total_amount = cart_data.data.total_amount;
    }

    const ip = "10.0.10.1";
    const nagad_url = await nagad.createPayment({
      amount: total_amount,
      ip: ip,
      orderId: `${Date.now()}`,
      productDetails: { a: "1", b: "2" },
      clientType: "PC_WEB",
    });

    if (nagad_url)
      return res.json({
        status: 0,
        data: {
          url: nagad_url,
        },
      });

    return res.json({
      status: -1,
      msg: "Couldn't initiate",
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ status: -1, msg: "Server error", err: err.toString() });
  }
};

const callback = async (req, res) => {
  let body = req.body,
    subsPayment,
    is_premium_user,
    userUpdate,
    subscription_type_name;
  const subscription_type_id = body.query.subscription_type_id;
  const user_id = body.query.user_id;
  console.log("BODY", body);
  const config = {
    apiVersion: "v-0.2.0",
    baseURL: NAGAD_URI,
    callbackURL: NAGAD_CALLBACK_URL,
    merchantID: NAGAD_MERCHANT_ID,
    merchantNumber: NAGAD_MERCHANT_NUMBER,
    privKey: "./keys/nagad/private.key",
    pubKey: "./keys/nagad/public.key",
    isPath: false,
  };

  const nagad = new nagad_pg.NagadGateway(config);

  const result = await nagad.verifyPayment(body.paymentRefID);
  if (result.status === "Success") {
    const nonce = crypto.randomBytes(16).toString("base64");
    if (subscription_type_id) {
      const subs_data = await Send_Queue(
        "main_user_request",
        "payment_queue",
        { _id: subscription_type_id },
        "SubscriptionType",
        "get"
      );
      is_premium_user = subs_data.data.is_premium;
      subscription_type_name = subs_data.data.name;
      subsPayment = await Send_Queue(
        "main_user_request",
        "payment_queue",
        {
          condition: { customer_id: user_id, subscription_type_id: subscription_type_id },
          data: {
            customer_id: user_id,
            amount: subs_data.data.subscription_fee,
            transaction_id: result.paymentRefId,
            subscription_type_id: subscription_type_id,
            created_by: user_id,
            updated_by: user_id,
          },
        },
        "SubscriptionPayment",
        "edit_add_condition"
      );
      userUpdate = await Send_Queue(
        "main_user_request",
        "payment_queue",
        {
          _id: user_id,
          subscription_type_id: subscription_type_id,
          created_by: user_id,
          updated_by: user_id,
        },
        "UserModel",
        "edit"
      );
    }
    let html = `
  <!DOCTYPE html>
  <html lang="en">
  <head>
  <meta http-equiv="Content-Security-Policy" content="script-src 'unsafe-inline' 'nonce-${nonce}'">
  </head>
  `;
    html += `<h1>${result.status}</h1>`;
    html += `<script nonce="${nonce}" type="text/javascript">
  data = {
      "message" : ${result.status},
      "paymentRefID": ${result.paymentRefId},
      "paymentRefID": ${result.paymentRefId},
          "active_status": true,
        "subscription_type_id": "${subscription_type_id}",
        "subscription_type_name":  "${subscription_type_name}",
         "is_premium_user": ${is_premium_user},
      "status" : 0,
  }
  window.ReactNativeWebView.postMessage(JSON.stringify(data));
</script>`;
    html += "</html>";
    return res.send(html);
  }
};

export default {
  init,
  callback,
};
