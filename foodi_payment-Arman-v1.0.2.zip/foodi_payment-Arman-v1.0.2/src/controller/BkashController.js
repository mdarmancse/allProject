import * as crypto from "crypto";
import { Send_Queue } from "../helper/common/RMQ";
import BkashAgreementModel from "../model/BkashAgreement";
import moment from "moment";

const BKASH_GRANT_URL = process.env.BKASH_GRANT_URL;
const BKASH_CREATE_URL = process.env.BKASH_CREATE_URL;
const BKASH_EXECUTE_URL = process.env.BKASH_EXECUTE_URL;
const BKASH_REFUND_URL = process.env.BKASH_REFUND_URL;
const BKASH_APP_KEY = process.env.BKASH_APP_KEY;
const BKASH_APP_SECRET = process.env.BKASH_APP_SECRET;
const BKASH_USERNAME = process.env.BKASH_USERNAME;
const BKASH_PASSWORD = process.env.BKASH_PASSWORD;
let BKASH_CALLBACK_URL = process.env.BKASH_CALLBACK_URL;
const BKASH_CALLBACK_AGREEMENT_URL = process.env.BKASH_CALLBACK_AGREEMENT_URL;
const BKASH_CANCEL_AGREEMENT_URL = process.env.BKASH_CANCEL_AGREEMENT_URL;

const grant = async (req, res, next) => {
  let body = req.body;
  const id = body.id;
  const user_id = body.id;
  let subscription_type_id = body.subscription_type_id;
  let total_amount;
  if (subscription_type_id) {
    const subs_data = await Send_Queue(
      "main_user_request",
      "payment_queue",
      { _id: body.subscription_type_id },
      "SubscriptionType",
      "get"
    );
    if (!subs_data || !subs_data.data) {
      return res.json({
        status: -1,
        msg: "Sorry ! No subscription found with this id",
      });
    }
    total_amount = subs_data.data.subscription_fee;
  } else {
    const cart_data = await Send_Queue(
      "main_restaurant_request",
      "payment_queue",
      { customer_id: body.id },
      "CartModel",
      "get"
    );
    if (!cart_data || !cart_data.data) {
      return res.json({
        status: -1,
        msg: "Add menu to cart first",
      });
    }
    total_amount = cart_data.data.total_amount;
  }
  const agreementID = body.agreement_id;

  try {
    let request_data = {
      app_key: BKASH_APP_KEY,
      app_secret: BKASH_APP_SECRET,
    };

    let request_headers = {
      "Content-Type": "application/json",
      username: BKASH_USERNAME,
      password: BKASH_PASSWORD,
    };

    let response = await fetch(BKASH_GRANT_URL, {
      method: "post",
      headers: request_headers,
      body: JSON.stringify(request_data),
    });

    let result = await response.json();
    const id_token = result.id_token;
    if (result.statusMessage === "Successful") {
      if (!(await saveUserToken(id, id_token))) {
        return res.json({
          status: -1,
          message: "Couldn't initiate",
        });
      }
      if (subscription_type_id) {
        BKASH_CALLBACK_URL = `${body.headers.base_url}/api/v1/payment/bkash/express/callback?subscription_type_id=${subscription_type_id}&user_id=${user_id}`;
      } else {
        BKASH_CALLBACK_URL = `${body.headers.base_url}/api/v1/payment/bkash/callback`;
      }
      // create_payment
      let request_data = {
        mode: "0001",
        amount: total_amount,
        currency: "BDT",
        intent: "sale",
        payerReference: "01XXXXXXXXX",
        agreementID: agreementID,
        merchantInvoiceNumber: "commonPayment001",
        callbackURL: BKASH_CALLBACK_URL,
      };

      let request_headers = {
        "Content-Type": "application/json",
        Authorization: id_token,
        "X-App-Key": BKASH_APP_KEY,
      };

      let response = await fetch(BKASH_CREATE_URL, {
        method: "post",
        headers: request_headers,
        body: JSON.stringify(request_data),
      });

      let result = await response.json();

      if (result.bkashURL) {
        const payment_id = result.paymentID;
        if (!saveUserPaymentID(id, payment_id, subscription_type_id)) {
          return res.json({
            status: -1,
            message: "Couldn't save agreement",
          });
        }
        return res.json({
          status: 0,
          url: result.bkashURL,
          message: result.statusMessage,
        });
      } else {
        return res.json({
          status: -1,
          message: result.statusMessage,
        });
      }
    }
  } catch (err) {
    console.error(err);
    return res.status(500).json({ status: -1, msg: "Server error", err: err.toString() });
  }
};

const createAgreement = async (req, res, next) => {
  let body = req.body;
  const user_id = body.id;
  let subscription_type_id = body.subscription_type_id;

  try {
    //   Call for grant
    let request_data = {
      app_key: BKASH_APP_KEY,
      app_secret: BKASH_APP_SECRET,
    };

    let request_headers = {
      "Content-Type": "application/json",
      username: BKASH_USERNAME,
      password: BKASH_PASSWORD,
    };

    let response = await fetch(BKASH_GRANT_URL, {
      method: "post",
      headers: request_headers,
      body: JSON.stringify(request_data),
    });

    let result = await response.json();
    console.log("result :", result);
    console.log("result :", result.statusCode);

    let id_token = result.id_token;
    if (result.statusCode === "0000") {
      if (!saveUserToken(user_id, id_token, subscription_type_id)) {
        return res.json({
          status: -1,
          message: "Couldn't initiate",
        });
      }
      if (subscription_type_id) {
        BKASH_CALLBACK_URL = `${body.headers.base_url}/api/v1/payment/bkash/express/callback?subscription_type_id=${subscription_type_id}&user_id=${user_id}`;
      } else {
        BKASH_CALLBACK_URL = `${body.headers.base_url}/api/v1/payment/bkash/callback`;
      }
      // create_payment
      let request_data = {
        mode: "0000",
        payerReference: "01XXXXXXXXX",
        callbackURL: BKASH_CALLBACK_URL,
      };

      let request_headers = {
        "Content-Type": "application/json",
        Authorization: id_token,
        "X-App-Key": BKASH_APP_KEY,
      };

      let response = await fetch(BKASH_CREATE_URL, {
        method: "post",
        headers: request_headers,
        body: JSON.stringify(request_data),
      });

      let result = await response.json();

      if (result.bkashURL) {
        const payment_id = result.paymentID;
        if (!saveUserPaymentID(user_id, payment_id, subscription_type_id)) {
          return res.json({
            status: -1,
            message: "Couldn't save agreement",
          });
        }
        return res.json({
          status: 0,
          url: result.bkashURL,
          message: result.statusMessage,
        });
      } else {
        return res.json({
          status: -1,
          message: result.statusMessage,
        });
      }
    }

    // if fail
    return res.json({
      status: -1,
      message: result.statusMessage,
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ status: -1, msg: "Server error", err: err.toString() });
  }
};

const executeAgreement = async (payment_id) => {
  try {
    const token = await getUserPaymentToken(payment_id);
    const request_data = {
      paymentID: payment_id,
    };

    const request_headers = {
      "Content-Type": "application/json",
      Authorization: token,
      "X-app-key": BKASH_APP_KEY,
    };

    const response = await fetch(BKASH_EXECUTE_URL, {
      method: "post",
      headers: request_headers,
      body: JSON.stringify(request_data),
    });

    const result = await response.json();

    const nonce = crypto.randomBytes(16).toString("base64");
    if (result.statusMessage === "Successful" && result.agreementStatus === "Completed") {
      console.log("aggremenID", result.agreementID);
      let html = `
    <!DOCTYPE html>
    <html lang="en">
    <head>
    <meta http-equiv="Content-Security-Policy" content="script-src 'unsafe-inline' 'nonce-${nonce}'">
    </head>
    `;
      html += `<h1>${result.statusMessage}</h1>`;
      html += `<script nonce="${nonce}" type="text/javascript">
    data = {
        "message" : "${result.statusMessage}",
        "payment_id": "${payment_id}",
        "transaction_id": "${result.trxID}",
        "agreement_id": "${result.agreementID}",
        "customerMsisdn": "${result.customerMsisdn}",
        "status" : 0,
    }
    window.ReactNativeWebView.postMessage(JSON.stringify(data));
  </script>`;
      html += "</html>";
      return {
        status: 0,
        html: html,
      };
    }

    let html = `
  <!DOCTYPE html>
  <html lang="en">
  <head>
  <meta http-equiv="Content-Security-Policy" content="script-src 'unsafe-inline' 'nonce-${nonce}'">
  </head>
  `;
    html += `<h1>${result.statusMessage}</h1>`;
    html += `<script nonce="${nonce}" type="text/javascript">
  data = {
      "message" : "${result.statusMessage}",
      "status" : -1,
  }
  window.ReactNativeWebView.postMessage(JSON.stringify(data));
</script>`;
    html += "</html>";
    return {
      status: -1,
      html: html,
    };
  } catch (err) {
    console.error(err);
    return {
      status: -1,
      message: "Something went wrong.",
    };
  }
};

const express_executeAgreement = async (payment_id, subscription_type_id, user_id) => {
  try {
    let is_premium_user,
      subsPayment,
      userUpdate,
      subscription_expire_date_time,
      subscription_type_name;
    const token = await getExpressUserPaymentToken(payment_id);
    const request_data = {
      paymentID: payment_id,
    };

    const request_headers = {
      "Content-Type": "application/json",
      Authorization: token,
      "X-app-key": BKASH_APP_KEY,
    };

    const response = await fetch(BKASH_EXECUTE_URL, {
      method: "post",
      headers: request_headers,
      body: JSON.stringify(request_data),
    });

    const result = await response.json();

    console.log("BKASH RESULT", result);

    const nonce = crypto.randomBytes(16).toString("base64");
    if (result.statusMessage === "Successful" && result.agreementStatus === "Completed") {
      if (subscription_type_id) {
        console.log("subscription_type_id", subscription_type_id);
        const subs_data = await Send_Queue(
          "main_user_request",
          "payment_queue",
          { _id: subscription_type_id },
          "SubscriptionType",
          "get"
        );
        is_premium_user = subs_data.data.is_premium;
        subscription_type_name = subs_data.data.name;
        let expiry_day = subs_data.data.subscribe_for_in_days;
        subscription_expire_date_time = moment().add(expiry_day, "days").toDate();
        subsPayment = await Send_Queue(
          "main_user_request",
          "payment_queue",
          {
            condition: {
              customer_id: user_id,
              subscription_type_id: subscription_type_id,
            },
            data: {
              customer_id: user_id,
              amount: subs_data.data.subscription_fee,
              transaction_id: result.paymentID,
              subscription_type_id: subscription_type_id,
              created_by: user_id,
              updated_by: user_id,
            },
          },
          "SubscriptionPayment",
          "edit_add_condition"
        );
        userUpdate = await Send_Queue(
          "main_user_request",
          "payment_queue",
          {
            _id: user_id,
            subscription_type_id: subscription_type_id,
            subscription_expire_date_time: subscription_expire_date_time,
            created_by: user_id,
            updated_by: user_id,
          },
          "UserModel",
          "edit"
        );
      }

      console.log("aggremenID", result.agreementID);
      let html = `
    <!DOCTYPE html>
    <html lang="en">
    <head>
    <meta http-equiv="Content-Security-Policy" content="script-src 'unsafe-inline' 'nonce-${nonce}'">
    </head>
    `;
      html += `<h1>${result.statusMessage}</h1>`;
      html += `<script nonce="${nonce}" type="text/javascript">
    data = {
        "message" : "${result.statusMessage}",
        "active_status": true,
        "subscription_type_id": "${subscription_type_id}",
        "subscription_type_name":  "${subscription_type_name}",
         "is_premium_user": ${is_premium_user},
        "payment_id": "${payment_id}",
        "transaction_id": "${result.trxID}",
        "agreement_id": "${result.agreementID}",
        "customerMsisdn": "${result.customerMsisdn}",
        "status" : 0,
    }
    window.ReactNativeWebView.postMessage(JSON.stringify(data));
  </script>`;
      html += "</html>";
      return {
        status: 0,
        html: html,
      };
    }

    let html = `
  <!DOCTYPE html>
  <html lang="en">
  <head>
  <meta http-equiv="Content-Security-Policy" content="script-src 'unsafe-inline' 'nonce-${nonce}'">
  </head>
  `;
    html += `<h1>${result.statusMessage}</h1>`;
    html += `<script nonce="${nonce}" type="text/javascript">
  data = {
      "message" : "${result.statusMessage}",
      "status" : -1,
  }
  window.ReactNativeWebView.postMessage(JSON.stringify(data));
</script>`;
    html += "</html>";
    return {
      status: -1,
      html: html,
    };
  } catch (err) {
    console.error(err);
    return {
      status: -1,
      message: "Something went wrong.",
    };
  }
};

const cancelAgreement = async (req, res, next) => {
  let body = req.body;
  let agreement_id = body.agreement_id;

  try {
    //   Call for grant
    let request_data = {
      app_key: BKASH_APP_KEY,
      app_secret: BKASH_APP_SECRET,
    };

    let request_headers = {
      "Content-Type": "application/json",
      username: BKASH_USERNAME,
      password: BKASH_PASSWORD,
    };

    let response = await fetch(BKASH_GRANT_URL, {
      method: "post",
      headers: request_headers,
      body: JSON.stringify(request_data),
    });

    let result = await response.json();

    if (result.statusMessage === "Successful") {
      // cancel agreement
      let request_data = {
        agreementID: agreement_id,
      };

      let request_headers = {
        "Content-Type": "application/json",
        Authorization: id_token,
        "X-App-Key": BKASH_APP_KEY,
      };

      let response = await fetch(BKASH_CANCEL_AGREEMENT_URL, {
        method: "post",
        headers: request_headers,
        body: JSON.stringify(request_data),
      });

      let result = await response.json();

      if (result && result.statusMessage === "Successful") {
        if (await deleteAgreement(agreement_id)) {
          return res.json({
            status: 0,
            message: result.statusMessage,
          });
        } else {
          return res.json({
            status: -1,
            message: "Something went wrong.",
          });
        }
      } else {
        return res.json({
          status: -1,
          message: result.statusMessage,
        });
      }
    }

    // if fail
    return res.json({
      status: -1,
      message: result.statusMessage,
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ status: -1, msg: "Server error", err: err.toString() });
  }
};

const deleteAgreement = async (agreement_id) => {
  return await BkashAgreementModel.deleteOne({ agreement_id: agreement_id });
};

const saveAgreement = async (req, res, next) => {
  try {
    let body = req.body;
    let user_id = body.id;
    let msisdn = body.msisdn;
    let agreement_id = body.agreement_id;

    const save_agreement = await BkashAgreementModel.create({
      user_id: user_id,
      msisdn: msisdn,
      agreement_id: agreement_id,
    });

    if (save_agreement) {
      return res.json({ status: 0, msg: "success", data: save_agreement });
    } else {
      return res.json({ status: -1, msg: "Failed" });
    }
  } catch (err) {
    console.error(err);
    return res.status(500).json({ status: -1, msg: "Server error", err: err.toString() });
  }
};
const getAgreement = async (req, res, next) => {
  let body = req.body;
  try {
    const agreement_data = await BkashAgreementModel.find({ user_id: body.id });
    return res.json({
      status: 0,
      data: agreement_data,
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ status: -1, msg: "Server error", err: err.toString() });
  }
};

const getUserPaymentToken = async (payment_id) => {
  const cart_data = await Send_Queue(
    "main_restaurant_request",
    "payment_queue",
    { bkash_payment_id: payment_id },
    "CartModel",
    "get"
  );
  if (!cart_data || !cart_data.data) {
    return false;
  }
  return cart_data.data.bkash_token;
};
const getExpressUserPaymentToken = async (payment_id) => {
  const subs_data = await Send_Queue(
    "main_user_request",
    "payment_queue",
    { bkash_payment_id: payment_id },
    "SubscriptionPayment",
    "get_condition"
  );

  if (!subs_data || !subs_data.data) {
    return false;
  }
  return subs_data.data.bkash_token;
};

const saveUserToken = async (user_id, token, subscription_type_id) => {
  let save_token;
  if (subscription_type_id) {
    save_token = await Send_Queue(
      "main_user_request",
      "payment_queue",
      {
        condition: { customer_id: user_id, subscription_type_id: subscription_type_id },
        data: {
          bkash_token: token,
          customer_id: user_id,
          subscription_type_id: subscription_type_id,
          created_by: user_id,
          updated_by: user_id,
        },
      },
      "SubscriptionPayment",
      "edit_add_condition"
    );
    console.log("save_token", save_token);
  } else {
    save_token = await Send_Queue(
      "main_restaurant_request",
      "payment_queue",
      {
        condition: { customer_id: user_id },
        data: {
          bkash_token: token,
        },
      },
      "CartModel",
      "edit_condition"
    );
  }

  return save_token.status === "success" ? 1 : 0;
};

const saveUserPaymentID = async (user_id, payment_id, subscription_type_id) => {
  let save_token;

  console.log("Payment ID", payment_id);
  if (subscription_type_id) {
    save_token = await Send_Queue(
      "main_user_request",
      "payment_queue",
      {
        condition: { customer_id: user_id, subscription_type_id: subscription_type_id },
        data: {
          bkash_payment_id: payment_id,
          customer_id: user_id,
          subscription_type_id: subscription_type_id,
          created_by: user_id,
          updated_by: user_id,
        },
      },
      "SubscriptionPayment",
      "edit_add_condition"
    );
  } else {
    save_token = await Send_Queue(
      "main_restaurant_request",
      "payment_queue",
      {
        condition: { customer_id: user_id },
        data: {
          bkash_payment_id: payment_id,
        },
      },
      "CartModel",
      "edit_condition"
    );
  }

  return save_token.status === "success" ? 1 : 0;
};

// cbk urls
const callback = async (req, res) => {
  try {
    console.log("CALLBACKREQ", req);
    let status = req.query.status;
    let payment_id = req.query.paymentID;

    if (payment_id && status === "success") {
      return res.send(await executeAgreement(payment_id).html);
    } else {
      const nonce = crypto.randomBytes(16).toString("base64");

      let html = `
  <!DOCTYPE html>
  <html lang="en">
  <head>
  <meta http-equiv="Content-Security-Policy" content="script-src 'unsafe-inline' 'nonce-${nonce}'">
  </head>
  `;
      html += `<h1>${status}</h1>`;
      html += `<script nonce="${nonce}" type="text/javascript">
  data = {
      "message" : "${status}",
      "payment_id": "${payment_id}",
      "status" : -1,
  }
  window.ReactNativeWebView.postMessage(JSON.stringify(data));
</script>`;
      html += "</html>";

      return res.send(html);
    }
  } catch (err) {
    console.error(err);
  }
};

const express_callback = async (req, res) => {
  try {
    console.log("BKASH REQ", req);
    let status = req.query.status;
    let payment_id = req.query.paymentID;
    const subscription_type_id = req.query.subscription_type_id;
    const user_id = req.query.user_id;
    console.log("subscription_type_id", subscription_type_id);
    if (payment_id && status === "success") {
      return res.send(
        await express_executeAgreement(payment_id, subscription_type_id, user_id).html
      );
    } else {
      const nonce = crypto.randomBytes(16).toString("base64");

      let html = `
  <!DOCTYPE html>
  <html lang="en">
  <head>
  <meta http-equiv="Content-Security-Policy" content="script-src 'unsafe-inline' 'nonce-${nonce}'">
  </head>
  `;
      html += `<h1>${status}</h1>`;
      html += `<script nonce="${nonce}" type="text/javascript">
  data = {
      "message" : "${status}",
      "payment_id": "${payment_id}",
      "status" : -1,
  }
  window.ReactNativeWebView.postMessage(JSON.stringify(data));
</script>`;
      html += "</html>";
      return res.send(html);
    }
  } catch (err) {
    console.error(err);
  }
};

export default {
  grant,
  createAgreement,
  cancelAgreement,
  saveAgreement,
  getAgreement,
  callback,
  express_callback,
};
