import moment from "moment/moment";
import * as crypto from "crypto";
import { Send_Queue } from "../helper/common/RMQ";

const UPAY_URL = process.env.UPAY_URL;
const UPAY_MERCHANT_ID = process.env.UPAY_MERCHANT_ID;
const UPAY_MERCHANT_KEY = process.env.UPAY_MERCHANT_KEY;
const UPAY_REDIRECT_URL = process.env.UPAY_REDIRECT_URL;
const UPAY_MERCHANT_NAME = process.env.UPAY_MERCHANT_NAME;
const UPAY_MERCHANT_CODE = process.env.UPAY_MERCHANT_CODE;
const UPAY_MERCHANT_COUNTRY_CODE = process.env.UPAY_MERCHANT_COUNTRY_CODE;
const UPAY_MERCHANT_CITY = process.env.UPAY_MERCHANT_CITY;
const UPAY_MERCHANT_CATEGORY_CODE = process.env.UPAY_MERCHANT_CATEGORY_CODE;
const UPAY_MERCHANT_MOBILE = process.env.UPAY_MERCHANT_MOBILE;
const UPAY_TRANSACTION_CURRENCY_CODE = process.env.UPAY_TRANSACTION_CURRENCY_CODE;

const init = async (req, res) => {
  let body = req.body,
    total_amount;

  if (body.subscription_type_id) {
    const subs_data = await Send_Queue(
      "main_user_request",
      "payment_queue",
      { _id: body.subscription_type_id },
      "SubscriptionType",
      "get"
    );
    if (!subs_data || !subs_data.data) {
      return res.json({
        status: -1,
        msg: "Sorry ! No subscription found with this id",
      });
    }
    total_amount = subs_data.data.subscription_fee;
  } else {
    const cart_data = await Send_Queue(
      "main_restaurant_request",
      "payment_queue",
      { customer_id: body.id },
      "CartModel",
      "get"
    );
    if (!cart_data || !cart_data.data) {
      return res.json({
        status: -1,
        msg: "Add menu to cart first",
      });
    }
    total_amount = cart_data.data.total_amount;
  }

  try {
    let request_data = {
      merchant_id: UPAY_MERCHANT_ID,
      merchant_key: UPAY_MERCHANT_KEY,
    };

    let request_headers = {
      "Content-Type": "application/json",
    };

    console.log("request_data :", request_data);
    let response = await fetch(UPAY_URL, {
      method: "post",
      headers: request_headers,
      body: JSON.stringify(request_data),
    });

    let result = await response.json();
    console.log("result :", result);

    if (result?.data?.token) {
      let token = result.data.token;
      return res.send(await create(token, total_amount));
    } else {
      return res.json({
        status: -1,
        msg: result.data.message,
      });
    }
  } catch (err) {
    console.error(err);
    return res.status(500).json({ status: -1, msg: "Server error", err: err.toString() });
  }
};

const create = async (token, total_amount) => {
  let date = moment(new Date()).format("YYYY-MM-DD");
  let transaction_id = Math.floor(Math.random() * 10000000);
  let invoice_id = Math.floor(Math.random() * 100000000);
  try {
    let request_data = {
      date: date,
      txn_id: transaction_id,
      invoice_id: invoice_id,
      amount: parseInt(total_amount),
      merchant_id: UPAY_MERCHANT_ID,
      merchant_name: UPAY_MERCHANT_NAME,
      merchant_code: UPAY_MERCHANT_CODE,
      merchant_country_code: UPAY_MERCHANT_COUNTRY_CODE,
      merchant_city: UPAY_MERCHANT_CITY,
      merchant_category_code: UPAY_MERCHANT_CATEGORY_CODE,
      merchant_mobile: UPAY_MERCHANT_MOBILE,
      transaction_currency_code: UPAY_TRANSACTION_CURRENCY_CODE,
      redirect_url: UPAY_REDIRECT_URL,
    };

    let request_headers = {
      Authorization: `UPAY ${token}`,
    };
    console.log("token: ", `UPAY ${token}`);

    console.log("UPAY_URL :", UPAY_URL);
    console.log("request_data :", JSON.stringify(request_data));
    let response = await fetch(UPAY_URL, {
      method: "post",
      headers: request_headers,
      body: JSON.stringify(request_data),
    });
    let result = await response.json();
    console.log("result :", result);

    // if (response.status != 200) {
    //   return {
    //     status: -1,
    //     msg: "Something went wrong.",
    //   };
    // }

    if (result && result.gateway_url) {
      return {
        status: 0,
        data: result.gateway_url,
      };
    } else {
      return {
        status: -1,
        msg: "Fail",
        data: result,
      };
    }
  } catch (err) {
    console.error(err);
    return {
      status: -1,
      message: "Something went wrong",
    };
  }
};

const redirect = async (req, res) => {
  let body = req.body;
  let invoice_id = body.invoice_id;
  let status = body.status;

  const nonce = crypto.randomBytes(16).toString("base64");

  let html = `
  <!DOCTYPE html>
  <html lang="en">
  <head>
  <meta http-equiv="Content-Security-Policy" content="script-src 'unsafe-inline' 'nonce-${nonce}'">
  </head>
  `;
  html += `<h1>${status}</h1>`;
  html += `<script nonce="${nonce}" type="text/javascript">
  data = {
      "message" : ${status},
      "invoice_id": ${invoice_id},
      "paymentRefID": ${result.paymentRefId},
      "status" : ${status === "successful" ? 1 : 0},
  }
  window.ReactNativeWebView.postMessage(JSON.stringify(data));
</script>`;
  html += "</html>";
  return res.send(html);
};

export default {
  init,
  redirect,
};
