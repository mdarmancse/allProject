import app from "./app";
import { Server } from "socket.io";
import { createServer } from "http";
import { locationSave } from "./controllers/RiderController";

const PORT = process.env.PORT || 8080;

const httpServer = createServer(app);
global.io = new Server(httpServer, {
  cors: {
    origin: "*",
  },
});

// Create a room for a specific rider

global.io.sockets.on("connection", (socket) => {
  console.log("A rider Connected");

  socket.on("location-save", (data) => {
    locationSave(socket, data);
  });
});

// import cluster from "cluster";
// import os from "os";
// const totalCPUs  = os.cpus().length;
//
// if (cluster.isMaster) {
//   console.log(`Number of CPUs is ${totalCPUs}`);
//   console.log(`Master ${process.pid} is running`);
//   // Fork workers.
//   for (let i = 0; i < totalCPUs; i++) {
//     cluster.fork();
//   }
//   cluster.on("exit", (worker, code, signal) => {
//     console.log(`worker ${worker.process.pid} died`);
//     console.log("Let's fork another worker!");
//     cluster.fork();
//   });
// } else {
//   console.log(`Worker ${process.pid} started`);
//   app.listen(PORT, () => {
//     console.log("User Service Run @ " + PORT);
//   });
// }

httpServer.listen(PORT, () => {
  console.log("Rider Service Run @ " + PORT);
});
