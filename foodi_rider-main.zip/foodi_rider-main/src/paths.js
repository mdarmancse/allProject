import {
  registration,
  login,
  verifyOTP,
  user_details,
} from "./controllers/RiderController";

const paths = {
  registration: registration,
  login: login,
  verifyOTP: verifyOTP,
  user_details: user_details,
};

export default async (path, body) => {
  let response;
  try {
    response = paths[path](body);
    if (response) return response;
  } catch (err) {
    console.error(err);
    return {
      status: -1,
      msg: "Gateway not found",
    };
  }
};
