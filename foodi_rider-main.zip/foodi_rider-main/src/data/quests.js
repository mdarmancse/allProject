export const quest_status = {
  ongoing: "OnGoing",
  to_be_started: "To be started",
  expired: "Expired",
};
