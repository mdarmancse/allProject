import jwt from "jsonwebtoken";
import { isTokenRevoked } from "../utility/functions.js";

const optional_routes = [];

export default async (req, res, next) => {
  try {
    console.log("req :", req.originalUrl);
    console.log("reqa :", optional_routes.includes(req.originalUrl));

    const bearerHeader = req.headers["authorization"];

    if (typeof bearerHeader !== "undefined") {
      const bearer = bearerHeader.split(" ");
      const bearerToken = bearer[1];

      try {
        const decoded = jwt.verify(bearerToken, "foodi@#$2020");
        const isRevoked = await isTokenRevoked(bearerToken);
        console.log("isRevoked", isRevoked);

        if (isRevoked) {
          return res.status(401).json({
            status: -1,
            msg: "Your session has expired. Please log in again.",
          });
        }

        const id = decoded.data.id;
        req.body.id = id;
        next();
      } catch (err) {
        res.status(401).json({ status: "Unauthorized" });
      }
    } else {
      if (optional_routes.includes(req.originalUrl)) {
        next();
      } else {
        res.status(403).json({ status: "Access Denied" });
      }
    }
  } catch (err) {
    res.status(500).json({ status: "Server Error" });
  }
};
