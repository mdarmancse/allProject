import Validator from "validatorjs";

export const userBasicRules = {
  first_name: "required|max:15",
  last_name: "required|max:15",
  mobile_number: "required|max:11",
  password: "required|min:6",
};

export const riderOrderRules = {
  order_id: "required|max:50",
  id: "required|max:50",
};

export const validator = async (body, rules, customMessages, callback) => {
  const validation = new Validator(body, rules, customMessages);
  validation.passes(() => callback(null, true));
  validation.fails(() => callback(validation.errors, false));
};
