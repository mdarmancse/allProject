const ListOneJoinService = async (match, DataModel, JoinStage, projection) => {
  try {
    let data;
    data = await DataModel.aggregate([match, JoinStage, projection]);

    return data;
  } catch (error) {
    return { status: "fail", data: error.toString() };
  }
};
export default ListOneJoinService;
