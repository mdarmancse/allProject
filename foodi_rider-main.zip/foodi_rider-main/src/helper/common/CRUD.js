import RiderModel from "../../models/Riders/RiderModel.js";
import RiderReviews from "../../models/Riders/RiderReviews.js";
import RidersOrder from "../../models/Orders/RidersOrder.js";
import RidersShift from "../../models/Shift/RidersShift.js";
import VehicleType from "../../models/Riders/VehicleType.js";
import GeneratedQuest from "../../models/quests/GeneratedQuest.js";
import QuestModel from "../../models/quests/QuestModel.js";
import RidersWallet from "../../models/Wallet/RidersWallet.js";
import OrderStatusHistory from "../../models/Orders/OrderStatusHistory.js";
import RidersOrderMap from "../../models/Orders/RidersOrderMap.js";
import RiderGoalOrderCompletionModel from "../../models/quests/RiderGoalOrderCompletionModel.js";
import { sendRiderNotifications } from "./Notifications.js";
import GenerateQuests from "../GenerateQuests.js";
import moment from "moment";
import { SYSTEM_TIMEZONE } from "../../consts/defaults.js";
import PayablesModel from "../../models/Wallet/PayablesModel.js";
import RiderNotifications from "../../models/Notifications/RiderNotifications.js";
import Notifications from "../../models/Notifications/Notifications.js";

const models = {
  OrderStatusHistory: OrderStatusHistory,
  RidersOrderMap: RidersOrderMap,
  RiderModel: RiderModel,
  RiderReviews: RiderReviews,
  RidersOrder: RidersOrder,
  Notifications: Notifications,
  RidersShift: RidersShift,
  VehicleType: VehicleType,
  RidersWallet: RidersWallet,
  QuestModel: QuestModel,
  RiderGoalOrderCompletionModel: RiderGoalOrderCompletionModel,
  GeneratedQuest: GeneratedQuest,
};
export const SocketService = async (Request, DataModel) => {
  try {
    let PostBody = Request;

    console.log("POSTBODY", PostBody);

    let MODEL = models[DataModel];
    let data = await MODEL.create(PostBody);
    console.log("DATA", data);
    if (data) {
      const rider_id = data.rider_id;
      let lastAssignedOrderData = null;

      // global.io.sockets.sockets.forEach((socket) => {
      //     const socketRiderId = socket.handshake.headers.cookie?.match(/rider_id=([^;]*)/)?.[1];
      //     if (socketRiderId === rider_id) {
      //         socket.join(`rider-${socketRiderId}`);
      //         global.io.to(`rider-${socketRiderId}`).emit('order-assigned', data);
      //     }
      // });
      global.io.sockets.sockets.forEach((socket) => {
        const socketRiderId =
          socket.handshake.headers.cookie?.match(/rider_id=([^;]*)/)?.[1];
        if (socketRiderId === rider_id) {
          socket.join(`rider-${socketRiderId}`);
          socket.once("order-assigned", (receivedData) => {
            // Handle the received data
            // ...
            console.log("Received order-assigned data:", receivedData);
          });
          socket.emit("order-assigned", data); // Send data directly to the socket
        }
      });

      const rider_device_id = await RiderModel.findById(rider_id, {
        device_id: 1,
      });
      console.log("rider_device_id", rider_device_id);
      if (rider_device_id) {
        let message = {
          notification: {
            title: "You have a new order",
            body: "Please accept the order",
          },
          data: {
            order_id: data.order_id,
          },
          android: {
            notification: {
              sound: "sdr",
              channelId: "order",
            },
          },
          token: rider_device_id.device_id,
        };
        console.log("PUSH NOTI_MSG", message);
        let push = await sendRiderNotifications(message);
        console.log("NEW PUSH NOTI", push);
      }

      return { status: "success", data: data };
    } else {
      return { status: "failed" };
    }
  } catch (error) {
    console.error(error);
    return { status: "failed" };
  }
};

export const CreateService = async (Request, DataModel) => {
  try {
    if (DataModel == "Notification") {
      let push_noti = await RiderNotifications.insertMany(Request.riders);
      if (push_noti) {
        let tokens = Request.riders.map((item) => item.device_id);
        let message = {
          notification: {
            title: Request.title,
            body: Request.description,
            image: Request.image,
          },
          data: {
            screenType: "notification",
          },
          tokens: tokens,
        };
        await sendNotifications(message);
        // console.log("tokens",tokens)
        // console.log("push_noti",push_noti)
        // console.log("Request.image",Request.image)
      }
    }

    if (DataModel == "RiderWallet") {
      let riderWalletModel = Request.rider_wallet;
      let payablesModel = Request.payables;
      let data = await UpdateService(Request.rider, "RiderModel");
      if (riderWalletModel) await RidersWallet.create(riderWalletModel);
      if (payablesModel) await PayablesModel.insertMany(payablesModel);

      if (data)
        return {
          status: "success",
          rider: data.data,
          riderWalletModel: riderWalletModel,
          payablesModel: payablesModel,
        };
    }

    let MODEL = models[DataModel];
    console.log("Request", Request);
    try {
      let data = await MODEL.create(Request);
      if (data) return { status: "success", data: data };
    } catch (err) {
      console.error(err);
      return { status: "failed", err: err.toString() };
    }
  } catch (error) {
    console.error(error);
    return { status: "failed", err: error.toString() };
  }
};

export const UpdateService = async (Request, DataModel) => {
  try {
    let MODEL = models[DataModel];
    let data = await MODEL.findOneAndUpdate(
      { _id: Request._id },
      { $set: Request },
      { returnOriginal: false }
    );
    if (data) return { status: "success", data: data };
  } catch (error) {
    return { status: "failed", error: error.toString() };
  }
};

export const DeleteService = async (Request, DataModel) => {
  try {
    let MODEL = models[DataModel];
    const data = await MODEL.deleteMany(Request);

    if (data) return { status: "success", data: data };
  } catch (error) {
    return { status: "failed", error: error.toString() };
  }
};

export const GetService = async (Request, DataModel) => {
  try {
    let MODEL = models[DataModel];
    let data = await MODEL.findOne({ _id: Request._id }, Request.project);
    if (data) return { status: "success", data: data };
  } catch (error) {
    return { status: "failed" };
  }
};

export const CheckRiderService = async (Request, DataModel) => {
  try {
    let data = await RiderModel.aggregate([
      {
        $match: {
          _id: { $in: Object.keys(Request.rider_json) },
          zones: {
            $elemMatch: {
              zone_id: Request.zone_id,
            },
          },
        },
      },
      {
        $lookup: {
          from: "riders_shift",
          let: { riderId: "$_id" },
          pipeline: [
            {
              $match: {
                $expr: {
                  $and: [
                    { $eq: ["$rider_id", "$$riderId"] },
                    { $eq: ["$is_active", true] },
                    {
                      $gte: [
                        "$start_time",
                        moment()
                          .startOf("day")
                          .add(SYSTEM_TIMEZONE.HOURS, "hours")
                          .toDate(),
                      ],
                    },
                    {
                      $lte: [
                        "$end_time",
                        moment()
                          .endOf("day")
                          .add(SYSTEM_TIMEZONE.HOURS, "hours")
                          .toDate(),
                      ],
                    },
                  ],
                },
              },
            },
          ],
          as: "shift",
        },
      },
      {
        $lookup: {
          from: "vehicle_type",
          localField: "vehicle_type_id",
          foreignField: "_id",
          pipeline: [
            {
              $project: {
                maximum_no_of_received_order_at_a_time: 1,
              },
            },
          ],
          as: "vehicle_type",
        },
      },
      {
        $project: {
          _id: 1,
          first_name: 1,
          last_name: 1,
          mobile_number: 1,
          // rider_max_order: "$vehicle_type",
          rider_max_order: {
            $arrayElemAt: [
              "$vehicle_type.maximum_no_of_received_order_at_a_time",
              0,
            ],
          },
          is_available: {
            $and: [
              { $eq: ["$is_active", true] },
              { $eq: ["$is_approve", true] },
              { $eq: ["$is_verified", true] },
              { $gt: [{ $size: "$shift" }, 0] },
            ],
          },
        },
      },
    ]);
    if (data) {
      return { status: "success", data: data };
    } else {
      return { status: "success", data: null };
    }
  } catch (error) {
    return { status: "failed" };
  }
};
