// import admin from "firebase-admin";
//
// import serviceAccount from '../../../serviceAccountKeyRider.json?v=1' assert { type: 'json' };
//
//
// admin.initializeApp({
//     credential: admin.credential.cert(serviceAccount)
// });
// export const sendNotifications = async (message) => {
//   try {
//       const response = await admin.messaging().send(message);
//       console.log('Successfully sent message:', response);
//       return {status :"success",data:response}
//   } catch (error) {
//     return { status: "failed" };
//   }
// };
