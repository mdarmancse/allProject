import mongoose from "mongoose";
export async function runTransaction(operations) {
  const session = await mongoose.startSession();
  session.startTransaction();
  try {
    for (const operation of operations) {
      await operation(session);
    }
    await session.commitTransaction();
    session.endSession();
  } catch (error) {
    await session.abortTransaction();
    session.endSession();
    throw error;
  }
}

// Usage
// await runTransaction([
//     async (session) => {
//         if (riderWalletModel) await RidersWallet.create(riderWalletModel, { session });
//     },
//     async (session) => {
//         if (payablesModel) await PayablesModel.insertMany(payablesModel, { session });
//     },
// ]);
n;
