import * as dotenv from "dotenv";
import Quest from "../models/quests/QuestModel.js";
import moment from "moment";
import { SYSTEM_TIMEZONE } from "../consts/defaults.js";
import GeneratedQuest from "../models/quests/GeneratedQuest.js";
import { v4 as uuidv4 } from "uuid";
import { Send_Queue } from "./common/RMQ.js";
import { ResponseVariant } from "./ResponseVariant.js";

dotenv.config();

const GOOGLE_API_KEY = process.env.GOOGLE_API_KEY;

const GenerateQuests = async () => {
  try {
    let quest_data = [];
    const quests = await Quest.find({});

    // Loop through each day for the next 7 days
    for (let i = 0; i < 7; i++) {
      const day = moment()
        .add(i, "days")
        .add(SYSTEM_TIMEZONE.HOURS, "hours")
        .format("YYYY-MM-DD");

      for (const quest of quests) {
        // Check if the quest end date is not before the current day
        if (moment(quest.end_date).isSameOrAfter(day, "day")) {
          if (quest.has_time_limit) {
            // If the quest has a time limit
            const startDateTime = moment(
              `${day} ${quest.start_time}`,
              "YYYY-MM-DD HH:mm"
            )
              .add(SYSTEM_TIMEZONE.HOURS, "hours")
              .toDate();
            const endDateTime = moment(
              `${day} ${quest.end_time}`,
              "YYYY-MM-DD HH:mm"
            )
              .add(SYSTEM_TIMEZONE.HOURS, "hours")
              .toDate();

            // Check if there is already a quest generated for the day with the same start time
            const existingQuest = await GeneratedQuest.findOne({
              quest_id: quest._id,
              start_date_time: startDateTime,
            });

            // If no existing quest is found, create a new one
            if (!existingQuest) {
              if (quest.goals.length > 0) {
                for (let i = 0; i < quest.goals.length; i++) {
                  quest.goals[i]._id = uuidv4();
                  quest.goals[i].generated_quest_id = quest.goals[i].quest_id;
                  delete quest.goals[i].quest_id;
                }
              }

              if (quest.zones.length > 0) {
                for (let i = 0; i < quest.zones.length; i++) {
                  quest.zones[i]._id = uuidv4();
                  quest.zones[i].generated_quest_id = quest.zones[i].quest_id;
                  delete quest.zones[i].quest_id;
                }
              }

              let GQ = await GeneratedQuest.create({
                _id: uuidv4(),
                quest_id: quest._id,
                name: quest.name,
                acceptable_acceptance_rate: quest.acceptable_acceptance_rate,
                acceptable_completion_rate: quest.acceptable_completion_rate,
                start_date_time: startDateTime,
                end_date_time: endDateTime,
                rules: quest.rules,
                zones: quest.zones,
                goals: quest.goals,
                is_active: quest.is_active,
                created_at: new Date(),
                updated_at: new Date(),
                created_by: "43615def-456d-44c9-abf3-08db65a648fb",
                updated_by: "43615def-456d-44c9-abf3-08db65a648fb",
              });

              quest_data.push(GQ);
            }
          } else {
            // If the quest does not have a time limit
            const existingQuest = await GeneratedQuest.findOne({
              quest_id: quest._id,
            });

            // If no existing quest is found, create a new one
            if (!existingQuest) {
              await GeneratedQuest.create({
                _id: uuidv4(),
                quest_id: quest._id,
                name: quest.name,
                acceptable_acceptance_rate: quest.acceptable_acceptance_rate,
                acceptable_completion_rate: quest.acceptable_completion_rate,
                start_date_time: quest.start_date,
                end_date_time: quest.end_date,
                rules: quest.rules,
                zones: quest.zones,
                goals: quest.goals,
                is_active: quest.is_active,
                created_at: new Date(),
                updated_at: new Date(),
              });
            }
          }
        }
      }
    }

    // return res.json(quest_data)

    if (quest_data.length > 0) {
      await Send_Queue(
        cms_queue,
        "rider_queue",
        quest_data,
        "generated_quest",
        "add"
      );
    }

    return true;
  } catch (err) {
    console.error(err);
    return false;
  }
};

export default GenerateQuests;
