import redis from "ioredis";
import dotenv from "dotenv";
dotenv.config();
const redis_client = redis.createClient({
  host: process.env.REDIS_URL,
  port: process.env.REDIS_PORT,
  password: process.env.REDIS_PASS,
  enableOfflineQueue: false,
});
export const redis_set = (key, id, data) => {
  console.log("host", process.env.REDIS_URL);
  return redis_client.hset(key, id, JSON.stringify(data));
};

export const redis_get = (key, id) => {
  return redis_client.hget(key, id);
};

export const redis_delete_by_id = (key, id) => {
  return redis_client.del(key, id);
};

export const redis_delete = (key) => {
  return redis_client.del(key);
};
