export const ResponseVariant = {
  success: (data = []) => {
    return {
      status: 0,
      msg: "Success",
      data: data,
    };
  },
  fail: (msg = "failed") => {
    return {
      status: -1,
      msg: msg,
    };
  },
  error: (msg = "Something went wrong.") => {
    return {
      status: -1,
      msg: msg,
    };
  },
};
