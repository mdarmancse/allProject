import Express, { Router } from "express";
import Auth from "../middleware/AuthVerifier.js";
import {
  calculateRiderIncentives,
  earningReportByDate,
  forgot_password,
  getCurrentLocationRider,
  locationSave,
  login,
  logout,
  paymentreport,
  registration,
  reset_password,
  updateProfile,
  verifyOTP,
  wallet,
  zoneByRider,
} from "../controllers/RiderController.js";

import {
  addReview,
  changeStatus,
  hitMap,
  orderDetails,
  orderHistory,
  orderList,
} from "../controllers/OrderController.js";
import multer from "multer";
import {
  availableShift,
  bookedShift,
  bookingStatus,
  checkShift,
  createBooking,
  endShift,
  evaluateStatus,
  myShift,
  resumePauseShift,
  shiftDetails,
  startShift,
  upcomingShift,
} from "../controllers/ShiftController.js";
import GenerateImageLink from "../helper/GenerateImageLink.js";
import fs from "fs";
import {
  generateQuests,
  getCurrentQuestList,
  getPastQuestList,
  getQuestDetails,
} from "../controllers/QuestContoller.js";
// Import socket.io
// import { Server } from "socket.io";
// import { createServer } from "http";
// const app = new Express();
// const httpServer = createServer(app);
// const io = new Server(httpServer, {
//     cors: {
//         origin: "*",
//     },
// });
//
// // Listen to the connection event
// io.on("connection", (socket) => {
//     console.log(`A client has connected with id: ${socket.id}`);
// });

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, "uploads/");
  },
  filename: function (req, file, cb) {
    cb(null, file.fieldname + "-" + Date.now());
  },
});

const upload = multer({
  storage: storage,
  // fileFilter: function (req, file, cb) {
  //     if (!file.mimetype.startsWith('image/')) {
  //         return cb(new Error('Only image files are allowed!'))
  //     }
  //     cb(null, true)
  // }
});
//
// const upload = multer({ dest: 'uploads/' });
const router = Router();
router
  .post(
    "/registration",
    upload.fields([
      { name: "image", maxCount: 1 },
      { name: "nid_front", maxCount: 1 },
      { name: "nid_back", maxCount: 1 },
      { name: "referer_nid_front", maxCount: 1 },
      { name: "referer_nid_back", maxCount: 1 },
      { name: "guardian_nid_front", maxCount: 1 },
      { name: "guardian_nid_back", maxCount: 1 },
      { name: "electricity_bill", maxCount: 1 },
      { name: "driving_license_image", maxCount: 1 },
      { name: "vehicle_registration_image", maxCount: 1 },
    ]),
    registration
  )
  .put(
    "/updateProfile",
    upload.fields([
      { name: "image", maxCount: 1 },
      { name: "nid_front", maxCount: 1 },
      { name: "nid_back", maxCount: 1 },
      { name: "referer_nid_front", maxCount: 1 },
      { name: "referer_nid_back", maxCount: 1 },
      { name: "guardian_nid_front", maxCount: 1 },
      { name: "guardian_nid_back", maxCount: 1 },
      { name: "electricity_bill", maxCount: 1 },
      { name: "driving_license_image", maxCount: 1 },
      { name: "vehicle_registration_image", maxCount: 1 },
    ]),
    Auth,
    updateProfile
  )
  .post("/login", login)
  .post("/forgot_password", forgot_password)
  .post("/reset_password", reset_password)
  .post("/verifyOTP", verifyOTP)
  .get("/logout", Auth, logout)
  .post("/wallet", Auth, wallet)
  .post("/order/details", Auth, orderDetails)
  .get("/order/list", Auth, orderList)
  .post("/order/history", Auth, orderHistory)
  .post("/order/hitMap", Auth, hitMap)
  .post("/changeStatus", upload.single("image"), Auth, changeStatus)
  .post("/review/add", Auth, addReview)
  .post("/shift/start", Auth, startShift)
  .put("/shift/end/:shift_id", Auth, endShift)
  .put("/shift/resumePause", Auth, resumePauseShift)
  .get("/shift/check", Auth, checkShift)
  .post("/shift/available", Auth, availableShift)
  .post("/shift/booked", Auth, bookedShift)
  .post("/shift/booking", Auth, createBooking)
  .post("/shift/myshift", Auth, myShift)
  .get("/shift/upcoming", Auth, upcomingShift)
  .get("/zones", Auth, zoneByRider)
  .get("/booking_status", Auth, bookingStatus)
  .get("/evaluate_status", Auth, evaluateStatus)
  .get("/quests/current", Auth, getCurrentQuestList)
  .get("/quests/past", Auth, getPastQuestList)
  .post("/quests/details", Auth, getQuestDetails)
  .get("/quests/generateQuests", generateQuests)
  .post("/report/payment", Auth, paymentreport)
  .post("/report/earning", Auth, earningReportByDate)
  .post("/report/incentives", Auth, calculateRiderIncentives)
  .post("/location/save", Auth, locationSave)
  .post("/location/get", Auth, getCurrentLocationRider);

export default router;
