import mongoose from "mongoose";
import moment from "moment";
import { v4 as uuidv4 } from "uuid";
import { SYSTEM_TIMEZONE } from "../../consts/defaults.js";
const DataSchema = new mongoose.Schema(
  {
    _id: {
      type: String,
      //  default: () => uuidv4(),
    },
    rider_id: { type: String, default: null },
    order_id: { type: String, default: null },
    customer_name: { type: String, default: null },
    branch_name: { type: String, default: null },
    order_status: {
      type: String,
      default: null,
      enum: [
        "placed",
        "accepted",
        "assigned",
        "preparing",
        "ongoing",
        "delivered",
        "cancel",
        "not_delivered",
        "cancel_by_rider",
      ],
    },
    proof_image: { type: String, default: null },
    zone_id: [
      {
        _id: { type: String },
        name: { type: String },
        city_id: { type: String },
        radius: { type: Number },
        lat_long: {
          type: {
            type: String,
            default: "Polygon",
            enum: ["Point", "Polygon"],
          },
          coordinates: [],
        },
      },
    ],
    is_active: { type: Boolean, default: true },
    created_at: {
      type: Date,
      default: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
    },
    created_by: { type: String, default: null },
    updated_at: {
      type: Date,
      default: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
    },
    updated_by: { type: String, default: null },
  },
  {
    collection: "riders_orders",
    //  timestamps: true,
    versionKey: false,
  }
);

DataSchema.statics.orderList = async function (rider_id) {
  try {
    const data = await this.aggregate([
      {
        $match: {
          rider_id: rider_id,
          order_status: { $nin: ["cancel", "delivered", "cancel_by_rider"] },
        },
      },
      {
        $addFields: {
          order_status_sort: {
            $cond: {
              if: { $eq: ["$order_status", "assigned"] },
              then: 0,
              else: 1,
            },
          },
        },
      },
      {
        $group: {
          _id: "$order_id",
          order_id: { $first: "$order_id" },
          customer_name: { $first: "$customer_name" },
          branch_name: { $first: "$branch_name" },
          order_status: { $first: "$order_status" },
          created_at: { $first: "$created_at" },
        },
      },
      {
        $project: {
          _id: 0,
          order_id: 1,
          customer_name: 1,
          branch_name: 1,
          order_status: 1,
          created_at: {
            $dateToString: {
              format: "%Y-%m-%d %H:%M",
              date: "$created_at",
              timezone: "Asia/Dhaka",
            },
          },
          order_status_sort: 1,
        },
      },
      {
        $sort: { created_at: -1, order_status_sort: 1 },
      },
    ]);

    return data;
  } catch (err) {
    console.error(err);
    return false;
  }
};

DataSchema.statics.orderHistory = async function (
  rider_id,
  start_date,
  end_date,
  order_status,
  lim,
  page
) {
  try {
    let match_stage = {};

    start_date && end_date
      ? (match_stage = {
          ...match_stage,

          created_at: {
            $gte: moment(start_date, "YYYY-MM-DD")
              .startOf("day")
              .add(SYSTEM_TIMEZONE.HOURS, "hours")
              .toDate(),
            $lte: moment(end_date, "YYYY-MM-DD")
              .endOf("day")
              .add(SYSTEM_TIMEZONE.HOURS, "hours")
              .toDate(),
          },
        })
      : match_stage;
    order_status
      ? (match_stage = { ...match_stage, order_status: order_status })
      : match_stage;
    let limit = lim > 0 ? lim : 15;
    const data = await this.aggregate([
      {
        $match: {
          rider_id: rider_id,
          ...match_stage,
        },
      },
      { $sort: { created_at: -1 } },
      {
        $lookup: {
          from: "riders_orders_map",
          let: { order_id: "$order_id" },
          pipeline: [
            {
              $match: {
                $expr: {
                  $and: [
                    { $eq: ["$order_id", "$$order_id"] },
                    { $eq: ["$order_status", "delivered"] },
                  ],
                },
              },
            },
            {
              $project: {
                _id: 0,
                delivered_time: "$created_at",
              },
            },
          ],
          as: "deliveryDetail",
        },
      },
      {
        $unwind: {
          path: "$deliveryDetail",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $addFields: {
          delivered_time: {
            $cond: [
              { $eq: ["$order_status", "delivered"] },
              "$deliveryDetail.delivered_time",
              "$$REMOVE",
            ],
          },
        },
      },
      {
        $project: {
          order_id: 1,
          customer_name: 1,
          branch_name: 1,
          order_status: 1,
          created_at: {
            $dateToString: {
              date: "$created_at",
              format: "%Y-%m-%d",
            },
          },
          delivered_time: 1,
        },
      },
    ])
      .skip(limit * (page - 1))
      .limit(limit);
    return data;
  } catch (err) {
    console.error(err);
    return false;
  }
};

const RiderModel = mongoose.model("riders_orders", DataSchema);
export default RiderModel;
