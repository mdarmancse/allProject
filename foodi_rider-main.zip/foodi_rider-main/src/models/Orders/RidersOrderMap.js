import mongoose from "mongoose";
import moment from "moment";
import { v4 as uuidv4 } from "uuid";
import { SYSTEM_TIMEZONE } from "../../consts/defaults.js";
const DataSchema = new mongoose.Schema(
  {
    _id: {
      type: String,
      default: () => uuidv4(),
    },
    rider_id: { type: String, default: null },
    order_id: { type: String, default: null },
    order_status: {
      type: String,
      default: null,
      enum: [
        "placed",
        "accepted",
        "assigned",
        "preparing",
        "ongoing",
        "delivered",
        "cancel",
        "not_delivered",
        "cancel_by_rider",
      ],
    },
    branch_payable: { type: Number, default: 0 },
    customer_payable: { type: Number, default: 0 },
    rider_current_balance: { type: Number, default: 0 },
    rider_due_adjustment: { type: Number, default: 0 },
    total_amount: { type: Number, default: 0 },
    rider_accepted: { type: Boolean, default: false },
    arrived_vendor: { type: Boolean, default: false },
    arrived_customer: { type: Boolean, default: false },
    proof_image: { type: String, default: null },
    is_active: { type: Boolean, default: true },
    created_at: {
      type: Date,
      default: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
    },
    created_by: { type: String, default: null },
    updated_at: {
      type: Date,
      default: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
    },
    updated_by: { type: String, default: null },
  },
  {
    collection: "riders_orders_map",
    //  timestamps: true,
    versionKey: false,
  }
);

const RiderModel = mongoose.model("riders_orders_map", DataSchema);
export default RiderModel;
