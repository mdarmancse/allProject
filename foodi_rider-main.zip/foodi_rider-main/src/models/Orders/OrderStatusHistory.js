import mongoose from "mongoose";
import moment from "moment";
import { v4 as uuidv4 } from "uuid";
import { SYSTEM_TIMEZONE } from "../../consts/defaults.js";
const DataSchema = new mongoose.Schema(
  {
    _id: {
      type: String,
      default: () => uuidv4(),
    },
    order_id: { type: String, default: null },
    order_status_name: {
      type: String,
      default: null,
      enum: [
        "placed",
        "accepted",
        "rider_accepted",
        "assigned",
        "preparing",
        "ongoing",
        "delivered",
        "cancel",
        "not_delivered",
        "cancel_by_rider",
      ],
    },
    latitude: { type: Number, default: 0 },
    longitude: { type: Number, default: 0 },
    created_at: {
      type: Date,
      default: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
    },
    created_by: { type: String, default: null },
    updated_at: {
      type: Date,
      default: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
    },
    updated_by: { type: String, default: null },
  },
  {
    collection: "order_status_history",
    //  timestamps: true,
    versionKey: false,
  }
);

DataSchema.statics.calculateTotalDeliveryTime = async function (order_id) {
  try {
    const timeNow = moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate();

    const data = await this.findOne(
      { order_id: order_id, order_status_name: "rider_accepted" },
      { _id: 0, created_at: 1 }
    );

    if (data) {
      const total_dt = Math.round(
        (timeNow - moment(data.created_at).toDate()) / 60000
      );
      return total_dt;
    } else {
      return null;
    }
  } catch (err) {
    console.error(err);
    return false;
  }
};

const RiderModel = mongoose.model("order_status_history", DataSchema);
export default RiderModel;
