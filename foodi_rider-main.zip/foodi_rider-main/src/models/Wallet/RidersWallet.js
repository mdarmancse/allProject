import mongoose from "mongoose";
import { v4 as uuidv4 } from "uuid";
import moment from "moment";
import { SYSTEM_TIMEZONE } from "../../consts/defaults.js";
const DataSchema = new mongoose.Schema(
  {
    _id: {
      type: String,
      default: () => uuidv4(),
    },
    order_id: { type: String, default: null },
    transaction_id: { type: String, default: null },
    payment_method: {
      type: String,
      default: null,
      enum: ["Cash", "Upay", "Nagad", "SSL", "bKash"],
    },
    from: { type: String, default: null },
    to: { type: String, default: null },
    amount: { type: Number, default: 0 },
    payment_type: {
      type: String,
      default: null,
      enum: [
        "collection",
        "payment_to_vendor",
        "cash_out",
        "cash_in",
        "adjustment",
        "earnings",
      ],
    },
    cash_out: { type: Number, default: 0 },
    rider_earning: { type: Number, default: 0 },
    order_status: {
      type: String,
      default: null,
      enum: [
        "placed",
        "accepted",
        "assigned",
        "preparing",
        "ongoing",
        "delivered",
        "cancel",
        "not_delivered",
      ],
    },
    is_active: { type: Boolean, default: true },
    created_at: {
      type: Date,
      default: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
    },
    created_by: { type: String, default: null },
    updated_at: {
      type: Date,
      default: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
    },
    updated_by: { type: String, default: null },
  },
  {
    collection: "riders_wallet",
    //  timestamps: true,
    versionKey: false,
  }
);
DataSchema.statics.paymentReport = async function (rider_id, lim, page = 1) {
  try {
    let limit = lim > 0 ? lim : 0;
    const skip = limit * (page - 1);
    const data = await this.aggregate([
      {
        $match: {
          to: rider_id,
          payment_type: "collection",
        },
      },
      {
        $facet: {
          weeklyData: [
            {
              $project: {
                _id: 0,
                id: "$_id",
                order_id: "$order_id",
                title: "Total Earnings",
                price: "$rider_earning",
                created_at: {
                  $dateToString: {
                    format: "%Y-%m-%d",
                    date: "$created_at",
                  },
                },
              },
            },
          ],
          driversEarning: [
            {
              $group: {
                _id: {
                  $dateToString: {
                    format: "%Y-%m-%d",
                    date: "$created_at",
                  },
                },
                order_id: { $first: "$order_id" },
                title: { $first: "Total Earnings" },
                price: { $sum: "$rider_earning" },
                created_at: {
                  $first: {
                    $dateToString: {
                      format: "%Y-%m-%d",
                      date: "$created_at",
                    },
                  },
                },
              },
            },
            {
              $sort: { created_at: -1 },
            },
            { $skip: skip },
            ...(limit > 0 ? [{ $limit: limit }] : []),
          ],
        },
      },
    ]);

    const finalData = data[0];

    const weeklyData = {
      labels: [],
      datasets: [
        {
          data: [],
        },
      ],
    };

    const driverEarning = [];

    const currentDate = moment().startOf("isoWeek");
    for (let i = 3; i >= 0; i--) {
      const startDate = currentDate.clone().subtract(i, "week");
      const endDate = startDate.clone().endOf("isoWeek");

      const startDateString = startDate.format("DD MMM YY");
      const endDateString = endDate.format("DD MMM YY");

      const weekData = {
        startDate: startDateString,
        endDate: endDateString,
        totalEarnings: 0,
      };

      for (const entry of finalData.weeklyData) {
        // Corrected the reference to `driversEarning`
        const entryDate = moment(entry.created_at, "YYYY-MM-DD");
        if (entryDate.isBetween(startDate, endDate, null, "[]")) {
          weekData.totalEarnings += parseFloat(entry.price); // Use parseFloat to convert price to a number
        }
      }

      weeklyData.labels.push(`${startDateString} - ${endDateString}`);
      weeklyData.datasets[0].data.push(weekData.totalEarnings.toFixed(2));
    }

    for (const entry of finalData.driversEarning) {
      driverEarning.push({
        id: entry.id,
        date: entry.created_at,
        title: entry.title,
        price: parseFloat(entry.price).toFixed(2),
      });
    }

    const result = {
      weeklyData: weeklyData,
      driverEarning: driverEarning,
    };

    return result;
  } catch (err) {
    console.error(err);
    return false;
  }
};
DataSchema.statics.getEarningReportbyDate = async function (rider_id, date) {
  const startOfDay = new Date(date);
  startOfDay.setHours(0, 0, 0, 0);

  const endOfDay = new Date(date);
  endOfDay.setHours(23, 59, 59, 999);
  try {
    const data = await this.aggregate([
      {
        $match: {
          created_at: {
            $gte: moment(date, "YYYY-MM-DD")
              .startOf("day")
              .add(SYSTEM_TIMEZONE.HOURS, "hours")
              .toDate(),
            $lte: moment(date, "YYYY-MM-DD")
              .endOf("day")
              .add(SYSTEM_TIMEZONE.HOURS, "hours")
              .toDate(),
          },
          to: rider_id,
          payment_type: "collection",
        },
      },
      {
        $group: {
          _id: {
            $dateToString: {
              format: "%Y-%m-%d",
              date: "$created_at",
            },
          },
          order_ids: { $addToSet: "$order_id" },
          title: { $first: "Total Earnings" },
          rider_earning: { $sum: "$rider_earning" },
          created_at: {
            $first: {
              $dateToString: {
                format: "%Y-%m-%d",
                date: "$created_at",
              },
            },
          },
        },
      },
      {
        $lookup: {
          from: "riders_orders_map",
          let: { order_ids: "$order_ids" },
          pipeline: [
            {
              $addFields: {
                order_ids: ["$order_id"],
              },
            },
            {
              $match: {
                $expr: {
                  $and: [
                    { $setIsSubset: ["$order_ids", "$$order_ids"] },
                    { $eq: ["$rider_id", rider_id] },
                    { $eq: ["$order_status", "delivered"] },
                    {
                      $and: [
                        {
                          $gte: [
                            "$created_at",
                            moment(date, "YYYY-MM-DD")
                              .startOf("day")
                              .add(SYSTEM_TIMEZONE.HOURS, "hours")
                              .toDate(),
                          ],
                        },
                        {
                          $lte: [
                            "$created_at",
                            moment(date, "YYYY-MM-DD")
                              .endOf("day")
                              .add(SYSTEM_TIMEZONE.HOURS, "hours")
                              .toDate(),
                          ],
                        },
                      ],
                    },
                  ],
                },
              },
            },
            {
              $project: {
                order_id: 1,
                order_status: 1,
                total_amount: { $ifNull: ["$total_amount", 0] },
                delivered_time: {
                  $dateToString: {
                    format: "%H:%M",
                    date: "$created_at",
                  },
                },
              },
            },
          ],
          as: "deliveries",
        },
      },
      {
        $lookup: {
          from: "riders_shift",
          pipeline: [
            {
              $match: { rider_id: rider_id },
            },
            {
              $project: {
                rider_id: 1,
                start_time: {
                  $dateToString: {
                    format: "%H:%M ",
                    date: "$start_time",
                  },
                },
                end_time: {
                  $dateToString: {
                    format: "%H:%M ",
                    date: "$end_time",
                  },
                },
                duration: {
                  $let: {
                    vars: {
                      diff: {
                        $subtract: ["$end_time", "$start_time"],
                      },
                    },
                    in: {
                      hours: {
                        $floor: { $divide: ["$$diff", 1000 * 60 * 60] },
                      },
                      minutes: {
                        $mod: [
                          { $floor: { $divide: ["$$diff", 1000 * 60] } },
                          60,
                        ],
                      },
                    },
                  },
                },
              },
            },
          ],
          as: "shifts",
        },
      },
      {
        $addFields: {
          shift: { $arrayElemAt: ["$shifts", 0] },
        },
      },

      {
        $lookup: {
          from: "generated_quests",
          pipeline: [
            {
              $match: {
                start_date_time: {
                  $gte: moment(date, "YYYY-MM-DD")
                    .startOf("day")
                    .add(SYSTEM_TIMEZONE.HOURS, "hours")
                    .toDate(),
                },
                end_date_time: {
                  $lte: moment(date, "YYYY-MM-DD")
                    .endOf("day")
                    .add(SYSTEM_TIMEZONE.HOURS, "hours")
                    .toDate(),
                },
              },
            },
            {
              $lookup: {
                from: "rider_goal_order_completions",
                localField: "goals._id",
                foreignField: "goal_id",
                pipeline: [
                  {
                    $match: {
                      rider_id: rider_id,
                      created_at: {
                        $gte: moment(date, "YYYY-MM-DD")
                          .startOf("day")
                          .add(SYSTEM_TIMEZONE.HOURS, "hours")
                          .toDate(),
                        $lte: moment(date, "YYYY-MM-DD")
                          .endOf("day")
                          .add(SYSTEM_TIMEZONE.HOURS, "hours")
                          .toDate(),
                      },
                    },
                  },
                ],
                as: "rider_goal_order",
              },
            },
            {
              $match: {
                rider_goal_order: { $ne: [] },
              },
            },
            {
              $addFields: {
                goal_object: {
                  $filter: {
                    input: "$goals",
                    as: "goal",
                    cond: {
                      $in: [
                        "$$goal._id",
                        {
                          $map: {
                            input: "$rider_goal_order",
                            as: "rgoc",
                            in: "$$rgoc.goal_id",
                          },
                        },
                      ],
                    },
                  },
                },
              },
            },

            {
              $addFields: {
                goals: { $arrayElemAt: ["$goal_object", 0] },
                rider_goal_order_count: { $size: "$rider_goal_order" },
              },
            },
            {
              $project: {
                _id: 1,
                name: 1,
                required_number_of_order: "$goals.required_number_of_order",
                per_order_value: "$goals.per_order_value",
                goal_name: "$goals.name",
                rider_goal_order_count: 1,
                quest_earning: {
                  $cond: [
                    {
                      $eq: [
                        "$rider_goal_order_count",
                        "$goals.required_number_of_order",
                      ],
                    },
                    {
                      $multiply: [
                        "$rider_goal_order_count",
                        "$rider_goal_order_count",
                      ],
                    },
                    0,
                  ],
                },
              },
            },
          ],
          as: "incentives",
        },
      },
      { $addFields: { incentives: { $arrayElemAt: ["$incentives", 0] } } },
      {
        $project: {
          _id: 0,
          title: 1,
          rider_earning: {
            $sum: ["$rider_earning", "$incentives.quest_earning"],
          },
          created_at: 1,
          start_time: "$shift.start_time",
          end_time: "$shift.end_time",
          duration: {
            $concat: [
              { $toString: { $floor: "$shift.duration.hours" } },
              " hr ",
              { $toString: "$shift.duration.minutes" },
              " min",
            ],
          },
          incentives: { $ifNull: ["$incentives", null] },
          deliveries: { $ifNull: ["$deliveries", null] },
        },
      },
    ]);

    return data;
  } catch (err) {
    console.error(err);
    return false;
  }
};

const RiderWallet = mongoose.model("riders_wallet", DataSchema);
export default RiderWallet;
