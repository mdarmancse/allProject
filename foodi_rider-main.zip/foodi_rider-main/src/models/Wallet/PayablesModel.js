import mongoose from "mongoose";
import { v4 as uuidv4 } from "uuid";
import moment from "moment";
import { SYSTEM_TIMEZONE } from "../../consts/defaults.js";
const DataSchema = new mongoose.Schema(
  {
    _id: {
      type: String,
      default: () => uuidv4(),
    },
    order_id: { type: String, default: null },
    from: { type: String, default: null },
    to: { type: String, default: null },
    amount: { type: Number, default: 0 },
    payment_method: {
      type: String,
      default: null,
      enum: ["Cash", "Upay", "Nagad", "SSL", "bKash"],
    },
    payment_type: {
      type: String,
      default: null,
      enum: [
        "collection",
        "payment_to_vendor",
        "cash_out",
        "cash_in",
        "adjustment",
        "earnings",
      ],
    },
    is_active: { type: Boolean, default: true },
    created_at: {
      type: Date,
      default: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
    },
    created_by: { type: String, default: null },
    updated_at: {
      type: Date,
      default: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
    },
    updated_by: { type: String, default: null },
  },
  {
    collection: "payables",
    //  timestamps: true,
    versionKey: false,
  }
);
DataSchema.statics.recentTransaction = async function (
  rider_id,
  lim,
  page = 1,
  data_view_last_days = 15
) {
  try {
    let limit = lim > 0 ? lim : 0;
    const skip = limit * (page - 1);
    const data = await this.aggregate([
      {
        $match: {
          $or: [{ from: rider_id }, { to: rider_id }],
          created_at: {
            $gte: moment()
              .subtract(data_view_last_days, "days")
              .startOf("day")
              .add(SYSTEM_TIMEZONE.HOURS, "hours")
              .toDate(),
          },
        },
      },
      {
        $sort: {
          created_at: -1,
        },
      },

      {
        $project: {
          _id: 0,
          id: "$_id",
          order_id: "$order_id",
          title: "$payment_type",
          price: { $round: ["$amount", 2] },
          created_at: 1,
        },
      },
      { $skip: skip },
      ...(limit > 0 ? [{ $limit: limit }] : []),
    ]);
    return data;
  } catch (err) {
    console.error(err);
    return false;
  }
};

const PayablesModel = mongoose.model("payables", DataSchema);
export default PayablesModel;
