import mongoose from "mongoose";
import { v4 as uuidv4 } from "uuid";
import { quest_status } from "../../data/quests.js";
import moment from "moment/moment.js";
import { SYSTEM_TIMEZONE } from "../../consts/defaults.js";
const DataSchema = new mongoose.Schema(
  {
    _id: {
      type: String,
      default: () => uuidv4(),
    },
    quest_id: {
      type: String,
    },
    name: { type: String },
    acceptable_acceptance_rate: { type: Number, default: null },
    acceptable_completion_rate: { type: Number, default: null },
    start_date_time: { type: Date, default: null },
    end_date_time: { type: Date, default: null },
    rules: { type: String, default: null },

    zones: [
      {
        _id: { type: String, default: () => uuidv4() },
        generated_quest_id: { type: String },
        zone_id: { type: String },
      },
    ],

    goals: [
      {
        _id: { type: String, default: () => uuidv4() },
        generated_quest_id: { type: String },
        sl: { type: Number },
        name: { type: String },
        required_number_of_order: { type: Number },
        per_order_value: { type: Number },
      },
    ],

    is_active: { type: Boolean, default: true },
    created_at: {
      type: Date,
      default: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
    },
    created_by: { type: String, default: null },
    updated_at: {
      type: Date,
      default: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
    },
    updated_by: { type: String, default: null },
  },
  {
    collection: "generated_quests",
    //  timestamps: true,
    versionKey: false,
  }
);

DataSchema.statics.getCurrentQuests = async function (rider_id) {
  try {
    const currentDate = moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate();
    const futureDate = moment()
      .add(3, "days")
      .add(SYSTEM_TIMEZONE.HOURS, "hours")
      .toDate();

    const data = await this.aggregate([
      {
        $lookup: {
          from: "riders",
          localField: "zones.zone_id",
          foreignField: "zones.zone_id",
          as: "matched_riders",
        },
      },
      {
        $match: {
          "matched_riders._id": rider_id,
          is_active: true,
          $or: [
            {
              start_date_time: {
                $lte: currentDate,
              },
              end_date_time: {
                $gte: currentDate,
              },
            },
            {
              start_date_time: {
                $gte: currentDate,
                $lte: futureDate,
              },
            },
          ],
        },
      },
      {
        $addFields: {
          status: {
            $cond: {
              if: {
                $and: [
                  { $lte: ["$start_date_time", currentDate] },
                  { $gte: ["$end_date_time", currentDate] },
                ],
              },
              then: quest_status.ongoing,
              else: quest_status.to_be_started,
            },
          },
        },
      },
      {
        $project: {
          _id: 1,
          name: 1,
          status: 1,
          start_time: "$start_date_time",
          end_time: "$end_date_time",
        },
      },
    ]);
    return data;
  } catch (err) {
    throw err;
  }
};

DataSchema.statics.getPastQuests = async function (rider_id) {
  try {
    let sevenDaysAgo = moment().subtract(7, "days").startOf("day");
    const now = moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate();

    const data = await this.aggregate([
      {
        $lookup: {
          from: "riders",
          localField: "zones.zone_id",
          foreignField: "zones.zone_id",
          as: "matched_riders",
        },
      },
      {
        $match: {
          $and: [
            {
              "matched_riders._id": rider_id,
              end_date_time: {
                $gte: sevenDaysAgo.toDate(),
                $lte: now,
              },
            },
          ],
        },
      },
      {
        $addFields: {
          status: "Expired",
        },
      },
      {
        $lookup: {
          from: "rider_goal_order_completions",
          localField: "_id",
          foreignField: "generated_quest_id",
          as: "rider_goal_order_completions",
        },
      },
      {
        $unwind: {
          path: "$rider_goal_order_completions",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $group: {
          _id: "$_id",
          name: { $last: "$name" },
          status: { $last: "$status" },
          start_date_time: { $last: "$start_date_time" },
          end_date_time: { $last: "$end_date_time" },
          earning: {
            $sum: "$rider_goal_order_completions.order_value",
          },
        },
      },
      {
        $project: {
          _id: 1,
          name: 1,
          status: 1,
          earning: 1,
          start_time: "$start_date_time",
          end_time: "$end_date_time",
        },
      },
    ]);
    return data;
  } catch (err) {
    throw err;
  }
};

DataSchema.statics.getQuestDetails = async function (rider_id, quest_id) {
  const currentDate = moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate();

  try {
    const data = await this.aggregate([
      {
        $match: {
          _id: quest_id,
          is_active: true,
        },
      },
      {
        $lookup: {
          from: "rider_goal_order_completions",
          let: { quest_id: "$_id", rider_id: rider_id },
          pipeline: [
            {
              $match: {
                $expr: {
                  $and: [
                    { $eq: ["$generated_quest_id", "$$quest_id"] },
                    { $eq: ["$rider_id", "$$rider_id"] },
                  ],
                },
              },
            },
          ],
          as: "riderGoalOrderCompletions",
        },
      },
      {
        $addFields: {
          earning: { $sum: "$riderGoalOrderCompletions.order_value" },
        },
      },
      {
        $unwind: "$goals",
      },
      {
        $lookup: {
          from: "rider_goal_order_completions",
          let: { goal_id: "$goals._id", rider_id: rider_id },
          pipeline: [
            {
              $match: {
                $expr: {
                  $and: [
                    { $eq: ["$goal_id", "$$goal_id"] },
                    { $eq: ["$rider_id", "$$rider_id"] },
                  ],
                },
              },
            },
          ],
          as: "riderGoalOrderCompletionsPerGoal",
        },
      },
      {
        $addFields: {
          "goals.delivered_orders": {
            $size: "$riderGoalOrderCompletionsPerGoal",
          },
          "goals.total_order_value": {
            $multiply: [
              { $size: "$riderGoalOrderCompletionsPerGoal" },
              "$goals.per_order_value",
            ],
          },
        },
      },
      {
        $group: {
          _id: "$_id",
          quest_id: { $first: "$quest_id" },
          name: { $first: "$name" },
          acceptable_acceptance_rate: { $first: "$acceptable_acceptance_rate" },
          acceptable_completion_rate: { $first: "$acceptable_completion_rate" },
          start_date_time: { $first: "$start_date_time" },
          end_date_time: { $first: "$end_date_time" },
          rules: { $first: "$rules" },
          goals: { $push: "$goals" },
          earning: { $first: "$earning" },
        },
      },
      {
        $addFields: {
          total_delivered_orders: { $sum: "$goals.delivered_orders" },
          status: {
            $cond: [
              { $lte: ["$start_date_time", currentDate] },
              {
                $cond: [
                  { $gte: ["$end_date_time", currentDate] },
                  quest_status.ongoing,
                  quest_status.expired,
                ],
              },
              quest_status.to_be_started,
            ],
          },
        },
      },
      {
        $project: {
          _id: 1,
          name: 1,
          start_time: "$start_date_time",
          end_time: "$end_date_time",
          rules: 1,
          earning: 1,
          total_delivered_orders: 1,
          goals: 1,
          status: 1,
        },
      },
    ]);
    if (data) {
      let prevGoalCompleted = true;
      data[0].goals.forEach((goal) => {
        if (
          prevGoalCompleted &&
          goal.delivered_orders >= goal.required_number_of_order
        ) {
          goal.status = "Finished";
        } else if (prevGoalCompleted) {
          goal.status = "OnGoing";
          prevGoalCompleted = false;
        } else {
          goal.status = "Not Started";
        }
      });
      return data[0];
    }
  } catch (err) {
    throw err;
  }
};

DataSchema.statics.getRunningGoals = async function (rider_id) {
  try {
    const currentDate = moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate();
    // $sort: { start_date_time: 1 }, // We will complete the goal of the quest which have started first

    const data = await this.aggregate([
      {
        $lookup: {
          from: "riders",
          localField: "zones.zone_id",
          foreignField: "zones.zone_id",
          as: "matched_riders",
        },
      },
      {
        $match: {
          "matched_riders._id": rider_id,
          start_date_time: { $lte: currentDate },
          end_date_time: { $gte: currentDate },
          is_active: true,
        },
      },
      {
        $sort: { start_date_time: 1 }, // sort by start date in ascending order
      },
      {
        $unwind: "$goals",
      },
      {
        $sort: { "goals.sl": 1 },
      },
      {
        $lookup: {
          from: "rider_goal_order_completions",
          let: { quest_id: "$_id", goal_id: "$goals._id" },
          pipeline: [
            {
              $match: {
                $expr: {
                  $and: [
                    { $eq: ["$generated_quest_id", "$$quest_id"] },
                    { $eq: ["$goal_id", "$$goal_id"] },
                    { $eq: ["$is_active", true] },
                    { $eq: ["$rider_id", rider_id] },
                  ],
                },
              },
            },
            {
              $group: {
                _id: null,
                goal_completion_count: { $sum: 1 },
              },
            },
          ],
          as: "goal_completions",
        },
      },
      {
        $unwind: {
          path: "$goal_completions",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $addFields: {
          goal_completions_count: {
            $ifNull: ["$goal_completions.goal_completion_count", 0],
          },
        },
      },
      {
        $redact: {
          $cond: [
            {
              $lt: [
                "$goal_completions_count",
                "$goals.required_number_of_order",
              ],
            },
            "$$KEEP",
            "$$PRUNE",
          ],
        },
      },
      {
        $limit: 1,
      },
      {
        $project: {
          _id: 1,
          goals: 1,
        },
      },
    ]);
    if (data.length > 0) return data[0];
  } catch (err) {
    throw err;
  }
};

DataSchema.statics.getIncReportbyDate = async function (rider_id, date) {
  try {
    const startOfDay = new Date(date);
    startOfDay.setHours(0, 0, 0, 0);

    const endOfDay = new Date(date);
    endOfDay.setHours(23, 59, 59, 999);

    const data = await this.aggregate([
      {
        $lookup: {
          from: "rider_goal_order_completions",
          localField: "goals._id",
          foreignField: "goal_id",
          pipeline: [
            {
              $match: {
                rider_id: rider_id,
                created_at: { $gte: startOfDay, $lte: endOfDay },
              },
            },
          ],
          as: "rider_goal_order",
        },
      },
      {
        $match: {
          rider_goal_order: { $ne: [] },
        },
      },
      {
        $addFields: {
          goals: { $arrayElemAt: ["$goals", 0] },
          rider_goal_order_count: { $size: "$rider_goal_order" },
        },
      },
      {
        $project: {
          _id: 1,
          name: 1,
          required_number_of_order: "$goals.required_number_of_order",
          per_order_value: "$goals.per_order_value",
          rider_goal_order_count: 1,
          quest_earning: {
            $cond: [
              {
                $eq: [
                  "$rider_goal_order_count",
                  "$goals.required_number_of_order",
                ],
              },
              {
                $multiply: [
                  "$rider_goal_order_count",
                  "$rider_goal_order_count",
                ],
              },
              0,
            ],
          },
        },
      },
    ]);

    return data;
  } catch (err) {
    console.error(err);
    return false;
  }
};

const GeneratedQuests = mongoose.model("generated_quests", DataSchema);
export default GeneratedQuests;
