import mongoose from "mongoose";
import moment from "moment";
import { quest_status } from "../../data/quests.js";
const DataSchema = new mongoose.Schema(
  {
    _id: {
      type: String,
    },
    name: { type: String },
    acceptable_acceptance_rate: { type: Number, default: null },
    acceptable_completion_rate: { type: Number, default: null },
    start_date: { type: Date },
    end_date: { type: Date },
    has_time_limit: { type: Boolean, default: false },
    start_time: { type: String, default: null },
    end_time: { type: String, default: null },
    rules: { type: String, default: null },

    zones: [
      {
        _id: { type: String },
        quest_id: { type: String },
        zone_id: { type: String },
      },
    ],

    goals: [
      {
        _id: { type: String },
        quest_id: { type: String },
        sl: { type: Number },
        name: { type: String },
        required_number_of_order: { type: Number },
        per_order_value: { type: Number },
      },
    ],

    is_active: { type: Boolean, default: true },
    created_at: { type: Date, default: null },
    created_by: { type: String, default: null },
    updated_at: { type: Date, default: null },
    updated_by: { type: String, default: null },
  },
  {
    collection: "quests",
    //  timestamps: true,
    versionKey: false,
  }
);

const Quest = mongoose.model("quests", DataSchema);
export default Quest;
