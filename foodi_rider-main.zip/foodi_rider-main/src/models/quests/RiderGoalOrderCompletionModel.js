import mongoose from "mongoose";
import { v4 as uuidv4 } from "uuid";
import moment from "moment";
import { SYSTEM_TIMEZONE } from "../../consts/defaults.js";
const DataSchema = new mongoose.Schema(
  {
    _id: {
      type: String,
      default: () => uuidv4(),
    },
    generated_quest_id: { type: String },
    date: { type: Date },
    goal_id: { type: String },
    rider_id: { type: String },
    order_id: { type: String },
    order_value: { type: Number },

    is_active: { type: Boolean, default: true },
    created_at: {
      type: Date,
      default: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
    },
    created_by: { type: String, default: null },
    updated_at: {
      type: Date,
      default: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
    },
    updated_by: { type: String, default: null },
  },
  {
    collection: "rider_goal_order_completions",
    //  timestamps: true,
    versionKey: false,
  }
);

DataSchema.statics.getIncReportbyDate = async function (rider_id, date) {
  try {
    const startOfDay = new Date(date);
    startOfDay.setHours(0, 0, 0, 0);

    const endOfDay = new Date(date);
    endOfDay.setHours(23, 59, 59, 999);

    const data = this.aggregate([
      {
        $match: {
          rider_id: rider_id,
          created_at: { $gte: startOfDay, $lte: endOfDay },
        },
      },
      {
        $lookup: {
          from: "generated_quests",
          localField: "goal_id",
          foreignField: "goals._id",
          as: "generated_quests",
        },
      },
      {
        $project: {
          generated_quests: 1,
        },
      },
    ]);

    return data;
  } catch (err) {
    console.error(err);
    return false;
  }
};

const RiderGoalsOrderCompletion = mongoose.model(
  "rider_goal_order_completions",
  DataSchema
);

export default RiderGoalsOrderCompletion;
