import mongoose from "mongoose";
import { v4 as uuidv4 } from "uuid";
import moment from "moment";
import { SYSTEM_TIMEZONE } from "../../consts/defaults.js";
const DataSchema = new mongoose.Schema(
  {
    _id: {
      type: String,
      // default: () => uuidv4(),
    },
    rider_shift_duty_setup_id: { type: String, default: null },
    start_time: { type: Date, default: null },
    end_time: { type: Date, default: null },
    number_of_rider: { type: Number, default: 0 },
    is_active: { type: Boolean, default: true },
    created_at: {
      type: Date,
      default: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
    },
    created_by: { type: String, default: null },
    updated_at: {
      type: Date,
      default: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
    },
    updated_by: { type: String, default: null },
  },
  {
    collection: "rider_shift_duty_time_slot_setup",
    //  timestamps: true,
    versionKey: false,
  }
);
DataSchema.statics.getShiftData = async function (shift_time_slot_id) {
  try {
    let data;

    data = await this.aggregate([
      {
        $match: {
          _id: shift_time_slot_id,
          is_active: true,
        },
      },
      {
        $lookup: {
          from: "rider_shift_duty_booking",
          localField: "_id",
          foreignField: "rider_shift_duty_time_slot_setup_id",
          pipeline: [
            {
              $project: {
                rider_id: 1,
                rider_shift_duty_time_slot_setup_id: 1,
              },
            },
          ],
          as: "rider_shift_duty_booking",
        },
      },
      {
        $project: {
          _id: 1,
          number_of_rider: 1,
          is_available: {
            $cond: [
              {
                $lt: [
                  { $size: "$rider_shift_duty_booking" },
                  "$number_of_rider",
                ],
              },
              true,
              false,
            ],
          },
        },
      },
    ]);

    console.log(data);

    return data.shift();
  } catch (err) {
    console.error(err);
    return false;
  }
};
DataSchema.statics.getShiftDetails = async function (
  rider_id,
  shift_time_slot_id
) {
  try {
    let data;

    data = await this.aggregate([
      {
        $match: {
          _id: shift_time_slot_id,
          is_active: true,
        },
      },
      {
        $lookup: {
          from: "rider_shift_duty_setup",
          localField: "rider_shift_duty_setup_id",
          foreignField: "_id",
          pipeline: [
            {
              $lookup: {
                from: "zones",
                localField: "zone_id",
                foreignField: "_id",
                pipeline: [
                  {
                    $project: {
                      _id: 1,
                      name: 1,
                    },
                  },
                ],
                as: "zones",
              },
            },
            {
              $lookup: {
                from: "week_days",
                localField: "week_day_id",
                foreignField: "_id",
                pipeline: [
                  {
                    $project: {
                      _id: 1,
                      name: 1,
                    },
                  },
                ],
                as: "week_days",
              },
            },
            {
              $project: {
                _id: 0,
                zone_id: 1,
                shift_id: "$_id",
                week_day_id: 1,
                zone_name: { $arrayElemAt: ["$zones.name", 0] },
                week_day: { $arrayElemAt: ["$week_days.name", 0] },
              },
            },
          ],
          as: "rider_shift_duty_setup",
        },
      },
      {
        $lookup: {
          from: "rider_shift_duty_booking",
          localField: "_id",
          foreignField: "rider_shift_duty_time_slot_setup_id",
          pipeline: [
            {
              $addFields: {
                evaluated_hours: {
                  $let: {
                    vars: {
                      diffMinutes: {
                        $divide: [
                          {
                            $subtract: [
                              "$actual_start_time",
                              "$actual_end_time",
                            ],
                          },
                          1000 * 60,
                        ],
                      },
                    },
                    in: {
                      $concat: [
                        {
                          $cond: [
                            { $gte: ["$$diffMinutes", 60 * 24] },
                            {
                              $concat: [
                                {
                                  $toString: {
                                    $floor: {
                                      $divide: ["$$diffMinutes", 60 * 24],
                                    },
                                  },
                                },
                                "d ",
                              ],
                            },
                            "",
                          ],
                        },
                        {
                          $toString: {
                            $floor: {
                              $mod: [{ $divide: ["$$diffMinutes", 60] }, 24],
                            },
                          },
                        },
                        "h ",
                        {
                          $toString: {
                            $floor: { $mod: ["$$diffMinutes", 60] },
                          },
                        },
                        "m",
                      ],
                    },
                  },
                },
              },
            },
            {
              $lookup: {
                from: "rider_shift_duty_booking_evaluate_status",
                localField: "rider_shift_duty_booking_evaluate_status_id",
                foreignField: "_id",
                pipeline: [
                  {
                    $project: {
                      _id: 1,
                      name: 1,
                      information: 1,
                    },
                  },
                ],
                as: "evaluate_status",
              },
            },
            {
              $addFields: {
                evaluate_status: {
                  $arrayElemAt: ["$evaluate_status", 0],
                },
              },
            },

            {
              $project: {
                rider_id: 1,
                rider_shift_duty_time_slot_setup_id: 1,
                date: {
                  $dateToString: {
                    format: "%Y-%m-%d %H:%M",
                    date: "$date",
                  },
                },
                evaluated_start_time: {
                  $dateToString: {
                    format: "%H:%M ",
                    date: "$actual_start_time",
                  },
                },
                evaluated_end_time: {
                  $dateToString: {
                    format: "%H:%M ",
                    date: "$actual_end_time",
                  },
                },
                evaluated_hours: 1,
                evaluate_status_id: "$evaluate_status._id",
                evaluate_status: "$evaluate_status.name",
                evaluate_information: "$evaluate_status.information",
              },
            },
          ],
          as: "rider_shift_duty_booking",
        },
      },
      {
        $addFields: {
          planned_hours: {
            $let: {
              vars: {
                diffMinutes: {
                  $divide: [
                    {
                      $subtract: ["$end_time", "$start_time"],
                    },
                    1000 * 60,
                  ],
                },
              },
              in: {
                $concat: [
                  {
                    $cond: [
                      { $gte: ["$$diffMinutes", 60 * 24] },
                      {
                        $concat: [
                          {
                            $toString: {
                              $floor: { $divide: ["$$diffMinutes", 60 * 24] },
                            },
                          },
                          "d ",
                        ],
                      },
                      "",
                    ],
                  },
                  {
                    $toString: {
                      $floor: {
                        $mod: [{ $divide: ["$$diffMinutes", 60] }, 24],
                      },
                    },
                  },
                  "h ",
                  { $toString: { $floor: { $mod: ["$$diffMinutes", 60] } } },
                  "m",
                ],
              },
            },
          },
        },
      },
      {
        $project: {
          _id: 0,
          shift_time_slot_id: {
            $arrayElemAt: [
              "$rider_shift_duty_booking.rider_shift_duty_time_slot_setup_id",
              0,
            ],
          },
          week_day_id: {
            $arrayElemAt: ["$rider_shift_duty_setup.week_day_id", 0],
          },
          week_day: { $arrayElemAt: ["$rider_shift_duty_setup.week_day", 0] },
          zone_id: { $arrayElemAt: ["$rider_shift_duty_setup.zone_id", 0] },
          zone_name: { $arrayElemAt: ["$rider_shift_duty_setup.zone_name", 0] },
          date: { $arrayElemAt: ["$rider_shift_duty_booking.date", 0] },
          evaluated_hours: {
            $arrayElemAt: ["$rider_shift_duty_booking.evaluated_hours", 0],
          },
          evaluated_start_time: {
            $arrayElemAt: ["$rider_shift_duty_booking.evaluated_start_time", 0],
          },
          evaluated_end_time: {
            $arrayElemAt: ["$rider_shift_duty_booking.evaluated_end_time", 0],
          },
          evaluate_status_id: {
            $arrayElemAt: ["$rider_shift_duty_booking.evaluate_status_id", 0],
          },
          evaluate_status: {
            $arrayElemAt: ["$rider_shift_duty_booking.evaluate_status", 0],
          },
          evaluate_information: {
            $arrayElemAt: ["$rider_shift_duty_booking.evaluate_information", 0],
          },

          planned_start_time: {
            $dateToString: {
              format: "%H:%M ",
              date: "$start_time",
            },
          },
          planned_end_time: {
            $dateToString: {
              format: "%H:%M ",
              date: "$end_time",
            },
          },
          planned_hours: 1,
        },
      },
    ]);

    console.log(data);

    return data.shift();
  } catch (err) {
    console.error(err);
    return false;
  }
};

const RiderShiftTimeSlot = mongoose.model(
  "rider_shift_duty_time_slot_setup",
  DataSchema
);
export default RiderShiftTimeSlot;
