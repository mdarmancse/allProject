import mongoose from "mongoose";
import { v4 as uuidv4 } from "uuid";
import moment from "moment";
import { SYSTEM_TIMEZONE } from "../../consts/defaults.js";
const DataSchema = new mongoose.Schema(
  {
    _id: {
      type: String,
      // default: () => uuidv4(),
    },
    name: {
      type: String,
      default: null,
      enum: ["booked", "request_for_swap", "swap_accepted", "swaped"],
    },
    is_active: { type: Boolean, default: true },
    created_at: {
      type: Date,
      default: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
    },
    created_by: { type: String, default: null },
    updated_at: {
      type: Date,
      default: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
    },
    updated_by: { type: String, default: null },
  },
  {
    collection: "rider_shift_duty_booking_status",
    //  timestamps: true,
    versionKey: false,
  }
);
DataSchema.statics.getBookingStatus = async function () {
  try {
    let data;

    data = await this.aggregate([
      {
        $match: {
          is_active: true,
        },
      },
      {
        $project: {
          _id: 1,
          name: 1,
        },
      },
    ]);

    console.log(data);

    return data;
  } catch (err) {
    console.error(err);
    return false;
  }
};
const RiderShiftDutyBookingStatus = mongoose.model(
  "rider_shift_duty_booking_status",
  DataSchema
);
export default RiderShiftDutyBookingStatus;
