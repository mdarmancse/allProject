import mongoose from "mongoose";
import { v4 as uuidv4 } from "uuid";
import moment from "moment";
import { SYSTEM_TIMEZONE } from "../../consts/defaults.js";
const DataSchema = new mongoose.Schema(
  {
    _id: {
      type: String,
      default: () => uuidv4(),
    },
    rider_id: { type: String, default: null },
    date: {
      type: Date,
      default: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
    },
    rider_shift_duty_time_slot_setup_id: { type: String, default: null },
    rider_shift_duty_booking_status_id: { type: String, default: null },
    rider_shift_duty_booking_evaluate_status_id: {
      type: String,
      default: null,
    },
    actual_start_time: { type: String, default: null },
    actual_end_time: { type: String, default: null },
    created_at: {
      type: Date,
      default: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
    },
    created_by: { type: String, default: null },
    updated_at: {
      type: Date,
      default: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
    },
    updated_by: { type: String, default: null },
  },
  {
    collection: "rider_shift_duty_booking",
    //  timestamps: true,
    versionKey: false,
  }
);

DataSchema.statics.getBookingShiftList = async function (
  rider_id,
  zones,
  filterDate,
  start_time,
  end_time,
  lim,
  page = 1
) {
  try {
    let data;
    let limit = lim > 0 ? lim : 0;
    const skip = limit * (page - 1);
    let date = filterDate ? filterDate : moment().toDate();
    data = await this.aggregate([
      {
        $match: {
          rider_id: rider_id,
        },
      },
      {
        $lookup: {
          from: "rider_shift_duty_booking_status",
          localField: "rider_shift_duty_booking_status_id",
          foreignField: "_id",
          pipeline: [
            {
              $project: {
                _id: 1,
                name: 1,
              },
            },
          ],
          as: "booking_status",
        },
      },
      {
        $lookup: {
          from: "rider_shift_duty_time_slot_setup",
          localField: "rider_shift_duty_time_slot_setup_id",
          foreignField: "_id",
          pipeline: [
            {
              $lookup: {
                from: "rider_shift_duty_setup",
                localField: "rider_shift_duty_setup_id",
                foreignField: "_id",
                pipeline: [
                  {
                    $match: {
                      zone_id: { $in: zones.map((item) => item._id) },
                    },
                  },

                  {
                    $lookup: {
                      from: "zones",
                      localField: "zone_id",
                      foreignField: "_id",
                      pipeline: [
                        {
                          $project: {
                            _id: 1,
                            name: 1,
                          },
                        },
                      ],
                      as: "zones",
                    },
                  },
                  {
                    $project: {
                      _id: 0,
                      zone_id: 1,
                      shift_id: "$_id",
                      week_day_id: 1,
                      zones: { $arrayElemAt: ["$zones", 0] },
                    },
                  },
                ],
                as: "rider_shift_duty_setup",
              },
            },
            {
              $project: {
                _id: 1,
                number_of_rider: 1,
                start_time: 1,
                end_time: 1,
                start_time_hour: {
                  $dateToString: {
                    format: "%H:%M ",
                    date: "$start_time",
                  },
                },
                end_time_hour: {
                  $dateToString: {
                    format: "%H:%M ",
                    date: "$end_time",
                  },
                },
                rider_shift_duty_setup: {
                  $arrayElemAt: ["$rider_shift_duty_setup", 0],
                },
              },
            },
          ],
          as: "time_slot",
        },
      },
      {
        $addFields: {
          time_slot: { $arrayElemAt: ["$time_slot", 0] },
          shift_id: {
            $arrayElemAt: ["$time_slot.rider_shift_duty_setup.shift_id", 0],
          },
          week_day_id: {
            $arrayElemAt: ["$time_slot.rider_shift_duty_setup.week_day_id", 0],
          },
          zone_name: { $arrayElemAt: ["$time_slot.rider_shift_duty_setup", 0] },
          zone_id: {
            $arrayElemAt: ["$time_slot.rider_shift_duty_setup.zone_id", 0],
          },
        },
      },

      {
        $addFields: {
          total_time: {
            $let: {
              vars: {
                diffMinutes: {
                  $divide: [
                    {
                      $subtract: [
                        "$time_slot.end_time",
                        "$time_slot.start_time",
                      ],
                    },
                    1000 * 60,
                  ],
                },
              },
              in: {
                $concat: [
                  {
                    $cond: [
                      { $gte: ["$$diffMinutes", 60 * 24] },
                      {
                        $concat: [
                          {
                            $toString: {
                              $floor: { $divide: ["$$diffMinutes", 60 * 24] },
                            },
                          },
                          "d ",
                        ],
                      },
                      "",
                    ],
                  },
                  {
                    $toString: {
                      $floor: {
                        $mod: [{ $divide: ["$$diffMinutes", 60] }, 24],
                      },
                    },
                  },
                  "h ",
                  { $toString: { $floor: { $mod: ["$$diffMinutes", 60] } } },
                  "m",
                ],
              },
            },
          },
        },
      },

      {
        $match: {
          $expr: {
            $and: [
              {
                $gte: [
                  "$time_slot.start_time",
                  moment(date)
                    .startOf("day")
                    .add(SYSTEM_TIMEZONE.HOURS, "hours")
                    .toDate(),
                ],
              },
              {
                $lte: [
                  "$time_slot.end_time",
                  moment(date)
                    .endOf("day")
                    .add(SYSTEM_TIMEZONE.HOURS, "hours")
                    .toDate(),
                ],
              },
            ],
          },
          ...(start_time && end_time
            ? {
                $expr: {
                  $and: [
                    {
                      $gte: [
                        "$time_slot.start_time",
                        moment(`${date} ${start_time}`, "YYYY-MM-DD HH:mm")
                          .add(SYSTEM_TIMEZONE.HOURS, "hours")
                          .toDate(),
                      ],
                    },
                    {
                      $lte: [
                        "$time_slot.end_time",
                        moment(`${date} ${end_time}`, "YYYY-MM-DD HH:mm")
                          .add(SYSTEM_TIMEZONE.HOURS, "hours")
                          .toDate(),
                      ],
                    },
                  ],
                },
              }
            : {}),
        },
      },
      {
        $sort: { created_at: -1 },
      },
      {
        $match: {
          zone_id: { $in: zones.map((item) => item._id) },
        },
      },
      {
        $project: {
          _id: 0,
          shift_id: "$shift_id",
          shift_time_slot_id: "$time_slot._id",
          week_day_id: "$week_day_id",
          start_time: "$time_slot.start_time_hour",
          end_time: "$time_slot.end_time_hour",
          number_of_rider: "$time_slot.number_of_rider",
          total_time: 1,
          zone_id: "$zone_name.zones._id",
          zone_name: "$zone_name.zones.name",
          status: { $arrayElemAt: ["$booking_status.name", 0] },
          booking_status_id: { $arrayElemAt: ["$booking_status._id", 0] },
        },
      },

      { $skip: skip },
      ...(limit > 0 ? [{ $limit: limit }] : []),
    ]);

    console.log(data);

    return data;
  } catch (err) {
    console.error(err);
    return false;
  }
};

DataSchema.statics.getMyShiftList = async function (
  rider_id,
  // zones,
  start_date,
  end_date,
  lim,
  page = 1
) {
  try {
    let data;
    let limit = lim > 0 ? lim : 0;
    const skip = limit * (page - 1);
    data = await this.aggregate([
      {
        $match: {
          rider_id: rider_id,
        },
      },
      {
        $lookup: {
          from: "rider_shift_duty_booking_status",
          localField: "rider_shift_duty_booking_status_id",
          foreignField: "_id",
          pipeline: [
            {
              $project: {
                _id: 1,
                name: 1,
              },
            },
          ],
          as: "booking_status",
        },
      },
      {
        $lookup: {
          from: "rider_shift_duty_time_slot_setup",
          localField: "rider_shift_duty_time_slot_setup_id",
          foreignField: "_id",
          pipeline: [
            {
              $lookup: {
                from: "rider_shift_duty_setup",
                localField: "rider_shift_duty_setup_id",
                foreignField: "_id",
                pipeline: [
                  {
                    $lookup: {
                      from: "zones",
                      localField: "zone_id",
                      foreignField: "_id",
                      pipeline: [
                        {
                          $project: {
                            _id: 1,
                            name: 1,
                          },
                        },
                      ],
                      as: "zones",
                    },
                  },
                  {
                    $project: {
                      _id: 0,
                      zone_id: 1,
                      shift_id: "$_id",
                      week_day_id: 1,
                      zones: { $arrayElemAt: ["$zones", 0] },
                    },
                  },
                ],
                as: "rider_shift_duty_setup",
              },
            },
            {
              $project: {
                _id: 1,
                number_of_rider: 1,
                start_time: 1,
                end_time: 1,
                start_time_hour: {
                  $dateToString: {
                    format: "%H:%M ",
                    date: "$start_time",
                  },
                },
                end_time_hour: {
                  $dateToString: {
                    format: "%H:%M ",
                    date: "$end_time",
                  },
                },
                rider_shift_duty_setup: {
                  $arrayElemAt: ["$rider_shift_duty_setup", 0],
                },
              },
            },
          ],
          as: "time_slot",
        },
      },
      {
        $addFields: {
          time_slot: { $arrayElemAt: ["$time_slot", 0] },
          shift_id: {
            $arrayElemAt: ["$time_slot.rider_shift_duty_setup.shift_id", 0],
          },
          week_day_id: {
            $arrayElemAt: ["$time_slot.rider_shift_duty_setup.week_day_id", 0],
          },
          zone_name: { $arrayElemAt: ["$time_slot.rider_shift_duty_setup", 0] },
          zone_id: {
            $arrayElemAt: ["$time_slot.rider_shift_duty_setup.zone_id", 0],
          },
        },
      },

      {
        $addFields: {
          total_time: {
            $let: {
              vars: {
                diffMinutes: {
                  $divide: [
                    {
                      $subtract: [
                        "$time_slot.end_time",
                        "$time_slot.start_time",
                      ],
                    },
                    1000 * 60,
                  ],
                },
              },
              in: {
                $concat: [
                  {
                    $cond: [
                      { $gte: ["$$diffMinutes", 60 * 24] },
                      {
                        $concat: [
                          {
                            $toString: {
                              $floor: { $divide: ["$$diffMinutes", 60 * 24] },
                            },
                          },
                          "d ",
                        ],
                      },
                      "",
                    ],
                  },
                  {
                    $toString: {
                      $floor: {
                        $mod: [{ $divide: ["$$diffMinutes", 60] }, 24],
                      },
                    },
                  },
                  "h ",
                  { $toString: { $floor: { $mod: ["$$diffMinutes", 60] } } },
                  "m",
                ],
              },
            },
          },
        },
      },

      {
        $match: {
          $expr: {
            $and: [
              {
                $gte: [
                  "$time_slot.start_time",
                  moment(start_date)
                    .startOf("day")
                    .add(SYSTEM_TIMEZONE.HOURS, "hours")
                    .toDate(),
                ],
              },
              {
                $lte: [
                  "$time_slot.end_time",
                  moment(end_date)
                    .endOf("day")
                    .add(SYSTEM_TIMEZONE.HOURS, "hours")
                    .toDate(),
                ],
              },
            ],
          },
        },
      },
      {
        $sort: { created_at: -1 },
      },
      {
        $project: {
          _id: 0,
          shift_id: "$shift_id",
          shift_time_slot_id: "$time_slot._id",
          week_day_id: "$week_day_id",
          start_time: "$time_slot.start_time_hour",
          end_time: "$time_slot.end_time_hour",
          number_of_rider: "$time_slot.number_of_rider",
          total_time: 1,
          zone_id: "$zone_name.zones._id",
          zone_name: "$zone_name.zones.name",
          status: { $arrayElemAt: ["$booking_status.name", 0] },
          booking_status_id: { $arrayElemAt: ["$booking_status._id", 0] },
        },
      },

      { $skip: skip },
      ...(limit > 0 ? [{ $limit: limit }] : []),
    ]);

    console.log(data);

    return data;
  } catch (err) {
    console.error(err);
    return false;
  }
};

DataSchema.statics.getUpcomingShiftList = async function (rider_id) {
  try {
    let data, shift_data, message;
    let date = moment().toDate();
    let current_hour = moment().toDate().getHours();
    console.log("currentHour", current_hour);
    data = await this.aggregate([
      {
        $match: {
          rider_id: rider_id,
        },
      },
      {
        $lookup: {
          from: "rider_shift_duty_booking_status",
          localField: "rider_shift_duty_booking_status_id",
          foreignField: "_id",
          pipeline: [
            {
              $project: {
                _id: 1,
                name: 1,
              },
            },
          ],
          as: "booking_status",
        },
      },
      {
        $lookup: {
          from: "rider_shift_duty_time_slot_setup",
          localField: "rider_shift_duty_time_slot_setup_id",
          foreignField: "_id",
          pipeline: [
            {
              $lookup: {
                from: "rider_shift_duty_setup",
                localField: "rider_shift_duty_setup_id",
                foreignField: "_id",
                pipeline: [
                  {
                    $lookup: {
                      from: "week_days",
                      localField: "week_day_id",
                      foreignField: "_id",
                      pipeline: [
                        {
                          $project: {
                            _id: 1,
                            name: 1,
                          },
                        },
                      ],
                      as: "week_days",
                    },
                  },
                  {
                    $lookup: {
                      from: "zones",
                      localField: "zone_id",
                      foreignField: "_id",
                      pipeline: [
                        {
                          $project: {
                            _id: 1,
                            name: 1,
                          },
                        },
                      ],
                      as: "zones",
                    },
                  },
                  {
                    $project: {
                      _id: 0,
                      zone_id: 1,
                      shift_id: "$_id",
                      week_day_id: 1,
                      zones: { $arrayElemAt: ["$zones", 0] },
                      week_day: { $arrayElemAt: ["$week_days.name", 0] },
                    },
                  },
                ],
                as: "rider_shift_duty_setup",
              },
            },
            {
              $sort: { start_time: 1 },
            },
            {
              $project: {
                _id: 1,
                number_of_rider: 1,
                start_time: 1,
                end_time: 1,
                start_time_hour: {
                  $dateToString: {
                    format: "%H:%M ",
                    date: "$start_time",
                  },
                },
                end_time_hour: {
                  $dateToString: {
                    format: "%H:%M ",
                    date: "$end_time",
                  },
                },
                rider_shift_duty_setup: {
                  $arrayElemAt: ["$rider_shift_duty_setup", 0],
                },
              },
            },
          ],
          as: "time_slot",
        },
      },
      {
        $addFields: {
          time_slot: { $arrayElemAt: ["$time_slot", 0] },
          shift_id: {
            $arrayElemAt: ["$time_slot.rider_shift_duty_setup.shift_id", 0],
          },
          week_day_id: {
            $arrayElemAt: ["$time_slot.rider_shift_duty_setup.week_day_id", 0],
          },
          week_day: {
            $arrayElemAt: ["$time_slot.rider_shift_duty_setup.week_day", 0],
          },
          zone_name: { $arrayElemAt: ["$time_slot.rider_shift_duty_setup", 0] },

          zone_id: {
            $arrayElemAt: ["$time_slot.rider_shift_duty_setup.zone_id", 0],
          },
        },
      },

      {
        $addFields: {
          total_time: {
            $let: {
              vars: {
                diffMinutes: {
                  $divide: [
                    {
                      $subtract: [
                        "$time_slot.end_time",
                        "$time_slot.start_time",
                      ],
                    },
                    1000 * 60,
                  ],
                },
              },
              in: {
                $concat: [
                  {
                    $cond: [
                      { $gte: ["$$diffMinutes", 60 * 24] },
                      {
                        $concat: [
                          {
                            $toString: {
                              $floor: { $divide: ["$$diffMinutes", 60 * 24] },
                            },
                          },
                          "d ",
                        ],
                      },
                      "",
                    ],
                  },
                  {
                    $toString: {
                      $floor: {
                        $mod: [{ $divide: ["$$diffMinutes", 60] }, 24],
                      },
                    },
                  },
                  "h ",
                  { $toString: { $floor: { $mod: ["$$diffMinutes", 60] } } },
                  "m",
                ],
              },
            },
          },
        },
      },

      {
        $addFields: {
          bookingStatus: { $arrayElemAt: ["$booking_status.name", 0] },
        },
      },
      {
        $match: {
          bookingStatus: {
            $in: ["booked", "swap_accepted", "request_for_swap"],
          },
          $expr: {
            $and: [
              {
                $gte: [
                  "$date",
                  moment(date)
                    .startOf("day")
                    .add(SYSTEM_TIMEZONE.HOURS, "hours")
                    .toDate(),
                ],
              },
              {
                $lte: [
                  "$date",
                  moment(date)
                    .endOf("day")
                    .add(SYSTEM_TIMEZONE.HOURS, "hours")
                    .toDate(),
                ],
              },
            ],
          },
        },
      },
      {
        $sort: { date: 1 },
      },
      {
        $limit: 1,
      },
      {
        $addFields: {
          formattedDate: {
            $concat: [
              {
                $switch: {
                  branches: [
                    { case: { $eq: [{ $month: "$date" }, 1] }, then: "Jan" },
                    { case: { $eq: [{ $month: "$date" }, 2] }, then: "Feb" },
                    { case: { $eq: [{ $month: "$date" }, 3] }, then: "Mar" },
                    { case: { $eq: [{ $month: "$date" }, 4] }, then: "Apr" },
                    { case: { $eq: [{ $month: "$date" }, 5] }, then: "May" },
                    { case: { $eq: [{ $month: "$date" }, 6] }, then: "Jun" },
                    { case: { $eq: [{ $month: "$date" }, 7] }, then: "Jul" },
                    { case: { $eq: [{ $month: "$date" }, 8] }, then: "Aug" },
                    { case: { $eq: [{ $month: "$date" }, 9] }, then: "Sep" },
                    { case: { $eq: [{ $month: "$date" }, 10] }, then: "Oct" },
                    { case: { $eq: [{ $month: "$date" }, 11] }, then: "Nov" },
                    { case: { $eq: [{ $month: "$date" }, 12] }, then: "Dec" },
                  ],
                  default: "",
                },
              },
              " ",
              {
                $substrCP: ["$date", 8, 2],
              },
            ],
          },
        },
      },
      {
        $addFields: {
          message: {
            $cond: [
              {
                $gt: [
                  {
                    $hour: {
                      $add: ["$date", SYSTEM_TIMEZONE.HOURS * 60 * 60 * 1000],
                    },
                  },
                  { $hour: moment().toDate() },
                ],
              },
              "You are late",
              "",
            ],
          },
        },
      },
      {
        $project: {
          _id: 0,
          formattedDate: 1,
          shift_id: "$shift_id",
          shift_time_slot_id: "$time_slot._id",
          date: 1,
          week_day_id: "$week_day_id",
          start_time: "$time_slot.start_time_hour",
          end_time: "$time_slot.end_time_hour",
          number_of_rider: "$time_slot.number_of_rider",
          total_time: 1,
          zone_id: "$zone_name.zones._id",
          week_day: "$week_day",
          zone_name: "$zone_name.zones.name",
          status: "$bookingStatus",
          booking_status_id: { $arrayElemAt: ["$booking_status._id", 0] },
          message: "$message",
        },
      },
    ]);

    shift_data = data.shift();
    let start_time = shift_data.date;
    let current_time = moment()
      .add(SYSTEM_TIMEZONE.HOURS, "hours")
      .format("HH:mm");

    shift_data.message = moment(start_time, "HH:mm").isAfter(
      moment(current_time, "HH:mm")
    )
      ? "You are late"
      : "";

    return shift_data;
  } catch (err) {
    console.error(err);
    return false;
  }
};
const RiderShiftDutyBooking = mongoose.model(
  "rider_shift_duty_booking",
  DataSchema
);
export default RiderShiftDutyBooking;
