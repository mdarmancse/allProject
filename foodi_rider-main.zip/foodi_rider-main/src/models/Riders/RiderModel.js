import { Schema, model } from "mongoose";
import { v4 as uuidv4 } from "uuid";
import moment from "moment";
import { SYSTEM_TIMEZONE } from "../../consts/defaults.js";
import Zone from "../Common/Zone.js";
const date_now = new Date();
// const user_id = uuidv4().replace(/\-/g, "");
const user_id = () => uuidv4();
const DataSchema = Schema(
  {
    _id: {
      type: String,
      default: user_id,
    },

    first_name: { type: String, default: null },
    email: { type: String, default: null },
    last_name: { type: String, default: null },
    mobile_number: { type: String, default: null },
    password: { type: String, default: null },
    confirm_password: { type: String, default: null },
    image: { type: String, default: null },
    current_balance: { type: Number, default: 0 },
    nid_front: { type: String, default: null },
    nid_back: { type: String, default: null },
    referer_nid_front: { type: String, default: null },
    referer_nid_back: { type: String, default: null },
    mac: { type: String, default: null },
    imei: { type: String, default: null },
    house_nameplate: { type: String, default: null },
    present_address: { type: String, default: null },
    permanent_address: { type: String, default: null },
    guardian_nid_front: { type: String, default: null },
    guardian_nid_back: { type: String, default: null },
    vehicle_type_id: { type: String, default: null },
    city_id: { type: String, default: null },
    bkash_no: { type: String, default: null },

    nid_no: { type: String, default: null },
    driving_license_id: { type: String, default: null },
    driving_license_image: { type: String, default: null },
    vehicle_registration_id: { type: String, default: null },
    vehicle_registration_image: { type: String, default: null },
    referrer_url: { type: String, default: null },
    birth_date: { type: Date, default: null },
    joining_date: { type: Date, default: null },
    active_contract_date: { type: Date, default: null },

    electricity_bill: { type: String, default: null },
    otp: { type: Number, default: 0 },
    otp_expire_time: { type: Date, default: Date.now() },
    is_new: { type: Boolean, default: false },
    zones: [
      {
        _id: { type: String, default: () => uuidv4() },
        rider_id: { type: String },
        zone_id: { type: String },
      },
    ],
    device_id: { type: String, default: null },
    latitude: { type: Number, default: null },
    longitude: { type: Number, default: null },
    is_verified: { type: Boolean, default: false },
    is_active: { type: Boolean, default: true },
    is_approve: { type: Boolean, default: false },
    created_at: {
      type: Date,
      default: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
    },
    created_by: { type: String, default: user_id },
    updated_at: {
      type: Date,
      default: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
    },
    updated_by: { type: String, default: user_id },
  },
  {
    versionKey: false,
  }
);
DataSchema.statics.getRiderById = async function (id) {
  try {
    const data = await this.aggregate([
      {
        $match: {
          _id: id,
          is_active: true,
        },
      },
      {
        $project: {
          _id: 1,
          first_name: 1,
          last_name: 1,
          vehicle_type_id: 1,
          zone_id: 1,
          current_balance: 1,
          is_active: 1,
        },
      },
    ]);
    return data.shift();
  } catch (err) {
    console.error(err);
    return false;
  }
};

DataSchema.statics.getZoneByRider = async function (rider_id) {
  try {
    let data;

    data = await this.aggregate([
      {
        $match: {
          _id: rider_id,
          is_active: true,
        },
      },
      {
        $lookup: {
          from: "zones",
          localField: "zones.zone_id",
          foreignField: "_id",
          pipeline: [
            {
              $project: {
                _id: 1,
                name: 1,
              },
            },
          ],
          as: "zones",
        },
      },
      {
        $project: {
          _id: 0,
          zones: 1,
        },
      },
      { $unwind: "$zones" },
      { $replaceRoot: { newRoot: "$zones" } },
    ]);

    console.log(data);

    return data;
  } catch (err) {
    console.error(err);
    return false;
  }
};
const RiderModel = model("riders", DataSchema);
export default RiderModel;
