import mongoose from "mongoose";
import { v4 as uuidv4 } from "uuid";
import moment from "moment";
import { SYSTEM_TIMEZONE } from "../../consts/defaults.js";
const DataSchema = new mongoose.Schema(
  {
    _id: {
      type: String,
      default: () => uuidv4(),
    },
    rest_id: { type: String },
    rider_id: { type: String },
    comment: { type: String },
    name: { type: String, default: "Unknown Name" },
    order_id: { type: String },
    rating: { type: String, default: "good", enum: ["good", "bad"] },
    issues: {
      late_prepare: { type: Boolean, default: false },
      miss_behave: { type: Boolean, default: false },
      incorrect_items: { type: Boolean, default: false },
      packing_issue: { type: Boolean, default: false },
      other: { type: Boolean, default: false },
    },
    is_active: { type: Boolean, default: true },
    created_at: {
      type: Date,
      default: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
    },
    created_by: { type: String, default: null },
    updated_at: {
      type: Date,
      default: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
    },
    updated_by: { type: String, default: null },
  },
  {
    collection: "rider_reviews",
    versionKey: false,
  }
);

const RiderReviews = mongoose.model("rider_reviews", DataSchema);
export default RiderReviews;
