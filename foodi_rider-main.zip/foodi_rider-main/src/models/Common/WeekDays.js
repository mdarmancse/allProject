import mongoose from "mongoose";
import { v4 as uuidv4 } from "uuid";
import moment from "moment";
import { SYSTEM_TIMEZONE } from "../../consts/defaults.js";
import RiderShiftDutyBooking from "../Shift/RiderShiftDutyBooking";
const DataSchema = new mongoose.Schema(
  {
    _id: {
      type: String,
    },
    name: { type: String, default: null },
    created_at: {
      type: Date,
      default: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
    },
    updated_at: {
      type: Date,
      default: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
    },
  },
  {
    collection: "week_days",
    //  timestamps: true,
    versionKey: false,
  }
);
DataSchema.statics.getMyShiftList = async function (
  rider_id,
  start_date,
  end_date
) {
  try {
    let data,
      week_number,
      startDate,
      endDate,
      total_shifts = 0;
    startDate = moment(start_date)
      .startOf("day")
      .add(SYSTEM_TIMEZONE.HOURS, "hours")
      .toDate();
    endDate = moment(end_date)
      .endOf("day")
      .add(SYSTEM_TIMEZONE.HOURS, "hours")
      .toDate();

    week_number = moment(startDate).isoWeek();

    data = await this.aggregate([
      {
        $project: {
          _id: 1,
          name: 1,
        },
      },

      {
        $facet: {
          booked_shift: [
            {
              $lookup: {
                from: "rider_shift_duty_setup",
                localField: "_id",
                foreignField: "week_day_id",
                pipeline: [
                  {
                    $lookup: {
                      from: "rider_shift_duty_time_slot_setup",
                      localField: "_id",
                      foreignField: "rider_shift_duty_setup_id",
                      pipeline: [
                        {
                          $lookup: {
                            from: "rider_shift_duty_booking",
                            localField: "_id",
                            foreignField: "rider_shift_duty_time_slot_setup_id",
                            pipeline: [
                              {
                                $match: {
                                  rider_id: rider_id,
                                },
                              },
                              {
                                $lookup: {
                                  from: "rider_shift_duty_booking_status",
                                  localField:
                                    "rider_shift_duty_booking_status_id",
                                  foreignField: "_id",
                                  pipeline: [
                                    {
                                      $project: {
                                        _id: 1,
                                        name: 1,
                                      },
                                    },
                                  ],
                                  as: "booking_status",
                                },
                              },
                              {
                                $addFields: {
                                  booking_status: {
                                    $arrayElemAt: ["$booking_status", 0],
                                  },
                                },
                              },
                              {
                                $project: {
                                  rider_id: 1,
                                  rider_shift_duty_time_slot_setup_id: 1,
                                  booking_status_id: "$booking_status._id",
                                  booking_status: "$booking_status.name",
                                },
                              },
                            ],
                            as: "rider_shift_duty_booking",
                          },
                        },

                        {
                          $project: {
                            _id: 1,
                            rider_shift_duty_booking: 1,
                            number_of_rider: 1,
                            start_time: 1,
                            end_time: 1,
                            start_time_hour: {
                              $dateToString: {
                                format: "%H:%M ",
                                date: "$start_time",
                              },
                            },
                            end_time_hour: {
                              $dateToString: {
                                format: "%H:%M ",
                                date: "$end_time",
                              },
                            },

                            duration: {
                              $let: {
                                vars: {
                                  diff: {
                                    $subtract: ["$end_time", "$start_time"],
                                  },
                                },
                                in: {
                                  hours: {
                                    $floor: {
                                      $divide: ["$$diff", 1000 * 60 * 60],
                                    },
                                  },
                                  minutes: {
                                    $mod: [
                                      {
                                        $floor: {
                                          $divide: ["$$diff", 1000 * 60],
                                        },
                                      },
                                      60,
                                    ],
                                  },
                                },
                              },
                            },
                          },
                        },
                      ],
                      as: "time_slot",
                    },
                  },
                  {
                    $addFields: {
                      time_slot: { $arrayElemAt: ["$time_slot", 0] },
                      rider_book_data: {
                        $arrayElemAt: [
                          "$time_slot.rider_shift_duty_booking",
                          0,
                        ],
                      },
                      booking_status: {
                        $arrayElemAt: [
                          "$time_slot.rider_shift_duty_booking.booking_status",
                          0,
                        ],
                      },
                      rider_id: {
                        $arrayElemAt: [
                          "$time_slot.rider_shift_duty_booking.rider_id",
                          0,
                        ],
                      },
                    },
                  },

                  {
                    $lookup: {
                      from: "zones",
                      localField: "zone_id",
                      foreignField: "_id",
                      pipeline: [
                        {
                          $project: {
                            _id: 1,
                            name: 1,
                          },
                        },
                      ],
                      as: "zones",
                    },
                  },

                  {
                    $match: {
                      $expr: {
                        $and: [
                          {
                            $gte: ["$time_slot.start_time", startDate],
                          },
                          {
                            $lte: ["$time_slot.end_time", endDate],
                          },
                        ],
                      },
                    },
                  },

                  {
                    $sort: { start_time: -1 },
                  },
                  {
                    $addFields: {
                      rider_book_data: {
                        $arrayElemAt: ["$rider_book_data", 0],
                      },
                    },
                  },
                  {
                    $match: {
                      rider_book_data: { $exists: true },
                    },
                  },

                  {
                    $project: {
                      _id: 0,
                      rider_id: { $arrayElemAt: ["$rider_id", 0] },
                      shift_id: "$_id",
                      shift_time_slot_id: "$time_slot._id",
                      duration: "$time_slot.duration",
                      status: {
                        $cond: {
                          if: {
                            $gt: [
                              { $size: "$time_slot.rider_shift_duty_booking" },
                              0,
                            ],
                          },
                          then: { $arrayElemAt: ["$booking_status", 0] },
                          else: 0,
                        },
                      },
                      start_time: "$time_slot.start_time_hour",
                      end_time: "$time_slot.end_time_hour",
                      number_of_rider: "$time_slot.number_of_rider",
                      zone_id: 1,
                      zone_name: { $arrayElemAt: ["$zones.name", 0] },
                      week_day_id: 1,
                      swap_request_timeout_hour: 1,
                    },
                  },
                ],
                as: "shift_data",
              },
            },
            {
              $addFields: {
                total_duration: {
                  $let: {
                    vars: {
                      total_minutes: {
                        $sum: {
                          $map: {
                            input: "$shift_data",
                            as: "shift",
                            in: {
                              $add: [
                                { $multiply: ["$$shift.duration.hours", 60] },
                                "$$shift.duration.minutes",
                              ],
                            },
                          },
                        },
                      },
                    },
                    in: {
                      hours: { $floor: { $divide: ["$$total_minutes", 60] } },
                      minutes: { $mod: ["$$total_minutes", 60] },
                    },
                  },
                },
              },
            },
            { $sort: { _id: 1 } },
            {
              $project: {
                _id: 1,
                name: 1,
                total_duration: 1,
                shift_data: {
                  $cond: {
                    if: { $gt: [{ $size: "$shift_data" }, 0] },
                    then: "$shift_data",
                    else: null,
                  },
                },
              },
            },
          ],
          history: [
            {
              $lookup: {
                from: "rider_shift_duty_setup",
                localField: "_id",
                foreignField: "week_day_id",
                pipeline: [
                  {
                    $lookup: {
                      from: "rider_shift_duty_time_slot_setup",
                      localField: "_id",
                      foreignField: "rider_shift_duty_setup_id",
                      pipeline: [
                        {
                          $lookup: {
                            from: "rider_shift_duty_booking",
                            localField: "_id",
                            foreignField: "rider_shift_duty_time_slot_setup_id",
                            pipeline: [
                              {
                                $match: {
                                  rider_id: rider_id,
                                },
                              },
                              {
                                $lookup: {
                                  from: "rider_shift_duty_booking_evaluate_status",
                                  localField:
                                    "rider_shift_duty_booking_evaluate_status_id",
                                  foreignField: "_id",
                                  pipeline: [
                                    {
                                      $project: {
                                        _id: 1,
                                        name: 1,
                                        information: 1,
                                      },
                                    },
                                  ],
                                  as: "evaluate_status",
                                },
                              },
                              {
                                $addFields: {
                                  evaluate_status: {
                                    $arrayElemAt: ["$evaluate_status", 0],
                                  },
                                },
                              },
                              {
                                $project: {
                                  rider_id: 1,
                                  rider_shift_duty_time_slot_setup_id: 1,
                                  evaluate_status_id: "$evaluate_status._id",
                                  evaluate_status: "$evaluate_status.name",
                                  evaluate_information:
                                    "$evaluate_status.information",
                                },
                              },
                            ],
                            as: "rider_shift_duty_booking",
                          },
                        },

                        {
                          $project: {
                            _id: 1,
                            rider_shift_duty_booking: 1,
                            number_of_rider: 1,
                            start_time: 1,
                            end_time: 1,
                            start_time_hour: {
                              $dateToString: {
                                format: "%H:%M ",
                                date: "$start_time",
                              },
                            },
                            end_time_hour: {
                              $dateToString: {
                                format: "%H:%M ",
                                date: "$end_time",
                              },
                            },

                            duration: {
                              $let: {
                                vars: {
                                  diff: {
                                    $subtract: ["$end_time", "$start_time"],
                                  },
                                },
                                in: {
                                  hours: {
                                    $floor: {
                                      $divide: ["$$diff", 1000 * 60 * 60],
                                    },
                                  },
                                  minutes: {
                                    $mod: [
                                      {
                                        $floor: {
                                          $divide: ["$$diff", 1000 * 60],
                                        },
                                      },
                                      60,
                                    ],
                                  },
                                },
                              },
                            },
                          },
                        },
                      ],
                      as: "time_slot",
                    },
                  },
                  {
                    $addFields: {
                      time_slot: { $arrayElemAt: ["$time_slot", 0] },
                      rider_book_data: {
                        $arrayElemAt: [
                          "$time_slot.rider_shift_duty_booking",
                          0,
                        ],
                      },
                      evaluate_status: {
                        $arrayElemAt: [
                          "$time_slot.rider_shift_duty_booking.evaluate_status",
                          0,
                        ],
                      },
                      evaluate_information: {
                        $arrayElemAt: [
                          "$time_slot.rider_shift_duty_booking.evaluate_information",
                          0,
                        ],
                      },
                      rider_id: {
                        $arrayElemAt: [
                          "$time_slot.rider_shift_duty_booking.rider_id",
                          0,
                        ],
                      },
                    },
                  },

                  {
                    $lookup: {
                      from: "zones",
                      localField: "zone_id",
                      foreignField: "_id",
                      pipeline: [
                        {
                          $project: {
                            _id: 1,
                            name: 1,
                          },
                        },
                      ],
                      as: "zones",
                    },
                  },

                  {
                    $match: {
                      $expr: {
                        $and: [
                          {
                            $gte: ["$time_slot.start_time", startDate],
                          },
                          {
                            $lte: ["$time_slot.end_time", endDate],
                          },
                        ],
                      },
                    },
                  },

                  {
                    $sort: { start_time: -1 },
                  },
                  {
                    $addFields: {
                      rider_book_data: {
                        $arrayElemAt: ["$rider_book_data", 0],
                      },
                    },
                  },
                  {
                    $match: {
                      rider_book_data: { $exists: true },
                    },
                  },

                  {
                    $project: {
                      _id: 0,
                      rider_id: { $arrayElemAt: ["$rider_id", 0] },
                      shift_id: "$_id",
                      shift_time_slot_id: "$time_slot._id",
                      duration: "$time_slot.duration",
                      evaluate_information: {
                        $arrayElemAt: ["$evaluate_information", 0],
                      },
                      status: {
                        $cond: {
                          if: {
                            $gt: [
                              { $size: "$time_slot.rider_shift_duty_booking" },
                              0,
                            ],
                          },
                          then: { $arrayElemAt: ["$evaluate_status", 0] },
                          else: 0,
                        },
                      },
                      start_time: "$time_slot.start_time_hour",
                      end_time: "$time_slot.end_time_hour",
                      number_of_rider: "$time_slot.number_of_rider",
                      zone_id: 1,
                      zone_name: { $arrayElemAt: ["$zones.name", 0] },
                      week_day_id: 1,
                      swap_request_timeout_hour: 1,
                    },
                  },
                ],
                as: "shift_data",
              },
            },
            {
              $addFields: {
                total_duration: {
                  $let: {
                    vars: {
                      total_minutes: {
                        $sum: {
                          $map: {
                            input: "$shift_data",
                            as: "shift",
                            in: {
                              $add: [
                                { $multiply: ["$$shift.duration.hours", 60] },
                                "$$shift.duration.minutes",
                              ],
                            },
                          },
                        },
                      },
                    },
                    in: {
                      hours: { $floor: { $divide: ["$$total_minutes", 60] } },
                      minutes: { $mod: ["$$total_minutes", 60] },
                    },
                  },
                },
              },
            },
            { $sort: { _id: 1 } },
            {
              $project: {
                _id: 1,
                name: 1,
                total_duration: 1,
                shift_data: {
                  $cond: {
                    if: { $gt: [{ $size: "$shift_data" }, 0] },
                    then: "$shift_data",
                    else: null,
                  },
                },
              },
            },
          ],
        },
      },
    ]);

    let return_data = data.shift();

    total_shifts = await RiderShiftDutyBooking.count({
      rider_id: rider_id,
      date: {
        $gte: startDate,
        $lte: endDate,
      },
    });

    let final_data = {
      booked_shift: {
        total_shifts: total_shifts ? total_shifts : 0,
        sum_of_duration: calculateSumOfDuration(return_data.booked_shift),
        week_number: week_number ? week_number : null,
        shift_list: addDates(return_data.booked_shift, startDate),
      },
      history: {
        no_shows: countStatus(return_data.history, "no_show_excused"),
        sum_of_duration: calculateSumOfDuration(return_data.history),
        week_number: week_number ? week_number : null,
        shift_list: addDates(return_data.history, startDate),
      },
    };

    return final_data;
  } catch (err) {
    console.error(err);
    return false;
  }
};
function calculateSumOfDuration(data) {
  let total_minutes = data.reduce((acc, day) => {
    return acc + day.total_duration.hours * 60 + day.total_duration.minutes;
  }, 0);

  let hours = Math.floor(total_minutes / 60);
  let minutes = total_minutes % 60;

  let sum_of_duration = `${hours}h ${minutes}m`;

  return sum_of_duration;
}

function addDates(shift_list, startDate) {
  let startOfWeek = moment(startDate).startOf("isoWeek");
  return shift_list.map((day) => {
    let date = startOfWeek
      .clone()
      .add(day._id - 1, "days")
      .format("YYYY-MM-DD");
    return { ...day, date };
  });
}

function countStatus(shift_list, status) {
  let count = 0;
  shift_list.forEach((shift) => {
    if (shift.shift_data) {
      shift.shift_data.forEach((data) => {
        if (data.status === status) {
          count++;
        }
      });
    }
  });
  return count;
}

const WeekDays = mongoose.model("week_days", DataSchema);
export default WeekDays;
