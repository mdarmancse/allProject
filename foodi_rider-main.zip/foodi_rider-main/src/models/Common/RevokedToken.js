import mongoose from "mongoose";
import { v4 as uuidv4 } from "uuid";
import moment from "moment";
import { SYSTEM_TIMEZONE } from "../../consts/defaults.js";
const DataSchema = new mongoose.Schema(
  {
    _id: {
      type: String,
      default: () => uuidv4(),
    },
    token: {
      type: String,
      required: true,
      unique: true,
    },
    is_active: { type: Boolean, default: true },
    created_at: {
      type: Date,
      default: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
    },
    updated_at: {
      type: Date,
      default: moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate(),
    },
  },
  {
    collection: "revoked_tokens",
    //  timestamps: true,
    versionKey: false,
  }
);

const RevokedToken = mongoose.model("revoked_tokens", DataSchema);
export default RevokedToken;
