import moment from "moment";
import { v4 as uuidv4 } from "uuid";
import { ResponseVariant } from "../helper/ResponseVariant.js";
import GeneratedQuest from "../models/quests/GeneratedQuest.js";
import Quest from "../models/quests/QuestModel.js";
import { SYSTEM_TIMEZONE } from "../consts/defaults.js";
import { Send_Queue } from "../helper/common/RMQ.js";
import { config } from "dotenv";
config();
const cms_queue = process.env.CMS_QUEUE_NAME;

export async function getCurrentQuestList(req, res) {
  try {
    const { id } = req.body;

    const data = await GeneratedQuest.getCurrentQuests(id);

    if (data) {
      return res.json(ResponseVariant.success(data));
    } else {
      return res.json(ResponseVariant.fail("No data found."));
    }
  } catch (err) {
    console.error(err);
    return res.json(ResponseVariant.error());
  }
}

export async function getPastQuestList(req, res) {
  try {
    const { id } = req.body;

    const data = await GeneratedQuest.getPastQuests(id);
    if (data) {
      return res.json(ResponseVariant.success(data));
    } else {
      return res.json(ResponseVariant.fail("No data found."));
    }
  } catch (err) {
    console.error(err);
    return res.json(ResponseVariant.error());
  }
}

export async function getQuestDetails(req, res) {
  try {
    const { id, quest_id } = req.body;

    const data = await GeneratedQuest.getQuestDetails(id, quest_id);

    if (data) {
      return res.json(ResponseVariant.success(data));
    } else {
      return res.json(ResponseVariant.fail("No data found."));
    }
  } catch (err) {
    return res.json(ResponseVariant.error());
    throw err;
  }
}

// Run this cronjob in linux server. This task will run every night past midnight and will generate quests for next 7 days
// 1 0 * * * /usr/bin/curl {SERVER_URL}/v1/api/riders/quests/generateQuests > /dev/null 2>&1`
export async function generateQuests(req, res) {
  try {
    let body = req.body;
    let quest_data = [];
    const quests = await Quest.find({});

    // Loop through each day for the next 7 days
    for (let i = 0; i < 7; i++) {
      const day = moment()
        .add(i, "days")
        .add(SYSTEM_TIMEZONE.HOURS, "hours")
        .format("YYYY-MM-DD");

      for (const quest of quests) {
        // Check if the quest end date is not before the current day
        if (moment(quest.end_date).isSameOrAfter(day, "day")) {
          if (quest.has_time_limit) {
            // If the quest has a time limit
            const startDateTime = moment(
              `${day} ${quest.start_time}`,
              "YYYY-MM-DD HH:mm"
            )
              .add(SYSTEM_TIMEZONE.HOURS, "hours")
              .toDate();
            const endDateTime = moment(
              `${day} ${quest.end_time}`,
              "YYYY-MM-DD HH:mm"
            )
              .add(SYSTEM_TIMEZONE.HOURS, "hours")
              .toDate();

            // Check if there is already a quest generated for the day with the same start time
            const existingQuest = await GeneratedQuest.findOne({
              quest_id: quest._id,
              start_date_time: startDateTime,
            });

            // If no existing quest is found, create a new one
            if (!existingQuest) {
              if (quest.goals.length > 0) {
                for (let i = 0; i < quest.goals.length; i++) {
                  quest.goals[i]._id = uuidv4();
                  quest.goals[i].generated_quest_id = quest.goals[i].quest_id;
                  delete quest.goals[i].quest_id;
                }
              }

              if (quest.zones.length > 0) {
                for (let i = 0; i < quest.zones.length; i++) {
                  quest.zones[i]._id = uuidv4();
                  quest.zones[i].generated_quest_id = quest.zones[i].quest_id;
                  delete quest.zones[i].quest_id;
                }
              }

              let GQ = await GeneratedQuest.create({
                _id: uuidv4(),
                quest_id: quest._id,
                name: quest.name,
                acceptable_acceptance_rate: quest.acceptable_acceptance_rate,
                acceptable_completion_rate: quest.acceptable_completion_rate,
                start_date_time: startDateTime,
                end_date_time: endDateTime,
                rules: quest.rules,
                zones: quest.zones,
                goals: quest.goals,
                is_active: quest.is_active,
                created_at: new Date(),
                updated_at: new Date(),
                created_by: "43615def-456d-44c9-abf3-08db65a648fb",
                updated_by: "43615def-456d-44c9-abf3-08db65a648fb",
              });

              quest_data.push(GQ);
            }
          } else {
            // If the quest does not have a time limit
            const existingQuest = await GeneratedQuest.findOne({
              quest_id: quest._id,
            });

            // If no existing quest is found, create a new one
            if (!existingQuest) {
              await GeneratedQuest.create({
                _id: uuidv4(),
                quest_id: quest._id,
                name: quest.name,
                acceptable_acceptance_rate: quest.acceptable_acceptance_rate,
                acceptable_completion_rate: quest.acceptable_completion_rate,
                start_date_time: quest.start_date,
                end_date_time: quest.end_date,
                rules: quest.rules,
                zones: quest.zones,
                goals: quest.goals,
                is_active: quest.is_active,
                created_at: new Date(),
                updated_at: new Date(),
              });
            }
          }
        }
      }
    }

    // return res.json(quest_data)

    if (quest_data.length > 0) {
      await Send_Queue(
        cms_queue,
        "rider_queue",
        quest_data,
        "generated_quest",
        "add"
      );
    }

    return res.json(ResponseVariant.success());
  } catch (err) {
    console.error(err);
    return res.json(ResponseVariant.error());
  }
}
