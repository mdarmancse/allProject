import RidersOrder from "../models/Orders/RidersOrder.js";
import RidersOrderMap from "../models/Orders/RidersOrderMap.js";
import RiderReviews from "../models/Riders/RiderReviews.js";
import VehicleType from "../models/Riders/VehicleType.js";

import { config } from "dotenv";
import crud_helper from "../helper/common/crud_helper.js";
import { Send_Central, Send_Queue } from "../helper/common/RMQ.js";
import { riderOrderRules, validator } from "../helper/validator.js";

import moment from "moment/moment.js";
import ListService from "../helper/common/ListService.js";

config();
import Validator from "validatorjs";
import cryptoJS from "crypto-js";
import GenerateImageLink from "../helper/GenerateImageLink.js";
import fs from "fs";
import axios from "axios";
import { sendNotifications } from "../helper/common/Notifications.js";
import DistanceMatrix from "../helper/common/DistanceMatrix.js";
import RiderModel from "../models/Riders/RiderModel.js";
import RidersWallet from "../models/Wallet/RidersWallet.js";
import { UpdateService } from "../helper/common/CRUD.js";
import PayablesModel from "../models/Wallet/PayablesModel.js";
import GeneratedQuests from "../models/quests/GeneratedQuest.js";
import RiderGoalsOrderCompletion from "../models/quests/RiderGoalOrderCompletionModel.js";
import OrderStatusHistory from "../models/Orders/OrderStatusHistory.js";

const cms_queue = process.env.CMS_QUEUE_NAME;
const company_name = process.env.COMPANY_NAME;

export async function orderDetails(req, res, next) {
  const rules = riderOrderRules;
  let error;
  const body = req.body;

  await validator(body, rules, {}, (err) => {
    error = err;
  });
  if (error) {
    return res.json({
      status: -1,
      data: error,
      msg: "Validation error.",
    });
  }

  try {
    const queue_request = [
      { $match: { _id: body.order_id } },
      {
        $lookup: {
          from: "restaurents",
          localField: "branch_id",
          foreignField: "_id",
          pipeline: [
            {
              $project: {
                _id: 1,
                name: 1,
                phone_number: 1,
                address: 1,
                image: 1,
                commission: 1,
                delivery_charge: 1,
                delivery_time: 1,
                pickup_time: 1,
                location: 1,
              },
            },
          ],
          as: "restaurant_details",
        },
      },
      {
        $project: {
          customer_id: 1,
          zone_id: 1,
          user_lat: 1,
          user_long: 1,
          device_id: 1,
          payment_method_id: 1,
          sub_total: { $round: ["$sub_total", 2] },
          total_amount: { $round: ["$total_amount", 2] },
          address: 1,
          instruction: 1,
          order_details: 1,
          rider_accepted: 1,
          arrived_vendor: 1,
          arrived_customer: 1,
          arrival_time: 1,
          delivery_time: 1,
          order_status: 1,
          avg_time: 1,
          payment_to_vendor: { $round: ["$payment_to_vendor", 2] },
          delivery_charge: { $round: ["$delivery_charge", 2] },
          restaurant_details: { $arrayElemAt: ["$restaurant_details", 0] },
        },
      },
    ];

    let order_details_data = await Send_Queue(
      "main_restaurant_request",
      "rider_queue",
      queue_request,
      "OrderModel",
      "join_get"
    );
    //  return res.json({ status: 1, data: order_details_data });
    if (!order_details_data || !order_details_data.data) {
      return res.json({ status: -1, msg: "No order found" });
    }

    const customer_id = order_details_data.data.customer_id;
    let user_data = await Send_Queue(
      "main_user_request",
      "rider_queue",
      { _id: customer_id },
      "UserModel",
      "get"
    );

    order_details_data.data.user_details = user_data.data;

    let rider_details = await RiderModel.getRiderById(body.id);
    let rider_charge;
    if (rider_details.vehicle_type_id) {
      rider_charge = (
        await VehicleType.vehicleTypeById(rider_details.vehicle_type_id)
      ).commission;
    }

    order_details_data.data.riders_earning = rider_charge;

    let results;
    if (order_details_data) {
      results = {
        status: 1,
        msg: "Data fetched successfully",
        data: order_details_data.data,
      };
    } else {
      results = {
        status: -1,
        msg: "No data found",
      };
    }

    return res.status(200).json(results);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ status: -1, msg: "Server error" });
  }
}

export async function orderList(req, res, next) {
  let rules = { id: "required" };
  let error;
  let body = req.body;

  await validator(body, rules, {}, (err) => {
    error = err;
  });
  if (error) {
    return res.json({
      status: -1,
      data: error,
      msg: "Validation error.",
    });
  }

  let results = {};

  try {
    const order_data = await RidersOrder.orderList(body.id);

    if (order_data.length > 0) {
      results = {
        status: 1,
        msg: "Data fetched successfully",
        data: order_data,
      };
    } else {
      results = {
        status: -1,
        msg: "No data found",
      };
    }

    return res.status(200).json(results);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ status: -1, msg: "Server error" });
  }
}

export async function orderHistory(req, res, next) {
  let rules = { id: "required", start_date: "required", end_date: "required" };
  let error;
  let body = req.body;

  await validator(body, rules, {}, (err) => {
    error = err;
  });
  if (error) {
    return res.json({
      status: -1,
      data: error,
      msg: "Validation error.",
    });
  }

  let results = {};

  try {
    const order_data = await RidersOrder.orderHistory(
      body.id,
      body.start_date,
      body.end_date,
      body.order_status,
      body.limit,
      body.page
    );

    if (order_data) {
      results = {
        status: 1,
        msg: "Data fetched successfully",
        data: order_data,
        //start_date: new Date(`${body.start_date}T00:00:00.000Z`),
      };
    } else {
      results = {
        status: -1,
        msg: "No data found",
      };
    }

    return res.status(200).json(results);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ status: -1, msg: "Server error" });
  }
}

const cancelOrderbyRider = async (
  order_id,
  rider_id,
  order_details_data,
  user_data
) => {
  let queue_data;
  let rider_status = {
    rider_id: rider_id,
    order_status: "cancel_by_rider",
    customer_name: user_data.data.firstName + " " + user_data.data.lastName,
    branch_name: order_details_data.data.restaurant_details.name,
    created_by: rider_id,
    updated_by: rider_id,
    is_active: false,
    proof_image: null,
  };
  let riders_order = await RidersOrder.findOneAndUpdate(
    {
      rider_id: rider_id,
      order_id: order_id,
    },
    { $set: rider_status },
    {
      returnOriginal: false,
    }
  );
  console.log("riders_order", riders_order);
  let riders_order_map = await RidersOrderMap.create({
    rider_id: rider_id,
    order_id: order_id,
    order_status: "cancel_by_rider",
    rider_accepted: false,
    arrived_vendor: false,
    proof_image: null,
    created_by: rider_id,
    updated_by: rider_id,
  });

  console.log("riders_order_map", riders_order_map);

  queue_data = await Send_Queue(
    "main_restaurant_request",
    "rider_queue",
    {
      _id: order_id,
      rider_id: null,
      order_status: "accepted",
      rider_accepted: false,
    },
    "OrderModel",
    "edit"
  );

  let send_cms_data = {
    order: {
      data: queue_data.data ? queue_data.data : null,
      method: "edit",
    },
    wallet: {
      data: null,
      method: "add",
    },
    rider_goal_order_completion: {
      data: null,
      method: "add",
    },
    payable: {
      data: null,
      method: "add",
    },
    rider_order_map: {
      data: riders_order_map ? riders_order_map : null,
      method: "add",
    },
    rider_order: {
      data: riders_order ? riders_order : null,
      method: "edit",
    },
    rider_current_balance: {
      data: null,
      method: "edit",
    },
  };

  // return res.json(send_cms_data)
  const send_q = await Send_Queue(
    cms_queue,
    "rider_queue",
    send_cms_data,
    "order",
    "order_status"
  );
  // console.log("queue_data", send_q);
  return {
    status: 1,
    msg: "Order has been cancelled!",
  };
};

export async function changeStatus(req, res, next) {
  try {
    const currentTime = moment();
    let results = {},
      message,
      push_noti,
      queue_data,
      delivery_time,
      rider_rest_distance,
      device_id,
      rest_lat,
      rest_long,
      rider_rest_time,
      payment_method,
      avg_time,
      highest_recipe_time,
      new_delivery_time,
      payableData,
      subscription_type_id,
      goal_data,
      updateRider,
      rider_wallet_data,
      rest_cust_duration,
      arrivalTime,
      formattedArrivalTime,
      total_delivery_time;
    const {
      order_id,
      order_status,
      rider_lat,
      rider_long,
      rider_accepted,
      arrived_vendor,
      arrived_customer,
      rider_cancel,
    } = req.body;

    let rules = {
      order_id: "required",
      order_status: "required",
    };

    let error, imageLink, imagePath;
    let body = req.body;
    //let device_id=body.device_id;

    await validator(body, rules, {}, (err) => {
      error = err;
    });
    if (error) {
      return res.json({
        status: -1,
        data: error,
        msg: "Validation error.",
      });
    }

    let queue_request = [
      { $match: { _id: body.order_id } },
      {
        $lookup: {
          from: "restaurents",
          localField: "branch_id",
          foreignField: "_id",
          pipeline: [
            {
              $project: {
                _id: 1,
                name: 1,
                phone_number: 1,
                address: 1,
                image: 1,
                commission: 1,
                delivery_charge: 1,
                delivery_time: 1,
                pickup_time: 1,
                location: 1,
                total_delivery_time: 1,
              },
            },
          ],
          as: "restaurant_details",
        },
      },
      {
        $project: {
          customer_id: 1,
          zone_id: 1,
          user_lat: 1,
          user_long: 1,
          delivery_time: 1,
          highest_recipe_time: 1,
          avg_time: 1,
          payment_method_id: 1,
          sub_total: 1,
          total_amount: 1,
          address: 1,
          instruction: 1,
          order_details: 1,
          device_id: 1,
          order_status: 1,
          payment_to_vendor: 1,
          delivery_charge: 1,
          value_added_tax_inclusive: 1,
          supplementary_duty: 1,
          discount_amount: 1,
          total_delivery_time: 1,
          rest_cust_duration: 1,
          restaurant_details: { $arrayElemAt: ["$restaurant_details", 0] },
        },
      },
    ];

    let order_details_data,
      user_data,
      customer_id,
      commission,
      sub_total,
      total_amount,
      discount_amount,
      total_vat,
      total_sd,
      restaurant_pay,
      customer_pay,
      foodi_pay,
      rider_charge,
      rider_earning,
      rider_details,
      rider_first_name,
      current_balance,
      rewards_data,
      get_customer_point;
    order_details_data = await Send_Queue(
      "main_restaurant_request_2",
      "rider_queue",
      queue_request,
      "OrderModel",
      "join_get"
    );

    if (order_details_data.data) {
      rider_details = await RiderModel.getRiderById(body.id);
      customer_id = order_details_data.data.customer_id;
      commission = order_details_data.data.restaurant_details.commission
        ? order_details_data.data.restaurant_details.commission
        : 0;
      sub_total = order_details_data.data.sub_total;
      total_amount = order_details_data.data.total_amount;
      payment_method = order_details_data.data.payment_method_id;
      restaurant_pay = sub_total - (sub_total * commission) / 100;
      customer_pay = total_amount;
      foodi_pay = customer_pay - restaurant_pay;
      rider_charge = (
        await VehicleType.vehicleTypeById(rider_details.vehicle_type_id)
      ).commission;
      rider_earning = foodi_pay - rider_charge;

      user_data = await Send_Queue(
        "main_user_request",
        "rider_queue",
        { _id: customer_id },
        "UserModel",
        "get"
      );
      device_id = user_data.data.device_id;
      subscription_type_id = user_data.data.subscription_type_id;
      if (rider_cancel === "true") {
        const cancelOrder = await cancelOrderbyRider(
          order_id,
          body.id,
          order_details_data,
          user_data
        );

        return res.json(cancelOrder);
      }
    } else {
      return res.json({ status: -1, msg: "No order found" });
    }

    //accepted,ongoing,preparing,cancel,not_delivered,delivered
    if (order_status === "assigned" && rider_accepted === "true") {
      rest_long =
        order_details_data.data.restaurant_details.location.coordinates[0];
      rest_lat =
        order_details_data.data.restaurant_details.location.coordinates[1];
      avg_time = order_details_data.data.avg_time;
      highest_recipe_time = order_details_data.data.highest_recipe_time;
      delivery_time = order_details_data.data.delivery_time;
      rest_long =
        order_details_data.data.restaurant_details.location.coordinates[0];
      rest_lat =
        order_details_data.data.restaurant_details.location.coordinates[1];
      rider_rest_distance = await DistanceMatrix(
        rest_lat,
        rest_long,
        rider_lat,
        rider_long
      );
      rider_rest_time = Math.round(rider_rest_distance.duration.value / 60);

      new_delivery_time = delivery_time - avg_time + rider_rest_time;
      rider_first_name = rider_details.first_name;
      arrivalTime = currentTime.add(rider_rest_time, "minutes");
      formattedArrivalTime = arrivalTime.format("h:mm A");
    }
    if (order_status === "preparing" && arrived_vendor === "true") {
      avg_time = order_details_data.data.avg_time;
      delivery_time = order_details_data.data.delivery_time;
      new_delivery_time = delivery_time - avg_time;

      message = {
        notification: {
          title: "We have begun preparing your order.",
          body: "Click & track your order",
        },
        data: {
          screenType: "order",
        },
        token: device_id,
      };
      push_noti = await sendNotifications(message);
    }
    if (order_status === "ongoing") {
      if (arrived_customer === "true") {
        delivery_time = order_details_data.data.delivery_time;
        new_delivery_time = delivery_time;
      } else {
        highest_recipe_time = order_details_data.data.highest_recipe_time;
        delivery_time = order_details_data.data.delivery_time;
        new_delivery_time = delivery_time - highest_recipe_time;

        let wallet_data = {
          order_id: order_id,
          from: body.id,
          to: order_details_data.data.restaurant_details._id,
          payment_type: "payment_to_vendor",
          amount: -restaurant_pay,
          cash_out: 0,
          order_status: order_status,
          payment_method: payment_method,
          created_by: body.id,
          updated_by: body.id,
        };
        const rider_wallet_data = await RidersWallet.create(wallet_data);
        if (rider_wallet_data) {
          let payable_data = {
            order_id: order_id,
            from: body.id,
            to: company_name,
            amount: -restaurant_pay,
            payment_method: payment_method,
            payment_type: "payment_to_vendor",
            created_by: body.id,
            updated_by: body.id,
          };

          payableData = await PayablesModel.create(payable_data);

          current_balance = rider_details.current_balance - restaurant_pay;

          const update_rider = {
            _id: body.id,
            current_balance: current_balance,
          };
          updateRider = await UpdateService(update_rider, "RiderModel");

          console.log("current_balance", current_balance);
        }
        rest_cust_duration = order_details_data.data.rest_cust_duration;
        arrivalTime = currentTime.add(rest_cust_duration, "minutes");
        formattedArrivalTime = arrivalTime.format("h:mm A");
      }

      message = {
        notification: {
          title: "Order Ongoing",
          body: "We are working on your order and it is currently in progress. We will notify you once it is ready for delivery",
        },
        data: {
          screenType: "order",
        },
        token: device_id,
      };
    }
    if (order_status === "delivered") {
      total_delivery_time = await OrderStatusHistory.calculateTotalDeliveryTime(
        order_id
      );

      //   return res.json(total_delivery_time)
      get_customer_point = await Send_Queue(
        "main_restaurant_request",
        "rider_queue",
        { subscription_type_id: subscription_type_id },
        "PointSetter",
        "customer_point"
      );
      console.log("get_customer_point", get_customer_point);
      //return res.json(get_customer_point)
      if (get_customer_point) {
        if (get_customer_point.per_point_value > 0) {
          let rewards_point = total_amount / get_customer_point.per_point_value;
          let reward_json = {
            type: "Earn",
            order_id: order_id,
            customer_id: customer_id,
            description: "Task Completed",
            point: rewards_point,
            cost: total_amount,
            per_point_value: get_customer_point.per_point_value,
            created_by: body.id,
            updated_by: body.id,
          };
          rewards_data = await Send_Queue(
            "main_restaurant_request",
            "rider_queue",
            reward_json,
            "EarnBurnHistory",
            "add"
          );
        }
      }

      const quest_data = await GeneratedQuests.getRunningGoals(body.id);
      console.log(quest_data);
      if (quest_data) {
        goal_data = await RiderGoalsOrderCompletion.create({
          generated_quest_id: quest_data._id,
          goal_id: quest_data.goals._id,
          rider_id: body.id,
          order_id: order_id,
          order_value: quest_data.goals.per_order_value,
          created_by: body.id,
          updated_by: body.id,
        });
        console.log("goal_data :", goal_data);
      }

      let wallet_data = {
        order_id: order_id,
        from: customer_id,
        to: body.id,
        payment_type: "collection",
        amount: customer_pay,
        cash_out: 0,
        rider_earning: rider_charge,
        order_status: order_status,
        payment_method: payment_method,
        created_by: body.id,
        updated_by: body.id,
      };

      rider_wallet_data = await RidersWallet.create(wallet_data);

      if (rider_wallet_data) {
        let payable_data = [
          {
            order_id: order_id,
            from: body.id,
            to: company_name,
            amount: customer_pay,
            payment_method: payment_method,
            payment_type: "collection",
            created_by: body.id,
            updated_by: body.id,
          },
          {
            order_id: order_id,
            from: company_name,
            to: body.id,
            amount: rider_charge,
            payment_method: payment_method,
            payment_type: "earnings",
            created_by: body.id,
            updated_by: body.id,
          },
        ];
        payableData = await PayablesModel.insertMany(payable_data);
        current_balance = rider_details.current_balance + customer_pay;

        console.log("RIDER_ID", body.id);
        const update_rider = {
          _id: body.id,
          current_balance: current_balance,
        };
        updateRider = await UpdateService(update_rider, "RiderModel");

        console.log("current_balance", current_balance);
      }
      message = {
        notification: {
          title: "Your order has been delivered",
          body: "Thanks for your order",
        },
        data: {
          screenType: "order",
        },
        token: device_id,
      };

      imagePath = req.file ? req.file.path : null;
      imageLink = imagePath ? await GenerateImageLink(imagePath) : null;
    }
    if (order_status === "not_delivered") {
      message = {
        notification: {
          title: "Update on Your Order",
          body: "We apologize for the delay in delivering your order. Our team is working diligently to resolve the issue and ensure that your order arrives as soon as possible. Thank you for your patience and understanding.",
        },
        data: {
          screenType: "order",
        },
        token: device_id,
      };
    }
    if (order_status === "cancel") {
      message = {
        notification: {
          title: "Your order has been cancelled",
          body: "We regret to inform you that your order has been cancelled. Please contact us if you have any questions",
        },
        data: {
          screenType: "order",
        },
        token: device_id,
      };
    }

    let rider_status = {
      rider_id: body.id,
      order_status,
      created_by: body.id,
      updated_by: body.id,
      customer_name: user_data.data.firstName + " " + user_data.data.lastName,
      branch_name: order_details_data.data.restaurant_details.name,
      proof_image: imageLink ? imageLink.url : null,
    };
    let riders_order = await RidersOrder.findOneAndUpdate(
      {
        rider_id: body.id,
        order_id: body.order_id,
      },
      { $set: rider_status },
      {
        returnOriginal: false,
      }
    );

    // return res.json(riders_order)
    console.log("riders_order", riders_order);
    let riders_order_map = await RidersOrderMap.create({
      rider_id: body.id,
      order_id: body.order_id,
      order_status: order_status,
      branch_payable: restaurant_pay
        ? restaurant_pay
        : order_details_data.data.payment_to_vendor,
      customer_payable: customer_pay ? customer_pay : 0,
      rider_current_balance: current_balance,
      rider_accepted: rider_accepted
        ? rider_accepted
        : order_details_data.data.rider_accepted,
      arrived_vendor: arrived_vendor
        ? arrived_vendor
        : order_details_data.data.arrived_vendor,
      arrived_customer: arrived_customer
        ? arrived_customer
        : order_details_data.data.arrived_customer,
      proof_image: imageLink ? imageLink.url : null,
      total_amount: rider_charge,
      created_by: body.id,
      updated_by: body.id,
    });

    console.log("riders_order_map", riders_order_map);

    let order_status_history = await OrderStatusHistory.create({
      order_id: body.order_id,
      order_status_name: order_status,
      latitude: rider_lat,
      longitude: rider_long,
      created_by: body.id,
      updated_by: body.id,
    });

    console.log("order_status_history", order_status_history);

    //return res.json(riders_order_map)
    if (imageLink) await fs.promises.unlink(imagePath);

    let send_rest_data = {
      _id: order_id,
      rider_id: body.id,
      rider_accepted: rider_accepted
        ? rider_accepted
        : order_details_data.data.rider_accepted,
      arrival_time: formattedArrivalTime
        ? formattedArrivalTime
        : order_details_data.data.arrival_time,
      rider_first_name: rider_first_name
        ? rider_first_name
        : order_details_data.data.rider_first_name,
      payment_to_vendor: restaurant_pay
        ? restaurant_pay
        : order_details_data.data.payment_to_vendor,
      arrived_vendor: arrived_vendor
        ? arrived_vendor
        : order_details_data.data.arrived_vendor,
      arrived_customer: arrived_customer
        ? arrived_customer
        : order_details_data.data.arrived_customer,
      order_status: order_status,
      delivery_time: new_delivery_time,
      total_delivery_time: total_delivery_time,
      avg_time: rider_rest_time,
      proof_image: imageLink ? imageLink.url : null,
    };
    queue_data = await Send_Queue(
      "main_restaurant_request",
      "rider_queue",
      send_rest_data,
      "OrderModel",
      "socket_add"
    );
    let balance_data = {
      _id: body.id,
      current_balance: current_balance,
    };
    let send_cms_data = {
      order: {
        data: queue_data.data ? queue_data.data : null,
        method: "edit",
      },
      wallet: {
        data: rider_wallet_data ? rider_wallet_data : null,
        method: "add",
      },
      rider_goal_order_completion: {
        data: goal_data ? goal_data : null,
        method: "add",
      },
      payable: {
        data: payableData ? payableData : null,
        method: "add",
      },
      rider_order_map: {
        data: riders_order_map ? riders_order_map : null,
        method: "add",
      },
      rider_order: {
        data: riders_order ? riders_order : null,
        method: "edit",
      },
      rider_current_balance: {
        data: balance_data ? balance_data : null,
        method: "edit",
      },
      order_status_history: {
        data: order_status_history ? order_status_history : null,
        method: "add",
      },
      // rewards_data:{
      //     data:rewards_data?rewards_data:null,
      //     method:'add'
      // }
    };

    //return res.json(send_rest_data)
    const send_q = await Send_Queue(
      cms_queue,
      "rider_queue",
      send_cms_data,
      "order",
      "order_status"
    );
    console.log("queue_data", send_q);

    if (queue_data) {
      //if (formattedArrivalTime) queue_data.data.arrival_time =formattedArrivalTime;
      if (message) {
        await sendNotifications(message);
      }
      results = {
        status: 1,
        msg: "Order Status Updated",
        data: queue_data.data,
      };
    } else {
      results = {
        status: -1,
        msg: "Something Went wrong!",
      };
    }

    return res.status(200).json(results);
  } catch (err) {
    console.error(err);
    return res
      .status(500)
      .json({ status: -1, msg: "Server error", error: err.toString() });
  }
}

export async function addReview(req, res, next) {
  try {
    const { rest_id, comment, name, order_id, rating, issues } = req.body;
    let rider_id = req.body.id;
    const review = await RiderReviews.findOneAndUpdate(
      { rest_id, rider_id, order_id },
      {
        rest_id,
        rider_id: rider_id,
        comment,
        name,
        order_id,
        rating,
        issues,
        created_by: rider_id,
        updated_by: rider_id,
      },
      {
        upsert: true,
        new: true,
        setDefaultsOnInsert: true,
        rawResult: true,
      }
    );

    if (review && review.lastErrorObject.updatedExisting == false) {
      await Send_Queue(
        cms_queue,
        "rider_queue",
        review.value,
        "rider_review",
        "add"
      );
      console.log("Document Inserted");
    }
    if (review && review.lastErrorObject.updatedExisting == true) {
      await Send_Queue(
        cms_queue,
        "rider_queue",
        review.value,
        "rider_review",
        "edit"
      );
      console.log("Document Updated");
    }

    if (rating === "bad") {
      return res.status(200).json({
        status: 1,
        issues: {
          late_prepare: issues.late_prepare,
          miss_behave: issues.miss_behave,
          incorrect_items: issues.incorrect_items,
          packing_issue: issues.packing_issue,
          other: issues.other,
        },
      });
    } else {
      return res.status(200).json({
        status: 1,
        msg: "Review added successfully.",
      });
    }
  } catch (err) {
    console.error(err);
    return res.status(500).json({ status: -1, msg: "Server error" });
  }
}

export async function hitMap(req, res, next) {
  let error;
  let body = req.body;
  let rules = { id: "required" };
  await validator(body, rules, {}, (err) => {
    error = err;
  });
  if (error) {
    return res.json({
      status: -1,
      data: error,
      msg: "Validation error.",
    });
  }

  let results = {};

  try {
    const last30Minutes = new Date(Date.now() - 30 * 60 * 1000);
    const queue_request = [
      // {
      //     $match: {
      //         created_at: { $gte: last30Minutes }
      //     }
      // },

      {
        $lookup: {
          from: "restaurents",
          localField: "branch_id",
          foreignField: "_id",
          pipeline: [
            {
              $project: {
                _id: 1,
                name: 1,
                phone_number: 1,
                address: 1,
                image: 1,
                commission: 1,
                delivery_charge: 1,
                delivery_time: 1,
                pickup_time: 1,
                location: 1,
              },
            },
          ],
          as: "restaurant",
        },
      },

      {
        $unwind: "$restaurant",
      },

      {
        $project: {
          _id: 1,
          longitude: { $arrayElemAt: ["$restaurant.location.coordinates", 0] },
          latitude: { $arrayElemAt: ["$restaurant.location.coordinates", 1] },
        },
      },

      {
        $group: {
          _id: { longitude: "$longitude", latitude: "$latitude" },
          weight: { $sum: 1 },
        },
      },

      {
        $project: {
          _id: 0,
          longitude: "$_id.longitude",
          latitude: "$_id.latitude",
          weight: 1,
        },
      },
    ];

    console.log(queue_request);

    // res.send(queue_request)

    let order_details_data, user_data, customer_id;
    order_details_data = await Send_Queue(
      "main_restaurant_request",
      "rider_queue",
      queue_request,
      "OrderModel",
      "join_get"
    );
    console.log("order_details_data", order_details_data);

    if (order_details_data.data.length > 0) {
      results = {
        status: 1,
        msg: "Data fetched successfully",
        data: order_details_data.data,
      };
    } else {
      results = {
        status: -1,
        msg: "No data found",
      };
    }

    return res.status(200).json(results);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ status: -1, msg: "Server error" });
  }
}
