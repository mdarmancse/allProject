import { config } from "dotenv";
import { Send_Central, Send_Queue } from "../helper/common/RMQ.js";
import { userBasicRules, validator } from "../helper/validator.js";
config();
import RidersShift from "../models/Shift/RidersShift.js";
import Zone from "../models/Common/Zone.js";
import RiderShiftDutyBooking from "../models/Shift/RiderShiftDutyBooking.js";
import RiderShiftDutyBookingStatus from "../models/Shift/RiderShiftDutyBookingStatus.js";
import RiderShiftDutyBookingEvaluateStatus from "../models/Shift/RiderShiftDutyBookingEvaluateStatus.js";
import RiderShiftDutySetup from "../models/Shift/RiderShiftDutySetup.js";
import RiderShiftTimeSlot from "../models/Shift/RiderShiftTimeSlot.js";

import moment from "moment";
import { SYSTEM_TIMEZONE } from "../consts/defaults.js";
import RiderModel from "../models/Riders/RiderModel.js";
import WeekDays from "../models/Common/WeekDays";
const cms_queue = process.env.CMS_QUEUE_NAME;
// import { redis_delete, redis_get, redis_set } from "../helper/redis.js";

export async function startShift(req, res, next) {
  try {
    const { id } = req.body;

    const existingShift = await RidersShift.findOne({
      rider_id: id,
      end_time: null,
    });

    if (existingShift) {
      return res.json({
        status: -1,
        msg: "You are already in a shift. Please end your current shift before starting a new one.",
      });
    } else {
      const data = await RidersShift.create({
        rider_id: id,
        start_time: Date.now(),
        is_active: true,
        created_by: id,
        updated_by: id,
      });

      if (data) {
        await Send_Queue(cms_queue, "rider_queue", data, "rider_shift", "add");
      }

      //if(data)await Send_Central(data,'rider','edit');

      return res.json({
        status: 0,
        data: data,
        msg: "Shift started successfully.",
      });
    }
  } catch (error) {
    return res.status(500).json({
      status: -1,
      msg: error.message,
    });
  }
}

export async function endShift(req, res, next) {
  try {
    const { shift_id } = req.params;
    const { id } = req.body;

    const existingShift = await RidersShift.findById(shift_id);

    if (!existingShift) {
      return res.status(404).json({
        status: -1,
        msg: "Shift not found",
      });
    }

    if (existingShift.end_time !== null) {
      return res.status(400).json({
        status: -1,
        msg: "Shift has already ended",
      });
    }

    const data = await RidersShift.findOneAndUpdate(
      { _id: shift_id },
      {
        end_time: Date.now(),
        is_active: false,
        updated_by: id,
        updated_at: Date.now(),
      },
      { returnOriginal: false }
    );
    if (data) {
      await Send_Queue(cms_queue, "rider_queue", data, "rider_shift", "edit");
    }

    return res.status(200).json({
      status: 1,
      msg: "Shift ended successfully",
      data: data,
    });
  } catch (error) {
    return res.status(500).json({
      status: -1,
      msg: error.message,
    });
  }
}

export async function resumePauseShift(req, res, next) {
  try {
    const { id, shift_id, status } = req.body;

    const rules = {
      id: "required",
      shift_id: "required",
      status: "required",
    };

    let error;
    await validator(req.body, rules, {}, (err) => {
      error = err;
    });

    if (error) {
      return res.status(200).json({
        status: -1,
        data: error,
        msg: "Validation error.",
      });
    }

    const existingShift = await RidersShift.findById(shift_id);

    if (!existingShift) {
      return res.status(404).json({
        status: -1,
        msg: "Shift not found",
      });
    }

    if (existingShift.end_time !== null) {
      return res.status(400).json({
        status: -1,
        msg: "Cannot resume or pause an ended shift",
      });
    }

    let updateData;
    let message;

    if (status === "pause") {
      updateData = {
        is_active: false,
        updated_by: id,
        updated_at: Date.now(),
      };
      message = "Shift paused";
    } else if (status === "resume") {
      updateData = {
        is_active: true,
        updated_by: id,
        updated_at: Date.now(),
      };
      message = "Shift resumed";
    } else {
      return res.status(400).json({
        status: -1,
        msg: "Invalid status",
      });
    }

    const data = await RidersShift.findOneAndUpdate(
      { _id: shift_id },
      updateData,
      { returnOriginal: false }
    );
    if (data) {
      await Send_Queue(cms_queue, "rider_queue", data, "rider_shift", "edit");
    }

    return res.status(200).json({
      status: 1,
      msg: message,
      data: data,
    });
  } catch (error) {
    return res.status(500).json({
      status: -1,
      msg: error.message,
    });
  }
}

export async function checkShift(req, res, next) {
  try {
    const { id } = req.body;

    const today = moment().add(SYSTEM_TIMEZONE.HOURS, "hours").toDate();
    const shift = await RidersShift.findOne({
      rider_id: id,
      start_time: { $lte: today },
      $or: [{ end_time: null }, { end_time: { $gte: today } }],
    });

    if (shift) {
      if (shift.is_active && !shift.end_time) {
        return res.json({
          status: 0,
          msg: "Shift is currently running",
          data: shift,
        });
      } else if (!shift.is_active && !shift.end_time) {
        return res.json({
          status: 0,
          msg: "Shift is currently paused",
          data: shift,
        });
      } else {
        return res.json({
          status: -1,
          msg: "No shift found",
        });
      }
    } else {
      return res.status(404).json({ status: -1, msg: "No shift found" });
    }
  } catch (error) {
    return res.status(500).json({
      status: -1,
      msg: "Server error",
      err: error.toString(),
    });
  }
}

export async function availableShift(req, res, next) {
  try {
    let zones;
    const { id, date, start_time, end_time, zone_id, limit, page } = req.body;
    if (zone_id) {
      zones = zone_id.map((id) => {
        return { _id: id };
      });
    } else {
      zones = await RiderModel.getZoneByRider(id);
    }

    const data = await RiderShiftDutySetup.getAvailableShiftList(
      zones,
      date,
      start_time,
      end_time,
      limit,
      page
    );
    if (data.length > 0) {
      return res.json({
        status: 1,
        data: data,
      });
    } else {
      return res.json({
        status: -1,
        msg: "No data found",
      });
    }
  } catch (error) {
    return res.status(500).json({
      status: -1,
      msg: "Server error",
      err: error.toString(),
    });
  }
}
export async function upcomingShift(req, res, next) {
  try {
    let zones;
    const { id, limit, page } = req.body;

    const data = await RiderShiftDutyBooking.getUpcomingShiftList(
      id,
      limit,
      page
    );
    if (data) {
      return res.json({
        status: 1,
        data: data,
      });
    } else {
      return res.json({
        status: -1,
        msg: "No data found",
      });
    }
  } catch (error) {
    return res.status(500).json({
      status: -1,
      msg: "Server error",
      err: error.toString(),
    });
  }
}

export async function bookedShift(req, res, next) {
  try {
    let zones;
    const { id, date, start_time, end_time, zone_id, limit, page } = req.body;
    if (zone_id) {
      zones = zone_id.map((id) => {
        return { _id: id };
      });
    } else {
      zones = await RiderModel.getZoneByRider(id);
    }
    const data = await RiderShiftDutyBooking.getBookingShiftList(
      id,
      zones,
      date,
      start_time,
      end_time,
      limit,
      page
    );
    if (data.length > 0) {
      return res.json({
        status: 1,
        data: data,
      });
    } else {
      return res.json({
        status: -1,
        msg: "No data found",
      });
    }
  } catch (error) {
    return res.status(500).json({
      status: -1,
      msg: "Server error",
      err: error.toString(),
    });
  }
}

export async function bookingStatus(req, res, next) {
  try {
    const data = await RiderShiftDutyBookingStatus.getBookingStatus();

    if (data) {
      return res.status(200).json({
        status: 1,
        data: data,
      });
    } else {
      return res.status(500).json({
        status: -1,
        msg: "Failed to fetch data.",
      });
    }
  } catch (err) {
    console.error(err);
    return res
      .status(500)
      .json({ message: "Server error", err: err.toString() });
  }
}
export async function evaluateStatus(req, res, next) {
  try {
    const data =
      await RiderShiftDutyBookingEvaluateStatus.getBookingEvaluateStatus();

    if (data) {
      return res.status(200).json({
        status: 1,
        data: data,
      });
    } else {
      return res.status(500).json({
        status: -1,
        msg: "Failed to fetch data.",
      });
    }
  } catch (err) {
    console.error(err);
    return res
      .status(500)
      .json({ message: "Server error", err: err.toString() });
  }
}

export async function createBooking(req, res, next) {
  try {
    const { id, shift_time_slot_id, booking_status_id } = req.body;
    let jsonData, booked_data, msg;
    const booking_status = await RiderShiftDutyBookingStatus.findById(
      booking_status_id,
      { _id: 1, name: 1 }
    );
    if (!booking_status) {
      return res.json({
        status: -1,
        msg: "No booking status found with this id",
      });
    }

    if (booking_status.name === "booked") {
      const shiftData = await RiderShiftTimeSlot.getShiftData(
        shift_time_slot_id
      );

      if (shiftData.is_available === false) {
        return res.json({
          status: -1,
          msg: "Sorry,the maximum number of riders for this shift has been reached.",
        });
      }
      jsonData = {
        rider_id: id,
        date: shiftData.start_time,
        rider_shift_duty_time_slot_setup_id: shift_time_slot_id,
        rider_shift_duty_booking_status_id: booking_status._id,
        created_by: id,
        updated_by: id,
      };
      booked_data = await RiderShiftDutyBooking.create(jsonData);
      if (booked_data) msg = "Your shift has been booked";
    }

    if (booking_status.name === "request_for_swap") {
      jsonData = {
        rider_shift_duty_booking_status_id: booking_status._id,
        updated_by: id,
      };
      booked_data = await RiderShiftDutyBooking.updateOne(
        {
          rider_id: id,
          rider_shift_duty_time_slot_setup_id: shift_time_slot_id,
        },
        {
          $set: jsonData,
        }
      );
      if (booked_data) msg = "Your request for a swap has been successful.";
    }

    if (booking_status.name === "swap_accepted") {
      const getStatusByName = await RiderShiftDutyBookingStatus.findOne(
        { name: "swaped" },
        { _id: 1, name: 1 }
      );

      const getOldBookingData = await RiderShiftDutyBooking.findOne(
        { rider_shift_duty_time_slot_setup_id: shift_time_slot_id },
        { _id: 1, rider_id: 1, rider_shift_duty_booking_status_id: 1 }
      );
      const createjsonData = {
        rider_id: id,
        rider_shift_duty_time_slot_setup_id: shift_time_slot_id,
        rider_shift_duty_booking_status_id: getStatusByName._id,
        created_by: id,
        updated_by: id,
      };
      const updatejsonData = {
        rider_shift_duty_booking_status_id: booking_status._id,
        updated_by: getOldBookingData.rider_id,
      };
      await RiderShiftDutyBooking.create(createjsonData);
      booked_data = await RiderShiftDutyBooking.updateOne(
        {
          rider_id: getOldBookingData.rider_id,
          rider_shift_duty_time_slot_setup_id: shift_time_slot_id,
        },
        {
          $set: updatejsonData,
        }
      );
      if (booked_data) msg = "The swap has been accepted successfully.";
    }

    if (booked_data) {
      return res.json({
        status: 1,
        msg: msg,
      });
    } else {
      return res.json({
        status: -1,
        msg: "Something went wrong",
      });
    }
  } catch (err) {
    console.error(err);
    return res
      .status(500)
      .json({ message: "Server error", err: err.toString() });
  }
}

export async function myShift(req, res, next) {
  try {
    let zones;
    const { id, start_date, end_date } = req.body;
    // zones = await RiderModel.getZoneByRider(id);

    const data = await WeekDays.getMyShiftList(
      id,
      // zones,
      start_date,
      end_date
    );
    if (data) {
      return res.json({
        status: 1,
        data: data,
      });
    } else {
      return res.json({
        status: -1,
        msg: "No data found",
      });
    }
  } catch (error) {
    return res.status(500).json({
      status: -1,
      msg: "Server error",
      err: error.toString(),
    });
  }
}
export async function shiftDetails(req, res, next) {
  try {
    let zones;
    const { id, shift_time_slot_id } = req.body;
    // zones = await RiderModel.getZoneByRider(id);

    const data = await RiderShiftTimeSlot.getShiftDetails(
      id,
      shift_time_slot_id
    );
    if (data) {
      return res.json({
        status: 1,
        data: data,
      });
    } else {
      return res.json({
        status: -1,
        msg: "No data found",
      });
    }
  } catch (error) {
    return res.status(500).json({
      status: -1,
      msg: "Server error",
      err: error.toString(),
    });
  }
}
