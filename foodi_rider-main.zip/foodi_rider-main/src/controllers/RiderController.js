import RiderModel from "../models/Riders/RiderModel.js";
import RevokedTokenModel from "../models/Common/RevokedToken.js";
import { initOTP, generateToken } from "../utility/functions.js";
import { config } from "dotenv";
import crud_helper from "../helper/common/crud_helper.js";
import { Send_Central, Send_Queue } from "../helper/common/RMQ.js";
import { userBasicRules, validator } from "../helper/validator.js";
import moment from "moment/moment.js";
import ListService from "../helper/common/ListService.js";
config();
import Validator from "validatorjs";
import cryptoJS from "crypto-js";
import GenerateImageLink from "../helper/GenerateImageLink.js";
import fs from "fs";
import RidersWallet from "../models/Wallet/RidersWallet.js";
import PayablesModel from "../models/Wallet/PayablesModel.js";
import { redis_get, redis_set } from "../helper/redis.js";
import RiderLocation from "../models/Riders/RiderLocation.js";
import RiderGoalOrderCompletion from "../models/quests/RiderGoalOrderCompletionModel.js";
import GeneratedQuest from "../models/quests/GeneratedQuest.js";

// import { redis_delete, redis_get, redis_set } from "../helper/redis.js";

const cms_queue = process.env.CMS_QUEUE_NAME;
export async function registration(req, res, next) {
  try {
    let imageLink, nidFrontLink, nidBackLink, refNidFrontLink, refNidBackLink;
    let rules = userBasicRules;
    let error;
    let body = req.body;
    await validator(body, rules, {}, (err) => {
      error = err;
    });
    if (error) {
      return res.status(200).json({
        status: -1,
        data: error,
        msg: "Validation error.",
      });
    }

    const { mobile_number } = body;
    const imagePath =
      req.files && Array.isArray(req.files.image) && req.files.image.length > 0
        ? req.files.image[0].path
        : null;
    const nidFrontPath =
      req.files &&
      Array.isArray(req.files.nid_front) &&
      req.files.nid_front.length > 0
        ? req.files.nid_front[0].path
        : null;
    const nidBackPath =
      req.files &&
      Array.isArray(req.files.nid_back) &&
      req.files.nid_back.length > 0
        ? req.files.nid_back[0].path
        : null;
    const reffrontPath =
      req.files &&
      Array.isArray(req.files.referer_nid_front) &&
      req.files.referer_nid_front.length > 0
        ? req.files.referer_nid_front[0].path
        : null;
    const refbackPath =
      req.files &&
      Array.isArray(req.files.referer_nid_back) &&
      req.files.referer_nid_back.length > 0
        ? req.files.referer_nid_back[0].path
        : null;
    const gurfontPath =
      req.files &&
      Array.isArray(req.files.guardian_nid_front) &&
      req.files.guardian_nid_front.length > 0
        ? req.files.guardian_nid_front[0].path
        : null;
    const gurbackPath =
      req.files &&
      Array.isArray(req.files.guardian_nid_back) &&
      req.files.guardian_nid_back.length > 0
        ? req.files.guardian_nid_back[0].path
        : null;
    const ecbillPath =
      req.files &&
      Array.isArray(req.files.electricity_bill) &&
      req.files.electricity_bill.length > 0
        ? req.files.electricity_bill[0].path
        : null;
    const drLcPath =
      req.files &&
      Array.isArray(req.files.driving_license_image) &&
      req.files.driving_license_image.length > 0
        ? req.files.driving_license_image[0].path
        : null;
    const vehRegPath =
      req.files &&
      Array.isArray(req.files.vehicle_registration_image) &&
      req.files.vehicle_registration_image.length > 0
        ? req.files.vehicle_registration_image[0].path
        : null;

    const existingUser = await RiderModel.findOne({ mobile_number });
    if (existingUser) {
      if (imagePath) await fs.promises.unlink(imagePath);
      if (nidFrontPath) await fs.promises.unlink(nidFrontPath);
      if (nidBackPath) await fs.promises.unlink(nidBackPath);
      if (reffrontPath) await fs.promises.unlink(reffrontPath);
      if (refbackPath) await fs.promises.unlink(refbackPath);
      if (gurfontPath) await fs.promises.unlink(gurfontPath);
      if (gurbackPath) await fs.promises.unlink(gurbackPath);
      if (ecbillPath) await fs.promises.unlink(ecbillPath);
      if (drLcPath) await fs.promises.unlink(drLcPath);
      if (vehRegPath) await fs.promises.unlink(vehRegPath);
      return res.status(200).json({
        status: -1,
        msg: "A rider already registered with this number,please try with another number!",
      });
    }

    const createData = {};
    // const zones=[
    //     {
    //     rider_id:body.zones[0]["rider_id"],
    //     zone_id:body.zones[0]["zone_id"],
    //     },
    //     {
    //         rider_id:body.zones[1]["rider_id"],
    //         zone_id:body.zones[1]["zone_id"],
    //     },
    // ]
    if (body.first_name) createData.first_name = body.first_name;
    if (body.last_name) createData.last_name = body.last_name;
    if (body.mobile_number) createData.mobile_number = body.mobile_number;
    if (body.email) createData.email = body.email;
    if (body.password)
      createData.password = cryptoJS.MD5(body.password).toString();
    if (imagePath) createData.image = (await GenerateImageLink(imagePath)).url;
    if (nidFrontPath)
      createData.nid_front = (await GenerateImageLink(nidFrontPath)).url;
    if (nidBackPath)
      createData.nid_back = (await GenerateImageLink(nidBackPath)).url;
    if (reffrontPath)
      createData.referer_nid_front = (
        await GenerateImageLink(reffrontPath)
      ).url;
    if (refbackPath)
      createData.referer_nid_back = (await GenerateImageLink(refbackPath)).url;
    if (gurfontPath)
      createData.guardian_nid_front = (
        await GenerateImageLink(gurfontPath)
      ).url;
    if (gurbackPath)
      createData.guardian_nid_back = (await GenerateImageLink(gurbackPath)).url;
    if (ecbillPath)
      createData.electricity_bill = (await GenerateImageLink(ecbillPath)).url;
    if (drLcPath)
      createData.driving_license_image = (
        await GenerateImageLink(drLcPath)
      ).url;
    if (vehRegPath)
      createData.vehicle_registration_image = (
        await GenerateImageLink(vehRegPath)
      ).url;
    if (body.mac) createData.mac = body.mac;
    if (body.imei) createData.imei = body.imei;
    if (body.house_nameplate) createData.house_nameplate = body.house_nameplate;
    if (body.present_address) createData.present_address = body.present_address;
    if (body.permanent_address)
      createData.permanent_address = body.permanent_address;
    if (body.vehicle_type_id) createData.vehicle_type_id = body.vehicle_type_id;
    if (body.city_id) createData.city_id = body.city_id;
    if (body.bkash_no) createData.bkash_no = body.bkash_no;
    if (body.nagad_no) createData.nagad_no = body.nagad_no;
    if (body.nid_no) createData.nid_no = body.nid_no;
    if (body.driving_license_id)
      createData.driving_license_id = body.driving_license_id;
    if (body.vehicle_registration_id)
      createData.vehicle_registration_id = body.vehicle_registration_id;
    if (body.referrer_url) createData.referrer_url = body.referrer_url;
    if (body.birth_date) createData.birth_date = body.birth_date;
    if (body.joining_date) createData.joining_date = body.joining_date;
    if (body.active_contract_date)
      createData.active_contract_date = body.active_contract_date;
    //createData.zones =zones;

    const riderData = await RiderModel.create(createData);

    if (riderData.image) await fs.promises.unlink(imagePath);
    if (riderData.nid_front) await fs.promises.unlink(nidFrontPath);
    if (riderData.nid_back) await fs.promises.unlink(nidBackPath);
    if (riderData.referer_nid_front) await fs.promises.unlink(reffrontPath);
    if (riderData.referer_nid_back) await fs.promises.unlink(refbackPath);
    if (riderData.guardian_nid_front) await fs.promises.unlink(gurfontPath);
    if (riderData.guardian_nid_back) await fs.promises.unlink(gurbackPath);
    if (riderData.electricity_bill) await fs.promises.unlink(ecbillPath);
    if (riderData.driving_license_image) await fs.promises.unlink(drLcPath);
    if (riderData.vehicle_registration_image)
      await fs.promises.unlink(vehRegPath);

    if (riderData) {
      await Send_Queue(cms_queue, "rider_queue", riderData, "rider", "add");
    }

    return res.status(200).json({
      status: 0,
      msg: "Successfully registered",
      user_data: {
        mobile_number: riderData.mobile_number,
        first_name: riderData.first_name,
        last_name: riderData.last_name,
        email: riderData.email,
        is_active: riderData.is_active,
        is_approve: riderData.is_approve,
        image: riderData.image,
        nid_front: riderData.nid_front,
        nid_back: riderData.nid_back,
        referer_nid_front: riderData.referer_nid_front,
        referer_nid_back: riderData.referer_nid_back,
        mac: riderData.mac,
        imei: riderData.imei,
        house_nameplate: riderData.house_nameplate,
        present_address: riderData.present_address,
        permanent_address: riderData.permanent_address,
        guardian_nid_front: riderData.guardian_nid_front,
        guardian_nid_back: riderData.guardian_nid_back,
        vehicle_type_id: riderData.vehicle_type_id,
        city_id: riderData.city_id,
        bkash_no: riderData.bkash_no,
        nagad_no: riderData.nagad_no,
        electricity_bill: riderData.electricity_bill,
        current_balnce: riderData.current_balnce,
        nid_no: riderData.nid_no,
        driving_license_id: riderData.driving_license_id,
        driving_license_image: riderData.driving_license_image,
        vehicle_registration_id: riderData.vehicle_registration_id,
        vehicle_registration_image: riderData.vehicle_registration_image,
        referrer_url: riderData.referrer_url,
        birth_date: user_data.birth_date
          ? moment(user_data.birth_date).format("YYYY-MM-DD")
          : null,
        joining_date: user_data.joining_date
          ? moment(user_data.joining_date).format("YYYY-MM-DD")
          : null,
        active_contract_date: user_data.active_contract_date
          ? moment(user_data.active_contract_date).format("YYYY-MM-DD")
          : null,
      },
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({
      status: -1,
      msg: "Server error.",
    });
  }
}

export async function updateProfile(req, res, next) {
  try {
    let body = req.body;
    const riderId = body.id;
    const { old_password, new_password, confirm_password } = req.body;
    let error;

    const existingUser = await RiderModel.findOne({ _id: riderId });

    if (!existingUser) {
      return res.status(200).json({
        status: -1,
        msg: "Rider not found.",
      });
    }

    if (old_password) {
      const olldhashedPassword = cryptoJS.MD5(old_password).toString();
      const existingUserWithOldPassword = await RiderModel.findOne({
        _id: riderId,
        password: olldhashedPassword,
      });

      if (!existingUserWithOldPassword) {
        return res.status(200).json({
          status: -1,
          msg: "Invalid old password",
        });
      }
    }

    if (new_password !== confirm_password) {
      return res.status(200).json({
        status: -1,
        msg: "New Password and Confirm Password do not match",
      });
    }

    const imagePath =
      req.files && Array.isArray(req.files.image) && req.files.image.length > 0
        ? req.files.image[0].path
        : null;
    const nidFrontPath =
      req.files &&
      Array.isArray(req.files.nid_front) &&
      req.files.nid_front.length > 0
        ? req.files.nid_front[0].path
        : null;
    const nidBackPath =
      req.files &&
      Array.isArray(req.files.nid_back) &&
      req.files.nid_back.length > 0
        ? req.files.nid_back[0].path
        : null;
    const reffrontPath =
      req.files &&
      Array.isArray(req.files.referer_nid_front) &&
      req.files.referer_nid_front.length > 0
        ? req.files.referer_nid_front[0].path
        : null;
    const refbackPath =
      req.files &&
      Array.isArray(req.files.referer_nid_back) &&
      req.files.referer_nid_back.length > 0
        ? req.files.referer_nid_back[0].path
        : null;
    const gurfontPath =
      req.files &&
      Array.isArray(req.files.guardian_nid_front) &&
      req.files.guardian_nid_front.length > 0
        ? req.files.guardian_nid_front[0].path
        : null;
    const gurbackPath =
      req.files &&
      Array.isArray(req.files.guardian_nid_back) &&
      req.files.guardian_nid_back.length > 0
        ? req.files.guardian_nid_back[0].path
        : null;
    const ecbillPath =
      req.files &&
      Array.isArray(req.files.electricity_bill) &&
      req.files.electricity_bill.length > 0
        ? req.files.electricity_bill[0].path
        : null;
    const drLcPath =
      req.files &&
      Array.isArray(req.files.driving_license_image) &&
      req.files.driving_license_image.length > 0
        ? req.files.driving_license_image[0].path
        : null;
    const vehRegPath =
      req.files &&
      Array.isArray(req.files.vehicle_registration_image) &&
      req.files.vehicle_registration_image.length > 0
        ? req.files.vehicle_registration_image[0].path
        : null;

    const updateData = {};
    // const zones=[
    //     {
    //         rider_id:body.zones[0]["rider_id"],
    //         zone_id:body.zones[0]["zone_id"],
    //     },
    //     {
    //         rider_id:body.zones[1]["rider_id"],
    //         zone_id:body.zones[1]["zone_id"],
    //     },
    // ]

    if (body.first_name) updateData.first_name = body.first_name;
    if (body.last_name) updateData.last_name = body.last_name;
    if (body.email) updateData.email = body.email;
    if (body.new_password)
      updateData.password = cryptoJS.MD5(body.new_password).toString();
    if (imagePath) updateData.image = (await GenerateImageLink(imagePath)).url;
    if (nidFrontPath)
      updateData.nid_front = (await GenerateImageLink(nidFrontPath)).url;
    if (nidBackPath)
      updateData.nid_back = (await GenerateImageLink(nidBackPath)).url;
    if (reffrontPath)
      updateData.referer_nid_front = (
        await GenerateImageLink(reffrontPath)
      ).url;
    if (refbackPath)
      updateData.referer_nid_back = (await GenerateImageLink(refbackPath)).url;
    if (gurfontPath)
      updateData.guardian_nid_front = (
        await GenerateImageLink(gurfontPath)
      ).url;
    if (gurbackPath)
      updateData.guardian_nid_back = (await GenerateImageLink(gurbackPath)).url;
    if (ecbillPath)
      updateData.electricity_bill = (await GenerateImageLink(ecbillPath)).url;
    if (drLcPath)
      updateData.driving_license_image = (
        await GenerateImageLink(drLcPath)
      ).url;
    if (vehRegPath)
      updateData.vehicle_registration_image = (
        await GenerateImageLink(vehRegPath)
      ).url;

    if (body.mac) updateData.mac = body.mac;
    if (body.imei) updateData.imei = body.imei;
    if (body.house_nameplate) updateData.house_nameplate = body.house_nameplate;
    if (body.present_address) updateData.present_address = body.present_address;
    if (body.permanent_address)
      updateData.permanent_address = body.permanent_address;
    if (body.vehicle_type_id) updateData.vehicle_type_id = body.vehicle_type_id;
    if (body.city_id) updateData.city_id = body.city_id;
    if (body.bkash_no) updateData.bkash_no = body.bkash_no;
    if (body.nagad_no) updateData.nagad_no = body.nagad_no;
    if (body.nid_no) updateData.nid_no = body.nid_no;
    if (body.driving_license_id)
      updateData.driving_license_id = body.driving_license_id;
    if (body.vehicle_registration_id)
      updateData.vehicle_registration_id = body.vehicle_registration_id;
    if (body.referrer_url) updateData.referrer_url = body.referrer_url;
    if (body.birth_date) updateData.birth_date = body.birth_date;
    if (body.joining_date) updateData.joining_date = body.joining_date;
    if (body.active_contract_date)
      updateData.active_contract_date = body.active_contract_date;

    //updateData.zones=zones

    const updatedUser = await RiderModel.findByIdAndUpdate(
      riderId,
      updateData,
      { new: true }
    );

    if (imagePath) await fs.promises.unlink(imagePath);
    if (nidFrontPath) await fs.promises.unlink(nidFrontPath);
    if (nidBackPath) await fs.promises.unlink(nidBackPath);
    if (reffrontPath) await fs.promises.unlink(reffrontPath);
    if (refbackPath) await fs.promises.unlink(refbackPath);
    if (gurfontPath) await fs.promises.unlink(gurfontPath);
    if (gurbackPath) await fs.promises.unlink(gurbackPath);
    if (ecbillPath) await fs.promises.unlink(ecbillPath);
    if (drLcPath) await fs.promises.unlink(drLcPath);
    if (vehRegPath) await fs.promises.unlink(vehRegPath);

    if (updatedUser) {
      await Send_Queue(cms_queue, "rider_queue", updatedUser, "rider", "edit");
    }
    return res.status(200).json({
      status: 0,
      msg: "Successfully profile updated",
      user_data: {
        mobile_number: updatedUser.mobile_number,
        first_name: updatedUser.first_name,
        last_name: updatedUser.last_name,
        email: updatedUser.email,
        is_active: updatedUser.is_active,
        is_approve: updatedUser.is_approve,
        image: updatedUser.image,
        nid_front: updatedUser.nid_front,
        nid_back: updatedUser.nid_back,
        referer_nid_front: updatedUser.referer_nid_front,
        referer_nid_back: updatedUser.referer_nid_back,
        mac: updatedUser.mac,
        imei: updatedUser.imei,
        house_nameplate: updatedUser.house_nameplate,
        present_address: updatedUser.present_address,
        permanent_address: updatedUser.permanent_address,
        guardian_nid_front: updatedUser.guardian_nid_front,
        guardian_nid_back: updatedUser.guardian_nid_back,
        vehicle_type_id: updatedUser.vehicle_type_id,
        city_id: updatedUser.city_id,
        bkash_no: updatedUser.bkash_no,
        nagad_no: updatedUser.nagad_no,
        electricity_bill: updatedUser.electricity_bill,
        current_balance: updatedUser.current_balance,
        nid_no: updatedUser.nid_no,
        driving_license_id: updatedUser.driving_license_id,
        driving_license_image: updatedUser.driving_license_image,
        vehicle_registration_id: updatedUser.vehicle_registration_id,
        vehicle_registration_image: updatedUser.vehicle_registration_image,
        referrer_url: updatedUser.referrer_url,
        birth_date: updatedUser.birth_date
          ? moment(updatedUser.birth_date).format("YYYY-MM-DD")
          : null,
        joining_date: updatedUser.joining_date
          ? moment(updatedUser.joining_date).format("YYYY-MM-DD")
          : null,
        active_contract_date: updatedUser.active_contract_date
          ? moment(updatedUser.active_contract_date).format("YYYY-MM-DD")
          : null,
      },
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({
      status: -1,
      msg: "Server error.",
    });
  }
}

//Login
export async function login(req, res, next) {
  try {
    let body = req.body;
    let results = {};
    const rules = {
      mobile_number: "required|size:11",
      password: "required",
    };

    let error;
    await validator(body, rules, {}, (err) => {
      error = err;
    });

    if (error) {
      return res.status(500).json({
        status: -1,
        data: error,
        msg: "Validation error.",
      });
    }
    const {
      mobile_number: mobile_number,
      password: password,
      device_id: device_id,
    } = req.body;
    const user_data = await RiderModel.findOneAndUpdate(
      {
        mobile_number: mobile_number,
        password: cryptoJS.MD5(password).toString(),
        is_active: true,
        is_approve: true,
      },
      {
        $set: {
          device_id: device_id,
        },
      },
      {
        returnOriginal: false,
      }
    );

    if (user_data) {
      await Send_Queue(cms_queue, "rider_queue", user_data, "rider", "edit");
      if (
        user_data.mobile_number === mobile_number &&
        user_data.password === cryptoJS.MD5(password).toString()
      ) {
        let uu_data = {
          token: await generateToken({
            id: user_data._id,
          }),
          _id: user_data._id,
          first_name: user_data.first_name,
          last_name: user_data.last_name,
          email: user_data.email,
          password: user_data.password,
          mobile_number: user_data.mobile_number,
          isVerified: user_data.isVerified,
          is_active: user_data.is_active,
          is_approve: user_data.is_approve,
          image: user_data.image,
          nid_front: user_data.nid_front,
          nid_back: user_data.nid_back,
          referer_nid_front: user_data.referer_nid_front,
          referer_nid_back: user_data.referer_nid_back,
          mac: user_data.mac,
          imei: user_data.imei,
          house_nameplate: user_data.house_nameplate,
          present_address: user_data.present_address,
          permanent_address: user_data.permanent_address,
          guardian_nid_front: user_data.guardian_nid_front,
          guardian_nid_back: user_data.guardian_nid_back,
          vehicle_type_id: user_data.vehicle_type_id,
          city_id: user_data.city_id,
          bkash_no: user_data.bkash_no,
          nagad_no: user_data.nagad_no,
          electricity_bill: user_data.electricity_bill,
          current_balance: user_data.current_balance,
          nid_no: user_data.nid_no,
          driving_license_id: user_data.driving_license_id,
          driving_license_image: user_data.driving_license_image,
          vehicle_registration_id: user_data.vehicle_registration_id,
          vehicle_registration_image: user_data.vehicle_registration_image,
          referrer_url: user_data.referrer_url,
          birth_date: user_data.birth_date
            ? moment(user_data.birth_date).format("YYYY-MM-DD")
            : null,
          joining_date: user_data.joining_date
            ? moment(user_data.joining_date).format("YYYY-MM-DD")
            : null,
          active_contract_date: user_data.active_contract_date
            ? moment(user_data.active_contract_date).format("YYYY-MM-DD")
            : null,
        };
        results = {
          status: 0,
          msg: "Login Successfully",
          data: uu_data,
        };
      } else {
        results = {
          status: -1,
          msg: "Incorrect mobile or password or still not approve",
        };
      }
    } else {
      results = {
        status: -1,
        msg: "Incorrect mobile or password or still not approve",
      };
    }
    return res.status(200).json(results);
  } catch (err) {
    return res.status(500).json({
      status: -1,
      msg: "Server Error.",
      err: err.toString(),
    });
  }
}

//Forgot Password
export async function forgot_password(req, res, next) {
  // TODO: Fetch  subs type id

  try {
    let body = req.body;

    const rules = {
      mobile_number: "required|size:11",
    };
    const added_minute = 1;
    const plus_one_minute = moment(new Date()).add(added_minute, "m").toDate();

    let error;
    await validator(body, rules, {}, (err) => {
      error = err;
    });

    if (error) {
      return res.status(200).json({
        status: -1,
        data: error,
        msg: "Validation error.",
      });
    }

    let number = body.mobile_number;

    const user_data = await RiderModel.findOne({
      mobile_number: number,
      is_active: true,
      is_approve: true,
    });
    if (user_data) {
      let otp = 0;
      while (!(otp > 100000 && otp < 999999)) {
        otp = Math.floor(Math.random() * 1000000);
        console.log("otp :", otp);
      }

      const sendOTP = await initOTP(number, otp);
      if (!sendOTP) {
        return {
          msg: "Couldn't initiate otp",
          status: -1,
        };
      }
      const update_otp = await RiderModel.findOneAndUpdate(
        {
          _id: user_data._id,
        },
        {
          $set: {
            otp: otp,
            otp_expire_time: plus_one_minute,
          },
        },
        {
          returnOriginal: false,
        }
      );

      if (update_otp)
        await Send_Queue(cms_queue, "rider_queue", update_otp, "rider", "edit");
      return res.status(200).json({
        msg: "Otp sent to phone number",
        data: {
          mobile_number: user_data.mobile_number,
          otp_expire_in_seconds: added_minute * 60,
          is_new: user_data.is_new,
          isVerified: user_data.isVerified ? user_data.isVerified : 0,
          is_active: user_data.is_active,
          is_approve: user_data.is_approve,
        },
        status: 0,
      });
    } else {
      return res.status(200).json({
        status: -1,
        msg: "User not found!",
      });
    }
  } catch (e) {
    console.error(e);
    return res.status(500).json({ message: "Server error" });
  }
}

// Verify OTP
export async function verifyOTP(req, res, next) {
  try {
    let body = req.body;
    const rules = {
      mobile_number: "required|size:11",
      otp: "required",
    };

    let error;
    await validator(body, rules, {}, (err) => {
      error = err;
    });

    if (error) {
      return res.status(200).json({
        status: -1,
        data: error,
        msg: "Validation error.",
      });
    }
    const mobile = body.mobile_number;
    const otp = body.otp;
    const user_data = await RiderModel.findOne({
      mobile_number: mobile,
    });

    if (user_data) {
      let user_otp = user_data.otp;

      let is_otp_timed_out = moment(user_data.otp_expire_time).isAfter(
        new Date()
      );

      if (!is_otp_timed_out) {
        return res.status(200).json({
          msg: "OTP timed out. Please login again.",
          status: -1,
        });
      }

      if (otp == user_otp) {
        const update_user = await RiderModel.findOneAndUpdate(
          {
            mobile_number: mobile,
          },
          {
            $set: {
              is_verified: 1,
            },
          },
          { returnOriginal: false }
        );
        // await redis_set('users', update_user._id, update_user);
        if (update_user) {
          await Send_Queue(
            cms_queue,
            "rider_queue",
            update_user,
            "rider",
            "edit"
          );
          let uu_data = {
            mobile_number: update_user.mobile_number,
            is_new: update_user.is_new,
            isVerified: update_user.isVerified,
            is_active: user_data.is_active,
            is_approve: user_data.is_approve,
          };
          update_user.is_new == 0
            ? (uu_data.first_name = update_user.first_name)
            : "";
          update_user.is_new == 0
            ? (uu_data.last_name = update_user.last_name)
            : "";
          return res.status(200).json({
            msg: "Verification Successful",
            data: uu_data,
            status: 0,
          });
        } else {
          return res.status(400).json({
            msg: "Something went wrong",
            status: -1,
          });
        }
      } else {
        return res.status(200).json({
          msg: "Wrong OTP",
          status: -1,
        });
      }
    } else {
      return res.status(200).json({
        msg: "User not found.",
        status: -1,
      });
    }
  } catch (e) {
    console.error(e);
    return res.status(500).json({ message: "Server error" });
  }
}

//Reset Password
// export async function reset_password(req,res,next) {
//     try {
//         const rules = {
//             mobile: "required|size:11",
//             password: "required",
//             confirm_password: "required",
//         };
//
//         let error;
//         let body=req.body;
//         await validator(body, rules, {}, (err) => {
//             error = err;
//         });
//         if (error) {
//             return res.json({
//                 status: -1,
//                 data: error,
//                 msg: "Validation error.",
//             });
//         }
//
//         let results = {};
//         let user_data = {};
//         const { mobile,password,confirm_password} = req.body;
//
//         const existingUser = await RiderModel.findOne({ mobile: mobile ,is_verified:1});
//         if (existingUser) {
//             if (password != confirm_password){
//                 return res.json( {
//                     status: -1,
//                     msg: 'New Password and Confirm Password do not match',
//                 });
//             }
//             let update = {
//                 password:cryptoJS.MD5(password).toString(),
//
//             };
//             user_data = await RiderModel.findOneAndUpdate({ mobile: mobile }, update, {
//                 returnOriginal: false,
//             });
//             results = {
//                 status: 0,
//                 msg: 'Password has been reset successfully',
//                 user_data: {
//                     mobile: user_data.mobile,
//                     first_name: user_data.first_name,
//                     last_name: user_data.last_name,
//                     email: user_data.email,
//                 },
//             };
//         } else {
//             results = {
//                 status: -1,
//                 msg: 'User not found or not verified',
//             };
//         }
//
//         return res.status(200).json(results);
//     } catch (err) {
//      console.error(err);
//  return res.status(500).json({ message: 'Server error' });
//     }
//
//
// }

export async function reset_password(req, res, next) {
  try {
    const { mobile_number, password, confirm_password, otp } = req.body;

    const rules = {
      mobile_number: "required|size:11",
      password: "required",
      confirm_password: "required",
      otp: "required|size:6",
    };
    let error;
    let body = req.body;
    await validator(body, rules, {}, (err) => {
      error = err;
    });
    if (error) {
      return res.status(200).json({
        status: -1,
        data: error,
        msg: "Validation error.",
      });
    }

    const existingUser = await RiderModel.findOne({
      mobile_number,
      is_verified: true,
    });
    if (!existingUser) {
      return res.status(200).json({
        status: -1,
        msg: "User not found or not verified",
      });
    }

    if (existingUser.otp != otp) {
      return res.status(200).json({
        status: -1,
        msg: "Invalid OTP",
      });
    }

    if (password !== confirm_password) {
      return res.status(200).json({
        status: -1,
        msg: "New Password and Confirm Password do not match",
      });
    }

    const hashedPassword = cryptoJS.MD5(password).toString();
    const updatedUser = await RiderModel.findOneAndUpdate(
      { mobile_number },
      { password: hashedPassword },
      { new: true }
    );
    if (updatedUser) {
      await Send_Queue(cms_queue, "rider_queue", updatedUser, "rider", "edit");
    }
    const user_data = {
      mobile_number: updatedUser.mobile_number,
      first_name: updatedUser.first_name,
      last_name: updatedUser.last_name,
      email: updatedUser.email,
      is_active: updatedUser.is_active,
      is_approve: updatedUser.is_approve,
    };

    return res.status(200).json({
      status: 0,
      msg: "Password has been reset successfully",
      user_data,
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "Server error" });
  }
}

export async function user_details(req, res, next) {
  let body = req.body;
  try {
    const data = await RiderModel.findOne({ _id: body.id });

    if (!data) {
      return res.json({
        status: -1,
        msg: "Failed to fetch data.",
      });
    }

    return res.status(200).json({
      status: 0,
      data: data,
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "Server error" });
  }
}

export async function logout(req, res, next) {
  try {
    let bearerHeader = req.headers["authorization"];
    if (typeof bearerHeader !== "undefined") {
      const bearer = bearerHeader.split(" ");
      const bearerToken = bearer[1];
      const revokedToken = await RevokedTokenModel.create({
        token: bearerToken,
      });
      if (revokedToken) {
        return res.status(200).json({
          status: 1,
          msg: "Logout Successful",
        });
      } else {
        return res.status(200).json({
          status: -1,
          msg: "Something went wrong..!",
        });
      }
    } else {
      return res.status(200).json({
        status: -1,
        msg: "Something went wrong..!",
      });
    }
  } catch (err) {
    return res.status(500).json({
      status: -1,
      msg: "Server Error.",
    });
  }
}

export async function wallet(req, res, next) {
  let body = req.body;
  try {
    const data = await PayablesModel.recentTransaction(
      body.id,
      body.limit,
      body.page,
      body.dataview_last_days
    );

    if (data) {
      const current_balance = (await RiderModel.getRiderById(body.id))
        .current_balance;

      return res.status(200).json({
        status: 1,
        data: {
          current_balance: current_balance ? current_balance : 0,
          riderWalletData: data,
        },
      });
    } else {
      return res.status(500).json({
        status: -1,
        msg: "Failed to fetch data.",
      });
    }
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "Server error" });
  }
}

export async function paymentreport(req, res, next) {
  let body = req.body;
  try {
    const data = await RidersWallet.paymentReport(
      body.id,
      body.limit,
      body.page
    );

    if (data) {
      return res.status(200).json({
        status: 1,
        data: data,
      });
    } else {
      return res.status(500).json({
        status: -1,
        msg: "Failed to fetch data.",
      });
    }
  } catch (err) {
    console.error(err);
    return res
      .status(500)
      .json({ message: "Server error", err: err.toString() });
  }
}

export async function earningReportByDate(req, res, next) {
  let body = req.body;
  try {
    const data = await RidersWallet.getEarningReportbyDate(body.id, body.date);
    if (data.length > 0) {
      return res.status(200).json({
        status: 1,
        data: data,
      });
    } else {
      return res.status(500).json({
        status: -1,
        msg: "No data found",
      });
    }
  } catch (err) {
    console.error(err);
    return res
      .status(500)
      .json({ message: "Server error", err: err.toString() });
  }
}

export async function locationSave(socket, data) {
  try {
    const { headers } = socket.request;
    const riderId = headers.cookie
      .split("; ")
      .find((cookie) => cookie.startsWith("rider_id="))
      .split("=")[1];

    console.log("Received location data:", data);
    console.log("Rider ID:", riderId);

    const location = {
      lat: data.lat,
      long: data.long,
    };

    await redis_set("rider_location", riderId, JSON.stringify(location));

    const riderLocation = await RiderLocation.create({
      rider_id: riderId,
      created_by: riderId,
      updated_by: riderId,
      location: {
        type: "Point",
        coordinates: [location.long, location.lat],
      },
    });

    console.log("Location saved successfully!");
    socket.emit("response", riderLocation);
  } catch (error) {
    console.error("Error saving location:", error);
    socket.emit("response", "Error saving location");
  }
}
export async function getCurrentLocationRider(req, res, next) {
  try {
    const { rider_id } = req.body;
    const data = await redis_get("rider_location", rider_id);
    if (data) {
      return res.json({
        status: 1,
        data: data,
      });
    } else {
      return res.json({
        status: 1,
        msg: "No data found",
      });
    }
  } catch (error) {
    return res.status(500).json({
      status: 1,
      msg: "Internal Server Error",
      err: error.toString(),
    });
  }
}

export async function calculateRiderIncentives(req, res, next) {
  try {
    let body = req.body;
    const data = await GeneratedQuest.getIncReportbyDate(body.id, body.date);
    if (data) {
      return res.status(200).json({
        status: 1,
        data: data,
      });
    } else {
      return res.status(500).json({
        status: -1,
        msg: "Failed to fetch data.",
      });
    }
  } catch (err) {
    return res.status(500).json({
      status: -1,
      msg: "Server Error.",
      err: err.toString(),
    });
  }
}

export async function zoneByRider(req, res, next) {
  let body = req.body;
  try {
    const data = await RiderModel.getZoneByRider(body.id);

    if (data) {
      return res.status(200).json({
        status: 1,
        data: data,
      });
    } else {
      return res.status(500).json({
        status: -1,
        msg: "Failed to fetch data.",
      });
    }
  } catch (err) {
    console.error(err);
    return res
      .status(500)
      .json({ message: "Server error", err: err.toString() });
  }
}
