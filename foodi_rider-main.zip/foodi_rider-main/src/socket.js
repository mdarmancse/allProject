import Express from "express";
import { Server } from "socket.io";
import { createServer } from "http";

const app = new Express();
const httpServer = createServer(app);
const io = new Server(httpServer, {
  cors: {
    origin: "*",
  },
});

io.on("connection", (socket) => {
  console.log("A new client has connected!");
  socket.emit("abc", { msg: "gggg" });

  socket.on("message", (message) => {
    console.log(`Received message: ${message}`);
    socket.emit("acknowledge", `Received message: ${message}`);
  });
});

const PORT = process.env.PORT || 8080;

httpServer.listen(PORT, () => {
  console.log("Rider Service Run @ " + PORT);
});
