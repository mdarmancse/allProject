<?php
$CI = & get_instance();
$CI->load->model('Web_settings');
$Web_settings = $CI->Web_settings->retrieve_setting_editdata();
?>

<style>

    table tr td, table tr th{
        background-color: rgba(210,130,240, 0.3) !important;
    }
</style>

<script src="<?php echo base_url() ?>my-assets/js/admin_js/invoice_onloadprint.js" type="text/javascript"></script>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="header-icon">
            <i class="pe-7s-note2"></i>
        </div>
        <div class="header-title">
            <h1><?php echo display('invoice_details') ?></h1>
            <small><?php echo display('invoice_details') ?></small>
            <ol class="breadcrumb">
                <li><a href="#"><i class="pe-7s-home"></i> <?php echo display('home') ?></a></li>
                <li><a href="#"><?php echo display('invoice') ?></a></li>
                <li class="active"><?php echo display('invoice_details') ?></li>
            </ol>
        </div>
    </section>
    <!-- Main content -->
    <section class="content">
        <!-- Alert Message -->
        <?php
        $message = $this->session->userdata('message');
        if (isset($message)) {
            ?>
            <div class="alert alert-info alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <?php echo $message ?>
            </div>
            <?php
            $this->session->unset_userdata('message');
        }
        $error_message = $this->session->userdata('error_message');
        if (isset($error_message)) {
            ?>
            <div class="alert alert-danger alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <?php echo $error_message ?>
            </div>
            <?php
            $this->session->unset_userdata('error_message');
        }
        ?>
        <div class="row">
            <div class="col-sm-12">
                <div class="panel panel-bd">
                    <div id="printableArea"  class=""  onload="printDiv('printableArea')">

                        <div class="watermark" style="position:absolute; opacity: 0.5; width:100vw; height:50vh; z-index: -1; background-image: url('<?php echo base_url() ?>assets/images/icons/watermark.png') !important; background-repeat: no-repeat !important; background-size: 2.45in auto !important;-webkit-print-color-adjust: exact ; background-position: center !important;">
                        </div>

                            <div class="panel-body" >



                                <div class="col-xs-12 row" >

                                    <div class="col-xs-6">
                                        <img style="height: 100px; width: 100%" src="<?php
                                        if (isset($Web_settings[0]['invoice_logo'])) {
                                            echo html_escape($Web_settings[0]['invoice_logo']);
                                        }
                                        ?>" class="img-bottom-m" alt="">
                                    </div>
                                    <div class="col-xs-6 company-content" >
                                        {company_info}

                                        <address >
                                            <abbr><i class="ti-location-pin"></i> {address}</abbr><br>
                                            <nobr><abbr><nobr><i class="fa fa-whatsapp"></i>  Cell:</abbr> {mobile}</nobr><br>
                                            <abbr><b>


                                        </address>
                                        {/company_info}
                                    </div>


                                </div>

                                <div class="col-xs-12 row" >

                                    <div class="col-xs-3">

                                    </div>
                                    <div class="col-xs-6 bill " >
                                        Money Receipt

                                    </div>


                                    <div class="col-xs-3">

                                    </div>
                                </div>
                                <div class="col-xs-12 row" >

                                    <div class="col-xs-5">
                                         No : <span class="box_span"> {invoice_no}</span>
                                    </div>
                                    <div class="col-xs-2  " >


                                    </div>


                                    <div class="col-xs-5" style="text-align: right">
                                        Date: <span class="box_span">{final_date}</span>
                                    </div>
                                </div> <br> <br>
                                <div class="row ">
                                    <div class="col-xs-12 text-left ">


                                        <div class="text_parent">
                                            <span class="mr_text" style="border-bottom: none!important;">Received with thanks from &nbsp;&nbsp;&nbsp;&nbsp;</span> <span class="mr_text2">{customer_name}</span><br>
                                        </div>
                                        <div class="text_parent" >
                                            <span class="mr_text">The Sum of Taka (in words)&nbsp;&nbsp;&nbsp;&nbsp;</span> <span class="mr_text2">{am_inword} TK Only</span>
                                        </div>
                                        <div class="text_parent" >
                                           {payment_text}
                                        </div>


                                    </div>



                                </div>

                                <br>




                                <div class="row ">
                                    <div class="col-xs-4 text-left">
                                        <div class="bill">
                                         TK : {total_amount}
                                        </div>
                                    </div>
                                    <div class="col-sm-4"></div>
                                    <div class="col-sm-4">

                                        <div class="mr-footer-center">
                                        For <span class="company_name"><?= $company_info[0]['company_name']?></span>
                                        </div></div>
                                </div>


                            </div>



                    </div>

                    <div class="panel-footer text-left">
                        <input type="hidden" name="" id="url" value="<?php echo base_url('Cinvoice/manage_invoice');?>">
                        <a  class="btn btn-danger" href="<?php echo base_url('Cinvoice/manage_invoice'); ?>"><?php echo display('cancel') ?></a>
                        <button  class="btn btn-info" onclick="printDiv('printableArea')"><span class="fa fa-print"></span></button>

                    </div>
                </div>
            </div>
        </div>
    </section> <!-- /.content -->
</div> <!-- /.content-wrapper -->

