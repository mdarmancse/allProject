<!--Edit customer start -->
<div class="content-wrapper">
    <section class="content-header">
        <div class="header-icon">
            <i class="pe-7s-note2"></i>
        </div>
        <div class="header-title">
            <h1><?php echo display('category_edit') ?></h1>
            <small><?php echo display('category_edit') ?></small>
            <ol class="breadcrumb">
                <li><a href="#"><i class="pe-7s-home"></i> <?php echo display('home') ?></a></li>
                <li><a href="#"><?php echo display('category') ?></a></li>
                <li class="active"><?php echo display('category_edit') ?></li>
            </ol>
        </div>
    </section>

    <section class="content">

        <!-- Alert Message -->
        <?php
        $message = $this->session->userdata('message');
        if (isset($message)) {
        ?>
            <div class="alert alert-info alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <?php echo $message ?>
            </div>
        <?php
            $this->session->unset_userdata('message');
        }
        $error_message = $this->session->userdata('error_message');
        if (isset($error_message)) {
        ?>
            <div class="alert alert-danger alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <?php echo $error_message ?>
            </div>
        <?php
            $this->session->unset_userdata('error_message');
        }
        ?>

        <!-- New customer -->
        <div class="row">
            <div class="col-sm-12">
                <div class="panel panel-bd lobidrag">
                    <div class="panel-heading">
                        <div class="panel-title">
                            <h4><?php echo display('category_edit') ?> </h4>
                        </div>
                    </div>
                    <?php echo form_open_multipart('Ccategory/category_update', array('class' => 'form-vertical', 'id' => 'category_update')) ?>
                    <div class="panel-body">

                    <!-- <div class="form-group " >
                        <label class="col-sm-2 col-form-label" for="name">Name(In Chinese)</label>
                        <div class="col-sm-10">
                            <input type="text" placeholder="类别" value="<?php echo $name_bn ?>" id="name_bn" name="name_bn" class="form-control" required="">
                        </div>
                    </div> -->
                    <div class="form-group " >
                        <label class="col-sm-2 col-form-label" for="name">Name(In English)</label>
                        <div class="col-sm-10">
                            <input type="text" placeholder="Name" value="<?php echo $name ?>" id="name" name="name" class="form-control" required="">
                        </div>
                    </div>
                    <div class="form-group ">
                        <label class="col-sm-2 col-form-label" for="name">Status</label>
                        <div class="col-sm-10">
                            <label><input type="radio" id="status" name="status" value="1" <?php if (isset($status) && $status == "1") echo "checked"; ?>> Active</label>&nbsp;&nbsp;&nbsp;
                            <label><input type="radio" id="status" name="status" value="0" <?php if (isset($status) && $status == "0") echo "checked"; ?>> Inactive</label>
                        </div>
                    </div>
                     <div class="form-group " >
                        <label class="col-sm-2 col-form-label" for="name">Parent Category</label>
                        <div class="col-sm-10">
                            <select name="parent_id" id="parent_id" class="form-control">
                            <option value="0"><?php echo "Select Category" ?></option>
                                <?php foreach ($category_list as $value) {
                                    if ($value['parent_id'] == $id) {
                                ?>
                                      
                                        <option value="<?php echo $value['id']; ?>" selected><?php echo $value['name']; ?></option>

                                    <?php } else { ?>
                                        
                                        <option value="<?php echo $value['id']; ?>"><?php echo $value['name']; ?></option>
                                <?php }
                                }
                                ?>

                            </select>
                        </div>
                    </div>

                        <input type="hidden" value="<?php echo $id; ?>" name="category_id">


                        

                        <div class="form-group row">
                            <label for="example-text-input" class="col-sm-3 col-form-label"></label>
                            <div class="col-sm-4"  style="margin-top:20px">
                                <input type="submit" id="add-Customer" class="btn btn-success btn-large" name="add-Customer" value="<?php echo display('save_changes') ?>" />
                            </div>
                        </div>
                    </div>
                    <?php echo form_close() ?>
                </div>
            </div>
        </div>
    </section>
</div>
<!-- Edit customer end -->