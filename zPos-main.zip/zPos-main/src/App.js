import React, { Component }  from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import Login from './pages/login';
import styles from "./assets/css/custom.module.scss";
import ReactDOM from "react-dom/client";
import reportWebVitals from "./reportWebVitals";
import { BrowserRouter } from "react-router-dom";
import AppRoute from "./components/AppRoute";
import Header from "./components/header";
import Footer from "./components/footer";
import Navigation from "./components/Navigation/Navigation";
class App extends Component {

  render() {
    return (
        <BrowserRouter>
        <Navigation/>
        {/*<Login/>*/}


        </BrowserRouter>
    );
  }

}

export default App;
