import React, {Component} from 'react';
import Header from "../header";
import Footer from "../footer";
import {Col, Container, Nav, Navbar, NavDropdown, Row} from "react-bootstrap";
import {NavLink} from "react-router-dom";
import { Outlet, Link } from "react-router-dom";

import styles from "../../assets/css/custom.module.scss";
import calender from "../../assets/icons/calendar-tick.png";
class Navigation extends Component {
    render() {
        return (
            <>
                <Header/>




                <Col lg={12} md={12} sm={12}>

                    <Row className="p-3 text-center">
                        <Col lg={4} md={4} sm={6} className="p-2">
                            <button className={styles.nav_btn} variant="">
                                <img
                                    src={calender}
                                    width="50"
                                    height="50"
                                    //  className="d-inline-block align-top"
                                    //  className={styles.logo}
                                    alt="Z-POS"
                                />Work Period</button>

                        </Col>
                        <Col lg={8} md={8} sm={6} className="p-2">
                            <div className={styles.address} variant="">

                                <span className={styles.company_name}>Meal Master</span>
                                <span className={styles.company_address}>808 Mehedibag raod, Chittagong
                                    Vat Reg. No.: 8562314</span>


                            </div>

                        </Col>
                        <Col lg={4} md={4} sm={6} className="p-2">
                            <button className={styles.nav_btn} variant="">
                                <img
                                src={calender}
                                width="50"
                                height="50"
                              //  className="d-inline-block align-top"
                              //  className={styles.logo}
                                alt="Z-POS"
                            />POS</button>

                        </Col>
                        <Col lg={4} md={4} sm={6} className="p-2">
                            <button className={styles.nav_btn} variant="">
                                <img
                                src={calender}
                                width="50"
                                height="50"
                              //  className="d-inline-block align-top"
                              //  className={styles.logo}
                                alt="Z-POS"
                            />Accounts</button>

                        </Col>
                        <Col lg={4} md={4} sm={6} className="p-2">
                            <button className={styles.nav_btn} variant="">
                                <img
                                src={calender}
                                width="50"
                                height="50"
                              //  className="d-inline-block align-top"
                              //  className={styles.logo}
                                alt="Z-POS"
                            />HRM</button>

                        </Col>
                        <Col lg={4} md={4} sm={6} className="p-2">
                            <button className={styles.nav_btn} variant="">
                                <img
                                src={calender}
                                width="50"
                                height="50"
                              //  className="d-inline-block align-top"
                              //  className={styles.logo}
                                alt="Z-POS"
                            />Tickets</button>

                        </Col>
                        <Col lg={4} md={4} sm={6} className="p-2">
                            <button className={styles.nav_btn} variant="">
                                <img
                                src={calender}
                                width="50"
                                height="50"
                              //  className="d-inline-block align-top"
                              //  className={styles.logo}
                                alt="Z-POS"
                            />Inventory</button>

                        </Col>
                        <Col lg={4} md={4} sm={6} className="p-2">
                            <button className={styles.nav_btn} variant="">
                                <img
                                src={calender}
                                width="50"
                                height="50"
                              //  className="d-inline-block align-top"
                              //  className={styles.logo}
                                alt="Z-POS"
                            />Kitchen</button>

                        </Col>
                        <Col lg={4} md={4} sm={6} className="p-2">
                            <button className={styles.nav_btn} variant="">
                                <img
                                    src={calender}
                                    width="50"
                                    height="50"
                                    //  className="d-inline-block align-top"
                                    //  className={styles.logo}
                                    alt="Z-POS"
                                />Reports</button>

                        </Col>
                        <Col lg={4} md={4} sm={6} className="p-2">
                            <button className={styles.nav_btn} variant="">
                                <img
                                    src={calender}
                                    width="50"
                                    height="50"
                                    //  className="d-inline-block align-top"
                                    //  className={styles.logo}
                                    alt="Z-POS"
                                />Production</button>

                        </Col>
                        <Col lg={4} md={4} sm={6} className="p-2">
                            <button className={styles.nav_btn} variant="">
                                <img
                                    src={calender}
                                    width="50"
                                    height="50"
                                    //  className="d-inline-block align-top"
                                    //  className={styles.logo}
                                    alt="Z-POS"
                                />Reservation</button>

                        </Col>
                        <Col lg={4} md={4} sm={6} className="p-2">
                            <button className={styles.nav_btn} variant="">
                                <img
                                    src={calender}
                                    width="50"
                                    height="50"
                                    //  className="d-inline-block align-top"
                                    //  className={styles.logo}
                                    alt="Z-POS"
                                />Settings</button>

                        </Col>
                        <Col lg={4} md={4} sm={6} className="p-2">
                            <button className={styles.nav_btn} variant="">
                                <img
                                    src={calender}
                                    width="50"
                                    height="50"
                                    //  className="d-inline-block align-top"
                                    //  className={styles.logo}
                                    alt="Z-POS"
                                />Tutorial</button>

                        </Col>
                        <Col lg={4} md={4} sm={6} className="p-2">
                            <button className={styles.nav_btn} variant="">
                                <img
                                    src={calender}
                                    width="50"
                                    height="50"
                                    //  className="d-inline-block align-top"
                                    //  className={styles.logo}
                                    alt="Z-POS"
                                />Devenport Market</button>

                        </Col>

                    </Row>

                </Col>





                <Footer/>


            </>
        );
    }
}

export default Navigation;
