import React, {Component} from 'react';
import { Routes, Route, Link } from "react-router-dom";
import Login from "../pages/login";
import Navigation from "./Navigation/Navigation";
class AppRoute extends Component {
    render() {
        return (
            <>


                <Routes>
                    <Route path="/" element={<Login />} />
                    <Route path="navigation" element={<Navigation />} />
                </Routes>

            </>
        );
    }
}

export default AppRoute;
