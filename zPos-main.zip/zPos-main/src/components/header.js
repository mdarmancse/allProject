import React, {Component} from 'react';
import {Container, Nav, Navbar} from "react-bootstrap";
import styles from "../assets/css/custom.module.scss";
import logo from '../assets/images/logo.png';
import z from '../assets/images/z.png';
class Header extends Component {
    render() {
        return (


                <>

                    <Navbar>
                        <Container fluid={true}>
                            <Navbar.Brand href="#home">
                                <img
                                    src={z}
                                    width="50"
                                    height="40"
                                    // className="d-inline-block align-top"
                                    className={styles.nav_logo}
                                    alt="Z-POS"
                                />
                            </Navbar.Brand>
                          <p className={styles.header_time}>Monday, 11 April, 20022, 11:16AM </p>

                        </Container>
                    </Navbar>



                </>


        );
    }
}

export default Header;
