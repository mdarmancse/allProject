import React, {Component} from 'react';
import {Button, Col, Container, Row} from "react-bootstrap";
import z from '../assets/images/z.png';
import styles from "../assets/css/custom.module.scss";

class Footer extends Component {
    render() {
        return (


            <>

                <Container fluid={true} className={styles.footer}>
                   <Col lg={12} md={12} sm={6}>

                       <Row className="p-3 text-center">

                           <Col lg={3} md={3} sm={6} className="p-2">
                               <button className={styles.footer_btn_1} variant="">Keyboard</button>

                           </Col>

                           <Col lg={3} md={3} sm={6} className="p-2">
                               <button className={styles.footer_btn_2} variant="contained">User:Suman</button>

                           </Col>
                           <Col lg={3} md={3} sm={6} className="p-2">
                               <button className={styles.footer_btn_3} variant="contained">Support</button>

                           </Col>

                           <Col lg={3} md={3} sm={6} className="p-2">
                               <button className={styles.footer_btn_4} variant="contained">Main Menu</button>

                           </Col>




                       </Row>

                   </Col>
                </Container>

            </>
        );
    }
}

export default Footer;
