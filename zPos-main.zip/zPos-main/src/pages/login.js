import React, {Component} from 'react';

import {Button} from 'react-bootstrap';
import Container from "react-bootstrap/Container";
import styles from "../assets/css/custom.module.scss";
import logo from '../assets/images/logo.png';

import { createTheme,ThemeProvider } from '@mui/material/styles';
import {FormControl, InputLabel,OutlinedInput,InputAdornment,IconButton} from "@mui/material";
import {Visibility, VisibilityOff} from "@mui/icons-material";



export default function Login() {
    const theme = createTheme({
        status: {
            danger: '#e53e3e',
        },
        palette: {
            primary: {
                main: '#0971f1',
                darker: '#053e85',
            },
            white: {
                main: '#FFFFFF',
                contrastText: '#fff',
            },
        },
    });



    const [values, setValues] = React.useState({

        password: '',
        showPassword: false
    });

    const handleChange = (prop) => (event) => {
        setValues({ ...values, [prop]: event.target.value });
    };

    const handleClickShowPassword = () => {
        setValues({
            ...values,
            showPassword: !values.showPassword,
        });
    };

    const handleMouseDownPassword = (event) => {
        event.preventDefault();
    };


    return (
        <>
            <ThemeProvider theme={theme}>
                <Container fluid={true}  className={styles.login_container}>
                    <main className={styles.main} >


                        <div className={styles.grid} >

                            <div className={styles.card}>
                                <div className={styles.logo}>

                                    <img src={logo}  width={100} height={50} />

                                </div>
                                {/*<CssTextField label="Custom CSS" id="custom-css-outlined-input" />*/}
                                <FormControl color="white" variant="outlined" >
                                    <InputLabel color="white" htmlFor="outlined-adornment-password">Enter Your PIN</InputLabel>
                                    <OutlinedInput
                                        inputProps={{className:styles.label_text}}
                                        color="white"
                                        id="outlined-adornment-password"
                                        type={values.showPassword ? 'text' : 'password'}
                                        value={values.password}
                                        onChange={handleChange('password')}
                                        endAdornment={
                                            <InputAdornment position="end" color="white">
                                                <IconButton

                                                    aria-label="toggle password visibility"
                                                    onClick={handleClickShowPassword}
                                                    onMouseDown={handleMouseDownPassword}
                                                    edge="end"
                                                >
                                                    {values.showPassword ? <VisibilityOff /> : <Visibility />}
                                                </IconButton>
                                            </InputAdornment>
                                        }
                                        label="Enter Your PIN"
                                    />
                                </FormControl>
                                <div className={styles.btn_div}>

                                    <Button className={styles.submit_btn} variant="contained">Submit</Button>

                                </div>

                            </div>


                        </div>
                    </main>


                </Container>
            </ThemeProvider>

        </>
    );
}





