import React from 'react';
import ReactDOM from 'react-dom';
import './index.scss';
import styles  from './assets/css/custom.module.scss';
import App from './App';

import * as serviceWorkerRegistration from './serviceWorkerRegistration';
import reportWebVitals from './reportWebVitals';
import Footer from "./components/footer";

ReactDOM.render(
  <React.StrictMode>

    <App />

  </React.StrictMode>,
  document.getElementById('root')
);

serviceWorkerRegistration.register();

reportWebVitals();
