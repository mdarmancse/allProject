#
# TABLE STRUCTURE FOR: acc_coa
#

DROP TABLE IF EXISTS `acc_coa`;

CREATE TABLE `acc_coa` (
  `HeadCode` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `HeadName` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `PHeadName` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `HeadLevel` int(11) NOT NULL,
  `IsActive` tinyint(1) NOT NULL,
  `IsTransaction` tinyint(1) NOT NULL,
  `IsGL` tinyint(1) NOT NULL,
  `HeadType` char(1) COLLATE utf8_unicode_ci NOT NULL,
  `IsBudget` tinyint(1) NOT NULL,
  `IsDepreciation` tinyint(1) NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `DepreciationRate` decimal(18,2) NOT NULL,
  `CreateBy` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `CreateDate` datetime NOT NULL,
  `UpdateBy` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `UpdateDate` datetime NOT NULL,
  PRIMARY KEY (`HeadName`),
  KEY `customer_id` (`customer_id`),
  KEY `supplier_id` (`supplier_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('102010301', '01787281564', 'Cash At Bkash', 4, 1, 1, 0, 'A', 0, 0, NULL, NULL, '0.00', 'OpSoxJvBbbS8Rws', '2021-05-08 05:01:26', '', '0000-00-00 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('102010401', '01826345', 'Cash At Nagad', 4, 1, 1, 0, 'A', 0, 0, NULL, NULL, '0.00', 'OpSoxJvBbbS8Rws', '2021-07-08 11:46:03', '', '0000-00-00 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('102010304', '01852278210', 'Cash At Bkash', 4, 1, 1, 0, 'A', 0, 0, NULL, NULL, '0.00', 'OpSoxJvBbbS8Rws', '2021-05-08 05:08:23', '', '0000-00-00 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('5020203', '1-Imported', 'Account Payable', 3, 1, 1, 1, 'L', 0, 0, NULL, NULL, '0.00', 'OpSoxJvBbbS8Rws', '2021-09-30 05:12:05', '', '0000-00-00 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('102030100001', '1-Walking Customer', 'Customer Receivable', 4, 1, 1, 1, 'A', 0, 0, 1, NULL, '0.00', 'OpSoxJvBbbS8Rws', '2021-09-29 07:18:50', '', '0000-00-00 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('502020001', '10-YAkkaw', 'Account Payable', 3, 1, 1, 0, 'L', 0, 0, NULL, 10, '0.00', 'OpSoxJvBbbS8Rws', '2021-09-25 09:04:32', '', '0000-00-00 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('502040009', '27-Mr RimonAhmed', 'Employee Ledger', 3, 1, 1, 0, 'L', 0, 0, NULL, NULL, '0.00', 'OpSoxJvBbbS8Rws', '2021-05-07 18:01:40', '', '0000-00-00 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('502040010', '28-Mr Rajib', 'Employee Ledger', 3, 1, 1, 0, 'L', 0, 0, NULL, NULL, '0.00', 'OpSoxJvBbbS8Rws', '2021-05-07 18:10:55', '', '0000-00-00 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('502040010', '29-ZahidulRony', 'Employee Ledger', 3, 1, 1, 0, 'L', 0, 0, NULL, NULL, '0.00', 'OpSoxJvBbbS8Rws', '2021-05-07 18:13:12', '', '0000-00-00 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('502040010', '30-Kajol', 'Employee Ledger', 3, 1, 1, 0, 'L', 0, 0, NULL, NULL, '0.00', 'OpSoxJvBbbS8Rws', '2021-05-07 18:14:59', 'tF2YChLBH86gHfG', '2021-05-12 05:23:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('502020002', '6-Shoaib', 'Account Payable', 3, 1, 1, 1, 'L', 0, 0, NULL, 6, '0.00', 'OpSoxJvBbbS8Rws', '2021-09-30 05:12:14', '', '0000-00-00 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('5020204', '7-Imprted', 'Account Payable', 3, 1, 1, 0, 'L', 0, 0, NULL, 7, '0.00', 'OpSoxJvBbbS8Rws', '2021-11-01 08:08:33', '', '0000-00-00 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('502040007', '8-ArmanSolution', 'Employee Ledger', 3, 1, 1, 0, 'L', 0, 0, NULL, NULL, '0.00', 'OpSoxJvBbbS8Rws', '2021-03-14 06:36:17', '', '0000-00-00 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('5020205', '8-Local', 'Account Payable', 3, 1, 1, 0, 'L', 0, 0, NULL, 8, '0.00', 'OpSoxJvBbbS8Rws', '2021-11-01 08:08:34', '', '0000-00-00 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('5020206', '9-Factory', 'Account Payable', 3, 1, 1, 0, 'L', 0, 0, NULL, 9, '0.00', 'OpSoxJvBbbS8Rws', '2021-11-01 08:08:38', '', '0000-00-00 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('502040008', '9-Md Arman solution', 'Employee Ledger', 3, 1, 1, 0, 'L', 0, 0, NULL, NULL, '0.00', 'OpSoxJvBbbS8Rws', '2021-03-14 06:41:24', '', '0000-00-00 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('10106', 'ABC', 'XYZ', 2, 1, 0, 0, 'A', 0, 0, NULL, NULL, '0.00', 'OpSoxJvBbbS8Rws', '2021-02-23 10:27:19', '', '0000-00-00 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('50202', 'Account Payable', 'Current Liabilities', 2, 1, 0, 1, 'L', 0, 0, NULL, NULL, '0.00', 'OpSoxJvBbbS8Rws', '2021-09-29 06:38:15', '', '2019-09-05 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('10203', 'Account Receivable', 'Current Asset', 2, 1, 0, 1, 'A', 0, 0, NULL, NULL, '0.00', 'OpSoxJvBbbS8Rws', '2021-09-29 07:23:13', 'admin', '2013-09-18 15:29:35');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('40405', 'Additional Cost', 'Indirect Expenses', 2, 1, 1, 1, 'E', 0, 0, NULL, NULL, '0.00', 'OpSoxJvBbbS8Rws', '2021-10-11 09:44:27', '', '0000-00-00 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('10303', 'aes', 'Fixed Assets', 2, 1, 0, 1, 'A', 0, 0, NULL, NULL, '0.00', 'OpSoxJvBbbS8Rws', '2021-12-12 10:28:48', '', '0000-00-00 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('10104', 'Airconditioner', 'XYZ', 2, 1, 1, 0, 'A', 0, 0, NULL, NULL, '0.00', 'OpSoxJvBbbS8Rws', '2021-01-28 01:36:34', '', '0000-00-00 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('506', 'Ali Akbar', 'Liabilities', 1, 1, 0, 1, 'L', 0, 0, NULL, NULL, '0.00', 'KNmrMhXdbnd0erU', '2021-12-12 16:16:21', '', '0000-00-00 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('1', 'Assets', 'COA', 0, 1, 0, 1, 'A', 0, 0, NULL, NULL, '0.00', 'OpSoxJvBbbS8Rws', '2021-06-08 13:04:33', '', '2019-09-05 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('40402', 'Asz', 'Indirect Expenses', 2, 1, 1, 1, 'E', 0, 0, NULL, NULL, '0.00', 'OpSoxJvBbbS8Rws', '2021-06-22 13:50:15', '', '0000-00-00 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('40403', 'Bank and Legal Fees', 'Indirect Expenses', 2, 1, 1, 0, 'E', 0, 0, NULL, NULL, '0.00', '2', '2020-09-05 08:01:07', '', '0000-00-00 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('4010402', 'Bank Charge', 'LC Expenses', 3, 1, 0, 1, 'E', 0, 0, NULL, NULL, '0.00', 'OpSoxJvBbbS8Rws', '2021-10-17 10:30:55', '', '0000-00-00 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('40404', 'Bank Fees', 'Indirect Expenses', 2, 1, 1, 1, 'E', 0, 0, NULL, NULL, '0.00', 'OpSoxJvBbbS8Rws', '2021-10-03 11:16:50', '', '0000-00-00 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('102010309', 'BK - 01823344567', 'Cash At Bkash', 4, 1, 1, 1, 'A', 0, 0, NULL, NULL, '0.00', 'OpSoxJvBbbS8Rws', '2021-11-11 07:34:56', '', '0000-00-00 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('102010305', 'BK - 01864598947', 'Cash At Bkash', 4, 1, 1, 1, 'A', 0, 0, NULL, NULL, '0.00', 'OpSoxJvBbbS8Rws', '2021-09-25 11:26:58', '', '0000-00-00 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('102010308', 'BK - 0192922333', 'Cash At Bkash', 4, 1, 1, 1, 'A', 0, 0, NULL, NULL, '0.00', '3k5AW5cU8RAFqXC', '2021-11-11 07:30:52', '', '0000-00-00 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('102010306', 'BK - 01987223345', 'Cash At Bkash', 4, 1, 1, 1, 'A', 0, 0, NULL, NULL, '0.00', 'OpSoxJvBbbS8Rws', '2021-09-25 11:27:08', '', '0000-00-00 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('102010307', 'BK - 01992993949', 'Cash At Bkash', 4, 1, 1, 1, 'A', 0, 0, NULL, NULL, '0.00', 'OpSoxJvBbbS8Rws', '2021-11-06 11:00:27', '', '0000-00-00 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('102010302', 'BK 01852278200', 'Cash At Bkash', 4, 1, 1, 0, 'A', 0, 0, NULL, NULL, '0.00', 'KNmrMhXdbnd0erU', '2021-12-12 10:12:54', '', '0000-00-00 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('102010303', 'Bkash 01711020555', 'Cash At Bkash', 4, 1, 1, 0, 'A', 0, 0, NULL, NULL, '0.00', 'KNmrMhXdbnd0erU', '2021-12-12 10:12:32', '', '0000-00-00 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('102010210', 'Bkash Merchant Account', 'Cash At Bank', 4, 1, 1, 0, 'A', 0, 0, NULL, NULL, '0.00', 'OpSoxJvBbbS8Rws', '2021-05-08 04:25:47', '', '0000-00-00 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('102010208', 'Brac Bank Ltd', 'Cash At Bank', 4, 1, 1, 0, 'A', 0, 0, NULL, NULL, '0.00', 'OpSoxJvBbbS8Rws', '2021-05-08 04:22:45', '', '0000-00-00 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('50701', 'C', 'Capital', 2, 1, 0, 1, 'L', 0, 0, NULL, NULL, '0.00', 'KNmrMhXdbnd0erU', '2021-12-12 16:30:15', '', '0000-00-00 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('507', 'Capital', 'Liabilities', 1, 1, 0, 1, 'L', 0, 0, NULL, NULL, '0.00', 'KNmrMhXdbnd0erU', '2021-12-12 16:20:12', '', '0000-00-00 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('504', 'Capital1222', 'Liabilities', 1, 1, 0, 1, 'L', 0, 0, NULL, NULL, '0.00', 'KNmrMhXdbnd0erU', '2021-12-12 16:16:07', '', '0000-00-00 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('10201', 'Cash & Cash Equivalent', 'Current Asset', 2, 1, 0, 1, 'A', 0, 0, NULL, NULL, '0.00', 'OpSoxJvBbbS8Rws', '2021-05-31 06:29:34', 'admin', '2015-10-15 15:57:55');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('1020102', 'Cash At Bank', 'Cash & Cash Equivalent', 3, 1, 1, 1, 'A', 0, 0, NULL, NULL, '0.00', 'HLJq42qHAlAHg4T', '2021-11-16 06:40:06', 'admin', '2015-10-15 15:32:42');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('1020103', 'Cash At Bkash', 'Cash & Cash Equivalent', 3, 1, 1, 1, 'A', 0, 0, NULL, NULL, '0.00', 'HLJq42qHAlAHg4T', '2021-11-16 06:40:16', '', '0000-00-00 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('1020104', 'Cash At Nagad', 'Cash & Cash Equivalent', 3, 1, 1, 1, 'A', 0, 0, NULL, NULL, '0.00', 'HLJq42qHAlAHg4T', '2021-11-16 06:40:24', '', '0000-00-00 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('1020101', 'Cash In Hand', 'Cash & Cash Equivalent', 3, 1, 1, 1, 'A', 0, 0, NULL, NULL, '0.00', 'OpSoxJvBbbS8Rws', '2021-06-01 11:50:10', 'admin', '2016-05-23 12:05:43');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('102010212', 'Citi Bank', 'Cash At Bank', 4, 1, 1, 1, 'A', 0, 0, NULL, NULL, '0.00', 'HLJq42qHAlAHg4T', '2021-11-16 06:12:01', '', '0000-00-00 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('10103', 'Computer & Accessories', 'XYZ', 2, 1, 1, 0, 'A', 0, 0, NULL, NULL, '0.00', 'OpSoxJvBbbS8Rws', '2021-01-28 01:37:25', '', '0000-00-00 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('10105', 'Computers', 'XYZ', 2, 1, 0, 0, 'A', 0, 0, NULL, NULL, '0.00', 'OpSoxJvBbbS8Rws', '2021-02-23 10:27:01', '', '0000-00-00 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('102', 'Current Asset', 'Assets', 1, 1, 0, 1, 'A', 0, 0, NULL, NULL, '0.00', 'OpSoxJvBbbS8Rws', '2021-06-08 13:04:41', 'admin', '2018-07-07 11:23:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('502', 'Current Liabilities', 'Liabilities', 1, 1, 0, 1, 'L', 0, 0, NULL, NULL, '0.00', 'KNmrMhXdbnd0erU', '2021-12-12 10:28:53', 'admin', '2015-10-15 19:49:21');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('1020301', 'Customer Receivable', 'Account Receivable', 3, 1, 1, 1, 'A', 0, 0, NULL, NULL, '0.00', 'OpSoxJvBbbS8Rws', '2021-09-28 11:30:24', 'admin', '2018-07-07 12:31:42');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('401', 'Direct Expenses', 'Expense', 1, 1, 1, 1, 'E', 0, 1, NULL, NULL, '1.00', 'OpSoxJvBbbS8Rws', '2021-06-13 12:42:01', '', '0000-00-00 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('102010206', 'Eastern bank Ltd.', 'Cash At Bank', 4, 1, 1, 0, 'A', 0, 0, NULL, NULL, '0.00', 'OpSoxJvBbbS8Rws', '2021-05-08 03:34:04', '', '0000-00-00 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('4040102', 'Electric Bil', 'Operating Expenses', 3, 1, 1, 1, 'E', 0, 0, NULL, NULL, '0.00', '3k5AW5cU8RAFqXC', '2021-11-08 08:26:30', '', '0000-00-00 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('40103', 'Electric BIll', 'Direct Expenses', 2, 1, 1, 1, 'E', 0, 0, NULL, NULL, '0.00', 'OpSoxJvBbbS8Rws', '2021-06-12 13:07:48', '', '0000-00-00 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('50204', 'Employee Ledger', 'Current Liabilities', 2, 1, 0, 1, 'L', 0, 0, NULL, NULL, '0.00', 'OpSoxJvBbbS8Rws', '2021-06-01 12:14:08', '', '2019-09-05 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('403', 'Employee Salary', 'Expense', 1, 1, 1, 1, 'E', 0, 1, NULL, NULL, '1.00', 'OpSoxJvBbbS8Rws', '2021-06-01 12:12:49', '', '2019-09-05 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('2', 'Equity', 'COA', 0, 1, 0, 1, 'L', 0, 0, NULL, NULL, '0.00', 'OpSoxJvBbbS8Rws', '2021-05-31 04:28:04', '', '2019-09-05 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('4', 'Expense', 'COA', 0, 1, 0, 1, 'E', 0, 0, NULL, NULL, '0.00', 'OpSoxJvBbbS8Rws', '2021-06-08 13:11:04', '', '2019-09-05 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('102010201', 'First Security Islami Bank Ltd.', 'Cash At Bank', 4, 1, 1, 0, 'A', 0, 0, NULL, NULL, '0.00', 'OpSoxJvBbbS8Rws', '2021-05-07 06:18:12', '', '0000-00-00 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('103', 'Fixed Assets', 'Assets', 1, 1, 0, 1, 'A', 0, 0, NULL, NULL, '0.00', 'HLJq42qHAlAHg4T', '2021-08-31 04:39:53', '', '0000-00-00 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('1020105', 'Fund Transfer', 'Cash & Cash Equivalent', 3, 1, 1, 1, 'A', 0, 0, NULL, NULL, '0.00', 'HLJq42qHAlAHg4T', '2021-11-18 07:42:03', '', '0000-00-00 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('10302', 'Furniture', 'Fixed Assets', 2, 1, 1, 0, 'A', 0, 0, NULL, NULL, '0.00', 'OpSoxJvBbbS8Rws', '2021-04-29 04:44:28', '', '0000-00-00 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('10101', 'hol', 'hol', 2, 1, 0, 0, 'A', 0, 0, NULL, NULL, '0.00', 'OpSoxJvBbbS8Rws', '2021-03-16 12:21:11', '', '0000-00-00 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('3', 'Income', 'COA', 0, 1, 0, 1, 'I', 0, 0, NULL, NULL, '0.00', 'OpSoxJvBbbS8Rws', '2021-06-12 08:27:13', '', '2019-09-05 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('404', 'Indirect Expenses', 'Expense', 1, 1, 0, 1, 'E', 0, 1, NULL, NULL, '1.00', 'OpSoxJvBbbS8Rws', '2021-06-22 13:36:15', '', '0000-00-00 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('304', 'Indirect Incomes', 'Income', 1, 1, 0, 1, 'I', 0, 0, NULL, NULL, '0.00', 'OpSoxJvBbbS8Rws', '2021-06-23 08:43:44', '', '2019-09-05 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('30401', 'Interest Received', 'Indirect Incomes', 2, 1, 1, 1, 'I', 0, 0, NULL, NULL, '0.00', 'OpSoxJvBbbS8Rws', '2021-06-23 08:46:37', '', '0000-00-00 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('4040103', 'Internet Bill', 'Operating Expenses', 3, 1, 1, 1, 'E', 0, 0, NULL, NULL, '0.00', '3k5AW5cU8RAFqXC', '2021-11-08 08:29:58', '', '0000-00-00 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('10204', 'Inventory', 'Current Asset', 2, 0, 0, 0, 'A', 0, 0, NULL, NULL, '0.00', 'OpSoxJvBbbS8Rws', '2021-11-02 05:42:37', 'admin', '2013-09-18 15:29:35');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('102010207', 'Islami Bank Bangladesh Ltd.', 'Cash At Bank', 4, 1, 1, 0, 'A', 0, 0, NULL, NULL, '0.00', 'OpSoxJvBbbS8Rws', '2021-05-08 03:34:55', '', '0000-00-00 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('102010211', 'Jabah bank', 'Cash At Bank', 4, 1, 1, 1, 'A', 0, 0, NULL, NULL, '0.00', 'OpSoxJvBbbS8Rws', '2021-10-03 06:56:21', '', '0000-00-00 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('102010204', 'Janata Bank Ltd', 'Cash At Bank', 4, 1, 1, 0, 'A', 0, 0, NULL, NULL, '0.00', 'OpSoxJvBbbS8Rws', '2021-05-08 03:32:06', '', '0000-00-00 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('10102', 'Lands', 'Lands', 2, 1, 0, 0, 'A', 0, 0, NULL, NULL, '0.00', 'OpSoxJvBbbS8Rws', '2021-03-16 12:18:22', '', '0000-00-00 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('4010401', 'LC Commission', 'LC Expenses', 3, 1, 0, 1, 'E', 0, 0, NULL, NULL, '0.00', 'OpSoxJvBbbS8Rws', '2021-10-17 08:00:26', '', '0000-00-00 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('40104', 'LC Expenses', 'Direct Expenses', 2, 1, 1, 0, 'E', 0, 0, NULL, NULL, '0.00', 'OpSoxJvBbbS8Rws', '2021-10-17 08:00:36', '', '0000-00-00 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('503', 'LC Liabilities', 'Liabilities', 1, 1, 0, 1, 'L', 0, 0, NULL, NULL, '0.00', 'OpSoxJvBbbS8Rws', '2021-10-16 11:30:28', '', '0000-00-00 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('5', 'Liabilities', 'COA', 0, 1, 0, 1, 'L', 0, 0, NULL, NULL, '0.00', 'OpSoxJvBbbS8Rws', '2021-06-08 13:11:30', 'admin', '2015-10-15 19:46:54');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('102010203', 'Mercantile Bank Ltd', 'Cash At Bank', 4, 1, 1, 0, 'A', 0, 0, NULL, NULL, '0.00', 'OpSoxJvBbbS8Rws', '2021-05-08 03:31:42', '', '0000-00-00 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('102010402', 'NG - 01881239392', 'Cash At Nagad', 4, 1, 1, 1, 'A', 0, 0, NULL, NULL, '0.00', 'OpSoxJvBbbS8Rws', '2021-09-25 11:27:19', '', '0000-00-00 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('501', 'Non Current Liabilities', 'Liabilities', 1, 1, 0, 1, 'L', 0, 0, NULL, NULL, '0.00', 'OpSoxJvBbbS8Rws', '2021-06-08 13:11:47', 'admin', '2015-10-15 19:49:21');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('10301', 'Office Equipment', 'Fixed Assets', 2, 1, 1, 1, 'A', 0, 0, NULL, NULL, '0.00', 'OpSoxJvBbbS8Rws', '2021-09-29 11:35:32', '', '0000-00-00 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('40102', 'Office Rent', 'Direct Expenses', 2, 1, 1, 1, 'E', 0, 0, NULL, NULL, '0.00', 'OpSoxJvBbbS8Rws', '2021-12-07 21:53:58', '', '0000-00-00 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('10205', 'Opening Inventory', 'Current Asset', 2, 1, 0, 1, 'A', 0, 0, NULL, NULL, '0.00', 'OpSoxJvBbbS8Rws', '2021-06-02 06:52:34', 'admin', '2013-09-18 15:29:35');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('40401', 'Operating Expenses', 'Indirect Expenses', 2, 1, 1, 1, 'E', 0, 0, NULL, NULL, '0.00', '3k5AW5cU8RAFqXC', '2021-11-07 07:28:30', '', '0000-00-00 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('402', 'Product Purchase', 'Expense', 1, 1, 1, 1, 'E', 0, 0, NULL, NULL, '0.00', 'OpSoxJvBbbS8Rws', '2021-06-01 12:13:11', 'admin', '2015-10-15 18:37:42');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('303', 'Product Sale', 'Income', 1, 1, 1, 1, 'I', 0, 0, NULL, NULL, '0.00', 'OpSoxJvBbbS8Rws', '2021-09-25 10:36:00', '', '2019-09-05 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('40105', 'Production Expenses', 'Direct Expenses', 2, 1, 1, 0, 'E', 0, 0, NULL, NULL, '0.00', 'HLJq42qHAlAHg4T', '2021-12-06 13:30:26', '', '0000-00-00 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('102010202', 'Standard Chartered Bank', 'Cash At Bank', 4, 1, 1, 0, 'A', 0, 0, NULL, NULL, '0.00', 'OpSoxJvBbbS8Rws', '2021-05-08 03:24:33', '', '0000-00-00 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('102010209', 'The City Bank Ltd', 'Cash At Bank', 4, 1, 1, 0, 'A', 0, 0, NULL, NULL, '0.00', 'OpSoxJvBbbS8Rws', '2021-05-08 04:24:43', '', '0000-00-00 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('4010501', 'Transportation Cost', 'Production Expenses', 3, 1, 0, 0, 'E', 0, 0, NULL, NULL, '0.00', 'OpSoxJvBbbS8Rws', '2021-10-25 09:23:36', '', '0000-00-00 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('102010205', 'United Commercial Bank Ltd (UCBL)', 'Cash At Bank', 4, 1, 1, 0, 'A', 0, 0, NULL, NULL, '0.00', 'OpSoxJvBbbS8Rws', '2021-05-08 03:32:35', '', '0000-00-00 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('10107', 'XYZ', 'XYZ', 2, 1, 0, 0, 'A', 0, 0, NULL, NULL, '0.00', 'OpSoxJvBbbS8Rws', '2021-02-23 10:27:34', '', '2019-09-05 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('4040101', 'Yeah', 'Operating Expenses', 3, 1, 1, 1, 'E', 0, 0, NULL, NULL, '0.00', '3k5AW5cU8RAFqXC', '2021-11-07 07:34:27', '', '0000-00-00 00:00:00');
INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `customer_id`, `supplier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`) VALUES ('505', 'yu', 'Liabilities', 1, 1, 0, 1, 'L', 0, 0, NULL, NULL, '0.00', 'KNmrMhXdbnd0erU', '2021-12-12 10:30:02', '', '0000-00-00 00:00:00');


#
# TABLE STRUCTURE FOR: acc_transaction
#

DROP TABLE IF EXISTS `acc_transaction`;

CREATE TABLE `acc_transaction` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `VNo` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cheque_id` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Vtype` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `VDate` date DEFAULT NULL,
  `COAID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Narration` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `Debit` decimal(18,2) DEFAULT NULL,
  `Credit` decimal(18,2) DEFAULT NULL,
  `IsPosted` char(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CreateBy` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `CreateDate` datetime DEFAULT NULL,
  `UpdateBy` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `UpdateDate` datetime DEFAULT NULL,
  `IsAppove` char(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  UNIQUE KEY `ID` (`ID`),
  KEY `COAID` (`COAID`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `acc_transaction` (`ID`, `VNo`, `cheque_id`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`, `IsAppove`) VALUES (7, 'CV-1', NULL, 'CV', '2021-12-12', '504', 'Customer credit for Paid Amount Customer WER ', '0.00', '50000.00', '1', NULL, '2021-12-12 10:36:11', NULL, NULL, '1');
INSERT INTO `acc_transaction` (`ID`, `VNo`, `cheque_id`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`, `IsAppove`) VALUES (8, 'CV-1', NULL, 'CV', '2021-12-12', '1020101', 'Credit Vourcher from Cash In Hand', '50000.00', '0.00', '1', NULL, '2021-12-12 10:36:11', NULL, NULL, '1');
INSERT INTO `acc_transaction` (`ID`, `VNo`, `cheque_id`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`, `IsAppove`) VALUES (9, 'DV-1', NULL, 'DV', '2021-12-12', '502020002', 'test', '5000.00', '0.00', '1', NULL, '2021-12-12 16:34:24', NULL, NULL, '1');
INSERT INTO `acc_transaction` (`ID`, `VNo`, `cheque_id`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `UpdateBy`, `UpdateDate`, `IsAppove`) VALUES (10, 'DV-1', NULL, 'DV', '2021-12-12', '1020101', 'Debit voucher from Cash In Hand', '0.00', '5000.00', '1', NULL, '2021-12-12 16:34:24', NULL, NULL, '1');


#
# TABLE STRUCTURE FOR: app_setting
#

DROP TABLE IF EXISTS `app_setting`;

CREATE TABLE `app_setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `localhserver` varchar(250) DEFAULT NULL,
  `onlineserver` varchar(250) DEFAULT NULL,
  `hotspot` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `app_setting` (`id`, `localhserver`, `onlineserver`, `hotspot`) VALUES (1, 'https://www.devenport.co/erp', 'https://www.devenport.co/erp', 'https://192.168.1.167/saleserp');


#
# TABLE STRUCTURE FOR: attendance
#

DROP TABLE IF EXISTS `attendance`;

CREATE TABLE `attendance` (
  `att_id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `sign_in` varchar(30) NOT NULL,
  `sign_out` varchar(30) NOT NULL,
  `staytime` varchar(30) NOT NULL,
  PRIMARY KEY (`att_id`),
  KEY `employee_id` (`employee_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: bank_add
#

DROP TABLE IF EXISTS `bank_add`;

CREATE TABLE `bank_add` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bank_id` varchar(255) NOT NULL,
  `outlet_id` varchar(255) DEFAULT NULL,
  `bank_name` varchar(255) NOT NULL,
  `ac_name` varchar(250) DEFAULT NULL,
  `ac_number` varchar(250) DEFAULT NULL,
  `branch` varchar(250) DEFAULT NULL,
  `signature_pic` varchar(250) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `bank_add` (`id`, `bank_id`, `outlet_id`, `bank_name`, `ac_name`, `ac_number`, `branch`, `signature_pic`, `status`) VALUES (1, 'P1I8ZXUF4V', 'VC4C6BTBRLL57PF', 'Jabah bank', 'Shoaib', '888292292', 'Muradpoooor', NULL, 1);
INSERT INTO `bank_add` (`id`, `bank_id`, `outlet_id`, `bank_name`, `ac_name`, `ac_number`, `branch`, `signature_pic`, `status`) VALUES (2, '7AVW1G2MBJ', 'HK7TGDT69VFMXB7', 'Citi Bank', 'Shoaib', '0029993049950', 'Mehedibagh', NULL, 1);


#
# TABLE STRUCTURE FOR: bkash_add
#

DROP TABLE IF EXISTS `bkash_add`;

CREATE TABLE `bkash_add` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `bkash_id` varchar(255) NOT NULL,
  `outlet_id` varchar(255) DEFAULT NULL,
  `ac_name` varchar(255) NOT NULL,
  `bkash_no` varchar(255) NOT NULL,
  `bkash_type` varchar(255) NOT NULL,
  `status` int(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;

INSERT INTO `bkash_add` (`id`, `bkash_id`, `outlet_id`, `ac_name`, `bkash_no`, `bkash_type`, `status`) VALUES (1, 'ME8FXV51IA', NULL, 'Shoaib', '01864598947', 'Agent', 1);
INSERT INTO `bkash_add` (`id`, `bkash_id`, `outlet_id`, `ac_name`, `bkash_no`, `bkash_type`, `status`) VALUES (2, 'FN8K3SNUNM', NULL, 'Leo', '01987223345', 'Merchant', 1);
INSERT INTO `bkash_add` (`id`, `bkash_id`, `outlet_id`, `ac_name`, `bkash_no`, `bkash_type`, `status`) VALUES (3, 'IEVYEDQJNJ', NULL, 'Messi', '01992993949', 'Merchant', 1);
INSERT INTO `bkash_add` (`id`, `bkash_id`, `outlet_id`, `ac_name`, `bkash_no`, `bkash_type`, `status`) VALUES (4, 'I2RE4FRO6W', 'VC4C6BTBRLL57PF', 'Shoaib', '0192922333', 'Personal', 1);
INSERT INTO `bkash_add` (`id`, `bkash_id`, `outlet_id`, `ac_name`, `bkash_no`, `bkash_type`, `status`) VALUES (5, 'P7VXZ34VTI', 'VC4C6BTBRLL57PF', 'Sarwar Jaman', '01823344567', 'Agent', 1);


#
# TABLE STRUCTURE FOR: branch_name
#

DROP TABLE IF EXISTS `branch_name`;

CREATE TABLE `branch_name` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `branch_id` varchar(255) NOT NULL,
  `courier_id` varchar(255) NOT NULL,
  `branch_name` varchar(255) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `courier_id` (`courier_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `branch_name` (`id`, `branch_id`, `courier_id`, `branch_name`, `status`) VALUES (1, 'SU9SB5I3BJ1YCU9', 'R3GDG15K645F8UA', 'Muradpur', 1);


#
# TABLE STRUCTURE FOR: card
#

DROP TABLE IF EXISTS `card`;

CREATE TABLE `card` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `card_id` varchar(255) CHARACTER SET utf8 NOT NULL,
  `card_name` varchar(255) CHARACTER SET utf8 NOT NULL,
  `percentage` double(10,2) DEFAULT NULL,
  `status` int(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf16;

INSERT INTO `card` (`id`, `card_id`, `card_name`, `percentage`, `status`) VALUES (6, '20211003102625', 'VISA', '2.50', 1);
INSERT INTO `card` (`id`, `card_id`, `card_name`, `percentage`, `status`) VALUES (7, '20211005105401', 'MasterCard', '3.20', 1);


#
# TABLE STRUCTURE FOR: card_list
#

DROP TABLE IF EXISTS `card_list`;

CREATE TABLE `card_list` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `outlet_id` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `card_id` varchar(255) CHARACTER SET utf8 NOT NULL,
  `card_no_id` varchar(255) CHARACTER SET utf8 NOT NULL,
  `card_no` varchar(255) CHARACTER SET utf8 NOT NULL,
  `bank_id` varchar(255) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf16;

INSERT INTO `card_list` (`id`, `outlet_id`, `card_id`, `card_no_id`, `card_no`, `bank_id`) VALUES (2, 'VC4C6BTBRLL57PF', '20211005105401', '20211003102653', '112342', '7AVW1G2MBJ');
INSERT INTO `card_list` (`id`, `outlet_id`, `card_id`, `card_no_id`, `card_no`, `bank_id`) VALUES (3, 'HK7TGDT69VFMXB7', '20211005105401', '20211005105600', '231334345443', 'P1I8ZXUF4V');


#
# TABLE STRUCTURE FOR: central_warehouse
#

DROP TABLE IF EXISTS `central_warehouse`;

CREATE TABLE `central_warehouse` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `warehouse_id` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `central_warehouse` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `status` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `central_warehouse` (`id`, `warehouse_id`, `central_warehouse`, `status`) VALUES (1, 'HK7TGDT69VFMXB7', 'Central Warehouse', 1);


#
# TABLE STRUCTURE FOR: color_list
#

DROP TABLE IF EXISTS `color_list`;

CREATE TABLE `color_list` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `color_id` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `color_name` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `status` int(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf16;

INSERT INTO `color_list` (`id`, `color_id`, `color_name`, `status`) VALUES (1, 'F1A7PPP1FLHIHCP', 'Red', 1);
INSERT INTO `color_list` (`id`, `color_id`, `color_name`, `status`) VALUES (2, '3XXNI6FEFWP2SKB', 'Off-white', 1);
INSERT INTO `color_list` (`id`, `color_id`, `color_name`, `status`) VALUES (3, 'AZGHTTY86XL9X19', 'Silver', 1);
INSERT INTO `color_list` (`id`, `color_id`, `color_name`, `status`) VALUES (4, 'H6QINNWDXKKJUWY', 'Golden', 1);
INSERT INTO `color_list` (`id`, `color_id`, `color_name`, `status`) VALUES (5, 'M8PB3YLICZGFA55', 'Multi', 1);
INSERT INTO `color_list` (`id`, `color_id`, `color_name`, `status`) VALUES (6, 'IV2PYQRRB8SNZ9D', 'Wooden', 1);
INSERT INTO `color_list` (`id`, `color_id`, `color_name`, `status`) VALUES (7, 'FUP181BITXCRV75', 'Brown', 1);
INSERT INTO `color_list` (`id`, `color_id`, `color_name`, `status`) VALUES (8, 'TPLU9YWCMFTTYGR', 'Black', 1);
INSERT INTO `color_list` (`id`, `color_id`, `color_name`, `status`) VALUES (9, 'ASKCLFJCTZRAPXD', 'Ash', 1);
INSERT INTO `color_list` (`id`, `color_id`, `color_name`, `status`) VALUES (10, 'EUX7XCHCBSGC1Y4', 'Transparent', 1);
INSERT INTO `color_list` (`id`, `color_id`, `color_name`, `status`) VALUES (11, '4LPVS2BMOPAX1BM', 'Olive', 1);
INSERT INTO `color_list` (`id`, `color_id`, `color_name`, `status`) VALUES (12, 'LOX33DNFYELB8WO', 'Raddish ', 1);
INSERT INTO `color_list` (`id`, `color_id`, `color_name`, `status`) VALUES (13, 'E4B9AKL84ERAGEG', 'Chocolet', 1);
INSERT INTO `color_list` (`id`, `color_id`, `color_name`, `status`) VALUES (14, '6A77JORHL7K7PTW', 'Black and Blue', 1);
INSERT INTO `color_list` (`id`, `color_id`, `color_name`, `status`) VALUES (15, 'NZ6J7F4H81I21RV', 'Flowral', 1);
INSERT INTO `color_list` (`id`, `color_id`, `color_name`, `status`) VALUES (16, 'BAIJP7TQLAYBO25', 'Blue-Orange', 1);
INSERT INTO `color_list` (`id`, `color_id`, `color_name`, `status`) VALUES (17, 'LT6FDXOKKIV58F1', 'White', 1);
INSERT INTO `color_list` (`id`, `color_id`, `color_name`, `status`) VALUES (18, '6H9RPCWB7EIMNFE', 'Green', 1);
INSERT INTO `color_list` (`id`, `color_id`, `color_name`, `status`) VALUES (19, '19OE98JDYKHZFIP', 'Pink', 1);
INSERT INTO `color_list` (`id`, `color_id`, `color_name`, `status`) VALUES (20, 'E3LOM1SETLA1OFK', 'Orange', 1);
INSERT INTO `color_list` (`id`, `color_id`, `color_name`, `status`) VALUES (21, 'D3J54T3XCC5OPDM', 'Yellow', 1);
INSERT INTO `color_list` (`id`, `color_id`, `color_name`, `status`) VALUES (22, 'MEPZUZ4ASS2KEMN', 'Blue', 1);
INSERT INTO `color_list` (`id`, `color_id`, `color_name`, `status`) VALUES (23, '7VWMJZYJ3IX4K19', 'Blue & White', 1);
INSERT INTO `color_list` (`id`, `color_id`, `color_name`, `status`) VALUES (24, '88YJ5Y26C9INDQ3', 'Mixed', 1);
INSERT INTO `color_list` (`id`, `color_id`, `color_name`, `status`) VALUES (25, '4E4LVG17YFEZW98', 'Light Pink', 1);
INSERT INTO `color_list` (`id`, `color_id`, `color_name`, `status`) VALUES (26, 'MJ41S245FFQ8RDV', 'Purple', 1);
INSERT INTO `color_list` (`id`, `color_id`, `color_name`, `status`) VALUES (27, 'NGOI8BA4D66SZPN', 'Crystal', 1);
INSERT INTO `color_list` (`id`, `color_id`, `color_name`, `status`) VALUES (28, 'IMNVAE5VR4F7ZAD', 'Magenta', 1);
INSERT INTO `color_list` (`id`, `color_id`, `color_name`, `status`) VALUES (29, 'YASHP9S7P54NUQW', 'Warm', 1);
INSERT INTO `color_list` (`id`, `color_id`, `color_name`, `status`) VALUES (30, 'SROKHDLHZESB71V', 'Bronze', 1);
INSERT INTO `color_list` (`id`, `color_id`, `color_name`, `status`) VALUES (31, '1TPF123888TGZFO', 'Crime', 1);
INSERT INTO `color_list` (`id`, `color_id`, `color_name`, `status`) VALUES (32, 'FRDMMRPKS47YJBX', 'Gray', 1);
INSERT INTO `color_list` (`id`, `color_id`, `color_name`, `status`) VALUES (33, 'Q9QM6IUMMJ9C6WO', 'Light Brown', 1);
INSERT INTO `color_list` (`id`, `color_id`, `color_name`, `status`) VALUES (34, '8Y8WXKWGX3FIEIH', 'Purpel', 1);
INSERT INTO `color_list` (`id`, `color_id`, `color_name`, `status`) VALUES (35, 'DK9F8D56QTFTUDJ', 'Silver Gold', 1);
INSERT INTO `color_list` (`id`, `color_id`, `color_name`, `status`) VALUES (36, '6B138LS9ROGZ793', 'Ash & Black', 1);
INSERT INTO `color_list` (`id`, `color_id`, `color_name`, `status`) VALUES (37, 'EE6PZRV8ZVSFCZR', 'Black & White', 1);
INSERT INTO `color_list` (`id`, `color_id`, `color_name`, `status`) VALUES (38, 'UYD4U5ZUY9QMBAH', 'Sky Blue', 1);
INSERT INTO `color_list` (`id`, `color_id`, `color_name`, `status`) VALUES (39, 'INUP53751CG3M2V', 'Crystal & Brown', 1);
INSERT INTO `color_list` (`id`, `color_id`, `color_name`, `status`) VALUES (40, 'DS567RJA93ME78K', 'White and Pink', 1);
INSERT INTO `color_list` (`id`, `color_id`, `color_name`, `status`) VALUES (41, 'DCG884YCLSPX8Y7', 'Golden & Silver', 1);
INSERT INTO `color_list` (`id`, `color_id`, `color_name`, `status`) VALUES (42, 'F8SOM969SCTI7X1', 'Navy Blue', 1);
INSERT INTO `color_list` (`id`, `color_id`, `color_name`, `status`) VALUES (43, 'HEZEKKU7WNDWBCQ', 'Grey', 1);
INSERT INTO `color_list` (`id`, `color_id`, `color_name`, `status`) VALUES (44, '1MMBZA92NDFO3R6', 'White and Green ', 1);
INSERT INTO `color_list` (`id`, `color_id`, `color_name`, `status`) VALUES (45, 'FFRD8RCCFV9TFG4', 'White Yellow & Meroon', 1);
INSERT INTO `color_list` (`id`, `color_id`, `color_name`, `status`) VALUES (46, '8PPOTHBC93PVDG9', 'Chocolate', 1);
INSERT INTO `color_list` (`id`, `color_id`, `color_name`, `status`) VALUES (47, '4OVUVXOT2JHUP39', 'Lemon', 1);
INSERT INTO `color_list` (`id`, `color_id`, `color_name`, `status`) VALUES (48, 'J3LLYKRDRR1GNPI', 'Zebra', 1);
INSERT INTO `color_list` (`id`, `color_id`, `color_name`, `status`) VALUES (49, 'DKOVM6ZOTEAFQJA', 'Cane', 1);
INSERT INTO `color_list` (`id`, `color_id`, `color_name`, `status`) VALUES (50, 'KCJP5EKIU3GG3ZX', 'Coffee', 1);
INSERT INTO `color_list` (`id`, `color_id`, `color_name`, `status`) VALUES (51, '69ZRNZYCPHVPBJ7', 'Metal-Gold', 1);
INSERT INTO `color_list` (`id`, `color_id`, `color_name`, `status`) VALUES (52, 'WTTWTA2FNLVR48C', 'Black & Golden', 1);
INSERT INTO `color_list` (`id`, `color_id`, `color_name`, `status`) VALUES (53, 'MK8RB8JMU5LR6BU', 'Black -Golden-White', 1);
INSERT INTO `color_list` (`id`, `color_id`, `color_name`, `status`) VALUES (54, 'JCCBCSPRGJBAUVT', 'Black and White', 1);
INSERT INTO `color_list` (`id`, `color_id`, `color_name`, `status`) VALUES (55, 'GHEJV7XVY8QJGA9', 'Black -Golden-Ash', 1);
INSERT INTO `color_list` (`id`, `color_id`, `color_name`, `status`) VALUES (56, '643937HVSEZY9VT', 'Black-Wooden-Ash', 1);
INSERT INTO `color_list` (`id`, `color_id`, `color_name`, `status`) VALUES (57, '5LT8KZS4N65JYRJ', 'Couper-Black-Ash', 1);
INSERT INTO `color_list` (`id`, `color_id`, `color_name`, `status`) VALUES (58, 'UQFO8JGXGCVA7C1', 'Skyblue', 1);
INSERT INTO `color_list` (`id`, `color_id`, `color_name`, `status`) VALUES (59, '58VRL1PMT4ALGXP', 'Seablue', 1);
INSERT INTO `color_list` (`id`, `color_id`, `color_name`, `status`) VALUES (60, 'SDTGZWFQ7AU2III', 'Green (Damaged)', 1);
INSERT INTO `color_list` (`id`, `color_id`, `color_name`, `status`) VALUES (61, 'U7AIQK6PITOSQPL', 'Same', 1);


#
# TABLE STRUCTURE FOR: company_information
#

DROP TABLE IF EXISTS `company_information`;

CREATE TABLE `company_information` (
  `sl` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` varchar(250) NOT NULL,
  `company_name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `email2` varchar(1000) DEFAULT NULL,
  `address` text NOT NULL,
  `mobile` varchar(50) NOT NULL,
  `phone` varchar(1000) DEFAULT NULL,
  `website` varchar(50) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`sl`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `company_information` (`sl`, `company_id`, `company_name`, `email`, `email2`, `address`, `mobile`, `phone`, `website`, `status`) VALUES (1, '1', 'Innovative Online Limited', 'iol@gmail.com', 'info@dellarte.info', 'Panchlaish Chittagong', '01837023812', '01973718718', 'https://dubaivapepayel.com/iol/', 1);


#
# TABLE STRUCTURE FOR: courier_name
#

DROP TABLE IF EXISTS `courier_name`;

CREATE TABLE `courier_name` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `courier_id` varchar(255) NOT NULL,
  `courier_name` varchar(255) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `courier_name` (`id`, `courier_id`, `courier_name`, `status`) VALUES (1, 'R3GDG15K645F8UA', 'Sundarban', 1);


#
# TABLE STRUCTURE FOR: currency_tbl
#

DROP TABLE IF EXISTS `currency_tbl`;

CREATE TABLE `currency_tbl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `currency_name` varchar(50) NOT NULL,
  `icon` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `currency_tbl` (`id`, `currency_name`, `icon`) VALUES (1, 'Dollar', '$');
INSERT INTO `currency_tbl` (`id`, `currency_name`, `icon`) VALUES (2, 'BDT', 'Tk');


#
# TABLE STRUCTURE FOR: cus_cheque
#

DROP TABLE IF EXISTS `cus_cheque`;

CREATE TABLE `cus_cheque` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_id` varchar(255) DEFAULT NULL,
  `cheque_id` varchar(1000) DEFAULT NULL,
  `cheque_type` varchar(255) DEFAULT NULL,
  `cheque_no` varchar(255) DEFAULT NULL,
  `cheque_date` varchar(255) DEFAULT NULL,
  `amount` float DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `payment_date` varchar(1000) DEFAULT NULL,
  `status` int(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: customer_information
#

DROP TABLE IF EXISTS `customer_information`;

CREATE TABLE `customer_information` (
  `customer_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `customer_id_two` varchar(255) NOT NULL,
  `customer_name` varchar(255) DEFAULT NULL,
  `customer_address` varchar(255) NOT NULL,
  `address2` text NOT NULL,
  `customer_mobile` varchar(100) NOT NULL,
  `customer_email` varchar(100) DEFAULT NULL,
  `email_address` varchar(200) DEFAULT NULL,
  `contact` varchar(100) DEFAULT NULL,
  `contact_person` varchar(1000) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `fax` varchar(100) DEFAULT NULL,
  `city` text DEFAULT NULL,
  `state` text DEFAULT NULL,
  `zip` varchar(50) DEFAULT NULL,
  `country` varchar(250) DEFAULT NULL,
  `discount_customer` int(255) DEFAULT NULL,
  `website` varchar(1000) DEFAULT NULL,
  `status` int(2) NOT NULL COMMENT '1=paid,2=credit',
  `create_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `create_by` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`customer_id`),
  UNIQUE KEY `customer_id_two` (`customer_id_two`),
  KEY `customer_id` (`customer_id`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;

INSERT INTO `customer_information` (`customer_id`, `customer_id_two`, `customer_name`, `customer_address`, `address2`, `customer_mobile`, `customer_email`, `email_address`, `contact`, `contact_person`, `phone`, `fax`, `city`, `state`, `zip`, `country`, `discount_customer`, `website`, `status`, `create_date`, `create_by`) VALUES ('1', 'TESTID1', 'Walking Customer', 'Dhaka,Abcdefghjkks arrfssfdj.Baridhara,Mirour,Topokhana,India Bangladesh', 'baridhara', '01787281564', 'customer@gmebd.com', 'customer@gmebd.com', '0808090909', '', '0808090909', 'fax', 'Dhaka', 'Dhaka', '4000', 'Bangladesh', 0, NULL, 1, '2020-10-30 14:24:47', 'tF2YChLBH86gHfG');
INSERT INTO `customer_information` (`customer_id`, `customer_id_two`, `customer_name`, `customer_address`, `address2`, `customer_mobile`, `customer_email`, `email_address`, `contact`, `contact_person`, `phone`, `fax`, `city`, `state`, `zip`, `country`, `discount_customer`, `website`, `status`, `create_date`, `create_by`) VALUES ('20', '1231', 'Shoaib Elias', 'West Dewan Nogor', '', '01864598947', 'mishoel344@gmail.com', NULL, '01864598947', 'Shoaib', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, '2021-10-19 11:34:10', NULL);
INSERT INTO `customer_information` (`customer_id`, `customer_id_two`, `customer_name`, `customer_address`, `address2`, `customer_mobile`, `customer_email`, `email_address`, `contact`, `contact_person`, `phone`, `fax`, `city`, `state`, `zip`, `country`, `discount_customer`, `website`, `status`, `create_date`, `create_by`) VALUES ('21', '82828', 'Hachaha', '', '', '01019292092', 'mishoel344@gmail.com', NULL, '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, '2021-11-03 10:07:50', NULL);


#
# TABLE STRUCTURE FOR: daily_banking_add
#

DROP TABLE IF EXISTS `daily_banking_add`;

CREATE TABLE `daily_banking_add` (
  `banking_id` varchar(255) NOT NULL,
  `date` datetime DEFAULT NULL,
  `bank_id` varchar(100) DEFAULT NULL,
  `deposit_type` varchar(255) DEFAULT NULL,
  `transaction_type` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `amount` int(11) DEFAULT NULL,
  `status` int(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: daily_closing
#

DROP TABLE IF EXISTS `daily_closing`;

CREATE TABLE `daily_closing` (
  `outlet_id` varchar(255) DEFAULT NULL,
  `closing_id` varchar(255) NOT NULL,
  `last_day_closing` float NOT NULL,
  `cash_in` float NOT NULL,
  `cash_out` float NOT NULL,
  `date` varchar(250) NOT NULL,
  `amount` float NOT NULL,
  `adjustment` float DEFAULT NULL,
  `status` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `daily_closing` (`outlet_id`, `closing_id`, `last_day_closing`, `cash_in`, `cash_out`, `date`, `amount`, `adjustment`, `status`) VALUES (NULL, '1800588168', '0', '24372', '0', '2021-10-06', '24372', NULL, 1);
INSERT INTO `daily_closing` (`outlet_id`, `closing_id`, `last_day_closing`, `cash_in`, `cash_out`, `date`, `amount`, `adjustment`, `status`) VALUES (NULL, '126784010', '24372', '0', '0', '2021-11-16', '24372', NULL, 1);


#
# TABLE STRUCTURE FOR: designation
#

DROP TABLE IF EXISTS `designation`;

CREATE TABLE `designation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(150) NOT NULL,
  `details` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `designation` (`id`, `designation`, `details`) VALUES (2, 'Assistant General Manager', '');


#
# TABLE STRUCTURE FOR: discount
#

DROP TABLE IF EXISTS `discount`;

CREATE TABLE `discount` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `discount_id` varchar(255) DEFAULT NULL,
  `customer_id` varchar(255) DEFAULT NULL,
  `category_id` varchar(255) DEFAULT NULL,
  `discount_percentage` decimal(5,2) NOT NULL DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

#
# TABLE STRUCTURE FOR: email_config
#

DROP TABLE IF EXISTS `email_config`;

CREATE TABLE `email_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `protocol` text NOT NULL,
  `smtp_host` text NOT NULL,
  `smtp_port` text NOT NULL,
  `smtp_user` varchar(35) NOT NULL,
  `smtp_pass` varchar(35) NOT NULL,
  `mailtype` varchar(30) DEFAULT NULL,
  `isinvoice` tinyint(4) NOT NULL,
  `isservice` tinyint(4) NOT NULL,
  `isquotation` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `email_config` (`id`, `protocol`, `smtp_host`, `smtp_port`, `smtp_user`, `smtp_pass`, `mailtype`, `isinvoice`, `isservice`, `isquotation`) VALUES (1, 'smtp', 'smtp.gmail.com', '25', 'devenportbd@gmail.com', '5million$', 'html', 1, 1, 1);


#
# TABLE STRUCTURE FOR: employee_academic
#

DROP TABLE IF EXISTS `employee_academic`;

CREATE TABLE `employee_academic` (
  `ac_id` int(255) NOT NULL AUTO_INCREMENT,
  `employee_id` varchar(255) DEFAULT NULL,
  `degree` varchar(255) DEFAULT NULL,
  `institution` varchar(255) DEFAULT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `passing_year` varchar(255) DEFAULT NULL,
  `result` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`ac_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: employee_ex
#

DROP TABLE IF EXISTS `employee_ex`;

CREATE TABLE `employee_ex` (
  `ex_id` int(255) NOT NULL AUTO_INCREMENT,
  `employee_id` varchar(255) DEFAULT NULL,
  `company` varchar(255) DEFAULT NULL,
  `des` varchar(255) DEFAULT NULL,
  `duration` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ex_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: employee_history
#

DROP TABLE IF EXISTS `employee_history`;

CREATE TABLE `employee_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_id` varchar(255) DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `designation` varchar(100) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `dob` varchar(255) DEFAULT NULL,
  `rate_type` int(11) DEFAULT NULL,
  `hrate` float DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `blood_group` varchar(10) DEFAULT NULL,
  `address_line_1` text DEFAULT NULL,
  `address_line_2` text DEFAULT NULL,
  `image` text DEFAULT NULL,
  `country` varchar(50) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `zip` varchar(50) DEFAULT NULL,
  `department` varchar(255) DEFAULT NULL,
  `age` varchar(255) DEFAULT NULL,
  `training` varchar(1000) DEFAULT NULL,
  `father_name` varchar(255) DEFAULT NULL,
  `mother_name` varchar(255) DEFAULT NULL,
  `nid_number` varchar(1000) DEFAULT NULL,
  `nominee_name` varchar(255) DEFAULT NULL,
  `nominee_nid` varchar(1000) DEFAULT NULL,
  `nominee_image` varchar(1000) DEFAULT NULL,
  `nominee_phone` varchar(255) DEFAULT NULL,
  `gua_name` varchar(255) DEFAULT NULL,
  `gua_nid` varchar(1000) DEFAULT NULL,
  `gua_profession` varchar(255) DEFAULT NULL,
  `gua_image` varchar(1000) DEFAULT NULL,
  `gua_phone` varchar(1000) DEFAULT NULL,
  `fam_name` varchar(255) DEFAULT NULL,
  `fam_nid` varchar(255) DEFAULT NULL,
  `fam_profession` varchar(255) DEFAULT NULL,
  `fam_relation` varchar(255) DEFAULT NULL,
  `fam_image` varchar(255) DEFAULT NULL,
  `fam_phone` varchar(255) DEFAULT NULL,
  `dar` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: employee_salary_payment
#

DROP TABLE IF EXISTS `employee_salary_payment`;

CREATE TABLE `employee_salary_payment` (
  `emp_sal_pay_id` int(11) NOT NULL AUTO_INCREMENT,
  `generate_id` int(11) NOT NULL,
  `employee_id` varchar(50) CHARACTER SET latin1 NOT NULL,
  `total_salary` decimal(18,2) NOT NULL DEFAULT 0.00,
  `total_working_minutes` varchar(50) CHARACTER SET latin1 NOT NULL,
  `working_period` varchar(50) CHARACTER SET latin1 NOT NULL,
  `payment_due` varchar(50) CHARACTER SET latin1 NOT NULL,
  `payment_date` varchar(50) CHARACTER SET latin1 NOT NULL,
  `paid_by` varchar(50) CHARACTER SET latin1 NOT NULL,
  `salary_month` varchar(70) DEFAULT NULL,
  PRIMARY KEY (`emp_sal_pay_id`),
  KEY `employee_id` (`employee_id`),
  KEY `generate_id` (`generate_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: employee_salary_setup
#

DROP TABLE IF EXISTS `employee_salary_setup`;

CREATE TABLE `employee_salary_setup` (
  `e_s_s_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `employee_id` varchar(30) CHARACTER SET latin1 NOT NULL,
  `sal_type` varchar(30) NOT NULL,
  `salary_type_id` varchar(30) CHARACTER SET latin1 NOT NULL,
  `amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `create_date` date DEFAULT NULL,
  `update_date` datetime(6) DEFAULT NULL,
  `update_id` varchar(30) CHARACTER SET latin1 NOT NULL,
  `gross_salary` float NOT NULL,
  PRIMARY KEY (`e_s_s_id`),
  KEY `employee_id` (`employee_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: employee_tr
#

DROP TABLE IF EXISTS `employee_tr`;

CREATE TABLE `employee_tr` (
  `tr_id` int(255) NOT NULL AUTO_INCREMENT,
  `employee_id` varchar(255) DEFAULT NULL,
  `tr_centre` varchar(255) DEFAULT NULL,
  `tr_name` varchar(255) DEFAULT NULL,
  `tr_duration` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`tr_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: expense
#

DROP TABLE IF EXISTS `expense`;

CREATE TABLE `expense` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `type` varchar(100) NOT NULL,
  `voucher_no` varchar(50) NOT NULL,
  `amount` float NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: expense_item
#

DROP TABLE IF EXISTS `expense_item`;

CREATE TABLE `expense_item` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `expense_item_name` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: invoice
#

DROP TABLE IF EXISTS `invoice`;

CREATE TABLE `invoice` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `invoice_id` bigint(20) NOT NULL,
  `customer_id` bigint(20) NOT NULL,
  `customer_name_two` varchar(255) DEFAULT NULL,
  `customer_mobile_two` varchar(255) DEFAULT NULL,
  `date` varchar(50) DEFAULT NULL,
  `outlet_id` varchar(255) DEFAULT NULL,
  `total_amount` decimal(18,2) NOT NULL DEFAULT 0.00,
  `paid_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `due_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `prevous_due` decimal(20,2) NOT NULL DEFAULT 0.00,
  `shipping_cost` decimal(10,2) NOT NULL DEFAULT 0.00,
  `invoice` bigint(20) NOT NULL,
  `invoice_discount` decimal(10,2) DEFAULT 0.00 COMMENT 'invoice discount',
  `total_discount` decimal(10,2) DEFAULT 0.00 COMMENT 'total invoice discount',
  `total_tax` decimal(10,2) DEFAULT 0.00,
  `sales_by` varchar(50) NOT NULL,
  `invoice_details` text NOT NULL,
  `status` int(2) NOT NULL,
  `bank_id` varchar(30) DEFAULT NULL,
  `bkash_id` varchar(255) DEFAULT NULL,
  `nagad_id` varchar(255) DEFAULT NULL,
  `payment_type` int(11) DEFAULT NULL,
  `delivery_type` int(11) DEFAULT NULL,
  `courier_id` varchar(255) DEFAULT NULL,
  `branch_id` varchar(255) DEFAULT NULL,
  `reciever_id` int(20) DEFAULT NULL,
  `receiver_number` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `customer_id` (`customer_id`),
  KEY `invoice_id` (`invoice_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: invoice_details
#

DROP TABLE IF EXISTS `invoice_details`;

CREATE TABLE `invoice_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_details_id` varchar(100) NOT NULL,
  `invoice_id` varchar(100) NOT NULL,
  `product_id` varchar(30) NOT NULL,
  `sn` varchar(1000) DEFAULT NULL,
  `warehouse` varchar(255) DEFAULT NULL,
  `description` varchar(250) DEFAULT NULL,
  `quantity` decimal(10,0) DEFAULT NULL,
  `warrenty_date` varchar(50) DEFAULT NULL,
  `expiry_date` varchar(255) DEFAULT NULL,
  `rate` decimal(10,2) DEFAULT NULL,
  `supplier_rate` float DEFAULT NULL,
  `total_price` decimal(12,2) DEFAULT NULL,
  `discount` decimal(10,2) DEFAULT NULL,
  `discount_per` varchar(15) DEFAULT NULL,
  `tax` decimal(10,2) DEFAULT NULL,
  `paid_amount` decimal(12,0) DEFAULT NULL,
  `due_amount` decimal(10,2) DEFAULT NULL,
  `status` int(2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `invoice_id` (`invoice_id`),
  KEY `product_id` (`product_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: item_usage
#

DROP TABLE IF EXISTS `item_usage`;

CREATE TABLE `item_usage` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `production_id` varchar(255) DEFAULT NULL,
  `item_usage_id` varchar(255) DEFAULT NULL,
  `item_id` varchar(255) DEFAULT NULL,
  `usage_qty` int(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: language
#

DROP TABLE IF EXISTS `language`;

CREATE TABLE `language` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `phrase` text NOT NULL,
  `english` text DEFAULT NULL,
  `bangla` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=944 DEFAULT CHARSET=utf8;

INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (1, 'user_profile', 'User Profile', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (2, 'setting', 'Setting', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (3, 'language', 'Language', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (4, 'manage_users', 'Manage Users', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (5, 'add_user', 'Add User', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (6, 'manage_company', 'Manage Company', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (7, 'web_settings', 'Software Settings', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (8, 'manage_accounts', 'Manage Accounts', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (9, 'create_accounts', 'Create Account', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (10, 'manage_bank', 'Manage Bank', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (11, 'add_new_bank', 'Add New Bank', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (12, 'settings', 'Settings', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (13, 'closing_report', 'Closing Report', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (14, 'closing', 'Closing', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (15, 'cheque_manager', 'Cheque Manager', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (16, 'accounts_summary', 'Accounts Summary', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (17, 'expense', 'Expense', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (18, 'income', 'Income', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (19, 'accounts', 'Accounts', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (20, 'stock_report', 'Stock Report', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (21, 'stock', 'Stock', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (22, 'pos_invoice', 'POS Sale', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (23, 'manage_invoice', 'Manage Sale', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (24, 'new_invoice', 'New Sale', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (25, 'invoice', 'Sale', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (26, 'manage_purchase', 'Manage Purchase', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (27, 'add_purchase', 'Add Purchase', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (28, 'purchase', 'Purchase', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (29, 'paid_customer', 'Paid Customer ', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (30, 'manage_customer', 'Manage Customer ', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (31, 'add_customer', 'Add Customer ', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (32, 'customer', 'Customer', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (33, 'supplier_payment_actual', 'Supplier Payment Ledger', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (34, 'supplier_sales_summary', 'Supplier Sales Summary', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (35, 'supplier_sales_details', 'Supplier Sales Details', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (36, 'supplier_ledger', 'Supplier Ledger', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (37, 'manage_supplier', 'Manage Supplier', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (38, 'add_supplier', 'Add Supplier', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (39, 'supplier', 'Supplier', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (40, 'product_statement', 'Product Statement', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (41, 'manage_product', 'Manage Product', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (42, 'add_product', 'Add Product', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (43, 'product', 'Product', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (44, 'manage_category', 'Manage Category', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (45, 'add_category', 'Add Category', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (46, 'category', 'Category', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (47, 'sales_report_product_wise', 'Sales Report (Product Wise)', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (48, 'purchase_report', 'Purchase Report', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (49, 'sales_report', 'Sales Report', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (50, 'todays_report', 'Todays Report', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (51, 'report', 'Report', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (52, 'dashboard', 'Dashboard', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (53, 'online', 'Online', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (54, 'logout', 'Logout', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (55, 'change_password', 'Change Password', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (56, 'total_purchase', 'Total Purchase', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (57, 'total_amount', 'Total Amount', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (58, 'supplier_name', 'Supplier Name', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (59, 'invoice_no', 'Invoice No', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (60, 'purchase_date', 'Purchase Date', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (61, 'todays_purchase_report', 'Todays Purchase Report', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (62, 'total_sales', 'Total Sales', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (63, 'customer_name', 'Customer Name', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (64, 'sales_date', 'Sales Date', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (65, 'todays_sales_report', 'Todays Sales Report', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (66, 'home', 'Home', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (67, 'todays_sales_and_purchase_report', 'Todays sales and purchase report', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (68, 'total_ammount', 'Total Amount', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (69, 'rate', 'Rate', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (70, 'product_model', 'Product Model', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (71, 'product_name', 'Product Name', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (72, 'search', 'Search', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (73, 'end_date', 'End Date', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (74, 'start_date', 'Start Date', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (75, 'total_purchase_report', 'Total Purchase Report', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (76, 'total_sales_report', 'Total Sales Report', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (77, 'total_seles', 'Total Sales', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (78, 'all_stock_report', 'All Stock Report', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (79, 'search_by_product', 'Search By Product', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (80, 'date', 'Date', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (81, 'print', 'Print', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (82, 'stock_date', 'Stock Date', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (83, 'print_date', 'Print Date', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (84, 'sales', 'Sales', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (85, 'price', 'Price', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (86, 'sl', 'SL.', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (87, 'add_new_category', 'Add new category', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (88, 'category_name', 'Category Name', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (89, 'save', 'Save', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (90, 'delete', 'Delete', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (91, 'update', 'Update', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (92, 'action', 'Action', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (93, 'manage_your_category', 'Manage your category ', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (94, 'category_edit', 'Category Edit', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (95, 'status', 'Status', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (96, 'active', 'Active', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (97, 'inactive', 'Inactive', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (98, 'save_changes', 'Save Changes', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (99, 'save_and_add_another', 'Save And Add Another', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (100, 'model', 'Model', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (101, 'supplier_price', 'Supplier Price', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (102, 'sell_price', 'Sale Price', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (103, 'image', 'Image', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (104, 'select_one', 'Select One', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (105, 'details', 'Details', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (106, 'new_product', 'New Product', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (107, 'add_new_product', 'Add new product', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (108, 'barcode', 'Barcode', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (109, 'qr_code', 'Qr-Code', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (110, 'product_details', 'Product Details', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (111, 'manage_your_product', 'Manage your product', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (112, 'product_edit', 'Product Edit', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (113, 'edit_your_product', 'Edit your product', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (114, 'cancel', 'Cancel', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (115, 'incl_vat', 'Incl. Vat', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (116, 'money', 'TK', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (117, 'grand_total', 'Grand Total', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (118, 'quantity', 'Qnty', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (119, 'product_report', 'Product Report', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (120, 'product_sales_and_purchase_report', 'Product sales and purchase report', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (121, 'previous_stock', 'Previous Stock', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (122, 'out', 'Out', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (123, 'in', 'In', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (124, 'to', 'To', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (125, 'previous_balance', 'Previous Credit Balance', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (126, 'customer_address', 'Customer Address', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (127, 'customer_mobile', 'Customer Mobile', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (128, 'customer_email', 'Customer Email', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (129, 'add_new_customer', 'Add new Customer', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (130, 'balance', 'Balance', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (131, 'mobile', 'Mobile', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (132, 'address', 'Address', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (133, 'manage_your_customer', 'Manage your Customer ', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (134, 'customer_edit', 'Customer Edit', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (135, 'paid_customer_list', 'Paid Customer List', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (136, 'ammount', 'Amount', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (137, 'customer_ledger', 'Customer Ledger', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (138, 'manage_customer_ledger', 'Manage Customer Ledger', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (139, 'customer_information', 'Customer Information', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (140, 'debit_ammount', 'Debit Amount', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (141, 'credit_ammount', 'Credit Amount', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (142, 'balance_ammount', 'Balance Amount', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (143, 'receipt_no', 'Receipt NO', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (144, 'description', 'Description', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (145, 'debit', 'Debit', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (146, 'credit', 'Credit', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (147, 'item_information', 'Item Information', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (148, 'total', 'Total', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (149, 'please_select_supplier', 'Please Select Supplier', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (150, 'submit', 'Submit', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (151, 'submit_and_add_another', 'Submit And Add Another One', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (152, 'add_new_item', 'Add New Item', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (153, 'manage_your_purchase', 'Manage your purchase', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (154, 'purchase_edit', 'Purchase Edit', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (155, 'purchase_ledger', 'Purchase Ledger', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (156, 'invoice_information', 'Sale Information', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (157, 'paid_ammount', 'Paid Amount', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (158, 'discount', 'Dis./Pcs.', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (159, 'save_and_paid', 'Save And Paid', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (160, 'payee_name', 'Payee Name', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (161, 'manage_your_invoice', 'Manage your Sale', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (162, 'invoice_edit', 'Sale Edit', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (163, 'new_pos_invoice', 'New POS Sale', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (164, 'add_new_pos_invoice', 'Add new pos Sale', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (165, 'product_id', 'Product ID', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (166, 'paid_amount', 'Paid Amount', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (167, 'authorised_by', 'Authorised By', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (168, 'checked_by', 'Checked By', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (169, 'received_by', 'Received By', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (170, 'prepared_by', 'Prepared By', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (171, 'memo_no', 'Memo No', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (172, 'website', 'Website', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (173, 'email', 'Email', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (174, 'invoice_details', 'Sale Details', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (175, 'reset', 'Reset', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (176, 'payment_account', 'Payment Account', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (177, 'bank_name', 'Bank Name', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (178, 'cheque_or_pay_order_no', 'Cheque/Pay Order No', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (179, 'payment_type', 'Payment Type', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (180, 'payment_from', 'Payment From', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (181, 'payment_date', 'Payment Date', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (182, 'add_income', 'Add Income', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (183, 'cash', 'Cash', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (184, 'cheque', 'Cheque', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (185, 'pay_order', 'Pay Order', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (186, 'payment_to', 'Payment To', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (187, 'total_outflow_ammount', 'Total Expense Amount', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (188, 'transections', 'Transections', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (189, 'accounts_name', 'Accounts Name', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (190, 'outflow_report', 'Expense Report', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (191, 'inflow_report', 'Income Report', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (192, 'all', 'All', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (193, 'account', 'Account', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (194, 'from', 'From', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (195, 'account_summary_report', 'Account Summary Report', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (196, 'search_by_date', 'Search By Date', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (197, 'cheque_no', 'Cheque No', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (198, 'name', 'Name', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (199, 'closing_account', 'Closing Account', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (200, 'close_your_account', 'Close your account', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (201, 'last_day_closing', 'Last Day Closing', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (202, 'cash_in', 'Cash In', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (203, 'cash_out', 'Cash Out', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (204, 'cash_in_hand', 'Cash In Hand', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (205, 'add_new_bank', 'Add New Bank', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (206, 'day_closing', 'Day Closing', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (207, 'account_closing_report', 'Account Closing Report', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (208, 'last_day_ammount', 'Last Day Amount', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (209, 'adjustment', 'Adjustment', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (210, 'pay_type', 'Pay Type', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (211, 'customer_or_supplier', 'Customer ,Supplier Or Others', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (212, 'transection_id', 'Transections ID', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (213, 'accounts_summary_report', 'Accounts Summary Report', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (214, 'bank_list', 'Bank List', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (215, 'bank_edit', 'Bank Edit', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (216, 'debit_plus', 'Debit (+)', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (217, 'credit_minus', 'Credit (-)', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (218, 'account_name', 'Account Name', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (219, 'account_type', 'Account Type', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (220, 'account_real_name', 'Account Real Name', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (221, 'manage_account', 'Manage Account', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (222, 'company_name', 'Niha International', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (223, 'edit_your_company_information', 'Edit your company information', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (224, 'company_edit', 'Company Edit', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (225, 'admin', 'Admin', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (226, 'user', 'User', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (227, 'password', 'Password', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (228, 'last_name', 'Last Name', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (229, 'first_name', 'First Name', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (230, 'add_new_user_information', 'Add new user information', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (231, 'user_type', 'User Type', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (232, 'user_edit', 'User Edit', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (233, 'rtr', 'RTR', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (234, 'ltr', 'LTR', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (235, 'ltr_or_rtr', 'LTR/RTR', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (236, 'footer_text', 'Footer Text', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (237, 'favicon', 'Favicon', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (238, 'logo', 'Logo', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (239, 'update_setting', 'Update Setting', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (240, 'update_your_web_setting', 'Update your web setting', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (241, 'login', 'Login', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (242, 'your_strong_password', 'Your strong password', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (243, 'your_unique_email', 'Your unique email', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (244, 'please_enter_your_login_information', 'Please enter your login information.', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (245, 'update_profile', 'Update Profile', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (246, 'your_profile', 'Your Profile', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (247, 're_type_password', 'Re-Type Password', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (248, 'new_password', 'New Password', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (249, 'old_password', 'Old Password', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (250, 'new_information', 'New Information', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (251, 'old_information', 'Old Information', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (252, 'change_your_information', 'Change your information', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (253, 'change_your_profile', 'Change your profile', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (254, 'profile', 'Profile', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (255, 'wrong_username_or_password', 'Wrong User Name Or Password !', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (256, 'successfully_updated', 'Successfully Updated.', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (257, 'blank_field_does_not_accept', 'Blank Field Does Not Accept !', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (258, 'successfully_changed_password', 'Successfully changed password.', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (259, 'you_are_not_authorised_person', 'You are not authorised person !', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (260, 'password_and_repassword_does_not_match', 'Passwor and re-password does not match !', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (261, 'new_password_at_least_six_character', 'New Password At Least 6 Character.', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (262, 'you_put_wrong_email_address', 'You put wrong email address !', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (263, 'cheque_ammount_asjusted', 'Cheque amount adjusted.', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (264, 'successfully_payment_paid', 'Successfully Payment Paid.', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (265, 'successfully_added', 'Successfully Added.', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (266, 'successfully_updated_2_closing_ammount_not_changeale', 'Successfully Updated -2. Note: Closing Amount Not Changeable.', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (267, 'successfully_payment_received', 'Successfully Payment Received.', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (268, 'already_inserted', 'Already Inserted !', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (269, 'successfully_delete', 'Successfully Delete.', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (270, 'successfully_created', 'Successfully Created.', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (271, 'logo_not_uploaded', 'Logo not uploaded !', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (272, 'favicon_not_uploaded', 'Favicon not uploaded !', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (273, 'supplier_mobile', 'Supplier Mobile', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (274, 'supplier_address', 'Supplier Address', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (275, 'supplier_details', 'Supplier Details', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (276, 'add_new_supplier', 'Add New Supplier', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (277, 'manage_suppiler', 'Manage Supplier', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (278, 'manage_your_supplier', 'Manage your supplier', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (279, 'manage_supplier_ledger', 'Manage supplier ledger', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (280, 'invoice_id', 'Invoice ID', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (281, 'deposite_id', 'Deposite ID', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (282, 'supplier_actual_ledger', 'Supplier Payment Ledger', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (283, 'supplier_information', 'Supplier Information', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (284, 'event', 'Event', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (285, 'add_new_income', 'Add New Income', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (286, 'add_expese', 'Add Expense', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (287, 'add_new_expense', 'Add New Expense', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (288, 'total_inflow_ammount', 'Total Income Amount', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (289, 'create_new_invoice', 'Create New Sale', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (290, 'create_pos_invoice', 'Create POS Sale', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (291, 'total_profit', 'Total Profit', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (292, 'monthly_progress_report', 'Monthly Progress Report', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (293, 'total_invoice', 'Total Sale', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (294, 'account_summary', 'Account Summary', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (295, 'total_supplier', 'Total Supplier', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (296, 'total_product', 'Total Product', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (297, 'total_customer', 'Total Customer', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (298, 'supplier_edit', 'Supplier Edit', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (299, 'add_new_invoice', 'Add New Sale', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (300, 'add_new_purchase', 'Add new purchase', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (301, 'currency', 'Currency', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (302, 'currency_position', 'Currency Position', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (303, 'left', 'Left', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (304, 'right', 'Right', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (305, 'add_tax', 'Add Tax', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (306, 'manage_tax', 'Manage Tax', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (307, 'add_new_tax', 'Add new tax', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (308, 'enter_tax', 'Enter Tax', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (309, 'already_exists', 'Already Exists !', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (310, 'successfully_inserted', 'Successfully Inserted.', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (311, 'tax', 'Tax', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (312, 'tax_edit', 'Tax Edit', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (313, 'product_not_added', 'Product not added !', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (314, 'total_tax', 'Total Tax', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (315, 'manage_your_supplier_details', 'Manage your supplier details.', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (316, 'invoice_description', 'Lorem Ipsum is sim ply dummy Lorem Ipsum is simply dummy Lorem Ipsum is simply dummy Lorem Ipsum is simply dummy Lorem Ipsum is simply dummy Lorem Ipsum is sim ply dummy Lorem Ipsum is simply dummy Lorem Ipsum is simply dummy Lorem Ipsum is simply dummy Lorem Ipsum is simply dummy', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (317, 'thank_you_for_choosing_us', 'Thank you very much for choosing us.', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (318, 'billing_date', 'Billing Date', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (319, 'billing_to', 'Billing To', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (320, 'billing_from', 'Billing From', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (321, 'you_cant_delete_this_product', 'Sorry !!  You can\'t delete this product.This product already used in calculation system!', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (322, 'old_customer', 'Old Customer ', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (323, 'new_customer', 'New Customer', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (324, 'new_supplier', 'New Supplier', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (325, 'old_supplier', 'Old Supplier', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (326, 'credit_customer', 'Credit Customer ', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (327, 'account_already_exists', 'This Account Already Exists !', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (328, 'edit_income', 'Edit Income', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (329, 'you_are_not_access_this_part', 'You are not authorised person !', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (330, 'account_edit', 'Account Edit', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (331, 'due', 'Due', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (332, 'expense_edit', 'Expense Edit', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (333, 'please_select_customer', 'Please select customer !', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (334, 'profit_report', 'Profit Report (Sale Wise)', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (335, 'total_profit_report', 'Total profit report', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (336, 'please_enter_valid_captcha', 'Please enter valid captcha.', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (337, 'category_not_selected', 'Category not selected.', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (338, 'supplier_not_selected', 'Supplier not selected.', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (339, 'please_select_product', 'Please select product.', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (340, 'product_model_already_exist', 'Product model already exist !', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (341, 'invoice_logo', 'Sale Logo', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (342, 'available_qnty', 'Av. Qnty.', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (343, 'you_can_not_buy_greater_than_available_cartoon', 'You can not select grater than available cartoon !', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (344, 'customer_details', 'Customer details', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (345, 'manage_customer_details', 'Manage Customer details.', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (346, 'site_key', 'Captcha Site Key', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (347, 'secret_key', 'Captcha Secret Key', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (348, 'captcha', 'Captcha', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (349, 'cartoon_quantity', 'Cartoon Quantity', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (350, 'total_cartoon', 'Total Cartoon', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (351, 'cartoon', 'Cartoon', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (352, 'item_cartoon', 'Item/Cartoon', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (353, 'product_and_supplier_did_not_match', 'Product and supplier did not match !', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (354, 'if_you_update_purchase_first_select_supplier_then_product_and_then_quantity', 'If you update purchase,first select supplier then product and then update qnty.', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (355, 'item', 'Item', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (356, 'manage_your_credit_customer', 'Manage your credit Customer ', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (357, 'total_quantity', 'Total Quantity', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (358, 'quantity_per_cartoon', 'Quantity per cartoon', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (359, 'barcode_qrcode_scan_here', 'Barcode or QR-code scan here', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (360, 'synchronizer_setting', 'Synchronizer Setting', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (361, 'data_synchronizer', 'Data Synchronizer', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (362, 'hostname', 'Host name', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (363, 'username', 'User Name', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (364, 'ftp_port', 'FTP Port', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (365, 'ftp_debug', 'FTP Debug', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (366, 'project_root', 'Project Root', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (367, 'please_try_again', 'Please try again', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (368, 'save_successfully', 'Save successfully', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (369, 'synchronize', 'Synchronize', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (370, 'internet_connection', 'Internet Connection', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (371, 'outgoing_file', 'Outgoing File', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (372, 'incoming_file', 'Incoming File', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (373, 'ok', 'Ok', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (374, 'not_available', 'Not Available', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (375, 'available', 'Available', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (376, 'download_data_from_server', 'Download data from server', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (377, 'data_import_to_database', 'Data import to database', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (378, 'data_upload_to_server', 'Data uplod to server', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (379, 'please_wait', 'Please Wait', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (380, 'ooops_something_went_wrong', 'Oooops Something went wrong !', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (381, 'upload_successfully', 'Upload successfully', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (382, 'unable_to_upload_file_please_check_configuration', 'Unable to upload file please check configuration', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (383, 'please_configure_synchronizer_settings', 'Please configure synchronizer settings', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (384, 'download_successfully', 'Download successfully', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (385, 'unable_to_download_file_please_check_configuration', 'Unable to download file please check configuration', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (386, 'data_import_first', 'Data import past', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (387, 'data_import_successfully', 'Data import successfully', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (388, 'unable_to_import_data_please_check_config_or_sql_file', 'Unable to import data please check config or sql file', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (389, 'total_sale_ctn', 'Total Sale Ctn', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (390, 'in_qnty', 'In Qnty.', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (391, 'out_qnty', 'Out Qnty.', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (392, 'stock_report_supplier_wise', 'Stock Report (Supplier Wise)', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (393, 'all_stock_report_supplier_wise', 'Stock Report (Suppler Wise)', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (394, 'select_supplier', 'Select Supplier', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (395, 'stock_report_product_wise', 'Stock Report (Product Wise)', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (396, 'phone', 'Phone', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (397, 'select_product', 'Select Product', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (398, 'in_quantity', 'In Qnty.', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (399, 'out_quantity', 'Out Qnty.', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (400, 'in_taka', 'In TK.', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (401, 'out_taka', 'Out TK.', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (402, 'commission', 'Commission', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (403, 'generate_commission', 'Generate Commssion', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (404, 'commission_rate', 'Commission Rate', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (405, 'total_ctn', 'Total Ctn.', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (406, 'per_pcs_commission', 'Per PCS Commission', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (407, 'total_commission', 'Total Commission', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (408, 'enter', 'Enter', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (409, 'please_add_walking_customer_for_default_customer', 'Please add \'Walking Customer\' for default customer.', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (410, 'supplier_ammount', 'Supplier Amount', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (411, 'my_sale_ammount', 'My Sale Amount', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (412, 'signature_pic', 'Signature Picture', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (413, 'branch', 'Branch', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (414, 'ac_no', 'A/C Number', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (415, 'ac_name', 'A/C Name', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (416, 'bank_transaction', 'Bank Transaction', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (417, 'bank', 'Bank', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (418, 'withdraw_deposite_id', 'Withdraw / Deposite ID', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (419, 'bank_ledger', 'Bank Ledger', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (420, 'note_name', 'Note Name', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (421, 'pcs', 'Pcs.', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (422, '1', '1', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (423, '2', '2', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (424, '5', '5', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (425, '10', '10', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (426, '20', '20', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (427, '50', '50', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (428, '100', '100', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (429, '500', '500', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (430, '1000', '1000', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (431, 'total_discount', 'Total Discount', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (432, 'product_not_found', 'Product not found !', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (433, 'this_is_not_credit_customer', 'This is not credit customer !', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (434, 'personal_loan', 'Personal Loan', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (435, 'add_person', 'Add Person', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (436, 'add_loan', 'Add Loan', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (437, 'add_payment', 'Add Payment', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (438, 'manage_person', 'Manage Person', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (439, 'personal_edit', 'Person Edit', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (440, 'person_ledger', 'Person Ledger', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (441, 'backup_restore', 'Backup ', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (442, 'database_backup', 'Database backup', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (443, 'file_information', 'File information', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (444, 'filename', 'Filename', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (445, 'size', 'Size', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (446, 'backup_date', 'Backup date', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (447, 'backup_now', 'Backup now', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (448, 'restore_now', 'Restore now', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (449, 'are_you_sure', 'Are you sure ?', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (450, 'download', 'Download', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (451, 'backup_and_restore', 'Backup', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (452, 'backup_successfully', 'Backup successfully', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (453, 'delete_successfully', 'Delete successfully', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (454, 'stock_ctn', 'Stock/Qnt', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (455, 'unit', 'Unit', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (456, 'meter_m', 'Meter (M)', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (457, 'piece_pc', 'Piece (Pc)', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (458, 'kilogram_kg', 'Kilogram (Kg)', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (459, 'stock_cartoon', 'Stock Cartoon', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (460, 'add_product_csv', 'Add Product (CSV)', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (461, 'import_product_csv', 'Import product (CSV)', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (462, 'close', 'Close', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (463, 'download_example_file', 'Download example file.', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (464, 'upload_csv_file', 'Upload CSV File', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (465, 'csv_file_informaion', 'CSV File Information', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (466, 'out_of_stock', 'Out Of Stock', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (467, 'others', 'Others', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (468, 'full_paid', 'Full Paid', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (469, 'successfully_saved', 'Your Data Successfully Saved', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (470, 'manage_loan', 'Manage Loan', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (471, 'receipt', 'Receipt', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (472, 'payment', 'Payment', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (473, 'cashflow', 'Daily Cash Flow', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (474, 'signature', 'Signature', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (475, 'supplier_reports', 'Supplier Reports', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (476, 'generate', 'Generate', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (477, 'todays_overview', 'Todays Overview', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (478, 'last_sales', 'Last Sales', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (479, 'manage_transaction', 'Manage Transaction', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (480, 'daily_summary', 'Daily Summary', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (481, 'daily_cash_flow', 'Daily Cash Flow', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (482, 'custom_report', 'Custom Report', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (483, 'transaction', 'Transaction', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (484, 'receipt_amount', 'Receipt Amount', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (485, 'transaction_details_datewise', 'Transaction Details Datewise', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (486, 'cash_closing', 'Cash Closing', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (487, 'you_can_not_buy_greater_than_available_qnty', 'You can not buy greater than available qnty.', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (488, 'supplier_id', 'Supplier ID', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (489, 'category_id', 'Category ID', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (490, 'select_report', 'Select Report', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (491, 'supplier_summary', 'Supplier summary', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (492, 'sales_payment_actual', 'Sales payment actual', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (493, 'today_already_closed', 'Today already closed.', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (494, 'root_account', 'Root Account', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (495, 'office', 'Office', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (496, 'loan', 'Loan', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (497, 'transaction_mood', 'Transaction Mood', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (498, 'select_account', 'Select Account', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (499, 'add_receipt', 'Add Receipt', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (500, 'update_transaction', 'Update Transaction', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (501, 'no_stock_found', 'No Stock Found !', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (502, 'admin_login_area', 'Admin Login Area', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (503, 'print_qr_code', 'Print QR Code', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (504, 'discount_type', 'Discount Type', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (505, 'discount_percentage', 'Discount', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (506, 'fixed_dis', 'Fixed Dis.', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (507, 'return', 'Return', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (508, 'stock_return_list', 'Stock Return List', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (509, 'wastage_return_list', 'Wastage Return List', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (510, 'return_invoice', 'Sale Return', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (511, 'sold_qty', 'Sold Qty', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (512, 'ret_quantity', 'Return Qty', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (513, 'deduction', 'Deduction', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (514, 'check_return', 'Check Return', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (515, 'reason', 'Reason', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (516, 'usablilties', 'Usability', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (517, 'adjs_with_stck', 'Adjust With Stock', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (518, 'return_to_supplier', 'Return To Supplier', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (519, 'wastage', 'Wastage', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (520, 'to_deduction', 'Total Deduction ', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (521, 'nt_return', 'Net Return Amount', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (522, 'return_list', 'Return List', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (523, 'add_return', 'Add Return', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (524, 'per_qty', 'Purchase Qty', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (525, 'return_supplier', 'Supplier Return', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (526, 'stock_purchase', 'Stock Purchase Price', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (527, 'stock_sale', 'Stock Sale Price', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (528, 'supplier_return', 'Supplier Return', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (529, 'purchase_id', 'Purchase ID', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (530, 'return_id', 'Return ID', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (531, 'supplier_return_list', 'Supplier Return List', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (532, 'c_r_slist', 'Stock Return Stock', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (533, 'wastage_list', 'Wastage List', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (534, 'please_input_correct_invoice_id', 'Please Input a Correct Sale ID', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (535, 'please_input_correct_purchase_id', 'Please Input Your Correct  Purchase ID', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (536, 'add_more', 'Add More', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (537, 'prouct_details', 'Product Details', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (538, 'prouct_detail', 'Product Details', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (539, 'stock_return', 'Stock Return', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (540, 'choose_transaction', 'Select Transaction', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (541, 'transection_category', 'Select  Category', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (542, 'transaction_categry', 'Select Category', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (543, 'search_supplier', 'Search Supplier', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (544, 'customer_id', 'Customer ID', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (545, 'search_customer', 'Search Customer Invoice', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (546, 'serial_no', 'SN', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (547, 'item_discount', 'Item Discount', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (548, 'invoice_discount', 'Sale Discount', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (549, 'add_unit', 'Add Unit', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (550, 'manage_unit', 'Manage Unit', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (551, 'add_new_unit', 'Add New Unit', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (552, 'unit_name', 'Unit Name', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (553, 'payment_amount', 'Payment Amount', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (554, 'manage_your_unit', 'Manage Your Unit', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (555, 'unit_id', 'Unit ID', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (556, 'unit_edit', 'Unit Edit', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (557, 'vat', 'Vat', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (558, 'sales_report_category_wise', 'Sales Report (Category wise)', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (559, 'purchase_report_category_wise', 'Purchase Report (Category wise)', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (560, 'category_wise_purchase_report', 'Category wise purchase report', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (561, 'category_wise_sales_report', 'Category wise sales report', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (562, 'best_sale_product', 'Best Sale Product', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (563, 'all_best_sales_product', 'All Best Sales Products', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (564, 'todays_customer_receipt', 'Todays Customer Receipt', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (565, 'not_found', 'Record not found', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (566, 'collection', 'Collection', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (567, 'increment', 'Increment', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (568, 'accounts_tree_view', 'Accounts Tree View', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (569, 'debit_voucher', 'Debit Voucher', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (570, 'voucher_no', 'Voucher No', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (571, 'credit_account_head', 'Credit Account Head', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (572, 'remark', 'Remark', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (573, 'code', 'Code', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (574, 'amount', 'Amount', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (575, 'approved', 'Approved', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (576, 'debit_account_head', 'Debit Account Head', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (577, 'credit_voucher', 'Credit Voucher', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (578, 'find', 'Find', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (579, 'transaction_date', 'Transaction Date', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (580, 'voucher_type', 'Voucher Type', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (581, 'particulars', 'Particulars', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (582, 'with_details', 'With Details', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (583, 'general_ledger', 'General Ledger', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (584, 'general_ledger_of', 'General ledger of', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (585, 'pre_balance', 'Pre Balance', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (586, 'current_balance', 'Current Balance', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (587, 'to_date', 'To Date', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (588, 'from_date', 'From Date', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (589, 'trial_balance', 'Trial Balance', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (590, 'authorized_signature', 'Authorized Signature', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (591, 'chairman', 'Chairman', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (592, 'total_income', 'Total Income', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (593, 'statement_of_comprehensive_income', 'Statement of Comprehensive Income', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (594, 'profit_loss', 'Profit Loss', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (595, 'cash_flow_report', 'Cash Flow Report', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (596, 'cash_flow_statement', 'Cash Flow Statement', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (597, 'amount_in_dollar', 'Amount In Dollar', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (598, 'opening_cash_and_equivalent', 'Opening Cash and Equivalent', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (599, 'coa_print', 'Coa Print', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (600, 'cash_flow', 'Cash Flow', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (601, 'cash_book', 'Cash Book', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (602, 'bank_book', 'Bank Book', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (603, 'c_o_a', 'Chart of Account', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (604, 'journal_voucher', 'Journal Voucher', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (605, 'contra_voucher', 'Contra Voucher', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (606, 'voucher_approval', 'Vouchar Approval', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (607, 'supplier_payment', 'Supplier Payment', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (608, 'customer_receive', 'Customer Receive', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (609, 'gl_head', 'General Head', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (610, 'account_code', 'Account Head', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (611, 'opening_balance', 'Opening Balance', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (612, 'head_of_account', 'Head of Account', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (613, 'inventory_ledger', 'Inventory Ledger', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (614, 'newpassword', 'New Password', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (615, 'password_recovery', 'Password Recovery', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (616, 'forgot_password', 'Forgot Password ??', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (617, 'send', 'Send', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (618, 'due_report', 'Due Report', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (619, 'due_amount', 'Due Amount', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (620, 'download_sample_file', 'Download Sample File', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (621, 'customer_csv_upload', 'Customer Csv Upload', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (622, 'csv_supplier', 'Csv Upload Supplier', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (623, 'csv_upload_supplier', 'Csv Upload Supplier', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (624, 'previous', 'Previous', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (625, 'net_total', 'Net Total', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (626, 'currency_list', 'Currency List', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (627, 'currency_name', 'Currency Name', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (628, 'currency_icon', 'Currency Symbol', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (629, 'add_currency', 'Add Currency', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (630, 'role_permission', 'Role Permission', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (631, 'role_list', 'Role List', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (632, 'user_assign_role', 'User Assign Role', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (633, 'permission', 'Permission', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (634, 'add_role', 'Add Role', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (635, 'add_module', 'Add Module', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (636, 'module_name', 'Module Name', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (637, 'office_loan', 'Office Loan', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (638, 'add_menu', 'Add Menu', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (639, 'menu_name', 'Menu Name', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (640, 'sl_no', 'Sl No', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (641, 'create', 'Create', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (642, 'read', 'Read', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (643, 'role_name', 'Role Name', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (644, 'qty', 'Quantity', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (645, 'max_rate', 'Max Rate', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (646, 'min_rate', 'Min Rate', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (647, 'avg_rate', 'Average Rate', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (648, 'role_permission_added_successfully', 'Role Permission Successfully Added', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (649, 'update_successfully', 'Successfully Updated', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (650, 'role_permission_updated_successfully', 'Role Permission Successfully Updated ', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (651, 'shipping_cost', 'Shipping Cost', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (652, 'in_word', 'In Word ', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (653, 'shipping_cost_report', 'Shipping Cost Report', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (654, 'cash_book_report', 'Cash Book Report', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (655, 'inventory_ledger_report', 'Inventory Ledger Report', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (656, 'trial_balance_with_opening_as_on', 'Trial Balance With Opening As On', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (657, 'type', 'Type', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (658, 'taka_only', 'Taka Only', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (659, 'item_description', 'Desc', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (660, 'sold_by', 'Sold By', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (661, 'user_wise_sales_report', 'User Wise Sales Report', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (662, 'user_name', 'User Name', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (663, 'total_sold', 'Total Sold', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (664, 'user_wise_sale_report', 'User Wise Sales Report', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (665, 'barcode_or_qrcode', 'Barcode/QR-code', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (666, 'category_csv_upload', 'Category Csv  Upload', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (667, 'unit_csv_upload', 'Unit Csv Upload', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (668, 'invoice_return_list', 'Sales Return list', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (669, 'invoice_return', 'Sales Return', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (670, 'tax_report', 'Tax Report', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (671, 'select_tax', 'Select Tax', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (672, 'hrm', 'HRM', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (673, 'employee', 'Employee', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (674, 'add_employee', 'Add Employee', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (675, 'manage_employee', 'Manage Employee', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (676, 'attendance', 'Attendance', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (677, 'add_attendance', 'Attendance', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (678, 'manage_attendance', 'Manage Attendance', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (679, 'payroll', 'Payroll', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (680, 'add_payroll', 'Payroll', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (681, 'manage_payroll', 'Manage Payroll', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (682, 'employee_type', 'Employee Type', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (683, 'employee_designation', 'Employee Designation', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (684, 'designation', 'Designation', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (685, 'add_designation', 'Add Designation', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (686, 'manage_designation', 'Manage Designation', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (687, 'designation_update_form', 'Designation Update form', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (688, 'picture', 'Picture', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (689, 'country', 'Country', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (690, 'blood_group', 'Blood Group', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (691, 'address_line_1', 'Address Line 1', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (692, 'address_line_2', 'Address Line 2', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (693, 'zip', 'Zip code', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (694, 'city', 'City', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (695, 'hour_rate_or_salary', 'Houre Rate/Salary', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (696, 'rate_type', 'Rate Type', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (697, 'hourly', 'Hourly', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (698, 'salary', 'Salary', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (699, 'employee_update', 'Employee Update', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (700, 'checkin', 'Check In', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (701, 'employee_name', 'Employee Name', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (702, 'checkout', 'Check Out', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (703, 'confirm_clock', 'Confirm Clock', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (704, 'stay', 'Stay Time', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (705, 'sign_in', 'Sign In', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (706, 'check_in', 'Check In', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (707, 'single_checkin', 'Single Check In', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (708, 'bulk_checkin', 'Bulk Check In', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (709, 'successfully_checkout', 'Successfully Checkout', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (710, 'attendance_report', 'Attendance Report', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (711, 'datewise_report', 'Date Wise Report', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (712, 'employee_wise_report', 'Employee Wise Report', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (713, 'date_in_time_report', 'Date In Time Report', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (714, 'request', 'Request', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (715, 'sign_out', 'Sign Out', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (716, 'work_hour', 'Work Hours', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (717, 's_time', 'Start Time', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (718, 'e_time', 'In Time', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (719, 'salary_benefits_type', 'Benefits Type', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (720, 'salary_benefits', 'Salary Benefits', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (721, 'beneficial_list', 'Benefit List', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (722, 'add_beneficial', 'Add Benefits', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (723, 'add_benefits', 'Add Benefits', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (724, 'benefits_list', 'Benefit List', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (725, 'benefit_type', 'Benefit Type', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (726, 'benefits', 'Benefit', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (727, 'manage_benefits', 'Manage Benefits', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (728, 'deduct', 'Deduct', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (729, 'add', 'Add', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (730, 'add_salary_setup', 'Add Salary Setup', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (731, 'manage_salary_setup', 'Manage Salary Setup', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (732, 'basic', 'Basic', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (733, 'salary_type', 'Salary Type', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (734, 'addition', 'Addition', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (735, 'gross_salary', 'Gross Salary', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (736, 'set', 'Set', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (737, 'salary_generate', 'Salary Generate', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (738, 'manage_salary_generate', 'Manage Salary Generate', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (739, 'sal_name', 'Salary Name', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (740, 'gdate', 'Generated Date', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (741, 'generate_by', 'Generated By', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (742, 'the_salary_of', 'The Salary of ', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (743, 'already_generated', ' Already Generated', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (744, 'salary_month', 'Salary Month', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (745, 'successfully_generated', 'Successfully Generated', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (746, 'salary_payment', 'Salary Payment', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (747, 'employee_salary_payment', 'Employee Salary Payment', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (748, 'total_salary', 'Total Salary', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (749, 'total_working_minutes', 'Total Working Hours', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (750, 'working_period', 'Working Period', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (751, 'paid_by', 'Paid By', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (752, 'pay_now', 'Pay Now ', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (753, 'confirm', 'Confirm', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (754, 'successfully_paid', 'Successfully Paid', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (755, 'add_incometax', 'Add Income Tax', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (756, 'setup_tax', 'Setup Tax', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (757, 'start_amount', 'Start Amount', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (758, 'end_amount', 'End Amount', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (759, 'tax_rate', 'Tax Rate', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (760, 'setup', 'Setup', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (761, 'manage_income_tax', 'Manage Income Tax', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (762, 'income_tax_updateform', 'Income tax Update form', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (763, 'positional_information', 'Positional Information', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (764, 'personal_information', 'Personal Information', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (765, 'timezone', 'Time Zone', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (766, 'sms', 'SMS', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (767, 'sms_configure', 'SMS Configure', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (768, 'url', 'URL', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (769, 'sender_id', 'Sender ID', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (770, 'api_key', 'Api Key', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (771, 'gui_pos', 'GUI POS', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (772, 'manage_service', 'Manage Service', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (773, 'service', 'Service', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (774, 'add_service', 'Add Service', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (775, 'service_edit', 'Service Edit', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (776, 'service_csv_upload', 'Service CSV Upload', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (777, 'service_name', 'Service Name', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (778, 'charge', 'Charge', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (779, 'service_invoice', 'Service Invoice', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (780, 'service_discount', 'Service Discount', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (781, 'hanging_over', 'ETD', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (782, 'service_details', 'Service Details', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (783, 'tax_settings', 'Tax Settings', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (784, 'default_value', 'Default Value', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (785, 'number_of_tax', 'Number of Tax', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (786, 'please_select_employee', 'Please Select Employee', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (787, 'manage_service_invoice', 'Manage Service Invoice', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (788, 'update_service_invoice', 'Update Service Invoice', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (789, 'customer_wise_tax_report', 'Customer Wise  Tax Report', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (790, 'service_id', 'Service Id', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (791, 'invoice_wise_tax_report', 'Invoice Wise Tax Report', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (792, 'reg_no', 'Reg No', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (793, 'update_now', 'Update Now', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (794, 'import', 'Import', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (795, 'add_expense_item', 'Add Expense Item', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (796, 'manage_expense_item', 'Manage Expense Item', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (797, 'add_expense', 'Add Expense', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (798, 'manage_expense', 'Manage Expense', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (799, 'expense_statement', 'Expense Statement', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (800, 'expense_type', 'Expense Type', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (801, 'expense_item_name', 'Expense Item Name', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (802, 'stock_purchase_price', 'Stock Purchase Price', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (803, 'purchase_price', 'Purchase Price', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (804, 'customer_advance', 'Customer Advance', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (805, 'advance_type', 'Advance Type', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (806, 'restore', 'Restore', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (807, 'supplier_advance', 'Supplier Advance', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (808, 'please_input_correct_invoice_no', 'Please Input Correct Invoice NO', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (809, 'backup', 'Back Up', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (810, 'app_setting', 'App Settings', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (811, 'local_server_url', 'Local Server Url', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (812, 'online_server_url', 'Online Server Url', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (813, 'connet_url', 'Connected Hotspot Ip/url', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (814, 'update_your_app_setting', 'Update Your App Setting', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (815, 'select_category', 'Select Category', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (816, 'mini_invoice', 'Mini Invoice', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (817, 'purchase_details', 'Purchase Details', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (818, 'disc', 'Dis %', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (819, 'serial', 'Serial', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (820, 'transaction_head', 'Transaction Head', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (821, 'transaction_type', 'Transaction Type', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (822, 'return_details', 'Return Details', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (823, 'return_to_customer', 'Return To Customer ', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (824, 'sales_and_purchase_report_summary', 'Sales And Purchase Report Summary', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (825, 'add_person_officeloan', 'Add Person (Office Loan)', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (826, 'add_loan_officeloan', 'Add Loan (Office Loan)', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (827, 'add_payment_officeloan', 'Add Payment (Office Loan)', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (828, 'manage_loan_officeloan', 'Manage Loan (Office Loan)', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (829, 'add_person_personalloan', 'Add Person (Personal Loan)', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (830, 'add_loan_personalloan', 'Add Loan (Personal Loan)', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (831, 'add_payment_personalloan', 'Add Payment (Personal Loan)', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (832, 'manage_loan_personalloan', 'Manage Loan (Personal)', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (833, 'hrm_management', 'Human Resource', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (834, 'cash_adjustment', 'Cash Adjustment', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (835, 'adjustment_type', 'Adjustment Type', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (836, 'change', 'Change', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (837, 'sale_by', 'Sale By', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (838, 'salary_date', 'Salary Date', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (839, 'earnings', 'Earnings', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (840, 'total_addition', 'Total Addition', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (841, 'total_deduction', 'Total Deduction', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (842, 'net_salary', 'Net Salary', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (843, 'ref_number', 'Reference Number', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (844, 'name_of_bank', 'Name Of Bank', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (845, 'salary_slip', 'Salary Slip', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (846, 'basic_salary', 'Basic Salary', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (847, 'return_from_customer', 'Return From Customer', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (848, 'quotation', 'Quotation', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (849, 'add_quotation', 'Add Quotation', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (850, 'manage_quotation', 'Manage Quotation', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (851, 'terms', 'Terms', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (852, 'send_to_customer', 'Sent To Customer', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (853, 'quotation_no', 'Quotation No', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (854, 'quotation_date', 'Quotation Date', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (855, 'total_service_tax', 'Total Service Tax', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (856, 'totalservicedicount', 'Total Service Discount', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (857, 'item_total', 'Item Total', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (858, 'service_total', 'Service Total', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (859, 'quot_description', 'Quotation Description', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (860, 'sub_total', 'Sub Total', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (861, 'mail_setting', 'Mail Setting', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (862, 'mail_configuration', 'Mail Configuration', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (863, 'mail', 'Mail', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (864, 'protocol', 'Protocol', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (865, 'smtp_host', 'SMTP Host', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (866, 'smtp_port', 'SMTP Port', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (867, 'sender_mail', 'Sender Mail', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (868, 'mail_type', 'Mail Type', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (869, 'html', 'HTML', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (870, 'text', 'TEXT', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (871, 'expiry_date', 'Expiry Date', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (872, 'api_secret', 'Api Secret', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (873, 'please_config_your_mail_setting', NULL, NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (874, 'quotation_successfully_added', 'Quotation Successfully Added', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (875, 'add_to_invoice', 'Add To Invoice', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (876, 'added_to_invoice', 'Added To Invoice', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (877, 'closing_balance', 'Closing Balance', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (878, 'contact', 'Contact', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (879, 'fax', 'Fax', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (880, 'state', 'State', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (881, 'discounts', 'Discount', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (882, 'address1', 'Address1', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (883, 'address2', 'Address2', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (884, 'receive', 'Receive', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (885, 'purchase_history', 'Purchase History', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (886, 'cash_payment', 'Cash Payment', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (887, 'bank_payment', 'Bank Payment', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (888, 'do_you_want_to_print', 'Do You Want to Print', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (889, 'yes', 'Yes', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (890, 'no', 'No', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (891, 'todays_sale', 'Today\'s Sales', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (892, 'or', 'OR', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (893, 'no_result_found', 'No Result Found', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (894, 'add_service_quotation', 'Add Service Quotation', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (895, 'add_to_invoice', 'Add To Invoice', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (896, 'item_quotation', 'Item Quotation', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (897, 'service_quotation', 'Service Quotation', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (898, 'return_from', 'Return Form', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (899, 'customer_return_list', 'Customer Return List', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (900, 'pdf', 'Pdf', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (901, 'note', 'Note', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (902, 'update_debit_voucher', 'Update Debit Voucher', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (903, 'update_credit_voucher', 'Update Credit voucher', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (904, 'on', 'On', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (905, '', '', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (906, 'total_expenses', 'Total Expense', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (907, 'already_exist', 'Already Exist', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (908, 'checked_out', 'Checked Out', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (909, 'update_salary_setup', 'Update Salary Setup', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (910, 'employee_signature', 'Employee Signature', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (911, 'payslip', 'Payslip', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (912, 'exsisting_role', 'Existing Role', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (913, 'filter', 'Filter', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (914, 'testinput', NULL, NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (915, 'update_quotation', 'Update Quotation', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (916, 'quotation_successfully_updated', 'Quotation Successfully Updated', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (917, 'successfully_approved', 'Successfully Approved', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (918, 'expiry', 'Expiry', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (919, 'purchase_report_shelf_wise', 'Warehouse Wise Report', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (920, 'sales_cheque_report', 'Manage Cheque', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (921, 'purchase_cheque_report', 'Manage Cheque', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (922, 'dispatch_outlet', 'Dispatch Sale', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (923, 'reacquisition', 'Requisition', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (924, 'warehouse', 'Warehouse', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (925, 'outlet', 'Outlet Warehouse', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (926, 'rqsn_form', 'Reacquisition Form', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (927, 'cw_purchase', 'CW to Purchase', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (928, 'approval', 'Approval', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (929, 'aprove_rqsn', ' Approve Reacquisition', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (930, 'aprove_rqsn_purchase', 'Purchase Reacquisition Approve', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (931, 'product_recieve', 'Product Receive', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (932, 'outlet_approve', 'Oultlet Recieve', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (933, 'aprove_chalan', 'Product Recieve', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (934, 'outlet_stock', 'Outlet Stock Report', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (935, 'purchase_order', 'Purchase PO', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (936, 'aprove_rqsn_outlet', 'Approve Reacquisition Outlet', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (937, 'rqsn_list', 'Stock Transferred Report (CW)', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (938, 'outlet_return_list', 'Outlet Return List', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (939, 'wastage_outlet_return_list', 'Wastage List From Outlet', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (940, 'rqsn_list_outlet', 'Stock Transferred Report (Outlet)', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (941, 'add_courier', 'Add Courier', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (942, 'add_branch', 'Add Branch', NULL);
INSERT INTO `language` (`id`, `phrase`, `english`, `bangla`) VALUES (943, 'courier', 'Courier', NULL);


#
# TABLE STRUCTURE FOR: lc_list
#

DROP TABLE IF EXISTS `lc_list`;

CREATE TABLE `lc_list` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `lc_no` varchar(255) CHARACTER SET utf8 NOT NULL,
  `purchase_id` varchar(255) CHARACTER SET utf8 NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `margin` decimal(10,2) NOT NULL DEFAULT 0.00,
  `margin_value` decimal(20,2) NOT NULL DEFAULT 0.00,
  `paid` decimal(20,2) NOT NULL DEFAULT 0.00,
  `due_amount` decimal(20,2) NOT NULL DEFAULT 0.00,
  `status` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf16;

INSERT INTO `lc_list` (`id`, `lc_no`, `purchase_id`, `amount`, `margin`, `margin_value`, `paid`, `due_amount`, `status`) VALUES (1, 'LC88902', '20211012093239', '4660.00', '0.00', '0.00', '0.00', '0.00', 1);
INSERT INTO `lc_list` (`id`, `lc_no`, `purchase_id`, `amount`, `margin`, `margin_value`, `paid`, `due_amount`, `status`) VALUES (2, '112345LC', '20211013080134', '665689.00', '10.00', '0.00', '0.00', '0.00', 3);
INSERT INTO `lc_list` (`id`, `lc_no`, `purchase_id`, `amount`, `margin`, `margin_value`, `paid`, `due_amount`, `status`) VALUES (3, 'LQ002', '20211013080437', '333359.00', '20.00', '266687.20', '66671.80', '0.00', 2);
INSERT INTO `lc_list` (`id`, `lc_no`, `purchase_id`, `amount`, `margin`, `margin_value`, `paid`, `due_amount`, `status`) VALUES (4, '123456', '20211017070903', '39200.00', '10.00', '0.00', '3920.00', '35280.00', 2);
INSERT INTO `lc_list` (`id`, `lc_no`, `purchase_id`, `amount`, `margin`, `margin_value`, `paid`, `due_amount`, `status`) VALUES (5, '00000', '20211023090222', '4000.00', '10.00', '400.00', '333359.00', '0.00', 3);


#
# TABLE STRUCTURE FOR: lc_payment
#

DROP TABLE IF EXISTS `lc_payment`;

CREATE TABLE `lc_payment` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `lc_id` int(20) NOT NULL,
  `pay_type` int(10) NOT NULL,
  `account` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `amount` decimal(20,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf16;

INSERT INTO `lc_payment` (`id`, `lc_id`, `pay_type`, `account`, `amount`) VALUES (7, 2, 1, '', '100.00');
INSERT INTO `lc_payment` (`id`, `lc_id`, `pay_type`, `account`, `amount`) VALUES (8, 3, 1, '', '1000.80');
INSERT INTO `lc_payment` (`id`, `lc_id`, `pay_type`, `account`, `amount`) VALUES (9, 3, 2, '', '65671.00');
INSERT INTO `lc_payment` (`id`, `lc_id`, `pay_type`, `account`, `amount`) VALUES (11, 5, 1, '', '3600.00');


#
# TABLE STRUCTURE FOR: module
#

DROP TABLE IF EXISTS `module`;

CREATE TABLE `module` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `description` text DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `directory` varchar(100) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;

INSERT INTO `module` (`id`, `name`, `description`, `image`, `directory`, `status`) VALUES (1, 'invoice', NULL, NULL, NULL, 1);
INSERT INTO `module` (`id`, `name`, `description`, `image`, `directory`, `status`) VALUES (2, 'customer', NULL, NULL, NULL, 1);
INSERT INTO `module` (`id`, `name`, `description`, `image`, `directory`, `status`) VALUES (3, 'product', NULL, NULL, NULL, 1);
INSERT INTO `module` (`id`, `name`, `description`, `image`, `directory`, `status`) VALUES (4, 'supplier', NULL, NULL, NULL, 1);
INSERT INTO `module` (`id`, `name`, `description`, `image`, `directory`, `status`) VALUES (5, 'purchase', NULL, NULL, NULL, 1);
INSERT INTO `module` (`id`, `name`, `description`, `image`, `directory`, `status`) VALUES (6, 'stock', NULL, NULL, NULL, 1);
INSERT INTO `module` (`id`, `name`, `description`, `image`, `directory`, `status`) VALUES (7, 'return', NULL, NULL, NULL, 1);
INSERT INTO `module` (`id`, `name`, `description`, `image`, `directory`, `status`) VALUES (8, 'report', NULL, NULL, NULL, 1);
INSERT INTO `module` (`id`, `name`, `description`, `image`, `directory`, `status`) VALUES (9, 'accounts', NULL, NULL, NULL, 1);
INSERT INTO `module` (`id`, `name`, `description`, `image`, `directory`, `status`) VALUES (10, 'bank', NULL, NULL, NULL, 1);
INSERT INTO `module` (`id`, `name`, `description`, `image`, `directory`, `status`) VALUES (11, 'tax', NULL, NULL, NULL, 1);
INSERT INTO `module` (`id`, `name`, `description`, `image`, `directory`, `status`) VALUES (12, 'hrm_management', NULL, NULL, NULL, 1);
INSERT INTO `module` (`id`, `name`, `description`, `image`, `directory`, `status`) VALUES (13, 'service', NULL, NULL, NULL, 1);
INSERT INTO `module` (`id`, `name`, `description`, `image`, `directory`, `status`) VALUES (14, 'commission', NULL, NULL, NULL, 1);
INSERT INTO `module` (`id`, `name`, `description`, `image`, `directory`, `status`) VALUES (15, 'setting', NULL, NULL, NULL, 1);
INSERT INTO `module` (`id`, `name`, `description`, `image`, `directory`, `status`) VALUES (16, 'quotation', NULL, NULL, NULL, 1);
INSERT INTO `module` (`id`, `name`, `description`, `image`, `directory`, `status`) VALUES (17, 'warehouse ', NULL, NULL, NULL, 1);
INSERT INTO `module` (`id`, `name`, `description`, `image`, `directory`, `status`) VALUES (18, 'reacquisition', NULL, NULL, NULL, 1);
INSERT INTO `module` (`id`, `name`, `description`, `image`, `directory`, `status`) VALUES (19, 'approval', NULL, NULL, NULL, 1);
INSERT INTO `module` (`id`, `name`, `description`, `image`, `directory`, `status`) VALUES (20, 'product_recieve', NULL, NULL, NULL, 1);
INSERT INTO `module` (`id`, `name`, `description`, `image`, `directory`, `status`) VALUES (21, 'outlet_stock', NULL, NULL, NULL, 1);
INSERT INTO `module` (`id`, `name`, `description`, `image`, `directory`, `status`) VALUES (22, 'courier', NULL, NULL, NULL, 1);


#
# TABLE STRUCTURE FOR: money_receipt
#

DROP TABLE IF EXISTS `money_receipt`;

CREATE TABLE `money_receipt` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `VNo` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `COAID` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `customer_id` varchar(255) DEFAULT NULL,
  `date` varchar(255) DEFAULT NULL,
  `remark` text DEFAULT NULL,
  `pay_type` varchar(255) DEFAULT NULL,
  `bank_name` varchar(255) DEFAULT NULL,
  `cheque_type` varchar(255) DEFAULT NULL,
  `cheque_no` varchar(255) DEFAULT NULL,
  `cheque_date` varchar(255) DEFAULT NULL,
  `bkash_id` varchar(255) DEFAULT NULL,
  `nagad_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: nagad_add
#

DROP TABLE IF EXISTS `nagad_add`;

CREATE TABLE `nagad_add` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `nagad_id` varchar(255) NOT NULL,
  `outlet_id` varchar(255) DEFAULT NULL,
  `ac_name` varchar(255) NOT NULL,
  `nagad_no` varchar(255) NOT NULL,
  `nagad_type` varchar(255) NOT NULL,
  `status` int(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `nagad_add` (`id`, `nagad_id`, `outlet_id`, `ac_name`, `nagad_no`, `nagad_type`, `status`) VALUES (1, 'SME535MYEY', 'HK7TGDT69VFMXB7', 'Messi', '01881239392', 'Agent', 1);


#
# TABLE STRUCTURE FOR: opening_inventory
#

DROP TABLE IF EXISTS `opening_inventory`;

CREATE TABLE `opening_inventory` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `product_id` varchar(255) NOT NULL,
  `stock_qty` int(50) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf16;

#
# TABLE STRUCTURE FOR: outlet_warehouse
#

DROP TABLE IF EXISTS `outlet_warehouse`;

CREATE TABLE `outlet_warehouse` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `outlet_id` varchar(1000) CHARACTER SET utf8 DEFAULT NULL,
  `warehouse_id` varchar(1000) CHARACTER SET utf8 DEFAULT NULL,
  `user_id` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `customer_id` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `outlet_name` varchar(1000) CHARACTER SET utf8 DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `outlet_warehouse` (`id`, `outlet_id`, `warehouse_id`, `user_id`, `customer_id`, `outlet_name`, `status`) VALUES (2, 'VC4C6BTBRLL57PF', 'HK7TGDT69VFMXB7', '3k5AW5cU8RAFqXC', 'Dell Arte Golpahar', 'Dell Arte Golpahar', 1);
INSERT INTO `outlet_warehouse` (`id`, `outlet_id`, `warehouse_id`, `user_id`, `customer_id`, `outlet_name`, `status`) VALUES (3, 'M8A64F8GG9QQL57', 'HK7TGDT69VFMXB7', 'ksTbB7kJWrAf5QU', 'Dhaka', 'Dhaka', 1);


#
# TABLE STRUCTURE FOR: paid_amount
#

DROP TABLE IF EXISTS `paid_amount`;

CREATE TABLE `paid_amount` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `invoice_id` varchar(255) CHARACTER SET utf8 NOT NULL,
  `pay_type` int(20) NOT NULL,
  `pay_subtype` int(50) DEFAULT NULL,
  `account` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `COAID` varchar(50) CHARACTER SET utf8 NOT NULL,
  `amount` varchar(255) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=103 DEFAULT CHARSET=utf16;

INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (1, '5141741827', 1, NULL, '', '', '4000');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (2, '9614898944', 1, NULL, '', '', '3000');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (3, '2869373261', 1, NULL, '', '', '20000');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (4, '2869373261', 3, NULL, '01864598947', '', '3200');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (5, '7776332558', 1, NULL, '', '', '2000');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (6, '7776332558', 2, NULL, NULL, '', '2640');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (7, '3768652251', 1, NULL, '', '', '464');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (8, '5679324697', 1, NULL, '', '', '12000');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (9, '3345641243', 1, NULL, '', '', '20000');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (10, '3345641243', 3, NULL, '01864598947', '', '2000');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (11, '8286382841', 1, NULL, '', '', '2000');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (12, '8286382841', 2, NULL, NULL, '', '320');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (13, '8568932142', 3, NULL, '01864598947', '', '232');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (14, '9894457289', 1, NULL, '', '', '464');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (15, '4137141578', 1, NULL, '', '', '4640');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (16, '1662823526', 4, NULL, 'Jabah bank', '', '464');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (17, '4553489624', 4, NULL, 'Jabah bank', '', '232');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (18, '4463318214', 1, NULL, '', '', '464');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (19, '7932922575', 6, NULL, 'Jabah bank', '', '464');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (20, '8927694685', 6, NULL, 'Jabah bank', '', '232');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (21, '3148932138', 6, NULL, 'Jabah bank', '', '232');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (22, '5824748236', 6, NULL, 'Jabah bank', '', '464');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (23, '2443669179', 4, NULL, 'Jabah bank', '', '464');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (24, '2428192199', 4, NULL, 'Jabah bank', '', '232');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (25, '7857945718', 3, NULL, '01864598947', '', '4640');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (26, '2173664314', 1, NULL, '', '', '464');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (27, '2395972251', 1, NULL, '', '', '232');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (28, '2329539632', 1, NULL, '', '', '232');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (29, '6466715362', 1, NULL, '', '', '232');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (30, '4531946681', 1, NULL, '', '', '22980');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (31, '7442826814', 1, NULL, '', '', '232');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (32, '6924364716', 1, NULL, '', '', '232');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (33, '3251467152', 1, NULL, '', '', '232');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (34, '2732116734', 1, NULL, '', '', '2320');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (35, '7317588883', 1, NULL, '', '', '2320');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (36, '9877281346', 1, NULL, '', '', '696');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (37, '7645196398', 1, NULL, '', '', '464');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (38, '5967357941', 1, NULL, '', '', '696');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (39, '4644194978', 1, NULL, '', '', '2320');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (40, '4834799688', 1, NULL, '', '', '4640');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (41, '5766322551', 1, NULL, '', '', '4640');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (42, '9433984166', 1, NULL, '', '', '4640');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (43, '4627239834', 1, NULL, '', '', '6960');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (44, '6686897851', 1, NULL, '', '', '2400');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (45, '2943195425', 1, NULL, '', '', '696');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (46, '1892375364', 1, NULL, '', '', '11600');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (47, '2962411299', 1, NULL, '', '', '6960');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (48, '2961432683', 1, NULL, '', '', '2500');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (49, '6413529188', 1, NULL, '', '', '15000');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (50, '1637486295', 1, NULL, '', '', '4640');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (54, '7458244584', 1, NULL, '', '1020101', '27840');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (55, '2928698325', 1, NULL, '', '1020101', '15000');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (56, '7363758319', 1, NULL, '', '1020101', '464');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (57, '1219511489', 1, NULL, '', '1020101', '464');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (58, '6159747935', 1, NULL, '', '1020101', '464');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (59, '8164926888', 1, NULL, '', '1020101', '5336');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (60, '8724494968', 1, NULL, '', '1020101', '35336');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (61, '7656339839', 1, NULL, '', '1020101', '15732');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (62, '1436841947', 1, NULL, '', '1020101', '2464');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (63, '4944234958', 1, NULL, '', '1020101', '7336');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (64, '1457426431', 1, NULL, '', '1020101', '30232');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (65, '9879511159', 1, NULL, '', '1020101', '465964');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (66, '3785187489', 1, NULL, '', '1020101', '31964');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (67, '4419649786', 1, NULL, '', '1020101', '46964');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (68, '9712198898', 1, NULL, '', '1020101', '232');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (69, '1752397973', 1, NULL, '', '1020101', '232');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (70, '6383717156', 1, NULL, '', '1020101', '30000');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (71, '6456176272', 1, NULL, '', '1020101', '0');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (72, '2619712578', 1, NULL, '', '1020101', '10000');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (73, '2619712578', 3, NULL, '01864598947', '102010305', '4000');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (74, '2619712578', 5, NULL, '01881239392', '102010402', '5000');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (75, '1737823266', 1, NULL, '', '1020101', '9500');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (77, '6244236511', 1, NULL, '', '1020101', '1000');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (78, '6244236511', 1, NULL, '', '1020101', '');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (79, '6244236511', 1, NULL, '', '1020101', '2600');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (80, '6244236511', 1, NULL, '', '1020101', '500');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (81, '6244236511', 3, NULL, '01992993949', '102010307', '100');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (82, '8732594423', 1, NULL, '', '1020101', '20000');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (83, '8732594423', 3, NULL, '01992993949', '102010307', '10000');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (84, '8732594423', 1, NULL, '', '1020101', '4000');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (85, '8732594423', 4, NULL, 'Jabah bank', '102010211', '4000');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (86, '3836394929', 1, NULL, '', '1020101', '6000');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (87, '3836394929', 1, NULL, '', '1020101', '3500');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (88, '1584819626', 1, NULL, '', '1020101', '7500');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (89, '6922388115', 1, NULL, '', '1020101', '7600');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (90, '4979218373', 1, NULL, '', '1020101', '3800');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (91, '9382931571', 1, NULL, '', '1020101', '3800');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (92, '5841248653', 1, NULL, '', '1020101', '4000');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (93, '2497129582', 1, NULL, '', '1020101', '3500');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (94, '2473414626', 1, NULL, '', '1020101', '7000');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (95, '3656251882', 1, NULL, '', '1020101', '7600');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (96, '2611189914', 4, NULL, 'Citi Bank', '102010212', '5000');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (97, '7236121756', 4, NULL, 'Jabah bank', '102010211', '3800');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (98, '9971273911', 1, NULL, '', '1020101', '200');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (99, '2592561728', 1, NULL, '', '1020101', '11400');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (100, '2525468222', 1, NULL, '', '1020101', '7600');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (101, '9262689575', 1, NULL, '', '1020101', '7600');
INSERT INTO `paid_amount` (`id`, `invoice_id`, `pay_type`, `pay_subtype`, `account`, `COAID`, `amount`) VALUES (102, '1742668722', 1, NULL, '', '1020101', '7600');


#
# TABLE STRUCTURE FOR: payroll_tax_setup
#

DROP TABLE IF EXISTS `payroll_tax_setup`;

CREATE TABLE `payroll_tax_setup` (
  `tax_setup_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `start_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `end_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `rate` decimal(12,2) NOT NULL DEFAULT 0.00,
  `status` varchar(30) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`tax_setup_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: person_information
#

DROP TABLE IF EXISTS `person_information`;

CREATE TABLE `person_information` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `person_id` varchar(50) NOT NULL,
  `person_name` varchar(50) NOT NULL,
  `person_phone` varchar(50) NOT NULL,
  `person_address` text NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: person_ledger
#

DROP TABLE IF EXISTS `person_ledger`;

CREATE TABLE `person_ledger` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `transaction_id` varchar(50) NOT NULL,
  `person_id` varchar(50) NOT NULL,
  `date` varchar(50) NOT NULL,
  `debit` decimal(12,2) NOT NULL DEFAULT 0.00,
  `credit` decimal(12,2) NOT NULL DEFAULT 0.00,
  `details` text NOT NULL,
  `status` int(11) NOT NULL COMMENT '1=no paid,2=paid',
  PRIMARY KEY (`id`),
  KEY `person_id` (`person_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: personal_loan
#

DROP TABLE IF EXISTS `personal_loan`;

CREATE TABLE `personal_loan` (
  `per_loan_id` int(11) NOT NULL AUTO_INCREMENT,
  `transaction_id` varchar(30) NOT NULL,
  `person_id` varchar(30) NOT NULL,
  `debit` decimal(12,2) DEFAULT 0.00,
  `credit` decimal(12,2) NOT NULL DEFAULT 0.00,
  `date` varchar(30) NOT NULL,
  `details` varchar(100) NOT NULL,
  `status` int(11) NOT NULL COMMENT '1=no paid,2=paid',
  PRIMARY KEY (`per_loan_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: pesonal_loan_information
#

DROP TABLE IF EXISTS `pesonal_loan_information`;

CREATE TABLE `pesonal_loan_information` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `person_id` varchar(50) NOT NULL,
  `person_name` varchar(50) NOT NULL,
  `person_phone` varchar(30) NOT NULL,
  `person_address` text NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `person_id` (`person_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: product_brand
#

DROP TABLE IF EXISTS `product_brand`;

CREATE TABLE `product_brand` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `brand_id` varchar(255) NOT NULL,
  `brand_name` varchar(255) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: product_category
#

DROP TABLE IF EXISTS `product_category`;

CREATE TABLE `product_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` varchar(255) DEFAULT NULL,
  `category_name` varchar(255) DEFAULT NULL,
  `status` int(11) NOT NULL,
  `finished_raw` int(10) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;

INSERT INTO `product_category` (`id`, `category_id`, `category_name`, `status`, `finished_raw`) VALUES (1, 'CFGEFA3B8GLX978', 'Furniture Collection', 1, 1);
INSERT INTO `product_category` (`id`, `category_id`, `category_name`, `status`, `finished_raw`) VALUES (2, 'KH3BYGZ4714OY6N', 'Accessories', 1, 1);
INSERT INTO `product_category` (`id`, `category_id`, `category_name`, `status`, `finished_raw`) VALUES (3, 'X9L2DYGNA1EE1M8', 'Home Accessoiries', 1, 1);
INSERT INTO `product_category` (`id`, `category_id`, `category_name`, `status`, `finished_raw`) VALUES (4, 'HWI6KO2LTTIKUWR', 'Furniture', 1, 1);
INSERT INTO `product_category` (`id`, `category_id`, `category_name`, `status`, `finished_raw`) VALUES (5, '3XMQJT1DO7OZGMK', 'Home Accessorries', 1, 1);
INSERT INTO `product_category` (`id`, `category_id`, `category_name`, `status`, `finished_raw`) VALUES (6, 'EYQFYAJF84CYYM6', 'Accessorries', 1, 1);
INSERT INTO `product_category` (`id`, `category_id`, `category_name`, `status`, `finished_raw`) VALUES (7, 'X1TCOB6VBQMSBQN', 'Accossories', 1, 1);
INSERT INTO `product_category` (`id`, `category_id`, `category_name`, `status`, `finished_raw`) VALUES (8, 'JIEWFZAGU6RND2M', 'Stationaries', 1, 1);
INSERT INTO `product_category` (`id`, `category_id`, `category_name`, `status`, `finished_raw`) VALUES (9, 'BYXXPKLEKOQU56W', 'Toy', 1, 1);
INSERT INTO `product_category` (`id`, `category_id`, `category_name`, `status`, `finished_raw`) VALUES (10, 'GO1L3M41R4M94TG', 'Medicacal Supply', 1, 1);
INSERT INTO `product_category` (`id`, `category_id`, `category_name`, `status`, `finished_raw`) VALUES (11, 'WHSW6YLHPHVJSSX', 'Painting', 1, 1);
INSERT INTO `product_category` (`id`, `category_id`, `category_name`, `status`, `finished_raw`) VALUES (12, 'US84TX7LNU2Q7NI', 'Lighting Fixture', 1, 1);
INSERT INTO `product_category` (`id`, `category_id`, `category_name`, `status`, `finished_raw`) VALUES (13, 'ST41OYX7NPKEPEA', 'Kitchen Amenities', 1, 1);
INSERT INTO `product_category` (`id`, `category_id`, `category_name`, `status`, `finished_raw`) VALUES (14, '7RTZ33784IXCKH3', 'Pillow Cover', 1, 1);
INSERT INTO `product_category` (`id`, `category_id`, `category_name`, `status`, `finished_raw`) VALUES (15, 'AE2JUAE3EMHXDFZ', 'Bulb', 1, 1);
INSERT INTO `product_category` (`id`, `category_id`, `category_name`, `status`, `finished_raw`) VALUES (16, 'KL9UBAV55SRYCR6', 'Home Accessories', 1, 1);
INSERT INTO `product_category` (`id`, `category_id`, `category_name`, `status`, `finished_raw`) VALUES (17, 'OSTJERWIEJ688N8', 'Outdoor Furniture', 1, 1);
INSERT INTO `product_category` (`id`, `category_id`, `category_name`, `status`, `finished_raw`) VALUES (18, '66EB5NNSHYIAT9G', 'Vase ', 1, 1);
INSERT INTO `product_category` (`id`, `category_id`, `category_name`, `status`, `finished_raw`) VALUES (19, 'FFJKHIL9IKEMLW1', 'Gift Item', 1, 1);
INSERT INTO `product_category` (`id`, `category_id`, `category_name`, `status`, `finished_raw`) VALUES (20, 'CG2VSEKGE8P56E4', 'Luxary Item', 1, 1);
INSERT INTO `product_category` (`id`, `category_id`, `category_name`, `status`, `finished_raw`) VALUES (21, 'PQHL68USTT4JINY', 'Luxary Collection', 1, 1);
INSERT INTO `product_category` (`id`, `category_id`, `category_name`, `status`, `finished_raw`) VALUES (22, 'RBRJ3R5RSA4U1ZK', 'SS Steel', 1, 2);


#
# TABLE STRUCTURE FOR: product_information
#

DROP TABLE IF EXISTS `product_information`;

CREATE TABLE `product_information` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` varchar(100) NOT NULL,
  `product_id_two` varchar(100) DEFAULT NULL,
  `category_id` varchar(255) DEFAULT NULL,
  `brand_id` varchar(255) DEFAULT NULL,
  `ptype_id` varchar(255) DEFAULT NULL,
  `product_name` varchar(255) NOT NULL,
  `finished_raw` int(10) NOT NULL,
  `price` float DEFAULT NULL,
  `product_code` varchar(255) DEFAULT NULL,
  `color` varchar(255) DEFAULT NULL,
  `size` varchar(255) DEFAULT NULL,
  `trxn_unit` varchar(50) DEFAULT NULL,
  `unit_multiplier` int(50) DEFAULT NULL,
  `re_order_level` int(255) NOT NULL,
  `unit` varchar(50) DEFAULT NULL,
  `tax` float DEFAULT NULL COMMENT 'Tax in %',
  `serial_no` varchar(200) DEFAULT NULL,
  `product_model` varchar(100) DEFAULT NULL,
  `product_details` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `status` int(2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `category_id` (`category_id`),
  KEY `product_id` (`product_id`),
  KEY `brand_id` (`brand_id`) USING BTREE,
  KEY `ptype_ID` (`ptype_id`),
  KEY `product_id_two` (`product_id_two`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: product_purchase
#

DROP TABLE IF EXISTS `product_purchase`;

CREATE TABLE `product_purchase` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `outlet_id` varchar(255) DEFAULT NULL,
  `purchase_id` bigint(20) NOT NULL,
  `chalan_no` varchar(100) NOT NULL,
  `supplier_id` bigint(20) NOT NULL,
  `base_total` varchar(255) DEFAULT NULL,
  `grand_total_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `paid_amount` decimal(10,2) DEFAULT 0.00,
  `due_amount` decimal(10,2) DEFAULT 0.00,
  `total_discount` decimal(10,2) DEFAULT NULL,
  `purchase_date` varchar(50) DEFAULT NULL,
  `purchase_details` text DEFAULT NULL,
  `status` int(2) NOT NULL,
  `isFinal` int(50) DEFAULT NULL,
  `bank_id` varchar(30) DEFAULT NULL,
  `cheque_no` varchar(255) DEFAULT NULL,
  `cheque_date` varchar(255) DEFAULT NULL,
  `payment_type` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `purchase_id` (`purchase_id`),
  KEY `supplier_id` (`supplier_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: product_purchase_details
#

DROP TABLE IF EXISTS `product_purchase_details`;

CREATE TABLE `product_purchase_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `purchase_detail_id` varchar(100) DEFAULT NULL,
  `purchase_id` bigint(20) DEFAULT NULL,
  `rqsn_details_id` varchar(50) DEFAULT NULL,
  `product_id` varchar(30) DEFAULT NULL,
  `sn` varchar(1000) DEFAULT NULL,
  `quantity` decimal(10,2) DEFAULT NULL,
  `qty` decimal(10,2) NOT NULL,
  `damaged_qty` decimal(10,2) NOT NULL DEFAULT 0.00,
  `lot_number` bigint(255) NOT NULL,
  `origin` varchar(100) NOT NULL,
  `warehouse` varchar(100) NOT NULL,
  `warrenty_date` varchar(50) NOT NULL,
  `expired_date` varchar(50) NOT NULL,
  `rate` decimal(10,2) DEFAULT NULL,
  `total_amount` decimal(10,2) DEFAULT NULL,
  `additional_price` decimal(20,2) NOT NULL DEFAULT 0.00,
  `discount` float DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `purchase_id` (`purchase_id`),
  KEY `product_id` (`product_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: product_return
#

DROP TABLE IF EXISTS `product_return`;

CREATE TABLE `product_return` (
  `outlet_id` varchar(255) DEFAULT NULL,
  `return_id` varchar(30) CHARACTER SET latin1 NOT NULL,
  `product_id` varchar(20) CHARACTER SET latin1 NOT NULL,
  `invoice_id` varchar(20) CHARACTER SET latin1 NOT NULL,
  `purchase_id` varchar(30) CHARACTER SET latin1 DEFAULT NULL,
  `date_purchase` varchar(20) CHARACTER SET latin1 NOT NULL,
  `date_return` varchar(30) CHARACTER SET latin1 NOT NULL,
  `byy_qty` float NOT NULL,
  `ret_qty` float DEFAULT NULL,
  `customer_id` varchar(20) CHARACTER SET latin1 NOT NULL,
  `supplier_id` varchar(30) CHARACTER SET latin1 NOT NULL,
  `product_rate` decimal(10,2) NOT NULL DEFAULT 0.00,
  `deduction` float DEFAULT NULL,
  `total_deduct` decimal(10,2) NOT NULL DEFAULT 0.00,
  `total_tax` decimal(10,2) NOT NULL DEFAULT 0.00,
  `total_ret_amount` decimal(10,2) DEFAULT 0.00,
  `net_total_amount` decimal(10,2) DEFAULT 0.00,
  `reason` text CHARACTER SET latin1 DEFAULT NULL,
  `usablity` int(5) DEFAULT NULL,
  KEY `product_id` (`product_id`),
  KEY `invoice_id` (`invoice_id`),
  KEY `purchase_id` (`purchase_id`),
  KEY `customer_id` (`customer_id`),
  KEY `supplier_id` (`supplier_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: product_service
#

DROP TABLE IF EXISTS `product_service`;

CREATE TABLE `product_service` (
  `service_id` int(11) NOT NULL AUTO_INCREMENT,
  `service_name` varchar(250) NOT NULL,
  `description` text NOT NULL,
  `charge` decimal(10,2) NOT NULL DEFAULT 0.00,
  PRIMARY KEY (`service_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: product_type
#

DROP TABLE IF EXISTS `product_type`;

CREATE TABLE `product_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ptype_id` varchar(255) NOT NULL,
  `ptype_name` varchar(255) NOT NULL,
  `status` int(11) NOT NULL,
  `finished_raw` int(10) DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=168 DEFAULT CHARSET=utf8;

INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (44, 'WN31EI62I7OYSI2', 'Dishes', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (45, 'BMQPA22KHGRIHSP', 'Ceiling Partition', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (46, '5R3YT1XX5K1QGCO', 'Mirror', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (47, 'S1DNYOHF72GV6PA', 'Ceramic', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (48, 'BGNOEXG6FN14ENA', 'Flower with Pot', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (49, '8DDA2F6DFURZJ4Q', 'Linen Cotton ', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (50, '4AJQ8PSKE18S8AZ', 'Solid Cotton ', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (51, 'JFBINUNC3425ZK1', 'Jamdani Print', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (52, 'KBBW7N7NJNHMM1C', 'Velvet', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (53, '5IMLNCJQXZTCSKY', 'Chumki ', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (54, '9YOHJVDASXJMKQ6', 'Chumki', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (55, '97QB266XBVN4HA3', 'Design Mirror', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (56, 'H6LB51UI9NZI52H', 'Painting', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (57, '3P6ACW9T3OIB24O', 'Lighting', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (58, 'N2X3NYIRVMLQNEW', 'chandelier', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (59, '2PM3WZ57KHDZ8BU', 'Ceiling Fan', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (60, '7HR6QJ8WNYIIGPN', 'LED Bulb', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (61, '7Y8AR4QTIK1S58C', 'Single Frame', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (62, 'R3I3AAG5KK9BL2S', 'Collage', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (63, 'EGYB2GYYA22U8G1', 'Bag', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (64, 'KJMI7CT5MNQEQ6J', 'Metal Deco', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (65, 'WCIDBGJDTVPBIHY', 'Swings', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (66, 'DMHYS9M2DGMOI5I', 'Gift Item', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (67, 'NMP7I4Q9XRN6LIE', 'Bed sheet Casual', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (68, 'CZI67IMOVO155GG', 'Bed sheet Baby', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (69, 'HYJODWVJ7GWZD1T', 'Tissue', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (70, '5D6DWCH9K3OQESF', 'Clock', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (71, '87EP9JRYHYJF1WG', 'Alarm Clock', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (72, 'WOB4K77JK8O3U6O', 'Furniture', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (73, 'P6VIG765P7X5PS1', 'Locker  Big', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (74, 'VJT8WZK3ITCT7TH', 'Locker Mini', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (75, 'JOPUKPSHWXPGIUK', 'Bin', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (76, 'K1X24UPH8LQ3Y3W', 'Showpiece', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (77, 'RR7WOO6HUDO1LQY', 'Kids Toys ', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (78, '3ODH42UQS42T5JR', 'Curtain', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (79, 'H7MSV1V2TVHCZIH', 'Stationaries', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (80, 'XVDVDMK2SV7SCLU', 'Home Appliance', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (81, 'ZMF61PYQXTGKS4N', 'Wall Paper', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (82, 'DC37VJ3LV77JLDM', 'Electrical', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (83, 'QECHXSVKCCFAQ3M', 'Toys', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (84, 'HGTIQ2LOQ42K4OR', 'Necessities', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (85, 'NCUK4KIKZSARG61', 'Metal', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (86, 'DIJM9XKL922XWXH', 'Bucket Stand', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (87, 'LXQFAB5P3ROL69C', 'Vintage', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (88, 'BE16RXCBLORGUB8', 'Motka', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (89, 'IX7URAGUNFVDNJ2', 'Silver Frame', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (90, 'VLLKY4VW35QGC1A', 'Wooden Frame', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (91, 'F7H63YSBTVLYBZV', 'Wood&Cane', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (92, 'O52OG6AJ31YBYOY', 'Rattan', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (93, 'G231LSSHMAWJGMU', 'Wood Log', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (94, 'LKMVKFARYVOO6WV', 'Cotton Fabrics', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (95, '9ICN9GSQ73DLSGC', 'Sticker', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (96, 'IW6RPAKML8E7PP8', 'Bamboo Folding', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (97, '5YI9SGSJ2YD4JNA', 'Rope', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (98, 'C6BPIFS7VARI1BZ', 'Fabric', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (99, '7EOJOOZYGHIAZ8V', 'Glass', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (100, 'O2QYFKIGOYKDC1U', 'Jute', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (101, 'FI15OEUNMTJ5F33', 'Party Item', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (102, 'GPJWY9NTYX7O95L', 'Charracter KR', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (103, 'T9X18GSIOL2UNXP', 'Cartoon', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (104, 'N8EVUJFX7KUR7U4', 'Twin Doll', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (105, 'Z6TD6RWYI1FKOF5', 'Hero Charracter', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (106, 'I37KQCH2ALNBNCI', 'Kids NC', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (107, 'F14DULXCONNH7JP', 'Gift', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (108, 'LIDT13N1P9SD9H5', 'Adult ', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (109, 'OOGODHPW91MHNWG', 'Oximeter', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (110, '495XDYBZ2MVAYN7', 'Davos', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (111, '2ENV7KA36V68BM8', 'KN95', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (112, 'L4ZDQJWUYMKNNTM', 'PAD', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (113, '4XJC7NEY1FOK64I', 'Kid\'s Toys', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (114, 'P6JGN9TBAFFB41D', 'Watch', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (115, 'KJ29PZPX83A9ZI3', 'Plastic Medicated', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (116, 'M5251D6911DJUIR', 'Abstract', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (117, 'FIY7YII964PNVQX', 'Nature', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (118, 'GDQSDJXNDFKY5KG', 'Banana Leaf', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (119, 'SWB9F8INCP5SA5B', 'Scinary', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (120, 'LALW96TDHCZPWYF', 'Flower', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (121, 'L4MMR76FWQ9Q5GA', 'Landscape', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (122, 'LC6N6K22LO6JTN4', 'WB', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (123, '6Z1NCDZTYO42GMM', 'Tarkish', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (124, '9R84HO1SJUF7V6R', 'Twin Domb', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (125, 'XP9ZV7J1ZGZXMSO', 'Turkish', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (126, 'FRJNLPKBZ1CCDMK', 'Spoon', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (127, '657Q65BPMR4G2QY', 'Cutter', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (128, 'H9SRDKC2WKMXLDU', 'Food Tong', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (129, '7VEGYE8WJMYSOV6', 'Grater', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (130, 'GFVBD2L4ELKJDPS', 'Peeler', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (131, 'IFRXINTEXC334JT', 'Slicer', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (132, 'I1QGYOMR2TWM94G', 'Scissor', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (133, '3MN7L3C844JVG4W', 'Server', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (134, '1KS17STRIOYLFRZ', 'Strainer', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (135, 'BNX3FAFKF77B7OK', 'ACRYLIC DISHES', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (136, 'V31ZRJ4F8BSTVSI', 'Wall Mini Vase', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (137, 'I4JO5GEUBERISCP', 'Vase Big', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (138, '37R5H2B3TXJFDOA', 'Table Clock', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (139, '3OD5G3ZQD3SUJ75', 'Fabrique', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (140, '8CZ7G2IY81L2V62', 'Backyard', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (141, 'FGXPQGO3T1QRW98', 'Oval Shap', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (142, 'M1Z3H13Y5MAKRKJ', 'Seafood', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (143, 'HAC7P7WGKVVT2QD', 'Show Piece', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (144, '5X6KH5CCKQ3M2ST', 'Doll Set Open', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (145, 'JH9FDB8T6BLJ8DZ', 'Doll Set Closed', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (146, 'CDQ2CLW2VZQWRZO', 'Music ', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (147, 'B7Q7U7VKUZJKH65', 'Sitting', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (148, '4GZJVC1OBIW3MLY', 'Twel', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (149, 'K1UDL9T6LGDDWLS', 'Birthday Item', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (150, 'RWON2UY9FC54V4W', 'Photo Frame', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (151, 'AK8F8T7DEB6XAM9', 'Artifacial Leaf', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (152, '7UWSZ7BH66RTSZ8', 'Artifacial Flower', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (153, 'TANFAXGW24AFZSR', 'Artificial Flower Sticks', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (154, 'BKHG9OAZWPQPY12', 'Flowral', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (155, '7KETNRP5I4OXRH5', 'Black & White ', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (156, '5RJZC9UHCVEYSP3', 'Solid ', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (157, 'GNI2CEPNT7NO84V', ' MFG Rattant', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (158, '7DJKA6JW2OTFL61', ' MFG Metal', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (159, 'GLDMPDWLL9SMF77', 'Spring-Hook-Nut', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (160, 'K655L7CC2ZA56JW', 'MFG-Metal', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (161, 'U6CUQLH3Z9MO4RJ', ' Multy Circle', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (162, 'JJB12WSZ57GGWOC', 'Circle & Clock', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (163, 'T2FNFVECCDZYWQ7', 'Multi-Circle', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (164, 'BQACATH5IDEEMS9', 'Multi-Frame', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (165, 'EU6M29WMGI166RU', 'Colage ', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (166, 'IKXDM7VHJTFX5D7', 'Multi Dimentional', 1, 1);
INSERT INTO `product_type` (`id`, `ptype_id`, `ptype_name`, `status`, `finished_raw`) VALUES (167, 'VE7OG5OLDANY3J9', 'Hahaha', 1, 3);


#
# TABLE STRUCTURE FOR: production
#

DROP TABLE IF EXISTS `production`;

CREATE TABLE `production` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `pro_id` varchar(255) DEFAULT NULL,
  `base_number` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `date` varchar(255) DEFAULT NULL,
  `remark` text DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `production` (`id`, `pro_id`, `base_number`, `total`, `date`, `remark`, `status`) VALUES (3, '1574308896', 'PR-20211130153103', '336666.50', '2021-11-30', 'Production Goods', 1);


#
# TABLE STRUCTURE FOR: production_goods
#

DROP TABLE IF EXISTS `production_goods`;

CREATE TABLE `production_goods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pro_id` varchar(255) DEFAULT NULL,
  `production_goods_id` varchar(255) DEFAULT NULL,
  `product_id` varchar(255) DEFAULT NULL,
  `quantity` varchar(255) DEFAULT NULL,
  `price` varchar(255) DEFAULT NULL,
  `per_unit_cost` decimal(50,2) DEFAULT NULL,
  `transfer_cost` decimal(50,2) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO `production_goods` (`id`, `pro_id`, `production_goods_id`, `product_id`, `quantity`, `price`, `per_unit_cost`, `transfer_cost`, `status`) VALUES (4, '1574308896', '2018532387', '2462851536', '50', '336666.50', '6740.83', '7000.00', 1);


#
# TABLE STRUCTURE FOR: production_mix
#

DROP TABLE IF EXISTS `production_mix`;

CREATE TABLE `production_mix` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `production_id` varchar(255) DEFAULT NULL,
  `product_id` varchar(255) DEFAULT NULL,
  `total` decimal(20,2) NOT NULL,
  `grand_total` decimal(20,2) NOT NULL,
  `date` varchar(255) DEFAULT NULL,
  `additional_charge` decimal(50,2) NOT NULL DEFAULT 0.00,
  `labour_charge` decimal(50,2) NOT NULL DEFAULT 0.00,
  `remark` text DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `production_mix` (`id`, `production_id`, `product_id`, `total`, `grand_total`, `date`, `additional_charge`, `labour_charge`, `remark`, `status`) VALUES (3, '437153719', '2462851536', '6250.00', '6733.33', '2021-11-29', '300.00', '100.00', 'Product Mix', 1);


#
# TABLE STRUCTURE FOR: production_mix_details
#

DROP TABLE IF EXISTS `production_mix_details`;

CREATE TABLE `production_mix_details` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `production_detail_id` varchar(255) NOT NULL,
  `production_id` varchar(255) NOT NULL,
  `item_id` varchar(255) NOT NULL,
  `quantity` int(255) NOT NULL,
  `rate` decimal(20,2) NOT NULL,
  `unit` varchar(244) NOT NULL,
  `finished_raw` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;

INSERT INTO `production_mix_details` (`id`, `production_detail_id`, `production_id`, `item_id`, `quantity`, `rate`, `unit`, `finished_raw`, `status`) VALUES (22, '514108999', '437153719', '74144469', 20, '4000.00', 'Pcs', 0, 1);
INSERT INTO `production_mix_details` (`id`, `production_detail_id`, `production_id`, `item_id`, `quantity`, `rate`, `unit`, `finished_raw`, `status`) VALUES (23, '1740554471', '437153719', '76712517', 15, '2250.00', 'Pcs', 0, 1);
INSERT INTO `production_mix_details` (`id`, `production_detail_id`, `production_id`, `item_id`, `quantity`, `rate`, `unit`, `finished_raw`, `status`) VALUES (24, '1917621480', '437153719', '12312312', 50, '83.33', 'Pcs', 0, 1);


#
# TABLE STRUCTURE FOR: purchase_payment
#

DROP TABLE IF EXISTS `purchase_payment`;

CREATE TABLE `purchase_payment` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `purchase_id` varchar(255) NOT NULL,
  `pay_type` int(20) NOT NULL,
  `pay_subtype` int(50) DEFAULT NULL,
  `account` varchar(255) DEFAULT NULL,
  `amount` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=utf16;

INSERT INTO `purchase_payment` (`id`, `purchase_id`, `pay_type`, `pay_subtype`, `account`, `amount`) VALUES (8, '20210925091239', 1, NULL, '', '140000');
INSERT INTO `purchase_payment` (`id`, `purchase_id`, `pay_type`, `pay_subtype`, `account`, `amount`) VALUES (9, '20210925091239', 3, NULL, '01864598947', '100000');
INSERT INTO `purchase_payment` (`id`, `purchase_id`, `pay_type`, `pay_subtype`, `account`, `amount`) VALUES (10, '20210925091239', 5, NULL, '01881239392', '4600');
INSERT INTO `purchase_payment` (`id`, `purchase_id`, `pay_type`, `pay_subtype`, `account`, `amount`) VALUES (11, '20210925092125', 1, NULL, '', '400');
INSERT INTO `purchase_payment` (`id`, `purchase_id`, `pay_type`, `pay_subtype`, `account`, `amount`) VALUES (12, '20210925092927', 1, NULL, '', '300');
INSERT INTO `purchase_payment` (`id`, `purchase_id`, `pay_type`, `pay_subtype`, `account`, `amount`) VALUES (13, '20210925093937', 1, NULL, '', '');
INSERT INTO `purchase_payment` (`id`, `purchase_id`, `pay_type`, `pay_subtype`, `account`, `amount`) VALUES (14, '20210925105600', 1, NULL, '', '400');
INSERT INTO `purchase_payment` (`id`, `purchase_id`, `pay_type`, `pay_subtype`, `account`, `amount`) VALUES (15, '20210925110731', 1, NULL, '', '100');
INSERT INTO `purchase_payment` (`id`, `purchase_id`, `pay_type`, `pay_subtype`, `account`, `amount`) VALUES (16, '20210925112405', 1, NULL, '', '1000');
INSERT INTO `purchase_payment` (`id`, `purchase_id`, `pay_type`, `pay_subtype`, `account`, `amount`) VALUES (17, '20210925112405', 3, NULL, '01864598947', '500');
INSERT INTO `purchase_payment` (`id`, `purchase_id`, `pay_type`, `pay_subtype`, `account`, `amount`) VALUES (18, '20210925112405', 5, NULL, '01881239392', '500');
INSERT INTO `purchase_payment` (`id`, `purchase_id`, `pay_type`, `pay_subtype`, `account`, `amount`) VALUES (19, '20210926095301', 1, NULL, '', '15000');
INSERT INTO `purchase_payment` (`id`, `purchase_id`, `pay_type`, `pay_subtype`, `account`, `amount`) VALUES (20, '20210926095301', 3, NULL, '01864598947', '5000');
INSERT INTO `purchase_payment` (`id`, `purchase_id`, `pay_type`, `pay_subtype`, `account`, `amount`) VALUES (21, '864812874', 1, NULL, '', '10000');
INSERT INTO `purchase_payment` (`id`, `purchase_id`, `pay_type`, `pay_subtype`, `account`, `amount`) VALUES (22, '864812874', 3, NULL, '01864598947', '5000');
INSERT INTO `purchase_payment` (`id`, `purchase_id`, `pay_type`, `pay_subtype`, `account`, `amount`) VALUES (23, '864812874', 5, NULL, '01881239392', '5000');
INSERT INTO `purchase_payment` (`id`, `purchase_id`, `pay_type`, `pay_subtype`, `account`, `amount`) VALUES (24, '1479152285', 1, NULL, '', '10000');
INSERT INTO `purchase_payment` (`id`, `purchase_id`, `pay_type`, `pay_subtype`, `account`, `amount`) VALUES (25, '1479152285', 3, NULL, '01864598947', '5000');
INSERT INTO `purchase_payment` (`id`, `purchase_id`, `pay_type`, `pay_subtype`, `account`, `amount`) VALUES (26, '1479152285', 5, NULL, '01881239392', '5000');
INSERT INTO `purchase_payment` (`id`, `purchase_id`, `pay_type`, `pay_subtype`, `account`, `amount`) VALUES (27, '2094486955', 1, NULL, '', '20000');
INSERT INTO `purchase_payment` (`id`, `purchase_id`, `pay_type`, `pay_subtype`, `account`, `amount`) VALUES (28, '20210927095731', 1, NULL, '', '2000000');
INSERT INTO `purchase_payment` (`id`, `purchase_id`, `pay_type`, `pay_subtype`, `account`, `amount`) VALUES (29, '20210927095731', 3, NULL, '01864598947', '2000000');
INSERT INTO `purchase_payment` (`id`, `purchase_id`, `pay_type`, `pay_subtype`, `account`, `amount`) VALUES (30, '60704287', 1, NULL, '', '10000');
INSERT INTO `purchase_payment` (`id`, `purchase_id`, `pay_type`, `pay_subtype`, `account`, `amount`) VALUES (31, '60704287', 3, NULL, '01864598947', '5000');
INSERT INTO `purchase_payment` (`id`, `purchase_id`, `pay_type`, `pay_subtype`, `account`, `amount`) VALUES (32, '60704287', 5, NULL, '01881239392', '5000');
INSERT INTO `purchase_payment` (`id`, `purchase_id`, `pay_type`, `pay_subtype`, `account`, `amount`) VALUES (33, '20210928072809', 1, NULL, '', '220000');
INSERT INTO `purchase_payment` (`id`, `purchase_id`, `pay_type`, `pay_subtype`, `account`, `amount`) VALUES (34, '20210928113447', 1, NULL, '', '200000');
INSERT INTO `purchase_payment` (`id`, `purchase_id`, `pay_type`, `pay_subtype`, `account`, `amount`) VALUES (35, '20210929051317', 1, NULL, '', '10000');
INSERT INTO `purchase_payment` (`id`, `purchase_id`, `pay_type`, `pay_subtype`, `account`, `amount`) VALUES (36, '20210929051317', 3, NULL, '01864598947', '10000');
INSERT INTO `purchase_payment` (`id`, `purchase_id`, `pay_type`, `pay_subtype`, `account`, `amount`) VALUES (37, '20210929052451', 1, NULL, '', '15000');
INSERT INTO `purchase_payment` (`id`, `purchase_id`, `pay_type`, `pay_subtype`, `account`, `amount`) VALUES (38, '20210929062823', 1, NULL, '', '10000');
INSERT INTO `purchase_payment` (`id`, `purchase_id`, `pay_type`, `pay_subtype`, `account`, `amount`) VALUES (39, '20210929062823', 3, NULL, '01864598947', '10000');
INSERT INTO `purchase_payment` (`id`, `purchase_id`, `pay_type`, `pay_subtype`, `account`, `amount`) VALUES (40, '20210929063434', 1, NULL, '', '10000');
INSERT INTO `purchase_payment` (`id`, `purchase_id`, `pay_type`, `pay_subtype`, `account`, `amount`) VALUES (41, '20210929072714', 1, NULL, '', '10000');
INSERT INTO `purchase_payment` (`id`, `purchase_id`, `pay_type`, `pay_subtype`, `account`, `amount`) VALUES (42, '20210929072714', 3, NULL, '01864598947', '6000');
INSERT INTO `purchase_payment` (`id`, `purchase_id`, `pay_type`, `pay_subtype`, `account`, `amount`) VALUES (43, '20211003111035', 1, NULL, '', '200');
INSERT INTO `purchase_payment` (`id`, `purchase_id`, `pay_type`, `pay_subtype`, `account`, `amount`) VALUES (44, '1397275146', 1, NULL, '', '20000');
INSERT INTO `purchase_payment` (`id`, `purchase_id`, `pay_type`, `pay_subtype`, `account`, `amount`) VALUES (45, '302963549', 1, NULL, '', '20000');
INSERT INTO `purchase_payment` (`id`, `purchase_id`, `pay_type`, `pay_subtype`, `account`, `amount`) VALUES (46, '20211005100427', 1, NULL, '', '1000');
INSERT INTO `purchase_payment` (`id`, `purchase_id`, `pay_type`, `pay_subtype`, `account`, `amount`) VALUES (47, '20211005100427', 4, NULL, 'Jabah bank', '1000');
INSERT INTO `purchase_payment` (`id`, `purchase_id`, `pay_type`, `pay_subtype`, `account`, `amount`) VALUES (48, '20211005100751', 1, NULL, '', '1000');
INSERT INTO `purchase_payment` (`id`, `purchase_id`, `pay_type`, `pay_subtype`, `account`, `amount`) VALUES (49, '20211005100751', 3, NULL, '01864598947', '1000');
INSERT INTO `purchase_payment` (`id`, `purchase_id`, `pay_type`, `pay_subtype`, `account`, `amount`) VALUES (50, '1027402127', 1, NULL, '', '1000');
INSERT INTO `purchase_payment` (`id`, `purchase_id`, `pay_type`, `pay_subtype`, `account`, `amount`) VALUES (51, '1027402127', 4, NULL, 'Jabah bank', '3000');
INSERT INTO `purchase_payment` (`id`, `purchase_id`, `pay_type`, `pay_subtype`, `account`, `amount`) VALUES (52, '20211010102650', 1, NULL, '', '200000');
INSERT INTO `purchase_payment` (`id`, `purchase_id`, `pay_type`, `pay_subtype`, `account`, `amount`) VALUES (53, '506220117', 1, NULL, '', '260000');
INSERT INTO `purchase_payment` (`id`, `purchase_id`, `pay_type`, `pay_subtype`, `account`, `amount`) VALUES (54, '506220117', 1, NULL, '', '250000');
INSERT INTO `purchase_payment` (`id`, `purchase_id`, `pay_type`, `pay_subtype`, `account`, `amount`) VALUES (55, '20211023061450', 1, NULL, '', '20000');
INSERT INTO `purchase_payment` (`id`, `purchase_id`, `pay_type`, `pay_subtype`, `account`, `amount`) VALUES (56, '20211024050228', 1, NULL, '', '75000');
INSERT INTO `purchase_payment` (`id`, `purchase_id`, `pay_type`, `pay_subtype`, `account`, `amount`) VALUES (57, '20211024050340', 1, NULL, '', '210000');
INSERT INTO `purchase_payment` (`id`, `purchase_id`, `pay_type`, `pay_subtype`, `account`, `amount`) VALUES (58, '20211024060556', 1, NULL, '', '60000');
INSERT INTO `purchase_payment` (`id`, `purchase_id`, `pay_type`, `pay_subtype`, `account`, `amount`) VALUES (59, '519522793', 1, NULL, '', '61180');
INSERT INTO `purchase_payment` (`id`, `purchase_id`, `pay_type`, `pay_subtype`, `account`, `amount`) VALUES (60, '20211101123805', 1, NULL, '', '0');
INSERT INTO `purchase_payment` (`id`, `purchase_id`, `pay_type`, `pay_subtype`, `account`, `amount`) VALUES (61, '20211102073033', 1, NULL, '', '52500');
INSERT INTO `purchase_payment` (`id`, `purchase_id`, `pay_type`, `pay_subtype`, `account`, `amount`) VALUES (62, '20211102073115', 1, NULL, '', '79800');
INSERT INTO `purchase_payment` (`id`, `purchase_id`, `pay_type`, `pay_subtype`, `account`, `amount`) VALUES (63, '349893944', 1, NULL, '', '0');
INSERT INTO `purchase_payment` (`id`, `purchase_id`, `pay_type`, `pay_subtype`, `account`, `amount`) VALUES (64, '80244249', 1, NULL, '', '3500');
INSERT INTO `purchase_payment` (`id`, `purchase_id`, `pay_type`, `pay_subtype`, `account`, `amount`) VALUES (65, '20211115092743', 1, NULL, '', '266000.00');
INSERT INTO `purchase_payment` (`id`, `purchase_id`, `pay_type`, `pay_subtype`, `account`, `amount`) VALUES (66, '20211121085437', 4, NULL, 'Citi Bank', '15000');
INSERT INTO `purchase_payment` (`id`, `purchase_id`, `pay_type`, `pay_subtype`, `account`, `amount`) VALUES (67, '20211121085534', 1, NULL, '', '20000');
INSERT INTO `purchase_payment` (`id`, `purchase_id`, `pay_type`, `pay_subtype`, `account`, `amount`) VALUES (68, '20211123101706', 1, NULL, '', '20000');


#
# TABLE STRUCTURE FOR: quot_products_used
#

DROP TABLE IF EXISTS `quot_products_used`;

CREATE TABLE `quot_products_used` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quot_id` varchar(100) NOT NULL,
  `product_id` varchar(100) NOT NULL,
  `serial_no` varchar(30) DEFAULT NULL,
  `description` varchar(250) DEFAULT NULL,
  `used_qty` decimal(10,2) DEFAULT NULL,
  `rate` decimal(10,2) DEFAULT NULL,
  `supplier_rate` float DEFAULT NULL,
  `total_price` decimal(12,2) DEFAULT NULL,
  `discount` decimal(10,2) DEFAULT NULL,
  `discount_per` varchar(15) DEFAULT NULL,
  `tax` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  KEY `quot_id` (`quot_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: quotation
#

DROP TABLE IF EXISTS `quotation`;

CREATE TABLE `quotation` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `quotation_id` varchar(30) NOT NULL,
  `quot_description` text NOT NULL,
  `customer_id` varchar(30) NOT NULL,
  `quotdate` date NOT NULL,
  `expire_date` date DEFAULT NULL,
  `item_total_amount` decimal(12,2) NOT NULL,
  `item_total_dicount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `item_total_tax` decimal(10,2) NOT NULL DEFAULT 0.00,
  `service_total_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `service_total_discount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `service_total_tax` decimal(10,2) NOT NULL DEFAULT 0.00,
  `quot_dis_item` decimal(10,2) NOT NULL DEFAULT 0.00,
  `quot_dis_service` decimal(10,2) NOT NULL DEFAULT 0.00,
  `quot_no` varchar(50) NOT NULL,
  `create_by` varchar(30) NOT NULL,
  `create_date` date NOT NULL,
  `update_by` varchar(30) DEFAULT NULL,
  `update_date` date DEFAULT NULL,
  `status` tinyint(4) NOT NULL,
  `cust_show` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `quot_no` (`quot_no`),
  KEY `quotation_id` (`quotation_id`),
  KEY `customer_id` (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: quotation_service_used
#

DROP TABLE IF EXISTS `quotation_service_used`;

CREATE TABLE `quotation_service_used` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quot_id` varchar(20) NOT NULL,
  `service_id` int(11) NOT NULL,
  `qty` decimal(10,2) NOT NULL DEFAULT 0.00,
  `charge` decimal(10,2) NOT NULL DEFAULT 0.00,
  `discount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `discount_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `tax` decimal(10,2) NOT NULL DEFAULT 0.00,
  `total` decimal(10,2) NOT NULL DEFAULT 0.00,
  PRIMARY KEY (`id`),
  KEY `quot_id` (`quot_id`),
  KEY `service_id` (`service_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: quotation_taxinfo
#

DROP TABLE IF EXISTS `quotation_taxinfo`;

CREATE TABLE `quotation_taxinfo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `customer_id` int(11) NOT NULL,
  `relation_id` varchar(30) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `customer_id` (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

#
# TABLE STRUCTURE FOR: receiever_info
#

DROP TABLE IF EXISTS `receiever_info`;

CREATE TABLE `receiever_info` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `receiver_name` varchar(255) CHARACTER SET utf8 NOT NULL,
  `receiver_number` varchar(255) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf16;

INSERT INTO `receiever_info` (`id`, `receiver_name`, `receiver_number`) VALUES (1, 'Hasan', '01829229932');
INSERT INTO `receiever_info` (`id`, `receiver_name`, `receiver_number`) VALUES (2, 'Robi', '00192930301');
INSERT INTO `receiever_info` (`id`, `receiver_name`, `receiver_number`) VALUES (3, 'Jon', '0122342233');
INSERT INTO `receiever_info` (`id`, `receiver_name`, `receiver_number`) VALUES (4, 'Shoni', '99020021');
INSERT INTO `receiever_info` (`id`, `receiver_name`, `receiver_number`) VALUES (5, 'Karim', '8829212992');
INSERT INTO `receiever_info` (`id`, `receiver_name`, `receiver_number`) VALUES (6, 'rahim', '0199292023');


#
# TABLE STRUCTURE FOR: role_permission
#

DROP TABLE IF EXISTS `role_permission`;

CREATE TABLE `role_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fk_module_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `create` tinyint(1) DEFAULT NULL,
  `read` tinyint(1) DEFAULT NULL,
  `update` tinyint(1) DEFAULT NULL,
  `delete` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_module_id` (`fk_module_id`),
  KEY `fk_user_id` (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5987 DEFAULT CHARSET=utf8;

INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2190, 1, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2191, 2, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2192, 3, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2193, 114, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2194, 25, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2195, 26, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2196, 27, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2197, 28, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2198, 111, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2199, 113, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2200, 21, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2201, 22, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2202, 23, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2203, 24, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2204, 30, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2205, 31, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2206, 32, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2207, 33, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2208, 112, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2209, 35, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2210, 36, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2211, 43, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2212, 37, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2213, 38, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2214, 39, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2215, 40, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2216, 46, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2217, 47, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2218, 48, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2219, 49, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2220, 50, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2221, 51, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2222, 52, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2223, 53, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2224, 54, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2225, 55, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2226, 97, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2227, 98, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2228, 99, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2229, 100, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2230, 101, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2231, 102, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2232, 122, 1, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2233, 4, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2234, 5, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2235, 6, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2236, 7, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2237, 8, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2238, 9, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2239, 10, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2240, 11, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2241, 12, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2242, 13, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2243, 14, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2244, 15, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2245, 16, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2246, 17, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2247, 18, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2248, 19, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2249, 56, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2250, 57, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2251, 58, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2252, 41, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2253, 103, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2254, 104, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2255, 109, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2256, 110, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2257, 60, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2258, 61, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2259, 62, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2260, 63, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2261, 64, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2262, 65, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2263, 66, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2264, 67, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2265, 68, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2266, 69, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2267, 70, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2268, 71, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2269, 72, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2270, 73, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2271, 74, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2272, 75, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2273, 76, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2274, 77, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2275, 78, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2276, 79, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2277, 80, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2278, 81, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2279, 82, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2280, 83, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2281, 84, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2282, 85, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2283, 86, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2284, 105, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2285, 106, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2286, 107, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2287, 108, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2288, 59, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2289, 87, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2290, 88, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2291, 89, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2292, 90, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2293, 91, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2294, 92, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2295, 93, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2296, 94, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2297, 95, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2298, 96, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2299, 115, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2300, 116, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2301, 117, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2302, 118, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2303, 119, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2304, 120, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (2305, 121, 1, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5851, 1, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5852, 2, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5853, 3, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5854, 114, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5855, 123, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5856, 125, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5857, 25, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5858, 26, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5859, 27, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5860, 28, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5861, 111, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5862, 113, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5863, 21, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5864, 22, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5865, 23, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5866, 24, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5867, 30, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5868, 31, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5869, 32, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5870, 33, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5871, 112, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5872, 35, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5873, 36, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5874, 124, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5875, 135, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5876, 43, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5877, 37, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5878, 38, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5879, 39, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5880, 40, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5881, 139, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5882, 140, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5883, 46, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5884, 47, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5885, 48, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5886, 49, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5887, 50, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5888, 51, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5889, 52, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5890, 53, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5891, 54, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5892, 55, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5893, 97, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5894, 98, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5895, 99, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5896, 100, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5897, 101, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5898, 102, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5899, 122, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5900, 4, 9, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5901, 5, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5902, 6, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5903, 7, 9, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5904, 8, 9, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5905, 9, 9, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5906, 10, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5907, 11, 9, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5908, 12, 9, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5909, 13, 9, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5910, 14, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5911, 15, 9, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5912, 16, 9, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5913, 17, 9, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5914, 18, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5915, 19, 9, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5916, 56, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5917, 57, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5918, 58, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5919, 41, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5920, 103, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5921, 104, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5922, 109, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5923, 110, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5924, 60, 9, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5925, 61, 9, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5926, 62, 9, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5927, 63, 9, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5928, 64, 9, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5929, 65, 9, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5930, 66, 9, 1, 1, 1, 1);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5931, 67, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5932, 68, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5933, 69, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5934, 70, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5935, 71, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5936, 72, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5937, 73, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5938, 74, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5939, 75, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5940, 76, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5941, 77, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5942, 78, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5943, 79, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5944, 80, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5945, 81, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5946, 82, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5947, 83, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5948, 84, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5949, 85, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5950, 86, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5951, 105, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5952, 106, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5953, 107, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5954, 108, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5955, 59, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5956, 87, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5957, 88, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5958, 89, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5959, 90, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5960, 91, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5961, 92, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5962, 93, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5963, 94, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5964, 95, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5965, 96, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5966, 115, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5967, 116, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5968, 117, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5969, 118, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5970, 119, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5971, 120, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5972, 121, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5973, 126, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5974, 127, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5975, 128, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5976, 129, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5977, 138, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5978, 141, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5979, 130, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5980, 131, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5981, 137, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5982, 132, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5983, 133, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5984, 136, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5985, 142, 9, 0, 0, 0, 0);
INSERT INTO `role_permission` (`id`, `fk_module_id`, `role_id`, `create`, `read`, `update`, `delete`) VALUES (5986, 143, 9, 0, 0, 0, 0);


#
# TABLE STRUCTURE FOR: rqsn
#

DROP TABLE IF EXISTS `rqsn`;

CREATE TABLE `rqsn` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `rqsn_id` varchar(255) CHARACTER SET utf8 NOT NULL,
  `from_id` varchar(255) CHARACTER SET utf8 NOT NULL,
  `to_id` varchar(255) CHARACTER SET utf8 NOT NULL,
  `purchase_order_no` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rate` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `supplier_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `total` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `discount` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `grand_total` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `paid_amount` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `due_amount` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date` varchar(255) CHARACTER SET utf8 NOT NULL,
  `details` text CHARACTER SET utf8 DEFAULT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `rqsn` (`id`, `rqsn_id`, `from_id`, `to_id`, `purchase_order_no`, `rate`, `supplier_id`, `total`, `discount`, `grand_total`, `paid_amount`, `due_amount`, `date`, `details`, `status`) VALUES (1, '572799408', 'VC4C6BTBRLL57PF', 'HK7TGDT69VFMXB7', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-10-13', 'Outlet Opening Inventory', 5);
INSERT INTO `rqsn` (`id`, `rqsn_id`, `from_id`, `to_id`, `purchase_order_no`, `rate`, `supplier_id`, `total`, `discount`, `grand_total`, `paid_amount`, `due_amount`, `date`, `details`, `status`) VALUES (2, '978242697', 'HK7TGDT69VFMXB7', '3', 'PO1000', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-10-19', 'Requisition', 4);
INSERT INTO `rqsn` (`id`, `rqsn_id`, `from_id`, `to_id`, `purchase_order_no`, `rate`, `supplier_id`, `total`, `discount`, `grand_total`, `paid_amount`, `due_amount`, `date`, `details`, `status`) VALUES (3, '673914628', 'HK7TGDT69VFMXB7', '3', 'PO1001', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-10-19', 'Requisition', 5);
INSERT INTO `rqsn` (`id`, `rqsn_id`, `from_id`, `to_id`, `purchase_order_no`, `rate`, `supplier_id`, `total`, `discount`, `grand_total`, `paid_amount`, `due_amount`, `date`, `details`, `status`) VALUES (4, '1948568323', 'VC4C6BTBRLL57PF', 'HK7TGDT69VFMXB7', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-11-01', 'Requisition', 4);
INSERT INTO `rqsn` (`id`, `rqsn_id`, `from_id`, `to_id`, `purchase_order_no`, `rate`, `supplier_id`, `total`, `discount`, `grand_total`, `paid_amount`, `due_amount`, `date`, `details`, `status`) VALUES (5, '743485596', 'HK7TGDT69VFMXB7', '3', 'PO1002', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-11-01', 'Requisition', 5);
INSERT INTO `rqsn` (`id`, `rqsn_id`, `from_id`, `to_id`, `purchase_order_no`, `rate`, `supplier_id`, `total`, `discount`, `grand_total`, `paid_amount`, `due_amount`, `date`, `details`, `status`) VALUES (6, '699943256', 'VC4C6BTBRLL57PF', 'HK7TGDT69VFMXB7', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-11-02', 'Requisition', 1);
INSERT INTO `rqsn` (`id`, `rqsn_id`, `from_id`, `to_id`, `purchase_order_no`, `rate`, `supplier_id`, `total`, `discount`, `grand_total`, `paid_amount`, `due_amount`, `date`, `details`, `status`) VALUES (7, '279807236', 'VC4C6BTBRLL57PF', 'HK7TGDT69VFMXB7', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-11-02', 'Outlet Opening Inventory', 1);
INSERT INTO `rqsn` (`id`, `rqsn_id`, `from_id`, `to_id`, `purchase_order_no`, `rate`, `supplier_id`, `total`, `discount`, `grand_total`, `paid_amount`, `due_amount`, `date`, `details`, `status`) VALUES (8, '1197042746', 'HK7TGDT69VFMXB7', '3', 'PO1003', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-11-02', 'Requisition', 4);
INSERT INTO `rqsn` (`id`, `rqsn_id`, `from_id`, `to_id`, `purchase_order_no`, `rate`, `supplier_id`, `total`, `discount`, `grand_total`, `paid_amount`, `due_amount`, `date`, `details`, `status`) VALUES (9, '1533402096', 'HK7TGDT69VFMXB7', '3', 'PO1004', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-11-02', 'Requisition', 5);
INSERT INTO `rqsn` (`id`, `rqsn_id`, `from_id`, `to_id`, `purchase_order_no`, `rate`, `supplier_id`, `total`, `discount`, `grand_total`, `paid_amount`, `due_amount`, `date`, `details`, `status`) VALUES (10, '1262212301', 'VC4C6BTBRLL57PF', 'HK7TGDT69VFMXB7', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-11-15', 'Requisition', 1);
INSERT INTO `rqsn` (`id`, `rqsn_id`, `from_id`, `to_id`, `purchase_order_no`, `rate`, `supplier_id`, `total`, `discount`, `grand_total`, `paid_amount`, `due_amount`, `date`, `details`, `status`) VALUES (11, '1113820829', 'HK7TGDT69VFMXB7', '3', 'PO1005', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-11-15', 'Requisition', 4);
INSERT INTO `rqsn` (`id`, `rqsn_id`, `from_id`, `to_id`, `purchase_order_no`, `rate`, `supplier_id`, `total`, `discount`, `grand_total`, `paid_amount`, `due_amount`, `date`, `details`, `status`) VALUES (12, '528139294', 'HK7TGDT69VFMXB7', '3', 'PO1006', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-11-15', 'Requisition', 5);
INSERT INTO `rqsn` (`id`, `rqsn_id`, `from_id`, `to_id`, `purchase_order_no`, `rate`, `supplier_id`, `total`, `discount`, `grand_total`, `paid_amount`, `due_amount`, `date`, `details`, `status`) VALUES (13, '471148933', 'HK7TGDT69VFMXB7', '3', 'PO1007', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2021-11-15', 'Requisition', 1);


#
# TABLE STRUCTURE FOR: rqsn_details
#

DROP TABLE IF EXISTS `rqsn_details`;

CREATE TABLE `rqsn_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rqsn_detail_id` varchar(255) CHARACTER SET utf8 NOT NULL,
  `rqsn_id` varchar(255) CHARACTER SET utf8 NOT NULL,
  `product_id` varchar(255) CHARACTER SET utf8 NOT NULL,
  `unit` varchar(255) CHARACTER SET utf8 NOT NULL,
  `quantity` varchar(255) CHARACTER SET utf8 NOT NULL,
  `a_qty` int(255) DEFAULT NULL,
  `rate` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `warrenty_date` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `expiry_date` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `stock` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `item_total` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  `isaprv` int(11) DEFAULT NULL,
  `isrcv` int(11) DEFAULT NULL,
  `iscw` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `rqsn_details` (`id`, `rqsn_detail_id`, `rqsn_id`, `product_id`, `unit`, `quantity`, `a_qty`, `rate`, `warrenty_date`, `expiry_date`, `stock`, `item_total`, `status`, `isaprv`, `isrcv`, `iscw`) VALUES (1, '1939886398', '572799408', '51445258', '', '1', 1, NULL, '', '', '', '', 3, 1, 1, 1);
INSERT INTO `rqsn_details` (`id`, `rqsn_detail_id`, `rqsn_id`, `product_id`, `unit`, `quantity`, `a_qty`, `rate`, `warrenty_date`, `expiry_date`, `stock`, `item_total`, `status`, `isaprv`, `isrcv`, `iscw`) VALUES (2, '1285882819', '572799408', '36836735', '', '23', 23, NULL, '', '', '', '', 3, 1, 1, 1);
INSERT INTO `rqsn_details` (`id`, `rqsn_detail_id`, `rqsn_id`, `product_id`, `unit`, `quantity`, `a_qty`, `rate`, `warrenty_date`, `expiry_date`, `stock`, `item_total`, `status`, `isaprv`, `isrcv`, `iscw`) VALUES (3, '1434688927', '572799408', '91827288', '', '11', 11, NULL, '', '', '', '', 3, 1, 1, 1);
INSERT INTO `rqsn_details` (`id`, `rqsn_detail_id`, `rqsn_id`, `product_id`, `unit`, `quantity`, `a_qty`, `rate`, `warrenty_date`, `expiry_date`, `stock`, `item_total`, `status`, `isaprv`, `isrcv`, `iscw`) VALUES (4, '176208569', '572799408', '71213289', '', '3', 3, NULL, '', '', '', '', 3, 1, 1, 1);
INSERT INTO `rqsn_details` (`id`, `rqsn_detail_id`, `rqsn_id`, `product_id`, `unit`, `quantity`, `a_qty`, `rate`, `warrenty_date`, `expiry_date`, `stock`, `item_total`, `status`, `isaprv`, `isrcv`, `iscw`) VALUES (5, '2010190665', '572799408', '95576353', '', '2', 2, NULL, '', '', '', '', 3, 1, 1, 1);
INSERT INTO `rqsn_details` (`id`, `rqsn_detail_id`, `rqsn_id`, `product_id`, `unit`, `quantity`, `a_qty`, `rate`, `warrenty_date`, `expiry_date`, `stock`, `item_total`, `status`, `isaprv`, `isrcv`, `iscw`) VALUES (6, 'PO1648315639', '978242697', '95576353', '', '20', NULL, NULL, '', '', '', '', 1, NULL, NULL, NULL);
INSERT INTO `rqsn_details` (`id`, `rqsn_detail_id`, `rqsn_id`, `product_id`, `unit`, `quantity`, `a_qty`, `rate`, `warrenty_date`, `expiry_date`, `stock`, `item_total`, `status`, `isaprv`, `isrcv`, `iscw`) VALUES (7, '', '', '95576353', '', '20', NULL, NULL, '', '', '', '', 1, NULL, NULL, NULL);
INSERT INTO `rqsn_details` (`id`, `rqsn_detail_id`, `rqsn_id`, `product_id`, `unit`, `quantity`, `a_qty`, `rate`, `warrenty_date`, `expiry_date`, `stock`, `item_total`, `status`, `isaprv`, `isrcv`, `iscw`) VALUES (8, 'PO428388351', '673914628', '95576353', '', '20', NULL, NULL, '', '', '', '', 1, NULL, NULL, NULL);
INSERT INTO `rqsn_details` (`id`, `rqsn_detail_id`, `rqsn_id`, `product_id`, `unit`, `quantity`, `a_qty`, `rate`, `warrenty_date`, `expiry_date`, `stock`, `item_total`, `status`, `isaprv`, `isrcv`, `iscw`) VALUES (9, '', '', '95576353', '', '20', NULL, NULL, '', '', '', '', 1, NULL, NULL, NULL);
INSERT INTO `rqsn_details` (`id`, `rqsn_detail_id`, `rqsn_id`, `product_id`, `unit`, `quantity`, `a_qty`, `rate`, `warrenty_date`, `expiry_date`, `stock`, `item_total`, `status`, `isaprv`, `isrcv`, `iscw`) VALUES (12, '', '', '8852793726', '', '23', NULL, NULL, '', '', '', '', 1, NULL, NULL, NULL);
INSERT INTO `rqsn_details` (`id`, `rqsn_detail_id`, `rqsn_id`, `product_id`, `unit`, `quantity`, `a_qty`, `rate`, `warrenty_date`, `expiry_date`, `stock`, `item_total`, `status`, `isaprv`, `isrcv`, `iscw`) VALUES (13, '345585557', '699943256', '2379173567', 'Pcs', '23', NULL, NULL, '', '', '', '', 1, NULL, NULL, NULL);
INSERT INTO `rqsn_details` (`id`, `rqsn_detail_id`, `rqsn_id`, `product_id`, `unit`, `quantity`, `a_qty`, `rate`, `warrenty_date`, `expiry_date`, `stock`, `item_total`, `status`, `isaprv`, `isrcv`, `iscw`) VALUES (14, '40355638', '699943256', '9845841873', 'Pcs', '12', NULL, NULL, '', '', '', '', 1, NULL, NULL, NULL);
INSERT INTO `rqsn_details` (`id`, `rqsn_detail_id`, `rqsn_id`, `product_id`, `unit`, `quantity`, `a_qty`, `rate`, `warrenty_date`, `expiry_date`, `stock`, `item_total`, `status`, `isaprv`, `isrcv`, `iscw`) VALUES (15, '509070762', '279807236', '2243598857', '', '34', -12, NULL, '', '', '', '', 3, 1, 1, 1);
INSERT INTO `rqsn_details` (`id`, `rqsn_detail_id`, `rqsn_id`, `product_id`, `unit`, `quantity`, `a_qty`, `rate`, `warrenty_date`, `expiry_date`, `stock`, `item_total`, `status`, `isaprv`, `isrcv`, `iscw`) VALUES (16, '691625079', '279807236', '1526761661', '', '3', 3, NULL, '', '', '', '', 3, 1, 1, 1);
INSERT INTO `rqsn_details` (`id`, `rqsn_detail_id`, `rqsn_id`, `product_id`, `unit`, `quantity`, `a_qty`, `rate`, `warrenty_date`, `expiry_date`, `stock`, `item_total`, `status`, `isaprv`, `isrcv`, `iscw`) VALUES (17, '1178696856', '279807236', '3587127326', '', '34', 34, NULL, '', '', '', '', 3, 1, 1, 1);
INSERT INTO `rqsn_details` (`id`, `rqsn_detail_id`, `rqsn_id`, `product_id`, `unit`, `quantity`, `a_qty`, `rate`, `warrenty_date`, `expiry_date`, `stock`, `item_total`, `status`, `isaprv`, `isrcv`, `iscw`) VALUES (18, '1024500531', '279807236', '8582662153', '', '12', 12, NULL, '', '', '', '', 3, 1, 1, 1);
INSERT INTO `rqsn_details` (`id`, `rqsn_detail_id`, `rqsn_id`, `product_id`, `unit`, `quantity`, `a_qty`, `rate`, `warrenty_date`, `expiry_date`, `stock`, `item_total`, `status`, `isaprv`, `isrcv`, `iscw`) VALUES (19, '1750319868', '279807236', '8852793726', '', '23', 0, NULL, '', '', '', '', 3, 1, 1, 1);
INSERT INTO `rqsn_details` (`id`, `rqsn_detail_id`, `rqsn_id`, `product_id`, `unit`, `quantity`, `a_qty`, `rate`, `warrenty_date`, `expiry_date`, `stock`, `item_total`, `status`, `isaprv`, `isrcv`, `iscw`) VALUES (20, '269438715', '279807236', '9135155155', '', '12', 12, NULL, '', '', '', '', 3, 1, 1, 1);
INSERT INTO `rqsn_details` (`id`, `rqsn_detail_id`, `rqsn_id`, `product_id`, `unit`, `quantity`, `a_qty`, `rate`, `warrenty_date`, `expiry_date`, `stock`, `item_total`, `status`, `isaprv`, `isrcv`, `iscw`) VALUES (21, '2009682144', '279807236', '9378591696', '', '11', 11, NULL, '', '', '', '', 3, 1, 1, 1);
INSERT INTO `rqsn_details` (`id`, `rqsn_detail_id`, `rqsn_id`, `product_id`, `unit`, `quantity`, `a_qty`, `rate`, `warrenty_date`, `expiry_date`, `stock`, `item_total`, `status`, `isaprv`, `isrcv`, `iscw`) VALUES (22, '1485935135', '279807236', '4835118435', '', '3', 3, NULL, '', '', '', '', 3, 1, 1, 1);
INSERT INTO `rqsn_details` (`id`, `rqsn_detail_id`, `rqsn_id`, `product_id`, `unit`, `quantity`, `a_qty`, `rate`, `warrenty_date`, `expiry_date`, `stock`, `item_total`, `status`, `isaprv`, `isrcv`, `iscw`) VALUES (23, '1902309338', '279807236', '6472139669', '', '22', 22, NULL, '', '', '', '', 3, 1, 1, 1);
INSERT INTO `rqsn_details` (`id`, `rqsn_detail_id`, `rqsn_id`, `product_id`, `unit`, `quantity`, `a_qty`, `rate`, `warrenty_date`, `expiry_date`, `stock`, `item_total`, `status`, `isaprv`, `isrcv`, `iscw`) VALUES (24, 'PO413559212', '1197042746', '7247547612', 'Pcs', '2', NULL, NULL, '', '', '', '', 1, NULL, NULL, NULL);
INSERT INTO `rqsn_details` (`id`, `rqsn_detail_id`, `rqsn_id`, `product_id`, `unit`, `quantity`, `a_qty`, `rate`, `warrenty_date`, `expiry_date`, `stock`, `item_total`, `status`, `isaprv`, `isrcv`, `iscw`) VALUES (25, '', '', '7247547612', '', '2', NULL, NULL, '', '', '', '', 1, NULL, NULL, NULL);
INSERT INTO `rqsn_details` (`id`, `rqsn_detail_id`, `rqsn_id`, `product_id`, `unit`, `quantity`, `a_qty`, `rate`, `warrenty_date`, `expiry_date`, `stock`, `item_total`, `status`, `isaprv`, `isrcv`, `iscw`) VALUES (27, '', '', '2767977638', '', '50', NULL, NULL, '', '', '', '', 1, NULL, NULL, NULL);
INSERT INTO `rqsn_details` (`id`, `rqsn_detail_id`, `rqsn_id`, `product_id`, `unit`, `quantity`, `a_qty`, `rate`, `warrenty_date`, `expiry_date`, `stock`, `item_total`, `status`, `isaprv`, `isrcv`, `iscw`) VALUES (28, '647552893', '1262212301', '8852793726', 'Pcs', '3', 3, NULL, '', '', '', '', 2, 1, NULL, 1);
INSERT INTO `rqsn_details` (`id`, `rqsn_detail_id`, `rqsn_id`, `product_id`, `unit`, `quantity`, `a_qty`, `rate`, `warrenty_date`, `expiry_date`, `stock`, `item_total`, `status`, `isaprv`, `isrcv`, `iscw`) VALUES (29, 'PO1409349560', '1113820829', '8852793726', 'Pcs', '100', NULL, NULL, '', '', '', '', 1, NULL, NULL, NULL);
INSERT INTO `rqsn_details` (`id`, `rqsn_detail_id`, `rqsn_id`, `product_id`, `unit`, `quantity`, `a_qty`, `rate`, `warrenty_date`, `expiry_date`, `stock`, `item_total`, `status`, `isaprv`, `isrcv`, `iscw`) VALUES (30, '', '', '8852793726', '', '100', NULL, NULL, '', '', '', '', 1, NULL, NULL, NULL);
INSERT INTO `rqsn_details` (`id`, `rqsn_detail_id`, `rqsn_id`, `product_id`, `unit`, `quantity`, `a_qty`, `rate`, `warrenty_date`, `expiry_date`, `stock`, `item_total`, `status`, `isaprv`, `isrcv`, `iscw`) VALUES (31, 'PO766803607', '528139294', '6127785281', 'Pkt', '100', NULL, NULL, '', '', '', '', 3, NULL, NULL, NULL);
INSERT INTO `rqsn_details` (`id`, `rqsn_detail_id`, `rqsn_id`, `product_id`, `unit`, `quantity`, `a_qty`, `rate`, `warrenty_date`, `expiry_date`, `stock`, `item_total`, `status`, `isaprv`, `isrcv`, `iscw`) VALUES (32, '', '', '6127785281', '', '100', NULL, NULL, '', '', '', '', 1, NULL, NULL, NULL);
INSERT INTO `rqsn_details` (`id`, `rqsn_detail_id`, `rqsn_id`, `product_id`, `unit`, `quantity`, `a_qty`, `rate`, `warrenty_date`, `expiry_date`, `stock`, `item_total`, `status`, `isaprv`, `isrcv`, `iscw`) VALUES (33, 'PO846739655', '471148933', '3917361722', 'pcs', '122', NULL, NULL, '', '', '', '', 1, NULL, NULL, NULL);


#
# TABLE STRUCTURE FOR: rqsn_return
#

DROP TABLE IF EXISTS `rqsn_return`;

CREATE TABLE `rqsn_return` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `return_id` varchar(255) DEFAULT NULL,
  `rqsn_id` varchar(255) DEFAULT NULL,
  `product_id` varchar(255) DEFAULT NULL,
  `from_id` varchar(255) DEFAULT NULL,
  `to_id` varchar(255) DEFAULT NULL,
  `ret_qty` varchar(155) DEFAULT NULL,
  `tr_qty` varchar(255) DEFAULT NULL,
  `date_rqsn` varchar(50) DEFAULT NULL,
  `date_return` varchar(50) DEFAULT NULL,
  `reason` text DEFAULT NULL,
  `usablity` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: salary_sheet_generate
#

DROP TABLE IF EXISTS `salary_sheet_generate`;

CREATE TABLE `salary_sheet_generate` (
  `ssg_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(30) CHARACTER SET latin1 DEFAULT NULL,
  `gdate` varchar(30) DEFAULT NULL,
  `start_date` varchar(30) CHARACTER SET latin1 NOT NULL,
  `end_date` varchar(30) CHARACTER SET latin1 NOT NULL,
  `generate_by` varchar(30) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`ssg_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: salary_type
#

DROP TABLE IF EXISTS `salary_type`;

CREATE TABLE `salary_type` (
  `salary_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `sal_name` varchar(100) NOT NULL,
  `salary_type` varchar(50) NOT NULL,
  `status` varchar(30) NOT NULL,
  PRIMARY KEY (`salary_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

INSERT INTO `salary_type` (`salary_type_id`, `sal_name`, `salary_type`, `status`) VALUES (4, 'House Rent', '1', '1');
INSERT INTO `salary_type` (`salary_type_id`, `sal_name`, `salary_type`, `status`) VALUES (5, 'Medical Allowance', '1', '1');
INSERT INTO `salary_type` (`salary_type_id`, `sal_name`, `salary_type`, `status`) VALUES (6, 'Transport Allowance', '1', '1');


#
# TABLE STRUCTURE FOR: sec_role
#

DROP TABLE IF EXISTS `sec_role`;

CREATE TABLE `sec_role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(100) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

INSERT INTO `sec_role` (`id`, `type`) VALUES (1, 'Super Admin');
INSERT INTO `sec_role` (`id`, `type`) VALUES (9, 'accounts');


#
# TABLE STRUCTURE FOR: sec_userrole
#

DROP TABLE IF EXISTS `sec_userrole`;

CREATE TABLE `sec_userrole` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `roleid` int(11) NOT NULL,
  `createby` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `createdate` datetime NOT NULL,
  UNIQUE KEY `ID` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `sec_userrole` (`id`, `user_id`, `roleid`, `createby`, `createdate`) VALUES (1, '2', 1, '2', '2020-10-30 08:52:32');
INSERT INTO `sec_userrole` (`id`, `user_id`, `roleid`, `createby`, `createdate`) VALUES (2, '2', 2, '2', '2020-10-30 12:33:52');
INSERT INTO `sec_userrole` (`id`, `user_id`, `roleid`, `createby`, `createdate`) VALUES (3, '2', 2, 'OpSoxJvBbbS8Rws', '2020-10-30 12:38:49');
INSERT INTO `sec_userrole` (`id`, `user_id`, `roleid`, `createby`, `createdate`) VALUES (4, 'tF2YChLBH86gHfG', 2, 'OpSoxJvBbbS8Rws', '2020-10-30 12:41:34');
INSERT INTO `sec_userrole` (`id`, `user_id`, `roleid`, `createby`, `createdate`) VALUES (5, 'lhnKdCdtVDMGqNr', 2, 'OpSoxJvBbbS8Rws', '2021-01-24 07:00:46');
INSERT INTO `sec_userrole` (`id`, `user_id`, `roleid`, `createby`, `createdate`) VALUES (6, 'lhnKdCdtVDMGqNr', 4, 'OpSoxJvBbbS8Rws', '2021-01-24 07:08:02');
INSERT INTO `sec_userrole` (`id`, `user_id`, `roleid`, `createby`, `createdate`) VALUES (7, 'ijpPELEg1KWywCs', 4, 'OpSoxJvBbbS8Rws', '2021-01-24 07:09:51');
INSERT INTO `sec_userrole` (`id`, `user_id`, `roleid`, `createby`, `createdate`) VALUES (8, 'ijpPELEg1KWywCs', 5, 'tF2YChLBH86gHfG', '2021-01-24 07:15:29');
INSERT INTO `sec_userrole` (`id`, `user_id`, `roleid`, `createby`, `createdate`) VALUES (9, 'tF2YChLBH86gHfG', 2, 'OpSoxJvBbbS8Rws', '2021-01-26 05:39:28');
INSERT INTO `sec_userrole` (`id`, `user_id`, `roleid`, `createby`, `createdate`) VALUES (10, 'tF2YChLBH86gHfG', 2, 'OpSoxJvBbbS8Rws', '2021-01-28 04:15:05');
INSERT INTO `sec_userrole` (`id`, `user_id`, `roleid`, `createby`, `createdate`) VALUES (11, 'ijpPELEg1KWywCs', 6, 'OpSoxJvBbbS8Rws', '2021-02-09 07:25:58');
INSERT INTO `sec_userrole` (`id`, `user_id`, `roleid`, `createby`, `createdate`) VALUES (12, 'V2DEJbIBFZq40dl', 6, 'OpSoxJvBbbS8Rws', '2021-02-09 07:27:25');
INSERT INTO `sec_userrole` (`id`, `user_id`, `roleid`, `createby`, `createdate`) VALUES (13, 'HLJq42qHAlAHg4T', 2, 'OpSoxJvBbbS8Rws', '2021-08-26 10:48:23');
INSERT INTO `sec_userrole` (`id`, `user_id`, `roleid`, `createby`, `createdate`) VALUES (14, '3k5AW5cU8RAFqXC', 8, 'OpSoxJvBbbS8Rws', '2021-09-08 11:16:42');
INSERT INTO `sec_userrole` (`id`, `user_id`, `roleid`, `createby`, `createdate`) VALUES (15, 'HLJq42qHAlAHg4T', 7, 'OpSoxJvBbbS8Rws', '2021-09-12 09:25:34');
INSERT INTO `sec_userrole` (`id`, `user_id`, `roleid`, `createby`, `createdate`) VALUES (16, 'ksTbB7kJWrAf5QU', 8, 'OpSoxJvBbbS8Rws', '2021-11-07 04:28:07');
INSERT INTO `sec_userrole` (`id`, `user_id`, `roleid`, `createby`, `createdate`) VALUES (17, 'KNmrMhXdbnd0erU', 9, 'OpSoxJvBbbS8Rws', '2021-12-07 04:39:37');


#
# TABLE STRUCTURE FOR: sent_sms
#

DROP TABLE IF EXISTS `sent_sms`;

CREATE TABLE `sent_sms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `from` varchar(255) DEFAULT NULL,
  `to` varchar(255) DEFAULT NULL,
  `message` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `sent_sms` (`id`, `from`, `to`, `message`) VALUES (1, '8809601000500', '01787281564', 'Sarwar Tester ...');


#
# TABLE STRUCTURE FOR: service_invoice
#

DROP TABLE IF EXISTS `service_invoice`;

CREATE TABLE `service_invoice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `voucher_no` varchar(30) NOT NULL,
  `date` date NOT NULL,
  `employee_id` varchar(100) DEFAULT NULL,
  `customer_id` varchar(30) NOT NULL,
  `total_amount` decimal(20,2) NOT NULL DEFAULT 0.00,
  `total_discount` decimal(20,2) NOT NULL DEFAULT 0.00,
  `invoice_discount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `total_tax` decimal(10,2) NOT NULL DEFAULT 0.00,
  `paid_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `due_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `shipping_cost` decimal(10,2) NOT NULL DEFAULT 0.00,
  `previous` decimal(10,2) NOT NULL DEFAULT 0.00,
  `paytype` int(11) DEFAULT NULL,
  `bank_id` varchar(255) DEFAULT NULL,
  `bkash_id` varchar(255) DEFAULT NULL,
  `details` varchar(250) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `customer_id` (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: service_invoice_details
#

DROP TABLE IF EXISTS `service_invoice_details`;

CREATE TABLE `service_invoice_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `service_id` int(11) NOT NULL,
  `service_inv_id` varchar(30) NOT NULL,
  `qty` decimal(10,2) NOT NULL DEFAULT 0.00,
  `charge` decimal(10,2) NOT NULL DEFAULT 0.00,
  `discount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `discount_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `total` decimal(10,2) NOT NULL DEFAULT 0.00,
  PRIMARY KEY (`id`),
  KEY `service_id` (`service_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: size_list
#

DROP TABLE IF EXISTS `size_list`;

CREATE TABLE `size_list` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `size_id` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `size_name` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `status` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=78 DEFAULT CHARSET=utf16;

INSERT INTO `size_list` (`id`, `size_id`, `size_name`, `status`) VALUES (1, '3Q2KOUV5U625TPM', '36\"', 1);
INSERT INTO `size_list` (`id`, `size_id`, `size_name`, `status`) VALUES (2, '6ZAZ98Q1B741UYP', '28', 1);
INSERT INTO `size_list` (`id`, `size_id`, `size_name`, `status`) VALUES (3, '9ZKZMVXPTK7JFE3', '16\"', 1);
INSERT INTO `size_list` (`id`, `size_id`, `size_name`, `status`) VALUES (4, 'T7R4KNLLDME1GWZ', '18', 1);
INSERT INTO `size_list` (`id`, `size_id`, `size_name`, `status`) VALUES (5, 'V41TMZOSAA25P1L', '10\"', 1);
INSERT INTO `size_list` (`id`, `size_id`, `size_name`, `status`) VALUES (6, 'DTA4T63BOI1GVJH', 'Same', 1);
INSERT INTO `size_list` (`id`, `size_id`, `size_name`, `status`) VALUES (7, '1O3XW1M1JYQ35JT', 'L', 1);
INSERT INTO `size_list` (`id`, `size_id`, `size_name`, `status`) VALUES (8, 'PSTEBYFSBFAB8T9', '7\'ft', 1);
INSERT INTO `size_list` (`id`, `size_id`, `size_name`, `status`) VALUES (9, '99GFBEPZ5RLI22N', '7\'ft', 1);
INSERT INTO `size_list` (`id`, `size_id`, `size_name`, `status`) VALUES (10, 'NX977VHZR61GQA9', '7\'ft', 1);
INSERT INTO `size_list` (`id`, `size_id`, `size_name`, `status`) VALUES (11, '7LO6VIOLRHFVWSK', '5X3', 1);
INSERT INTO `size_list` (`id`, `size_id`, `size_name`, `status`) VALUES (12, '72XHSCORN26C6BB', '56SFT', 1);
INSERT INTO `size_list` (`id`, `size_id`, `size_name`, `status`) VALUES (13, 'Q4KRGY3QETP7S2N', '57\"X60\"', 1);
INSERT INTO `size_list` (`id`, `size_id`, `size_name`, `status`) VALUES (14, 'DE7IOO4NJQOFA2D', '36\"X78\"', 1);
INSERT INTO `size_list` (`id`, `size_id`, `size_name`, `status`) VALUES (15, '2Q9EFD477P7L7ZG', 'G', 1);
INSERT INTO `size_list` (`id`, `size_id`, `size_name`, `status`) VALUES (16, 'ZOH2VNA4D2QMB68', 'B', 1);
INSERT INTO `size_list` (`id`, `size_id`, `size_name`, `status`) VALUES (17, 'F652AUEFDS9Q2H2', 'M', 1);
INSERT INTO `size_list` (`id`, `size_id`, `size_name`, `status`) VALUES (18, '41I4J69X6C13N2E', 'S', 1);
INSERT INTO `size_list` (`id`, `size_id`, `size_name`, `status`) VALUES (19, 'VWNGM68VZNCFKT1', 'Free', 1);
INSERT INTO `size_list` (`id`, `size_id`, `size_name`, `status`) VALUES (20, '1I7FK4QQNQBWT2Z', 'Kids', 1);
INSERT INTO `size_list` (`id`, `size_id`, `size_name`, `status`) VALUES (21, 'KXKT7TMAXT7W5MB', '35X35', 1);
INSERT INTO `size_list` (`id`, `size_id`, `size_name`, `status`) VALUES (22, '8GYT4QMSCYV7Z3S', '33X33', 1);
INSERT INTO `size_list` (`id`, `size_id`, `size_name`, `status`) VALUES (23, 'BP9BC1T15UNAGM8', '14X18', 1);
INSERT INTO `size_list` (`id`, `size_id`, `size_name`, `status`) VALUES (24, '9ATPP2QEJ6B3SZX', '40X40', 1);
INSERT INTO `size_list` (`id`, `size_id`, `size_name`, `status`) VALUES (25, 'S5FXWXMYAQUKXUX', '80X120', 1);
INSERT INTO `size_list` (`id`, `size_id`, `size_name`, `status`) VALUES (26, 'VCF6B5L23KJUCR1', '48X20  48X16', 1);
INSERT INTO `size_list` (`id`, `size_id`, `size_name`, `status`) VALUES (27, 'LSF5SN6CFHIJGP7', '33X19', 1);
INSERT INTO `size_list` (`id`, `size_id`, `size_name`, `status`) VALUES (28, '9OW8HF37GVYZ8OA', '58X78', 1);
INSERT INTO `size_list` (`id`, `size_id`, `size_name`, `status`) VALUES (29, 'MDZY9F3ZQ2FURM7', '14X35', 1);
INSERT INTO `size_list` (`id`, `size_id`, `size_name`, `status`) VALUES (30, '1PPRGOMUVYOWB8F', '55X45', 1);
INSERT INTO `size_list` (`id`, `size_id`, `size_name`, `status`) VALUES (31, 'V96M652G75YQ213', '18X43', 1);
INSERT INTO `size_list` (`id`, `size_id`, `size_name`, `status`) VALUES (32, 'PSVI3MLTLU3PUHJ', '34X20', 1);
INSERT INTO `size_list` (`id`, `size_id`, `size_name`, `status`) VALUES (33, 'DXNGQRAW9W2SQSY', '14x39', 1);
INSERT INTO `size_list` (`id`, `size_id`, `size_name`, `status`) VALUES (34, 'XB9IZU1JV1F1XAH', 'Big', 1);
INSERT INTO `size_list` (`id`, `size_id`, `size_name`, `status`) VALUES (35, 'FO52958QOOF3M1L', 'Small', 1);
INSERT INTO `size_list` (`id`, `size_id`, `size_name`, `status`) VALUES (36, 'YRPYH3AXAACZTG1', 'Long', 1);
INSERT INTO `size_list` (`id`, `size_id`, `size_name`, `status`) VALUES (37, 'XQFKVPWWLGIDPWY', '15\" Long', 1);
INSERT INTO `size_list` (`id`, `size_id`, `size_name`, `status`) VALUES (38, 'TJNDNXWU7XU43P9', '13\" Long', 1);
INSERT INTO `size_list` (`id`, `size_id`, `size_name`, `status`) VALUES (39, '2QIH7I1FFP6FMEH', '10\" Long', 1);
INSERT INTO `size_list` (`id`, `size_id`, `size_name`, `status`) VALUES (40, '97RQPYGQEMWMVME', ' 20X20', 1);
INSERT INTO `size_list` (`id`, `size_id`, `size_name`, `status`) VALUES (41, 'CXL3IM3X1DE3XNG', ' 18X18', 1);
INSERT INTO `size_list` (`id`, `size_id`, `size_name`, `status`) VALUES (42, 'QNSPT9U13G51ZLQ', '16X16', 1);
INSERT INTO `size_list` (`id`, `size_id`, `size_name`, `status`) VALUES (43, '6FAIWNUXXDBK8J3', ' 12X18', 1);
INSERT INTO `size_list` (`id`, `size_id`, `size_name`, `status`) VALUES (44, 'WPY9DGWHC2JPCF7', '16 * 14', 1);
INSERT INTO `size_list` (`id`, `size_id`, `size_name`, `status`) VALUES (45, 'LX5FGTKCDBRK4OA', '14\"X12\"', 1);
INSERT INTO `size_list` (`id`, `size_id`, `size_name`, `status`) VALUES (46, '81X5EB8DDR4DQ36', '11\"X10\"', 1);
INSERT INTO `size_list` (`id`, `size_id`, `size_name`, `status`) VALUES (47, 'XKK2LGCO4AS5WHN', '16', 1);
INSERT INTO `size_list` (`id`, `size_id`, `size_name`, `status`) VALUES (48, 'EO5ZL7LEPXRLR3A', '16', 1);
INSERT INTO `size_list` (`id`, `size_id`, `size_name`, `status`) VALUES (49, 'K9UCXRDZRZLHQKD', '9\"X12\"', 1);
INSERT INTO `size_list` (`id`, `size_id`, `size_name`, `status`) VALUES (50, '1JYOASCSJK5OPP3', '16', 1);
INSERT INTO `size_list` (`id`, `size_id`, `size_name`, `status`) VALUES (51, '7H93MTDVCRBMYIE', '8.5 ', 1);
INSERT INTO `size_list` (`id`, `size_id`, `size_name`, `status`) VALUES (52, 'T7JTZ85FDC4CY7J', 'Medium', 1);
INSERT INTO `size_list` (`id`, `size_id`, `size_name`, `status`) VALUES (53, '9YESHUWIDS4QQO2', 'XXL', 1);
INSERT INTO `size_list` (`id`, `size_id`, `size_name`, `status`) VALUES (54, 'DQ5X5OLNG7X34JC', '92\"X41\"', 1);
INSERT INTO `size_list` (`id`, `size_id`, `size_name`, `status`) VALUES (55, 'PLMW2YH6OU5XEX7', '86\"X39\"', 1);
INSERT INTO `size_list` (`id`, `size_id`, `size_name`, `status`) VALUES (56, 'UDKNFD9D97KVJOR', 'W25\"XH30\"', 1);
INSERT INTO `size_list` (`id`, `size_id`, `size_name`, `status`) VALUES (57, 'PLW3WGLIH5MAGFH', '14\"X30\"', 1);
INSERT INTO `size_list` (`id`, `size_id`, `size_name`, `status`) VALUES (58, 'WP6IE8X44FYNT7Y', 'L38\"XW19\"XH31\"', 1);
INSERT INTO `size_list` (`id`, `size_id`, `size_name`, `status`) VALUES (59, 'IBE4SWH6IKKLJ7I', 'L30\"XW12\"XH33\"', 1);
INSERT INTO `size_list` (`id`, `size_id`, `size_name`, `status`) VALUES (60, 'FUYENBD24OTXNT5', '117X58X8', 1);
INSERT INTO `size_list` (`id`, `size_id`, `size_name`, `status`) VALUES (61, 'TC2G72UL4P4DWED', '159X80X7', 1);
INSERT INTO `size_list` (`id`, `size_id`, `size_name`, `status`) VALUES (62, 'AWEFV197CSP85RW', '13X68X6', 1);
INSERT INTO `size_list` (`id`, `size_id`, `size_name`, `status`) VALUES (63, 'XZNPH6LB1YCRT57', '134x77x14', 1);
INSERT INTO `size_list` (`id`, `size_id`, `size_name`, `status`) VALUES (64, '6XQYY4JTNINJEKO', '149x61x9', 1);
INSERT INTO `size_list` (`id`, `size_id`, `size_name`, `status`) VALUES (65, 'VLG2Y6H827WCQ9A', '155x82x10', 1);
INSERT INTO `size_list` (`id`, `size_id`, `size_name`, `status`) VALUES (66, 'BOQGQRTTGSYYKZ6', '157x78x10', 1);
INSERT INTO `size_list` (`id`, `size_id`, `size_name`, `status`) VALUES (67, '6EQUA3RR8NLPEKZ', '162x73x8', 1);
INSERT INTO `size_list` (`id`, `size_id`, `size_name`, `status`) VALUES (68, '1LWQ99SMH4F65LO', '134x68x8', 1);
INSERT INTO `size_list` (`id`, `size_id`, `size_name`, `status`) VALUES (69, '1O4H2PD6WIPX4TH', '134x689x8', 1);
INSERT INTO `size_list` (`id`, `size_id`, `size_name`, `status`) VALUES (70, 'XUZGWTYQ6N8X2RV', '132x61x9', 1);
INSERT INTO `size_list` (`id`, `size_id`, `size_name`, `status`) VALUES (71, 'N6SW6B24S2Y5P2N', '128x64x7', 1);
INSERT INTO `size_list` (`id`, `size_id`, `size_name`, `status`) VALUES (72, '19MQ536WFS4EJGD', '91x50x6', 1);
INSERT INTO `size_list` (`id`, `size_id`, `size_name`, `status`) VALUES (73, 'L324SRV4T1C3RXI', '117x9x51', 1);
INSERT INTO `size_list` (`id`, `size_id`, `size_name`, `status`) VALUES (74, '84F6AFWL7LCWGGS', '45X23', 1);
INSERT INTO `size_list` (`id`, `size_id`, `size_name`, `status`) VALUES (75, 'EFUVA9SA3I942TL', '4\"X4\"', 1);
INSERT INTO `size_list` (`id`, `size_id`, `size_name`, `status`) VALUES (76, 'UA2THPFQ6PCSB46', '15\"X19\"', 1);
INSERT INTO `size_list` (`id`, `size_id`, `size_name`, `status`) VALUES (77, '8B1AM7HRGVEGHUU', 'Multi', 1);


#
# TABLE STRUCTURE FOR: sms_settings
#

DROP TABLE IF EXISTS `sms_settings`;

CREATE TABLE `sms_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `api_key` varchar(100) DEFAULT NULL,
  `api_secret` varchar(100) DEFAULT NULL,
  `from` varchar(100) DEFAULT NULL,
  `isinvoice` int(11) NOT NULL DEFAULT 0,
  `isservice` int(11) NOT NULL DEFAULT 0,
  `isreceive` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `sms_settings` (`id`, `api_key`, `api_secret`, `from`, `isinvoice`, `isservice`, `isreceive`) VALUES (1, 'C20047385da5a06aec2c21.99251389', '', '8809601000500', 1, 1, 1);


#
# TABLE STRUCTURE FOR: sub_module
#

DROP TABLE IF EXISTS `sub_module`;

CREATE TABLE `sub_module` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mid` int(11) NOT NULL,
  `name` varchar(100) CHARACTER SET utf8 NOT NULL,
  `description` text CHARACTER SET utf8 DEFAULT NULL,
  `image` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `directory` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=144 DEFAULT CHARSET=latin1;

INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (1, 1, 'new_invoice', NULL, NULL, 'new_invoice', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (2, 1, 'manage_invoice', NULL, NULL, 'manage_invoice', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (3, 1, 'pos_invoice', NULL, NULL, 'pos_invoice', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (4, 9, 'c_o_a', NULL, NULL, 'show_tree', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (5, 9, 'supplier_payment', NULL, NULL, 'supplier_payment', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (6, 9, 'customer_receive', NULL, NULL, 'customer_receive', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (7, 9, 'debit_voucher', NULL, NULL, 'debit_voucher', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (8, 9, 'credit_voucher', NULL, NULL, 'credit_voucher', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (9, 9, 'voucher_approval', NULL, NULL, 'aprove_v', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (10, 9, 'contra_voucher', NULL, NULL, 'contra_voucher', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (11, 9, 'journal_voucher', NULL, NULL, 'journal_voucher', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (12, 9, 'report', NULL, NULL, 'ac_report', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (13, 9, 'cash_book', NULL, NULL, 'cash_book', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (14, 9, 'Inventory_ledger', NULL, NULL, 'inventory_ledger', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (15, 9, 'bank_book', NULL, NULL, 'bank_book', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (16, 9, 'general_ledger', NULL, NULL, 'general_ledger', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (17, 9, 'trial_balance', NULL, NULL, 'trial_balance', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (18, 9, 'cash_flow', NULL, NULL, 'cash_flow_report', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (19, 9, 'coa_print', NULL, NULL, 'coa_print', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (21, 3, 'category', NULL, NULL, 'manage_category', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (22, 3, 'add_product', NULL, NULL, 'create_product', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (23, 3, 'import_product_csv', NULL, NULL, 'add_product_csv', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (24, 3, 'manage_product', NULL, NULL, 'manage_product', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (25, 2, 'add_customer', NULL, NULL, 'add_customer', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (26, 2, 'manage_customer', NULL, NULL, 'manage_customer', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (27, 2, 'credit_customer', NULL, NULL, 'credit_customer', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (28, 2, 'paid_customer', NULL, NULL, 'paid_customer', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (30, 3, 'unit', NULL, NULL, 'manage_unit', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (31, 4, 'add_supplier', NULL, NULL, 'add_supplier', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (32, 4, 'manage_supplier', NULL, NULL, 'manage_supplier', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (33, 4, 'supplier_ledger', NULL, NULL, 'supplier_ledger_report', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (35, 5, 'add_purchase', NULL, NULL, 'add_purchase', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (36, 5, 'manage_purchase', NULL, NULL, 'manage_purchase', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (37, 7, 'return', NULL, NULL, 'add_return', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (38, 7, 'stock_return_list', NULL, NULL, 'return_list', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (39, 7, 'supplier_return_list', NULL, NULL, 'supplier_return_list', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (40, 7, 'wastage_return_list', NULL, NULL, 'wastage_return_list', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (41, 11, 'tax_settings', NULL, NULL, 'tax_settings', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (43, 6, 'stock_report', NULL, NULL, 'stock_report', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (46, 8, 'closing', NULL, NULL, 'add_closing', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (47, 8, 'closing_report', NULL, NULL, 'closing_report', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (48, 8, 'todays_report', NULL, NULL, 'all_report', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (49, 8, 'todays_customer_receipt', NULL, NULL, 'todays_customer_receipt', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (50, 8, 'sales_report', NULL, NULL, 'todays_sales_report', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (51, 8, 'due_report', NULL, NULL, 'retrieve_dateWise_DueReports', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (52, 8, 'purchase_report', NULL, NULL, 'todays_purchase_report', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (53, 8, 'purchase_report_category_wise', NULL, NULL, 'purchase_report_category_wise', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (54, 8, 'sales_report_product_wise', NULL, NULL, 'product_sales_reports_date_wise', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (55, 8, 'sales_report_category_wise', NULL, NULL, 'sales_report_category_wise', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (56, 10, 'add_new_bank', NULL, NULL, 'add_bank', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (57, 10, 'bank_transaction', NULL, NULL, 'bank_transaction', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (58, 10, 'manage_bank', NULL, NULL, 'bank_list', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (59, 14, 'generate_commission', NULL, NULL, 'commission', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (60, 12, 'add_designation', NULL, NULL, 'add_designation', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (61, 12, 'manage_designation', NULL, NULL, 'manage_designation', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (62, 12, 'add_employee', NULL, NULL, 'add_employee', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (63, 12, 'manage_employee', NULL, NULL, 'manage_employee', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (64, 12, 'add_attendance', NULL, NULL, 'add_attendance', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (65, 12, 'manage_attendance', NULL, NULL, 'manage_attendance', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (66, 12, 'attendance_report', NULL, NULL, 'attendance_report', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (67, 12, 'add_benefits', NULL, NULL, 'add_benefits', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (68, 12, 'manage_benefits', NULL, NULL, 'manage_benefits', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (69, 12, 'add_salary_setup', NULL, NULL, 'add_salary_setup', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (70, 12, 'manage_salary_setup', NULL, NULL, 'manage_salary_setup', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (71, 12, 'salary_generate', NULL, NULL, 'salary_generate', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (72, 12, 'manage_salary_generate', NULL, NULL, 'manage_salary_generate', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (73, 12, 'salary_payment', NULL, NULL, 'salary_payment', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (74, 12, 'add_expense_item', NULL, NULL, 'add_expense_item', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (75, 12, 'manage_expense_item', NULL, NULL, 'manage_expense_item', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (76, 12, 'add_expense', NULL, NULL, 'add_expense', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (77, 12, 'manage_expense', NULL, NULL, 'manage_expense', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (78, 12, 'expense_statement', NULL, NULL, 'expense_statement', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (79, 12, 'add_person_officeloan', NULL, NULL, 'add1_person', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (80, 12, 'add_loan_officeloan', NULL, NULL, 'add_office_loan', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (81, 12, 'add_payment_officeloan', NULL, NULL, 'add_loan_payment', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (82, 12, 'manage_loan_officeloan', NULL, NULL, 'manage1_person', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (83, 12, 'add_person_personalloan', NULL, NULL, 'add_person', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (84, 12, 'add_loan_personalloan', NULL, NULL, 'add_loan', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (85, 12, 'add_payment_personalloan', NULL, NULL, 'add_payment', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (86, 12, 'manage_loan_personalloan', NULL, NULL, 'manage_person', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (87, 15, 'manage_company', NULL, NULL, 'manage_company', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (88, 15, 'add_user', NULL, NULL, 'add_user', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (89, 15, 'manage_users', NULL, NULL, 'manage_user', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (90, 15, 'language', NULL, NULL, 'add_language', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (91, 15, 'currency', NULL, NULL, 'add_currency', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (92, 15, 'setting', NULL, NULL, 'soft_setting', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (93, 15, 'add_role', NULL, NULL, 'add_role', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (94, 15, 'role_list', NULL, NULL, 'role_list', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (95, 15, 'user_assign_role', NULL, NULL, 'user_assign', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (96, 15, 'Permission', NULL, NULL, NULL, 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (97, 8, 'shipping_cost_report', NULL, NULL, 'shipping_cost_report', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (98, 8, 'user_wise_sales_report', NULL, NULL, 'user_wise_sales_report', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (99, 8, 'invoice_return', NULL, NULL, 'invoice_return', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (100, 8, 'supplier_return', NULL, NULL, 'supplier_return', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (101, 8, 'tax_report', NULL, NULL, 'tax_report', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (102, 8, 'profit_report', NULL, NULL, 'profit_report', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (103, 11, 'add_incometax', NULL, NULL, 'add_incometax', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (104, 11, 'manage_income_tax', NULL, NULL, 'manage_income_tax', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (105, 13, 'add_service', NULL, NULL, 'create_service', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (106, 13, 'manage_service', NULL, NULL, 'manage_service', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (107, 13, 'service_invoice', NULL, NULL, 'service_invoice', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (108, 13, 'manage_service_invoice', NULL, NULL, 'manage_service_invoice', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (109, 11, 'tax_report', NULL, NULL, 'tax_report', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (110, 11, 'invoice_wise_tax_report', NULL, NULL, 'invoice_wise_tax_report', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (111, 2, 'customer_advance', NULL, NULL, 'customer_advance', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (112, 4, 'supplier_advance', NULL, NULL, 'supplier_advance', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (113, 2, 'customer_ledger', NULL, NULL, 'customer_ledger', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (114, 1, 'gui_pos', NULL, NULL, 'gui_pos', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (115, 15, 'sms_configure', NULL, NULL, 'sms_configure', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (116, 15, 'backup_restore', NULL, NULL, 'back_up', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (117, 15, 'import', NULL, NULL, 'sql_import', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (118, 15, 'restore', NULL, NULL, 'restore', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (119, 16, 'add_quotation', NULL, NULL, 'add_quotation', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (120, 16, 'manage_quotation', NULL, NULL, 'manage_quotation', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (121, 16, 'add_to_invoice', NULL, NULL, 'add_to_invoice', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (122, 8, 'purchase_report_shelf_wise', NULL, NULL, 'purchase_report_shelf_wise', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (123, 1, 'sales_cheque_report', NULL, NULL, 'sales_cheque_report', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (124, 5, 'purchase_cheque_report', NULL, NULL, 'purchase_cheque_report', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (125, 1, 'dispatch_outlet', NULL, NULL, 'dispatch_outlet', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (126, 17, 'warehouse', NULL, NULL, 'warehouse', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (127, 17, 'outlet', NULL, NULL, 'outlet', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (128, 18, 'rqsn_form', NULL, NULL, 'rqsn_form', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (129, 18, 'cw_purchase', NULL, NULL, 'cw_purchase', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (130, 19, 'aprove_rqsn', NULL, NULL, 'aprove_rqsn', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (131, 19, 'aprove_rqsn_purchase', NULL, NULL, 'aprove_rqsn_purchase', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (132, 20, 'outlet_approve', NULL, NULL, 'outlet_approve', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (133, 20, 'aprove_chalan', NULL, NULL, 'aprove_chalan', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (135, 5, 'purchase_order', NULL, NULL, 'purchase_order', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (136, 21, 'outlet_stock', NULL, NULL, 'outlet_stock', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (137, 19, 'aprove_rqsn_outlet', NULL, NULL, 'aprove_rqsn_outlet', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (138, 18, 'rqsn_list', NULL, NULL, 'rqsn_list', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (139, 7, 'outlet_return_list', NULL, NULL, 'outlet_return_list', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (140, 7, 'wastage_outlet_return_list', NULL, NULL, 'wastage_outlet_return_list', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (141, 18, 'rqsn_list_outlet', NULL, NULL, 'rqsn_list_outlet', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (142, 22, 'add_courier', NULL, NULL, 'add_courier', 1);
INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (143, 22, 'add_branch', NULL, NULL, 'add_branch', 1);


#
# TABLE STRUCTURE FOR: supplier_email
#

DROP TABLE IF EXISTS `supplier_email`;

CREATE TABLE `supplier_email` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `supplier_id` varchar(255) DEFAULT NULL,
  `email_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

INSERT INTO `supplier_email` (`id`, `supplier_id`, `email_id`) VALUES (5, '1', '');
INSERT INTO `supplier_email` (`id`, `supplier_id`, `email_id`) VALUES (6, '1', '');
INSERT INTO `supplier_email` (`id`, `supplier_id`, `email_id`) VALUES (7, '2', 'salamassociates@gmail.com');
INSERT INTO `supplier_email` (`id`, `supplier_id`, `email_id`) VALUES (8, '3', 'mishoel344@gmail.com');
INSERT INTO `supplier_email` (`id`, `supplier_id`, `email_id`) VALUES (9, '4', 'mishoel344@gmail.com');
INSERT INTO `supplier_email` (`id`, `supplier_id`, `email_id`) VALUES (10, '5', '12312@sad.gfh');
INSERT INTO `supplier_email` (`id`, `supplier_id`, `email_id`) VALUES (11, '6', 'mishoel344@gmail.com');


#
# TABLE STRUCTURE FOR: supplier_information
#

DROP TABLE IF EXISTS `supplier_information`;

CREATE TABLE `supplier_information` (
  `supplier_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `supplier_name` varchar(255) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `address2` text NOT NULL,
  `mobile` varchar(100) DEFAULT NULL,
  `emailnumber` varchar(200) DEFAULT NULL,
  `email_address` varchar(200) DEFAULT NULL,
  `contact` varchar(100) DEFAULT NULL,
  `contact_mobile` varchar(255) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `fax` varchar(100) DEFAULT NULL,
  `city` text DEFAULT NULL,
  `state` text DEFAULT NULL,
  `zip` varchar(50) DEFAULT NULL,
  `country` varchar(250) DEFAULT NULL,
  `details` varchar(255) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `status` int(2) NOT NULL,
  PRIMARY KEY (`supplier_id`),
  KEY `supplier_id` (`supplier_id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

INSERT INTO `supplier_information` (`supplier_id`, `supplier_name`, `address`, `address2`, `mobile`, `emailnumber`, `email_address`, `contact`, `contact_mobile`, `phone`, `fax`, `city`, `state`, `zip`, `country`, `details`, `website`, `status`) VALUES ('9', 'Factory', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, 1);
INSERT INTO `supplier_information` (`supplier_id`, `supplier_name`, `address`, `address2`, `mobile`, `emailnumber`, `email_address`, `contact`, `contact_mobile`, `phone`, `fax`, `city`, `state`, `zip`, `country`, `details`, `website`, `status`) VALUES ('1', 'Imported', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);
INSERT INTO `supplier_information` (`supplier_id`, `supplier_name`, `address`, `address2`, `mobile`, `emailnumber`, `email_address`, `contact`, `contact_mobile`, `phone`, `fax`, `city`, `state`, `zip`, `country`, `details`, `website`, `status`) VALUES ('7', 'Imprted', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, 1);
INSERT INTO `supplier_information` (`supplier_id`, `supplier_name`, `address`, `address2`, `mobile`, `emailnumber`, `email_address`, `contact`, `contact_mobile`, `phone`, `fax`, `city`, `state`, `zip`, `country`, `details`, `website`, `status`) VALUES ('8', 'Local', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, 1);
INSERT INTO `supplier_information` (`supplier_id`, `supplier_name`, `address`, `address2`, `mobile`, `emailnumber`, `email_address`, `contact`, `contact_mobile`, `phone`, `fax`, `city`, `state`, `zip`, `country`, `details`, `website`, `status`) VALUES ('5', 'YAkkaw', '', '', '018282828228', NULL, NULL, '', '', '', '', '', '', '', '', '', '', 1);
INSERT INTO `supplier_information` (`supplier_id`, `supplier_name`, `address`, `address2`, `mobile`, `emailnumber`, `email_address`, `contact`, `contact_mobile`, `phone`, `fax`, `city`, `state`, `zip`, `country`, `details`, `website`, `status`) VALUES ('6', 'Shoaib', 'West Dewan Nogor', '', '01864598947', NULL, NULL, '', '', '', '', 'Hathazari', 'Ctg', '4330', 'Bangladesh', '', '', 1);


#
# TABLE STRUCTURE FOR: supplier_product
#

DROP TABLE IF EXISTS `supplier_product`;

CREATE TABLE `supplier_product` (
  `supplier_pr_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` varchar(30) CHARACTER SET utf8 NOT NULL,
  `product_id_two` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `products_model` varchar(30) CHARACTER SET latin1 DEFAULT NULL,
  `supplier_id` bigint(20) NOT NULL,
  `supplier_price` float DEFAULT NULL,
  PRIMARY KEY (`supplier_pr_id`),
  KEY `product_id` (`product_id`),
  KEY `supplier_id` (`supplier_id`),
  KEY `product_id_two` (`product_id_two`)
) ENGINE=InnoDB AUTO_INCREMENT=2680 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1, '6117547181', NULL, '119', '1', '1000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2, '9785254979', NULL, '18', '1', '1160');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (3, '9316577333', NULL, '1611', '1', '2000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (4, '7327336118', NULL, '1607', '1', '2000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (5, '1486327457', NULL, '1702', '1', '1480');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (6, '1672439366', NULL, '1604', '1', '1560');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (7, '4344854594', NULL, 'CP-1', '1', '400');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (8, '1781724374', NULL, 'DL-36', '1', '6000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (9, '9628369232', NULL, 'Dl-28', '1', '6000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (10, '2289448113', NULL, 'DL-3161', '1', '6000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (11, '8935741783', NULL, 'DL-31', '1', '6000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (12, '9682671684', NULL, 'BM-135', '1', '3040');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (13, '6372184934', NULL, 'BM-01', '1', '3040');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (14, '7857722121', NULL, 'BM-08', '1', '3040');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (15, '2614612433', NULL, '1368-1W', '1', '1000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (16, '1521343998', NULL, '1506-1W', '1', '840');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (17, '2824979221', NULL, '4123260-1W', '1', '840');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (18, '8928941489', NULL, '4123260-2W', '1', '640');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (19, '7391248289', NULL, '1506-2B', '1', '640');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (20, '2387686754', NULL, '1366-1W', '1', '1320');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (21, '7124198723', NULL, '1366-2W', '1', '920');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (22, '2982934893', NULL, '1368-2B', '1', '640');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (23, '1188347544', NULL, '1513-1W', '1', '960');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (24, '5985937926', NULL, '1513-2W', '1', '840');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (25, '3414286571', NULL, '12012-1W', '1', '1320');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (26, '4652721595', NULL, '1365-2B', '1', '1160');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (27, '7566245642', NULL, '804020', '1', '640');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (28, '6551751728', NULL, '1604-1W', '1', '1640');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (29, '1729486384', NULL, '1604-2W', '1', '1480');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (30, '2937554135', NULL, '1728-20', '1', '1320');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (31, '3281112219', NULL, '1760', '1', '2040');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (32, '4327227717', NULL, 'V4046', '1', '1120');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (33, '9451824277', NULL, 'V38775', '1', '1120');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (34, '8157587991', NULL, '20266', '1', '2480');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (35, '2268732543', NULL, 'DSP A019', '1', '2000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (36, '5189259751', NULL, 'A30676', '1', '2280');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (37, '7246832488', NULL, 'DSP 30679', '1', '2000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (38, '8723859511', NULL, '40', '1', '1000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (39, '2126975543', NULL, '41', '1', '680');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (40, '6911186683', NULL, '36', '1', '840');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (41, '4587446527', NULL, '29', '1', '840');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (42, '2782775992', NULL, '37', '1', '760');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (43, '7484992226', NULL, 'FP-1', '1', '400');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (44, '4545176566', NULL, NULL, '1', '520');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (45, '4545176566', NULL, NULL, '1', '520');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (46, '4545176566', NULL, NULL, '1', '520');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (47, '8247196674', NULL, NULL, '1', '520');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (48, '8247196674', NULL, NULL, '1', '520');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (49, '8247196674', NULL, NULL, '1', '520');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (50, '8247196674', NULL, NULL, '1', '520');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (51, '8247196674', NULL, NULL, '1', '520');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (52, '8247196674', NULL, NULL, '1', '520');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (53, '4315599119', NULL, NULL, '1', '400');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (54, '4315599119', NULL, NULL, '1', '400');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (55, '4315599119', NULL, NULL, '1', '400');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (56, '4315599119', NULL, NULL, '1', '400');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (57, '4978366586', NULL, NULL, '1', '400');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (58, '8847215634', NULL, NULL, '1', '360');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (59, '8847215634', NULL, NULL, '1', '360');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (60, '8847215634', NULL, NULL, '1', '360');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (61, '8847215634', NULL, NULL, '1', '360');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (62, '8847215634', NULL, NULL, '1', '360');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (63, '9996644768', NULL, 'AM-218', '1', '18800');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (64, '8798426458', NULL, 'AM-054', '1', '18800');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (65, '1942285168', NULL, 'AM-1050', '1', '21200');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (66, '8314943644', NULL, 'AM-078 (Silver)', '1', '2000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (67, '6993658823', NULL, 'AM-6046', '1', '1600');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (68, '6183171245', NULL, 'AM-6045', '1', '1600');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (69, '2563995479', NULL, '30X40', '1', '1480');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (70, '4957251321', NULL, '35X35', '1', '1320');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (71, '9388772423', NULL, '33X33', '1', '1000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (72, '1883224616', NULL, '14X18', '1', '2000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (73, '6739173891', NULL, '40X40', '1', '2000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (74, '6699474499', NULL, '80X120', '1', '3240');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (75, '2749738668', NULL, '20\"/48\"-04', '1', '5200');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (76, '9612741194', NULL, '33X19', '1', '2800');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (77, '8833436892', NULL, '14X35', '1', '3600');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (78, '9912776398', NULL, '58X78', '1', '5200');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (79, '6237591559', NULL, '47X17', '1', '2800');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (80, '8833436892', NULL, '14X35', '1', '3600');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (81, '2644376212', NULL, '55X45', '1', '5200');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (82, '3879192181', NULL, NULL, '1', '5200');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (83, '5723535943', NULL, 'Mar-62', '1', '1560');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (84, '8543292519', NULL, 'Mar-49', '1', '1480');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (85, '9113117252', NULL, 'Mar-80', '1', '1640');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (86, '7346789156', NULL, 'Mar-85', '1', '1560');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (87, '7226717971', NULL, '28-Mar', '1', '1480');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (88, '5975849366', NULL, 'Mar-89', '1', '1480');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (89, '7546534387', NULL, 'Mar-73', '1', '1480');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (90, '5131395865', NULL, 'Feb-49', '1', '1200');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (91, '2571815586', NULL, 'Feb-37', '1', '1160');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (92, '2686984388', NULL, 'Feb-85', '1', '1320');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (93, '6242111567', NULL, 'Feb-89', '1', '1160');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (94, '4527339611', NULL, 'Feb-73', '1', '1160');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (95, '5344732381', NULL, 'Feb-80', '1', '1200');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (96, '1764793124', NULL, 'Feb-62', '1', '1160');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (97, '4294851864', NULL, '28-Feb', '1', '1160');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (98, '2584756662', NULL, 'Jan-80', '1', '760');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (99, '8339874146', NULL, 'Jan-58', '1', '1000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (100, '4446349637', NULL, '28-Jan', '1', '920');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (101, '3279178947', NULL, 'Jan-59', '1', '1000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (102, '7377141295', NULL, '15-Jan', '1', '1000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (103, '2376755711', NULL, 'Jan-33', '1', '1000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (104, '5548571477', NULL, '904', '1', '1520');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (105, '2821396562', NULL, '31-Jan', '1', '1000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (106, '6626591837', NULL, '10-Jan', '1', '840');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (107, '4338496782', NULL, 'Jan-32', '1', '920');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (108, '5577594936', NULL, '1007-1', '1', '1480');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (109, '4654657915', NULL, '16-Jan', '1', '1000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (110, '2252136232', NULL, 'SW-1001-2', '1', '1640');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (111, '1398535885', NULL, 'SW-1001-1', '1', '1200');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (112, '6125284151', NULL, 'Led 3039', '1', '2000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (113, '4812496823', NULL, 'SW 9607', '1', '2320');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (114, '9784319521', NULL, '934', '1', '1480');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (115, '4465789489', NULL, '610-2', '1', '2000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (116, '3269463633', NULL, '834-2', '1', '2000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (117, '2145475434', NULL, '1013-1', '1', '1480');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (118, '9423255773', NULL, '2019 F', '1', '7600');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (119, '1356923264', NULL, '2019 FBK', '1', '7600');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (120, '1559716764', NULL, '2130 WT', '1', '7600');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (121, '2819722765', NULL, '2165', '1', '10800');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (122, '7923811922', NULL, '2122', '1', '8400');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (123, '5465776641', NULL, '2198', '1', '10000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (124, '1153761296', NULL, 'Rose 247-1', '1', '14800');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (125, '4586491193', NULL, '1007-5', '1', '6600');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (126, '5186746747', NULL, '1007-3', '1', '5200');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (127, '3148738372', NULL, '1638-3', '1', '5200');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (128, '3635429493', NULL, '1013-3', '1', '5200');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (129, '2796864376', NULL, 'Aug-92', '1', '6800');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (130, '3564162997', NULL, 'Led-KX 3109 (5+1)', '1', '7600');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (131, '3151612985', NULL, '1001-3', '1', '4158');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (132, '4852671911', NULL, '8335 HL', '1', '6800');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (133, '3381594362', NULL, '5033-14', '1', '11600');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (134, '8894744398', NULL, 'HY-702A', '1', '2400');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (135, '2915855527', NULL, '4283C', '1', '3600');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (136, '8941969535', NULL, '4944CD', '1', '2800');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (137, '3969911339', NULL, '419-3', '1', '9200');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (138, '1113737366', NULL, '409', '1', '6800');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (139, '1122935425', NULL, '408', '1', '5200');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (140, '3642388784', NULL, '407', '1', '4400');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (141, '9533158763', NULL, NULL, '1', '10000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (142, '7216957213', NULL, 'G9', '1', '96');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (143, '8728126451', NULL, 'Bulb-E14/5W/Candle', '1', '200');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (144, '3348279611', NULL, '7W/Mini', '1', '176');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (145, '3265267212', NULL, 'E27/12W', '1', '224');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (146, '1116572633', NULL, 'E27/8W', '1', '176');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (147, '2995424741', NULL, 'E27/6W-WW', '1', '160');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (148, '2114421321', NULL, 'E27/6W-WH', '1', '160');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (149, '4655838764', NULL, 'E27/4W-WW', '1', '160');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (150, '9558224224', NULL, 'E27/4W-WH', '1', '160');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (151, '8323858689', NULL, 'ET-5W/Candle', '1', '200');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (152, '1324382141', NULL, 'LED-5W/E27', '1', '208');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (153, '8413886291', NULL, 'LED-9W/E27', '1', '224');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (154, '4979521488', NULL, 'Bulb/3W/WH', '1', '176');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (155, '1259753968', NULL, 'Bulb/5W/WH', '1', '176');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (156, '3343762763', NULL, '6030', '1', '332');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (157, '2125645776', NULL, '6560', '1', '332');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (158, '9834992991', NULL, '6562', '1', '400');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (159, '3434533256', NULL, '6061', '1', '332');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (160, '1445749516', NULL, '6563', '1', '400');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (161, '7927175276', NULL, '6564', '1', '440');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (162, '8114745264', NULL, '215 M', '1', '1200');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (163, '3538795431', NULL, '215 S', '1', '960');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (164, '4426458287', NULL, '1040', '1', '840');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (165, '9894817425', NULL, '1609', '1', '1320');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (166, '1178753713', NULL, '2701', '1', '1320');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (167, '5474128499', NULL, '1612', '1', '1320');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (168, '9325266482', NULL, 'HB 12-38', '1', '1640');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (169, '2625954283', NULL, '39-18', '1', '2000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (170, '3423298132', NULL, NULL, '1', '2400');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (171, '9457635754', NULL, NULL, '1', '840');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (172, '4985333856', NULL, NULL, '1', '10800');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (173, '2167846827', NULL, '19065-S', '1', '5200');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (174, '7248981552', NULL, '85', '1', '20400');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (175, '6248596455', NULL, '66', '1', '20400');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (176, '5274932542', NULL, '89/L', '1', '20400');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (177, '3814997595', NULL, '89/M', '1', '19600');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (178, '4628966792', NULL, NULL, '1', '240');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (179, '3732162243', NULL, NULL, '1', '1200');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (180, '1493778538', NULL, NULL, '1', '1600');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (181, '5437196822', NULL, NULL, '1', '680');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (182, '6565256298', NULL, '57208', '1', '1640');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (183, '6516813783', NULL, '57208-P', '1', '2240');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (184, '3263684532', NULL, '57014', '1', '1560');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (185, '9992343254', NULL, '55040', '1', '1120');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (186, '3143357753', NULL, '57205AB', '1', '1080');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (187, '6684869588', NULL, '5705AB', '1', '1080');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (188, '9992218453', NULL, '50166', '1', '1080');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (189, '9715378345', NULL, 'Alarm Clock', '1', '960');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (190, '4418136457', NULL, NULL, '1', '32400');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (191, '4418136457', NULL, NULL, '1', '24400');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (192, '3218313857', NULL, ' 21-49 set', '1', '4520');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (193, '5252946571', NULL, '21-49', '1', '2000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (194, '7852837353', NULL, '21146', '1', '4520');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (195, '2745354566', NULL, '21146 S', '1', '1840');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (196, '5889719235', NULL, '21150', '1', '4480');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (197, '9568787439', NULL, '21150 S', '1', '1880');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (198, '1843972267', NULL, '21188', '1', '4480');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (199, '8613575856', NULL, '21140', '1', '1880');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (200, '6843847628', NULL, '21125', '1', '4000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (201, '9871176828', NULL, '21125 S', '1', '1840');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (202, '1169885724', NULL, 'London S', '1', '2000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (203, '8478447969', NULL, '21239', '1', '2000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (204, '9638494364', NULL, 'Mini seater', '1', '1200');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (205, '7592794452', NULL, NULL, '1', '7600');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (206, '6982723572', NULL, NULL, '1', '4000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (207, '2597914986', NULL, '5006', '1', '11600');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (208, '2973273948', NULL, '60320', '1', '12000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (209, '7136159319', NULL, NULL, '1', '12000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (210, '1895439835', NULL, NULL, '1', '10000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (211, '2886438137', NULL, NULL, '1', '2400');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (212, '4447418133', NULL, NULL, '1', '10800');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (213, '6527212716', NULL, NULL, '1', '14800');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (214, '6451583137', NULL, NULL, '1', '6800');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (215, '1644851939', NULL, NULL, '1', '840');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (216, '3855392216', NULL, 'BS 1805', '1', '1280');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (217, '4386161158', NULL, 'B42595', '1', '3600');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (218, '5569576223', NULL, '769', '1', '400');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (219, '5973434122', NULL, '798', '1', '600');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (220, '3491518625', NULL, '799', '1', '600');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (221, '4962588536', NULL, '731', '1', '1160');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (222, '2788455493', NULL, 'DSP', '1', '240');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (223, '3423777229', NULL, '1109', '1', '3040');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (224, '4426391642', NULL, '1103', '1', '1520');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (225, '7632384854', NULL, '14CF0320', '1', '1680');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (226, '3423777229', NULL, '1109', '1', '2000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (227, '1222341891', NULL, 'Big', '1', '360');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (228, '9598922339', NULL, 'Medium', '1', '132');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (229, '1975345564', NULL, 'Mini', '1', '24');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (230, '6127493642', NULL, NULL, '1', '240');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (231, '1175178163', NULL, NULL, '1', '240');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (232, '9444181479', NULL, NULL, '1', '240');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (233, '6833962167', NULL, NULL, '1', '240');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (234, '4358728277', NULL, NULL, '1', '240');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (235, '9253185278', NULL, NULL, '1', '280');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (236, '4195546791', NULL, NULL, '1', '280');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (237, '2234233356', NULL, NULL, '1', '240');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (238, '9162334659', NULL, NULL, '1', '280');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (239, '7151637185', NULL, NULL, '1', '480');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (240, '5168838479', NULL, NULL, '1', '600');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (241, '7848132952', NULL, NULL, '1', '760');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (242, '9276273771', NULL, NULL, '1', '464');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (243, '2167457155', NULL, NULL, '1', '440');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (244, '7296318981', NULL, NULL, '1', '280');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (245, '4223247565', NULL, NULL, '1', '480');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (246, '3383931171', NULL, NULL, '1', '600');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (247, '6347819463', NULL, NULL, '1', '760');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (248, '9238693731', NULL, NULL, '1', '464');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (249, '8751113661', NULL, NULL, '1', '440');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (250, '8428759281', NULL, NULL, '1', '920');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (251, '2361837699', NULL, NULL, '1', '120');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (252, '4898956239', NULL, NULL, '1', '312');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (253, '7333398487', NULL, NULL, '1', '1');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (254, '8451495844', NULL, NULL, '1', '1480');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (255, '4913158834', NULL, NULL, '1', '1');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (256, '5244259278', NULL, NULL, '1', '120');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (257, '8378168234', NULL, NULL, '1', '200');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (258, '2771932833', NULL, NULL, '1', '120');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (259, '6962487258', NULL, NULL, '1', '80');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (260, '6896539234', NULL, NULL, '1', '160');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (261, '8273495119', NULL, NULL, '1', '160');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (262, '35649427', NULL, '', '3', '120');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (263, '51445258', NULL, '', '6', '200');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (264, '36836735', NULL, '123', '6', '100');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (265, '91827288', NULL, '5567', '6', '343');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (266, '71213289', NULL, '', '6', '700');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (269, '95576353', NULL, NULL, '6', '13000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (270, '85416849', NULL, '9920', '6', '3500');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (271, '121212', NULL, '991', '6', '250');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (272, '8892023', NULL, '908u8', '6', '700');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (273, '93173817', NULL, '88393', '6', '200');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (274, '19377848', NULL, '324', '6', '250');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (275, '9664113223', NULL, 'RC0011', '7', '6650');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (276, '7999354975', NULL, 'RC0011', '7', '6650');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (277, '6581972787', NULL, '1109', '7', '2660');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (278, '5813855173', NULL, '11011', '7', '1330');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (279, '4155483165', NULL, 'HK17566/PR', '7', '4200');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (280, '8855628686', NULL, '1109', '7', '1750');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (281, '3596255487', NULL, '1633', '7', '2030');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (282, '4352439382', NULL, '2053', '7', '9450');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (283, '9313725563', NULL, NULL, '7', '6650');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (284, '5111958482', NULL, 'E008C', '7', '3500');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (285, '9442461882', NULL, '50006', '7', '10150');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (286, '2228624196', NULL, 'C4-60', '7', '10850');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (287, '1413491679', NULL, 'Lc031B', '7', '12950');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (288, '3482566291', NULL, 'Lc031S', '7', '6650');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (289, '7212815561', NULL, 'VB007', '7', '735');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (290, '9135629945', NULL, 'MS005-1', '7', '7350');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (291, '4625139738', NULL, 'MS005-2', '7', '7350');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (292, '3564695864', NULL, 'AM-1050', '7', '16450');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (293, '4363181598', NULL, 'AM-6046', '7', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (294, '7331986942', NULL, 'AM-093', '7', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (295, '7955895835', NULL, 'DL-3161', '7', '3150');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (296, '5168367761', NULL, 'BM-135', '7', '1890');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (297, '9357552896', NULL, 'BM-01', '7', '2660');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (298, '8935123357', NULL, 'BM-08', '7', '2660');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (299, '8659294414', NULL, 'Dl-28', '7', '4550');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (300, '1765614519', NULL, '18872C', '7', '17500');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (301, '5788385326', NULL, '18873C', '7', '24850');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (302, '3547323356', NULL, 'CT005678', '7', '10850');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (303, '9671669166', NULL, 'D-009', '7', '805');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (304, '8983938559', NULL, 'D-019', '7', '896');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (305, '1942782557', NULL, 'D-03', '7', '875');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (306, '7749788537', NULL, 'D-0011H', '7', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (307, '6738531981', NULL, 'Multi', '7', '1295');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (308, '2897732516', NULL, 'P001091', '7', '1575');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (309, '3335671283', NULL, 'P00109C', '7', '2450');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (310, '3965679814', NULL, 'SC0056', '7', '1050');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (311, '8478263584', NULL, 'T00081', '7', '735');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (312, '2276153512', NULL, '00001SC', '7', '1750');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (313, '1123244399', NULL, NULL, '7', '4200');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (314, '4238655556', NULL, NULL, '7', '2800');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (315, '5832229389', NULL, 'Sp10211', '1', '84');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (316, '3381338211', NULL, 'Sp10212', '1', '105');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (317, '3536369835', NULL, 'Sp10213', '1', '84');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (318, '7837876282', NULL, '1487', '1', '175');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (319, '6614968465', NULL, '1485', '1', '112');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (320, '1899325252', NULL, '1487', '1', '196');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (321, '1787282879', NULL, '1488', '1', '182');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (322, '6526619443', NULL, '1489', '1', '175');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (323, '7735365688', NULL, '1484', '1', '84');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (324, '2238894745', NULL, '1519', '1', '350');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (325, '6288767213', NULL, '1482', '1', '147');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (326, '5564175817', NULL, '1481', '1', '175');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (327, '6448132434', NULL, 'Ox102106', '1', '350');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (328, '2661218898', NULL, 'M102107', '1', '14');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (329, '1243781487', NULL, 'M102108', '1', '140');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (330, '6642755931', NULL, 'A102109', '1', '35');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (331, '2712773467', NULL, 'Psb007', '1', '875');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (332, '2926244777', NULL, 'Psb007', '1', '875');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (333, '6897594498', NULL, 'Ssb001', '1', '875');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (334, '9934597565', NULL, 'Csb009', '1', '1015');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (335, '6544651487', NULL, 'Ssb001', '1', '945');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (336, '8323592277', NULL, 'Ssb001', '1', '875');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (337, '1623913451', NULL, '1aaa3', '1', '1575');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (338, '3564272325', NULL, 'E2cB', '1', '735');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (339, '9325236369', NULL, 'E2cB', '1', '595');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (340, '6651798976', NULL, 'Az003', '1', '140');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (341, '1555165568', NULL, 'Toy-P001', '8', '266');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (342, '7735783717', NULL, 'Toy-P002', '8', '266');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (343, '8957533843', NULL, 'Toy-P003', '8', '266');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (344, '8293598514', NULL, 'Toy-P004', '8', '196');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (345, '3743735545', NULL, 'Toy-P005', '8', '196');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (346, '9651941778', NULL, 'Toy-P006', '8', '336');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (347, '6896321823', NULL, 'Toy-P007', '8', '266');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (348, '3774259563', NULL, 'Toy-P008', '8', '266');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (349, '5396737737', NULL, 'Toy-P009', '8', '406');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (350, '5224186177', NULL, 'Toy-P010', '8', '406');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (351, '4369914824', NULL, 'Toy-P011', '8', '266');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (352, '7657269167', NULL, 'Toy-P012', '8', '406');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (353, '5118452739', NULL, 'Toy-P013', '8', '196');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (354, '9193563846', NULL, 'Toy-P014', '8', '196');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (355, '5915889263', NULL, 'Toy-P015', '8', '266');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (356, '7524469274', NULL, 'Toy-P016', '8', '196');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (357, '2122686254', NULL, 'Toy-P017', '8', '266');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (358, '1221495791', NULL, 'Toy-P018', '8', '266');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (359, '1558985824', NULL, 'Toy-P019', '8', '266');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (360, '8527969354', NULL, 'Toy-P020', '8', '140');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (361, '7951411983', NULL, 'Toy-P021', '8', '112');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (362, '2123991757', NULL, 'Wb/829 ', '1', '266');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (363, '5914929793', NULL, 'Wb/829', '1', '266');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (364, '8854542673', NULL, 'Wb3018', '1', '231');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (365, '3389394368', NULL, 'Wb/1001', '1', '266');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (366, '8367815932', NULL, 'R834', '1', '266');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (367, '3254688491', NULL, 'Wb0182 ', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (368, '1444953528', NULL, 'Wb0182', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (369, '3148972422', NULL, 'Wb0182', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (370, '1273521345', NULL, 'Wb0182', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (371, '4935132659', NULL, 'Yb0368', '1', '245');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (372, '7227771196', NULL, 'Yb0368', '1', '245');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (373, '5319577413', NULL, 'Yb0183', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (374, '2787326354', NULL, 'Wb834', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (375, '6957813851', NULL, 'Wb5', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (376, '3235968758', NULL, 'Sh7058', '1', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (377, '6622687444', NULL, 'Yb0300', '1', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (378, '9612479155', NULL, 'Yb0300', '1', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (379, '5363436769', NULL, 'Wb/2', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (380, '1259681115', NULL, 'Tc1706', '1', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (381, '5947115239', NULL, 'Wb508', '1', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (382, '9262242211', NULL, 'Wb508', '1', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (383, '4922417482', NULL, 'WB/2', '1', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (384, '5112891179', NULL, 'Wb835', '1', '231');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (385, '7745269497', NULL, 'Wb15', '1', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (386, '5529639185', NULL, 'Yb0287', '1', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (387, '5239221459', NULL, 'WB001', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (388, '4264299998', NULL, 'Wb7', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (389, '9397615861', NULL, 'Yb0455', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (390, '1956153632', NULL, 'WB002', '1', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (391, '7248848591', NULL, 'Wb1915', '1', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (392, '2595517224', NULL, '35X35', '7', '1155');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (393, '9474556473', NULL, '33X33', '7', '875');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (394, '4451999612', NULL, '14X18', '7', '1750');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (395, '7176516763', NULL, '40X40', '7', '1750');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (396, '1777252155', NULL, '80X120', '7', '2835');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (397, '7484643447', NULL, '20\"/48\"-04', '7', '4550');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (398, '3135165164', NULL, '33X19', '7', '2450');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (399, '7122973869', NULL, '58X78', '7', '4550');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (400, '4324662664', NULL, '14X35 (Broken)', '7', '3150');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (401, '7694873997', NULL, '55X45', '7', '4550');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (402, '1637461555', NULL, '43X107', '7', '3850');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (403, '8913659263', NULL, '34X20 (Broken)', '7', '3150');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (404, '9827481558', NULL, '14x39', '7', '3150');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (405, '1282981423', NULL, '8362-3', '7', '1560');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (406, '3988149781', NULL, '8449-3', '7', '1480');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (407, '1768644473', NULL, '8380-3', '7', '1640');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (408, '5963517428', NULL, '8285-3', '7', '1560');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (409, '1324376389', NULL, '8428-3', '7', '1480');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (410, '3548962478', NULL, '8389-3', '7', '1480');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (411, '8857541296', NULL, '8673-3', '7', '1480');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (412, '3352356696', NULL, '8449-2', '7', '1200');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (413, '8168522959', NULL, '8285-2', '7', '1320');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (414, '6169597339', NULL, '8389-2', '7', '1160');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (415, '6895748356', NULL, '8673-2', '7', '1160');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (416, '2616295274', NULL, '8380-2', '7', '1200');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (417, '4958541123', NULL, '8362-2', '7', '1160');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (418, '6981232244', NULL, '8428-2', '7', '1160');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (419, '8616413739', NULL, '8380-1', '7', '760');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (420, '5439464996', NULL, '6558-1', '7', '840');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (421, '9485349463', NULL, '6028-1', '7', '840');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (422, '1182988356', NULL, '6559-1', '7', '840');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (423, '6611723958', NULL, '6115-1', '7', '840');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (424, '4323368546', NULL, '6116-1', '7', '840');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (425, '7113574743', NULL, '6033-1', '7', '840');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (426, '8336831791', NULL, '904-1', '7', '1520');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (427, '9412139327', NULL, '6031-1', '7', '840');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (428, '9539311141', NULL, '6010-1', '7', '840');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (429, '2537443635', NULL, '6032-1', '7', '840');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (430, '7518352985', NULL, '1007-1', '7', '1160');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (431, '7581561359', NULL, '6116-1', '7', '1000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (432, '6484671163', NULL, 'SW-1001-2', '7', '1640');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (433, '3189262667', NULL, 'SW-1001-1', '7', '1200');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (434, '6598157251', NULL, 'SW-9607', '7', '2520');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (435, '3267159647', NULL, 'Led 3039', '7', '2000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (436, '7351776889', NULL, 'YMA42702', '7', '2320');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (437, '4531783584', NULL, 'JY934', '7', '1480');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (438, '7735374134', NULL, 'JY834-2', '7', '2000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (439, '8232812692', NULL, '2019 F', '7', '7600');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (440, '6919184433', NULL, '2019 FBK', '7', '7600');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (441, '2462863574', NULL, '2130 WT', '7', '7600');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (442, '2621245278', NULL, 'Rose 247-1', '7', '14800');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (443, '2791345991', NULL, '1007-5', '7', '6600');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (444, '3231384244', NULL, '1007-3', '7', '4550');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (445, '2941776132', NULL, '1638-3', '7', '4550');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (446, '2483196437', NULL, 'Led-KX 3109-5/1', '7', '6650');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (447, '7469832881', NULL, '1001-3', '7', '3639');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (448, '8529679431', NULL, 'HY-702A', '7', '2100');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (449, '4984618996', NULL, '4283C', '7', '3150');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (450, '7321618539', NULL, '4944CD', '7', '2450');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (451, '6974499279', NULL, '419-3', '7', '8050');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (452, '7438194222', NULL, 'YMA409', '7', '5950');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (453, '4293389226', NULL, 'YMA408', '7', '4550');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (454, '1964822592', NULL, 'K-001', '1', '84');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (455, '7485945644', NULL, 'K-001', '1', '84');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (456, '1671952926', NULL, 'K-001', '1', '84');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (457, '2884177348', NULL, 'K-002', '1', '140');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (458, '6347175766', NULL, 'K-003', '1', '140');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (459, '5414532192', NULL, 'K-003', '1', '105');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (460, '9642253692', NULL, 'K-003', '1', '84');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (461, '4896742614', NULL, 'K-004', '1', '105');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (462, '6292126413', NULL, 'K-005', '1', '42');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (463, '4442384253', NULL, 'K-005', '1', '42');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (464, '5887256537', NULL, 'K-005', '1', '42');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (465, '6589535896', NULL, 'K-006', '1', '42');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (466, '8159247557', NULL, 'K-007', '1', '53');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (467, '2925714549', NULL, 'K-008', '1', '70');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (468, '1759995947', NULL, 'K-009', '1', '224');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (469, '1981316324', NULL, 'K-010', '1', '210');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (470, '1415495835', NULL, 'K-011', '1', '126');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (471, '2246749163', NULL, 'K-012', '1', '154');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (472, '9182377989', NULL, 'K-013', '1', '112');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (473, '7165951742', NULL, 'K-014', '1', '63');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (474, '4246722493', NULL, 'K-015', '1', '63');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (475, '3333282116', NULL, 'K-016', '1', '39');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (476, '4417296976', NULL, 'K-017', '1', '105');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (477, '9782749872', NULL, 'PC00101', '7', '455');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (478, '6339199517', NULL, 'PC00101', '7', '455');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (479, '5395617151', NULL, 'PC00101', '7', '455');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (480, '7899797919', NULL, 'PC00102KH', '7', '455');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (481, '2159382724', NULL, 'PC00102KH', '7', '455');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (482, '7162633741', NULL, 'PC00102KH', '7', '455');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (483, '5241788887', NULL, 'PC00102KH', '7', '455');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (484, '3861191152', NULL, 'PC00102KH', '7', '455');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (485, '8577276865', NULL, 'PC00102KH', '7', '455');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (486, '3244643398', NULL, 'PC00103BV', '7', '350');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (487, '5512384872', NULL, 'PC00105BV', '7', '350');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (488, '8611972843', NULL, 'PC00106CH', '7', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (489, '9247946815', NULL, 'PC00106CH', '7', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (490, '8574419427', NULL, 'PC00106CH', '7', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (491, '7741684969', NULL, 'PC00106CH', '7', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (492, '6916683582', NULL, 'PC00106CH', '7', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (493, '4253621595', NULL, 'G9', '7', '84');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (494, '8484921153', NULL, 'Bulb-E14/5W/etLamp', '7', '175');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (495, '1942423238', NULL, 'Bulb-E14/5W/Candle', '7', '175');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (496, '3238173358', NULL, '7W/Mini', '7', '154');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (497, '8952228426', NULL, 'E27/8W', '7', '175');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (498, '8849264979', NULL, 'E27/6W-WW', '7', '140');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (499, '6598918855', NULL, 'E27/6W-WH', '7', '140');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (500, '4939753255', NULL, 'E27/4W-WH', '7', '140');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (501, '5175691392', NULL, 'LED-3W/E27', '7', '130');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (502, '2643616266', NULL, 'LED-5W/E27', '7', '182');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (503, '8921352154', NULL, 'LED-12W/E27', '7', '175');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (504, '7161998284', NULL, 'E27Bulb/5W/WH', '7', '245');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (505, '7984647491', NULL, 'Led panel light 6w', '7', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (506, '4853797269', NULL, 'Led panel light 12w', '7', '490');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (507, '9963131757', NULL, 'Led panel light 18w', '7', '735');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (508, '7654578631', NULL, '119', '7', '875');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (509, '4129422378', NULL, '018 AW', '7', '1015');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (510, '2242928629', NULL, '1611', '7', '1855');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (511, '7533761916', NULL, '1607', '7', '1505');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (512, '7891769957', NULL, '1702', '7', '1225');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (513, '5437779645', NULL, '21146 M', '7', '3673');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (514, '9214582687', NULL, '21146 S', '7', '1495');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (515, '8535924748', NULL, '21150 Big', '7', '3640');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (516, '7861755434', NULL, '21140 S', '7', '1528');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (517, '2844644761', NULL, '21140 M', '7', '1528');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (518, '3934332434', NULL, '21125 B', '7', '3250');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (519, '5688978983', NULL, 'london B', '7', '2048');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (520, '2629111183', NULL, 'london s', '7', '1528');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (521, '8312533419', NULL, 'am 21151 b', '7', '3640');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (522, '5369227265', NULL, 'am 21151 s', '7', '2048');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (523, '1365494997', NULL, 'route us', '7', '1625');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (524, '8269576399', NULL, '1368-1W', '7', '875');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (525, '8315858212', NULL, '1366-1W', '7', '805');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (526, '4191312233', NULL, '1366-2W', '7', '945');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (527, '6749763813', NULL, '1368-2B', '7', '560');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (528, '7686882672', NULL, '1513-2W', '7', '735');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (529, '6476749589', NULL, '804020', '7', '560');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (530, '9234853447', NULL, '4046', '7', '1050');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (531, '6513221838', NULL, '4046-1', '7', '1050');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (532, '1912127998', NULL, 'X1513-2', '7', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (533, '8717655435', NULL, '1506-2B', '7', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (534, '3427745113', NULL, 'X1604-1W', '7', '945');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (535, '4498811958', NULL, '1728-20', '7', '1295');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (536, '7687493187', NULL, 'RXP1760', '7', '1505');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (537, '7215558149', NULL, 'FV42', '7', '595');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (538, '6216194585', NULL, '20266', '7', '2170');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (539, '5125118345', NULL, '1476', '1', '350');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (540, '6541344776', NULL, '1475', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (541, '7294498591', NULL, '1479', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (542, '8789794597', NULL, '1474', '1', '525');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (543, '4277986577', NULL, '1477', '1', '266');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (544, '3843464645', NULL, '1480', '1', '434');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (545, '3591682569', NULL, '57205AB', '1', '945');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (546, '4339246438', NULL, '57014', '1', '1505');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (547, '3779524528', NULL, '55040', '1', '945');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (548, '4726598477', NULL, '57208AB', '1', '1435');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (549, '4868748425', NULL, '55041', '1', '980');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (550, '7968283985', NULL, 'BC001', '1', '70');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (551, '7732656998', NULL, 'FB001', '1', '175');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (552, '6546467563', NULL, 'FB002', '1', '175');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (553, '5396271777', NULL, 'BB001', '1', '126');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (554, '2249686286', NULL, 'Dsp/ht723 h ', '1', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (555, '3938882675', NULL, 'Ht 709', '1', '245');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (556, '3137784852', NULL, '694 mn', '1', '175');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (557, '1739731661', NULL, 'Ht 710', '1', '245');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (558, '5246889198', NULL, 'Ht 746', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (559, '2429569766', NULL, 'Ht 678 694 662', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (560, '6261753477', NULL, '693MNHT', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (561, '5969542492', NULL, 'Ht 716-719', '1', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (562, '8669591318', NULL, 'Ht 678 694 662', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (563, '3884133188', NULL, 'D797', '1', '245');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (564, '4512836571', NULL, '799', '1', '1050');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (565, '1385739953', NULL, '798', '1', '1050');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (566, '4991468979', NULL, '8835', '1', '406');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (567, '9592379894', NULL, 'Doll731', '1', '1085');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (568, '9345684398', NULL, 'DOLL002', '1', '875');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (569, '5491881529', NULL, 'BATH001', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (570, '5328266981', NULL, 'BATH002', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (571, '7857466778', NULL, 'BATH003', '1', '245');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (572, '9257492552', NULL, 'BATH004', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (573, '3813614277', NULL, 'Pb001', '1', '126');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (574, '5971699589', NULL, 'PB002', '1', '84');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (575, '1379924175', NULL, 'PB003', '1', '154');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (576, '1396916444', NULL, 'PB004', '1', '84');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (577, '9555629917', NULL, 'PB005', '1', '175');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (578, '9544879789', NULL, 'Pb49', '1', '175');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (579, '2735284943', NULL, 'Ppb16', '1', '154');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (580, '8112671674', NULL, 'PB006', '1', '175');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (581, '5278741787', NULL, 'PB007', '1', '175');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (582, '1898987672', NULL, 'PB008', '1', '175');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (583, '3222267875', NULL, 'DB001', '1', '25');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (584, '2414238487', NULL, 'KDBAG001', '1', '88');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (585, '1254753362', NULL, 'PB009', '1', '77');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (586, '3754549519', NULL, 'PB009', '1', '77');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (587, '9668293919', NULL, 'PB010', '1', '77');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (588, '3611871342', NULL, 'PB011', '1', '77');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (589, '8153483267', NULL, 'smbl001', '1', '42');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (590, '2553294161', NULL, 'F912115', '1', '1050');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (591, '7666772719', NULL, '172820', '1', '1050');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (592, '6718941617', NULL, '172822', '1', '1050');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (593, '7723172253', NULL, '88033', '1', '1050');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (594, '9154534821', NULL, 'BCAP001', '1', '56');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (595, '7515131183', NULL, 'PF001', '1', '525');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (596, '5149699953', NULL, 'Lb/36', '1', '455');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (597, '1853821556', NULL, 'Lb28', '1', '525');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (598, '7361381574', NULL, 'RXP1760', '1', '1505');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (599, '4682788269', NULL, 'AC986', '1', '525');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (600, '8636716436', NULL, 'SP989', '1', '1505');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (601, '1468835677', NULL, 'GI9867', '1', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (602, '8853313871', NULL, 'A019/dsp', '1', '1750');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (603, '1896738357', NULL, 'Fv 1728-20', '1', '1155');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (604, '7187251148', NULL, 'A306761KK', '1', '1995');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (605, '2329342659', NULL, '1472', '1', '595');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (606, '4372719112', NULL, '1528', '1', '595');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (607, '4837148635', NULL, '1527', '1', '735');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (608, '2635786587', NULL, '1529', '1', '665');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (609, '4394814423', NULL, 'Stk0001', '1', '70');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (610, '7771647634', NULL, '25-5', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (611, '9754489934', NULL, '26-5', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (612, '6624213112', NULL, '27-5', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (613, '7747246661', NULL, '28-5', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (614, '4784322382', NULL, '29-5', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (615, '5777897443', NULL, '30-5', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (616, '4381242782', NULL, '31-5', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (617, '9184977289', NULL, '32-5', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (618, '1265855494', NULL, '33-5', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (619, '4615324996', NULL, '34-5', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (620, '3854232459', NULL, '25-2', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (621, '9257471274', NULL, '26-2', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (622, '6685255839', NULL, '27-2', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (623, '4547187668', NULL, '28-2', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (624, '1539237536', NULL, '29-2', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (625, '4429669968', NULL, '30-2', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (626, '4364199983', NULL, '31-2', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (627, '6459863933', NULL, '32-2', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (628, '2484629295', NULL, '33-2', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (629, '2995363866', NULL, '34-2', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (630, '7478192918', NULL, '25-5/S', '1', '1546');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (631, '8972459978', NULL, '26-5/S', '1', '1546');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (632, '4142468922', NULL, '27-5/S', '1', '1546');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (633, '2979266372', NULL, '28-5/S', '1', '1546');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (634, '6992198221', NULL, '29-5/S', '1', '1546');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (635, '3868227937', NULL, '30-5/S', '1', '1546');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (636, '3436957552', NULL, '31-5/S', '1', '1546');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (637, '7884325264', NULL, '32-5/S', '1', '1546');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (638, '4264792451', NULL, '33-5/S', '1', '1546');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (639, '7688543856', NULL, '34-5/S', '1', '1546');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (640, '8722986391', NULL, '25-2/S', '1', '110');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (641, '9526713448', NULL, '26-2/S', '1', '110');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (642, '5496212632', NULL, '27-2/S', '1', '110');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (643, '7626173966', NULL, '28-2/S', '1', '110');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (644, '5183862233', NULL, '29-2/S', '1', '110');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (645, '3697682593', NULL, '30-2/S', '1', '110');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (646, '8564895443', NULL, '31-2/S', '1', '110');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (647, '6911823787', NULL, '32-2/S', '1', '110');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (648, '1988249244', NULL, '33-2/S', '1', '110');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (649, '5987749268', NULL, '34-2/S', '1', '110');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (650, '3167855117', NULL, '85', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (651, '1799234615', NULL, '85', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (652, '5189622515', NULL, '85', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (653, '5522459242', NULL, '85', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (654, '3763166922', NULL, '85', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (655, '1374273441', NULL, '85', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (656, '4624281858', NULL, '85', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (657, '1939315272', NULL, '85', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (658, '6637325245', NULL, '89', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (659, '3373928752', NULL, '89', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (660, '4621472182', NULL, '89', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (661, '2981688653', NULL, '89', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (662, '1352677937', NULL, '89', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (663, '9621122352', NULL, '89', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (664, '2849197616', NULL, '68', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (665, '9582779732', NULL, '69', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (666, '4941863843', NULL, '83', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (667, '1627678315', NULL, '83', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (668, '4561346817', NULL, '81', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (669, '8959725917', NULL, '81', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (670, '3918448418', NULL, '88', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (671, '8349814723', NULL, '88', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (672, '4291915614', NULL, '88', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (673, '4842637459', NULL, '92', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (674, '6543456237', NULL, '66', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (675, '5426195864', NULL, '66', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (676, '9323296786', NULL, '66', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (677, '4533514721', NULL, '101', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (678, '6243994181', NULL, '66', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (679, '5141373998', NULL, '85', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (680, '9985539191', NULL, 'RS41/C', '9', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (681, '3715569214', NULL, 'RS41/C', '9', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (682, '1125671985', NULL, 'RS41/C', '9', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (683, '6255314443', NULL, 'RS39/S', '9', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (684, '3765348671', NULL, 'RS39/S', '9', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (685, '3725953119', NULL, 'RS39/S', '9', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (686, '9635169355', NULL, '41-SP', '9', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (687, '2633297238', NULL, '41-SP', '9', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (688, '3721545743', NULL, '41-SP', '9', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (689, '5644335888', NULL, '39-SP', '9', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (690, '1115953426', NULL, '39-SP', '9', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (691, '5735638297', NULL, '39-SP', '9', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (692, '4636355465', NULL, 'E008MF', '9', '3250');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (693, '3169734615', NULL, '18871MF-C', '9', '11500');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (694, '7774636637', NULL, '18871MF-D', '9', '11500');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (695, '1271319615', NULL, 'C02-MFG', '9', '4850');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (696, '2316433919', NULL, 'CT-021MFG', '9', '4850');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (697, '4712816235', NULL, 'Con-102-MFG', '9', '6500');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (698, '4647468946', NULL, 'T-50129-MFG', '9', '7000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (699, '9589192322', NULL, '155224', '1', '12900');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (700, '2345168995', NULL, '15656', '1', '13000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (701, '1234885148', NULL, '15382', '1', '13000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (702, '6914444476', NULL, '15556', '1', '12500');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (703, '8235775973', NULL, '15677', '1', '12500');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (704, '2837432246', NULL, '15661', '1', '13000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (705, '8739495652', NULL, '15665', '1', '12800');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (706, '8871426753', NULL, '15690', '1', '13000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (707, '2634899517', NULL, '15692', '1', '13000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (708, '5674897826', NULL, '15383', '1', '13000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (709, '1649376965', NULL, '15490', '1', '13500');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (710, '4193589327', NULL, '15728', '1', '12000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (711, '1695139545', NULL, '15724', '1', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (712, '2561499766', NULL, '17034', '1', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (713, '4689747987', NULL, '15470', '1', '8000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (714, '4131828552', NULL, 'PF6030', '7', '291');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (715, '5772192821', NULL, 'PF6030', '7', '291');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (716, '6687121795', NULL, 'PF6560', '7', '291');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (717, '1249228831', NULL, 'PF6560', '7', '291');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (718, '8235671571', NULL, 'PF6560', '7', '291');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (719, '9172284155', NULL, 'PF6014', '7', '455');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (720, '8612458383', NULL, 'PF661', '7', '595');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (721, '8559611118', NULL, 'PF6563', '7', '350');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (722, '9684435218', NULL, '20x16', '7', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (723, '7412521644', NULL, '20x16', '7', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (724, '6128717726', NULL, '17.5?12.5', '7', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (725, '3142966783', NULL, '17.5?12.5', '7', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (726, '5476995329', NULL, 'PF-6509', '7', '1435');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (727, '6278646311', NULL, 'PF-6504', '7', '875');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (728, '1428271861', NULL, '215 M', '7', '1050');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (729, '2547274713', NULL, '215 S', '7', '840');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (730, '8862749873', NULL, 'YD1040', '7', '735');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (731, '6644486983', NULL, 'YJ1709/PF', '7', '1050');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (732, '4563898427', NULL, 'J1710/PF', '7', '1050');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (733, '7266672596', NULL, 'YD1028/PF', '7', '1085');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (734, '9811846939', NULL, 'YD1616/PF', '7', '1085');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (735, '8618772345', NULL, 'J1612', '7', '1240');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (736, '8236849859', NULL, 'J1612', '7', '1240');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (737, '9667514735', NULL, 'J1612', '7', '1240');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (738, '2364218481', NULL, 'BH2701/PF', '7', '1240');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (739, '3542125333', NULL, 'Hy2218', '7', '2040');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (740, '7769364553', NULL, 'HB 12-38', '7', '1640');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (741, '9768145668', NULL, '39-18', '7', '2000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (742, '7738588537', NULL, 'Q1609/PF', '7', '1240');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (743, '6244953121', NULL, 'Collage 08', '7', '1240');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (744, '5384695339', NULL, '10', '7', '1240');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (745, '9687578377', NULL, 'Q101-8', '7', '2250');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (746, '7949864966', NULL, 'Q083-8', '7', '3350');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (747, '2382865156', NULL, 'Q031-10', '7', '3350');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (748, '9498936954', NULL, 'Q099-8', '7', '2250');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (749, '4587194732', NULL, 'Q066-5', '7', '2050');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (750, '9372599386', NULL, 'Q087-12', '7', '3850');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (751, '6534997824', NULL, 'Q069', '7', '2850');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (752, '5497458531', NULL, 'Q001', '7', '3850');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (753, '7291479833', NULL, 'Q067', '7', '2750');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (754, '1935845316', NULL, 'Q068', '7', '2750');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (755, '6381221189', NULL, 'RC0011', '7', '6650');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (756, '2316743752', NULL, 'RC0011', '7', '6650');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (757, '2392725525', NULL, '1109', '7', '2660');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (758, '3941254222', NULL, '11011', '7', '1330');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (759, '7123241852', NULL, 'HK17566/PR', '7', '4200');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (760, '1813421766', NULL, '1109', '7', '1750');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (761, '9147664473', NULL, '1633', '7', '2030');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (762, '1729665148', NULL, '2053', '7', '9450');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (763, '1942417378', NULL, NULL, '7', '6650');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (764, '6921262455', NULL, 'E008C', '7', '3500');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (765, '2351325351', NULL, '50006', '7', '10150');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (766, '5327975213', NULL, 'C4-60', '7', '10850');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (767, '6928815193', NULL, 'Lc031B', '7', '12950');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (768, '9353912875', NULL, 'Lc031S', '7', '6650');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (769, '6162433378', NULL, 'VB007', '7', '735');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (770, '5147288495', NULL, 'MS005-1', '7', '7350');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (771, '1957962335', NULL, 'MS005-2', '7', '7350');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (772, '9151882255', NULL, 'AM-1050', '7', '16450');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (773, '9385984757', NULL, 'AM-6046', '7', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (774, '2571761266', NULL, 'AM-093', '7', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (775, '4793551323', NULL, 'DL-3161', '7', '3150');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (776, '7466122615', NULL, 'BM-135', '7', '1890');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (777, '1453921382', NULL, 'BM-01', '7', '2660');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (778, '5763439747', NULL, 'BM-08', '7', '2660');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (779, '6463666936', NULL, 'Dl-28', '7', '4550');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (780, '6519414735', NULL, '18872C', '7', '17500');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (781, '2428977659', NULL, '18873C', '7', '24850');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (782, '8544328778', NULL, 'CT005678', '7', '10850');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (783, '6411967646', NULL, 'D-009', '7', '805');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (784, '1384331812', NULL, 'D-019', '7', '896');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (785, '9476865812', NULL, 'D-03', '7', '875');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (786, '7281273291', NULL, 'D-0011H', '7', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (787, '4732734879', NULL, 'Multi', '7', '1295');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (788, '5753435294', NULL, 'P001091', '7', '1575');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (789, '8231167346', NULL, 'P00109C', '7', '2450');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (790, '9823241378', NULL, 'SC0056', '7', '1050');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (791, '8472766982', NULL, 'T00081', '7', '735');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (792, '3247847699', NULL, '00001SC', '7', '1750');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (793, '3135236264', NULL, NULL, '7', '4200');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (794, '2222782839', NULL, NULL, '7', '2800');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (795, '8983529725', NULL, 'Sp10211', '1', '84');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (796, '9129113198', NULL, 'Sp10212', '1', '105');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (797, '6635862842', NULL, 'Sp10213', '1', '84');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (798, '5511493151', NULL, '1487', '1', '175');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (799, '8821891288', NULL, '1485', '1', '112');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (800, '6311416231', NULL, '1487', '1', '196');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (801, '4977757868', NULL, '1488', '1', '182');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (802, '5519758784', NULL, '1489', '1', '175');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (803, '3191555241', NULL, '1484', '1', '84');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (804, '8157917563', NULL, '1519', '1', '350');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (805, '6371465865', NULL, '1482', '1', '147');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (806, '3794866318', NULL, '1481', '1', '175');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (807, '1417977359', NULL, 'Ox102106', '1', '350');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (808, '6613121331', NULL, 'M102107', '1', '14');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (809, '7194869969', NULL, 'M102108', '1', '140');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (810, '1911479842', NULL, 'A102109', '1', '35');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (811, '8186674522', NULL, 'Psb007', '1', '875');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (812, '9757378132', NULL, 'Psb007', '1', '875');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (813, '8499994923', NULL, 'Ssb001', '1', '875');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (814, '9635354528', NULL, 'Csb009', '1', '1015');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (815, '9834193842', NULL, 'Ssb001', '1', '945');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (816, '3345464725', NULL, 'Ssb001', '1', '875');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (817, '5749512618', NULL, '1aaa3', '1', '1575');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (818, '6422213615', NULL, 'E2cB', '1', '735');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (819, '3478284564', NULL, 'E2cB', '1', '595');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (820, '8346875579', NULL, 'Az003', '1', '140');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (821, '8411389163', NULL, 'Toy-P001', '8', '266');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (822, '7484575894', NULL, 'Toy-P002', '8', '266');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (823, '5353852359', NULL, 'Toy-P003', '8', '266');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (824, '2621197372', NULL, 'Toy-P004', '8', '196');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (825, '4177148785', NULL, 'Toy-P005', '8', '196');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (826, '2434155766', NULL, 'Toy-P006', '8', '336');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (827, '8799383473', NULL, 'Toy-P007', '8', '266');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (828, '3341843872', NULL, 'Toy-P008', '8', '266');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (829, '4855862561', NULL, 'Toy-P009', '8', '406');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (830, '6643458648', NULL, 'Toy-P010', '8', '406');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (831, '9392977392', NULL, 'Toy-P011', '8', '266');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (832, '2276331812', NULL, 'Toy-P012', '8', '406');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (833, '3566878243', NULL, 'Toy-P013', '8', '196');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (834, '5873527472', NULL, 'Toy-P014', '8', '196');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (835, '8318645948', NULL, 'Toy-P015', '8', '266');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (836, '6115767886', NULL, 'Toy-P016', '8', '196');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (837, '3112631445', NULL, 'Toy-P017', '8', '266');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (838, '3491963892', NULL, 'Toy-P018', '8', '266');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (839, '1151813539', NULL, 'Toy-P019', '8', '266');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (840, '5234577683', NULL, 'Toy-P020', '8', '140');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (841, '7574672477', NULL, 'Toy-P021', '8', '112');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (842, '3953728791', NULL, 'Wb/829 ', '1', '266');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (843, '6716683373', NULL, 'Wb/829', '1', '266');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (844, '8337624881', NULL, 'Wb3018', '1', '231');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (845, '1791461674', NULL, 'Wb/1001', '1', '266');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (846, '6944739624', NULL, 'R834', '1', '266');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (847, '2469349732', NULL, 'Wb0182 ', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (848, '7531611957', NULL, 'Wb0182', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (849, '3165422757', NULL, 'Wb0182', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (850, '5864769884', NULL, 'Wb0182', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (851, '7667655294', NULL, 'Yb0368', '1', '245');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (852, '4649179567', NULL, 'Yb0368', '1', '245');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (853, '1396549954', NULL, 'Yb0183', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (854, '7615523153', NULL, 'Wb834', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (855, '7426451377', NULL, 'Wb5', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (856, '1232187934', NULL, 'Sh7058', '1', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (857, '4464537316', NULL, 'Yb0300', '1', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (858, '7994826339', NULL, 'Yb0300', '1', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (859, '7319387629', NULL, 'Wb/2', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (860, '2761681441', NULL, 'Tc1706', '1', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (861, '7558649912', NULL, 'Wb508', '1', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (862, '4715469816', NULL, 'Wb508', '1', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (863, '2363255595', NULL, 'WB/2', '1', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (864, '4977144529', NULL, 'Wb835', '1', '231');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (865, '4133447956', NULL, 'Wb15', '1', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (866, '4224894484', NULL, 'Yb0287', '1', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (867, '9792577254', NULL, 'WB001', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (868, '1369147215', NULL, 'Wb7', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (869, '5921131979', NULL, 'Yb0455', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (870, '9916445243', NULL, 'WB002', '1', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (871, '9351711729', NULL, 'Wb1915', '1', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (872, '8689936427', NULL, '35X35', '7', '1155');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (873, '1693843851', NULL, '33X33', '7', '875');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (874, '6632814499', NULL, '14X18', '7', '1750');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (875, '5345144615', NULL, '40X40', '7', '1750');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (876, '4781423388', NULL, '80X120', '7', '2835');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (877, '9551523522', NULL, '20\"/48\"-04', '7', '4550');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (878, '3474776891', NULL, '33X19', '7', '2450');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (879, '3675126968', NULL, '58X78', '7', '4550');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (880, '7657983316', NULL, '14X35 (Broken)', '7', '3150');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (881, '4714988814', NULL, '55X45', '7', '4550');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (882, '3922174234', NULL, '43X107', '7', '3850');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (883, '8713395752', NULL, '34X20 (Broken)', '7', '3150');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (884, '2865759631', NULL, '14x39', '7', '3150');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (885, '6329589197', NULL, '8362-3', '7', '1560');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (886, '2633782746', NULL, '8449-3', '7', '1480');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (887, '7311537456', NULL, '8380-3', '7', '1640');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (888, '4636931257', NULL, '8285-3', '7', '1560');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (889, '3589546239', NULL, '8428-3', '7', '1480');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (890, '8317995944', NULL, '8389-3', '7', '1480');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (891, '9243955592', NULL, '8673-3', '7', '1480');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (892, '9652737249', NULL, '8449-2', '7', '1200');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (893, '2892219424', NULL, '8285-2', '7', '1320');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (894, '4536686453', NULL, '8389-2', '7', '1160');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (895, '7561314226', NULL, '8673-2', '7', '1160');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (896, '1392147461', NULL, '8380-2', '7', '1200');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (897, '8851659441', NULL, '8362-2', '7', '1160');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (898, '6148961813', NULL, '8428-2', '7', '1160');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (899, '3364281188', NULL, '8380-1', '7', '760');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (900, '8829841582', NULL, '6558-1', '7', '840');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (901, '7858283547', NULL, '6028-1', '7', '840');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (902, '9434434631', NULL, '6559-1', '7', '840');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (903, '4431911484', NULL, '6115-1', '7', '840');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (904, '5162548343', NULL, '6116-1', '7', '840');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (905, '5842764414', NULL, '6033-1', '7', '840');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (906, '1496564896', NULL, '904-1', '7', '1520');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (907, '5885349371', NULL, '6031-1', '7', '840');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (908, '3898752825', NULL, '6010-1', '7', '840');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (909, '2291343676', NULL, '6032-1', '7', '840');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (910, '3277247968', NULL, '1007-1', '7', '1160');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (911, '9241299318', NULL, '6116-1', '7', '1000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (912, '8612532738', NULL, 'SW-1001-2', '7', '1640');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (913, '2784796982', NULL, 'SW-1001-1', '7', '1200');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (914, '7397999886', NULL, 'SW-9607', '7', '2520');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (915, '7965625643', NULL, 'Led 3039', '7', '2000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (916, '1965783733', NULL, 'YMA42702', '7', '2320');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (917, '2924487158', NULL, 'JY934', '7', '1480');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (918, '7153683256', NULL, 'JY834-2', '7', '2000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (919, '2276112286', NULL, '2019 F', '7', '7600');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (920, '7643644513', NULL, '2019 FBK', '7', '7600');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (921, '9894999679', NULL, '2130 WT', '7', '7600');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (922, '8945231639', NULL, 'Rose 247-1', '7', '14800');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (923, '4738786552', NULL, '1007-5', '7', '6600');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (924, '2326713895', NULL, '1007-3', '7', '4550');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (925, '6167279538', NULL, '1638-3', '7', '4550');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (926, '5779464499', NULL, 'Led-KX 3109-5/1', '7', '6650');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (927, '5869227452', NULL, '1001-3', '7', '3639');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (928, '4977961197', NULL, 'HY-702A', '7', '2100');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (929, '2273356947', NULL, '4283C', '7', '3150');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (930, '7169953126', NULL, '4944CD', '7', '2450');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (931, '5195182887', NULL, '419-3', '7', '8050');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (932, '2451798578', NULL, 'YMA409', '7', '5950');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (933, '9739175436', NULL, 'YMA408', '7', '4550');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (934, '5926189964', NULL, 'K-001', '1', '84');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (935, '3873733544', NULL, 'K-001', '1', '84');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (936, '1237614171', NULL, 'K-001', '1', '84');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (937, '2222576555', NULL, 'K-002', '1', '140');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (938, '4116483466', NULL, 'K-003', '1', '140');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (939, '5312534516', NULL, 'K-003', '1', '105');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (940, '1967837673', NULL, 'K-003', '1', '84');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (941, '4777428885', NULL, 'K-004', '1', '105');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (942, '4668485587', NULL, 'K-005', '1', '42');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (943, '4366612256', NULL, 'K-005', '1', '42');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (944, '3114525544', NULL, 'K-005', '1', '42');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (945, '7449351159', NULL, 'K-006', '1', '42');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (946, '8913836642', NULL, 'K-007', '1', '53');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (947, '1552539884', NULL, 'K-008', '1', '70');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (948, '1854227451', NULL, 'K-009', '1', '224');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (949, '5295987292', NULL, 'K-010', '1', '210');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (950, '4332186383', NULL, 'K-011', '1', '126');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (951, '4461996863', NULL, 'K-012', '1', '154');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (952, '3946198536', NULL, 'K-013', '1', '112');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (953, '8887826361', NULL, 'K-014', '1', '63');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (954, '4598751475', NULL, 'K-015', '1', '63');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (955, '6653925761', NULL, 'K-016', '1', '39');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (956, '1596279547', NULL, 'K-017', '1', '105');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (957, '2688531215', NULL, 'PC00101', '7', '455');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (958, '1794225663', NULL, 'PC00101', '7', '455');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (959, '3439868936', NULL, 'PC00101', '7', '455');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (960, '6157974234', NULL, 'PC00102KH', '7', '455');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (961, '2175311319', NULL, 'PC00102KH', '7', '455');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (962, '8225747277', NULL, 'PC00102KH', '7', '455');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (963, '3894557346', NULL, 'PC00102KH', '7', '455');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (964, '7533889649', NULL, 'PC00102KH', '7', '455');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (965, '6383521356', NULL, 'PC00102KH', '7', '455');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (966, '8397268965', NULL, 'PC00103BV', '7', '350');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (967, '5451264564', NULL, 'PC00105BV', '7', '350');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (968, '9443834748', NULL, 'PC00106CH', '7', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (969, '6724761351', NULL, 'PC00106CH', '7', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (970, '4812669352', NULL, 'PC00106CH', '7', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (971, '2379938385', NULL, 'PC00106CH', '7', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (972, '5986812793', NULL, 'PC00106CH', '7', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (973, '5556183666', NULL, 'G9', '7', '84');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (974, '4645269817', NULL, 'Bulb-E14/5W/etLamp', '7', '175');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (975, '8452993186', NULL, 'Bulb-E14/5W/Candle', '7', '175');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (976, '2265623572', NULL, '7W/Mini', '7', '154');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (977, '3997735676', NULL, 'E27/8W', '7', '175');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (978, '5296951152', NULL, 'E27/6W-WW', '7', '140');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (979, '8542742555', NULL, 'E27/6W-WH', '7', '140');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (980, '3363166692', NULL, 'E27/4W-WH', '7', '140');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (981, '9188423728', NULL, 'LED-3W/E27', '7', '130');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (982, '3625233919', NULL, 'LED-5W/E27', '7', '182');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (983, '6435621279', NULL, 'LED-12W/E27', '7', '175');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (984, '7716845471', NULL, 'E27Bulb/5W/WH', '7', '245');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (985, '4634313695', NULL, 'Led panel light 6w', '7', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (986, '1796559425', NULL, 'Led panel light 12w', '7', '490');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (987, '3458798431', NULL, 'Led panel light 18w', '7', '735');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (988, '4839241316', NULL, '119', '7', '875');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (989, '4954987665', NULL, '018 AW', '7', '1015');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (990, '9336977479', NULL, '1611', '7', '1855');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (991, '6723558828', NULL, '1607', '7', '1505');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (992, '3731369328', NULL, '1702', '7', '1225');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (993, '7832729312', NULL, '21146 M', '7', '3673');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (994, '1216152833', NULL, '21146 S', '7', '1495');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (995, '7564832374', NULL, '21150 Big', '7', '3640');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (996, '3539724693', NULL, '21140 S', '7', '1528');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (997, '6338822823', NULL, '21140 M', '7', '1528');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (998, '2928859278', NULL, '21125 B', '7', '3250');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (999, '9493684252', NULL, 'london B', '7', '2048');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1000, '8134815946', NULL, 'london s', '7', '1528');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1001, '2949689673', NULL, 'am 21151 b', '7', '3640');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1002, '9121959568', NULL, 'am 21151 s', '7', '2048');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1003, '7239672715', NULL, 'route us', '7', '1625');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1004, '3111976589', NULL, '1368-1W', '7', '875');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1005, '6186469924', NULL, '1366-1W', '7', '805');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1006, '9815394998', NULL, '1366-2W', '7', '945');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1007, '3973331828', NULL, '1368-2B', '7', '560');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1008, '6923282918', NULL, '1513-2W', '7', '735');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1009, '7889886487', NULL, '804020', '7', '560');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1010, '9856724325', NULL, '4046', '7', '1050');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1011, '5644171286', NULL, '4046-1', '7', '1050');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1012, '3169824935', NULL, 'X1513-2', '7', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1013, '8433667366', NULL, '1506-2B', '7', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1014, '2975652288', NULL, 'X1604-1W', '7', '945');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1015, '8524657656', NULL, '1728-20', '7', '1295');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1016, '6281687698', NULL, 'RXP1760', '7', '1505');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1017, '7347114633', NULL, 'FV42', '7', '595');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1018, '9958541253', NULL, '20266', '7', '2170');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1019, '1635623364', NULL, '1476', '1', '350');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1020, '9958927991', NULL, '1475', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1021, '1285534268', NULL, '1479', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1022, '7559834314', NULL, '1474', '1', '525');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1023, '8288564822', NULL, '1477', '1', '266');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1024, '9656245848', NULL, '1480', '1', '434');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1025, '3686668448', NULL, '57205AB', '1', '945');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1026, '4273825972', NULL, '57014', '1', '1505');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1027, '7497476492', NULL, '55040', '1', '945');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1028, '1675959421', NULL, '57208AB', '1', '1435');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1029, '5427289151', NULL, '55041', '1', '980');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1030, '7364174727', NULL, 'BC001', '1', '70');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1031, '5747772776', NULL, 'FB001', '1', '175');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1032, '8525893761', NULL, 'FB002', '1', '175');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1033, '5484623855', NULL, 'BB001', '1', '126');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1034, '5929289824', NULL, 'Dsp/ht723 h ', '1', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1035, '9986183727', NULL, 'Ht 709', '1', '245');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1036, '1842974144', NULL, '694 mn', '1', '175');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1037, '2959753876', NULL, 'Ht 710', '1', '245');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1038, '2335295496', NULL, 'Ht 746', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1039, '1818288593', NULL, 'Ht 678 694 662', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1040, '5189453297', NULL, '693MNHT', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1041, '1826412862', NULL, 'Ht 716-719', '1', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1042, '9216999494', NULL, 'Ht 678 694 662', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1043, '6268553457', NULL, 'D797', '1', '245');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1044, '8429187977', NULL, '799', '1', '1050');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1045, '8252471393', NULL, '798', '1', '1050');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1046, '8624158686', NULL, '8835', '1', '406');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1047, '1596214292', NULL, 'Doll731', '1', '1085');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1048, '7199899955', NULL, 'DOLL002', '1', '875');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1049, '4611763819', NULL, 'BATH001', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1050, '3544442859', NULL, 'BATH002', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1051, '1443498186', NULL, 'BATH003', '1', '245');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1052, '1568667189', NULL, 'BATH004', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1053, '9399416492', NULL, 'Pb001', '1', '126');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1054, '2161578428', NULL, 'PB002', '1', '84');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1055, '9881293934', NULL, 'PB003', '1', '154');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1056, '7295192133', NULL, 'PB004', '1', '84');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1057, '7847526923', NULL, 'PB005', '1', '175');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1058, '3583388766', NULL, 'Pb49', '1', '175');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1059, '7318977852', NULL, 'Ppb16', '1', '154');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1060, '3821571881', NULL, 'PB006', '1', '175');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1061, '8584524672', NULL, 'PB007', '1', '175');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1062, '2195361796', NULL, 'PB008', '1', '175');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1063, '7531937441', NULL, 'DB001', '1', '25');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1064, '6378878115', NULL, 'KDBAG001', '1', '88');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1065, '2811851847', NULL, 'PB009', '1', '77');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1066, '3885818174', NULL, 'PB009', '1', '77');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1067, '3136685697', NULL, 'PB010', '1', '77');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1068, '9335131671', NULL, 'PB011', '1', '77');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1069, '6822778981', NULL, 'smbl001', '1', '42');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1070, '1538146614', NULL, 'F912115', '1', '1050');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1071, '4123993318', NULL, '172820', '1', '1050');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1072, '6522633118', NULL, '172822', '1', '1050');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1073, '5322568828', NULL, '88033', '1', '1050');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1074, '2821793325', NULL, 'BCAP001', '1', '56');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1075, '9685938823', NULL, 'PF001', '1', '525');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1076, '2657677158', NULL, 'Lb/36', '1', '455');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1077, '4422838119', NULL, 'Lb28', '1', '525');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1078, '5247861775', NULL, 'RXP1760', '1', '1505');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1079, '4843843457', NULL, 'AC986', '1', '525');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1080, '8426558396', NULL, 'SP989', '1', '1505');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1081, '8272747892', NULL, 'GI9867', '1', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1082, '5247577694', NULL, 'A019/dsp', '1', '1750');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1083, '1787385781', NULL, 'Fv 1728-20', '1', '1155');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1084, '4746216195', NULL, 'A306761KK', '1', '1995');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1085, '6293898724', NULL, '1472', '1', '595');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1086, '3266284918', NULL, '1528', '1', '595');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1087, '6536531397', NULL, '1527', '1', '735');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1088, '1478964625', NULL, '1529', '1', '665');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1089, '9457513764', NULL, 'Stk0001', '1', '70');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1090, '6391418956', NULL, '25-5', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1091, '4244667562', NULL, '26-5', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1092, '9815436486', NULL, '27-5', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1093, '1616963282', NULL, '28-5', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1094, '8351548716', NULL, '29-5', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1095, '6382182654', NULL, '30-5', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1096, '7398667161', NULL, '31-5', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1097, '4345618181', NULL, '32-5', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1098, '9233734167', NULL, '33-5', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1099, '9365661662', NULL, '34-5', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1100, '8559527184', NULL, '25-2', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1101, '8784957918', NULL, '26-2', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1102, '2772881144', NULL, '27-2', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1103, '5525665428', NULL, '28-2', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1104, '9221247718', NULL, '29-2', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1105, '9839384373', NULL, '30-2', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1106, '4152429314', NULL, '31-2', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1107, '3764211533', NULL, '32-2', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1108, '2771473284', NULL, '33-2', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1109, '2278358784', NULL, '34-2', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1110, '7952863423', NULL, '25-5/S', '1', '1546');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1111, '2388497359', NULL, '26-5/S', '1', '1546');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1112, '5187674342', NULL, '27-5/S', '1', '1546');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1113, '8543697331', NULL, '28-5/S', '1', '1546');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1114, '6273529613', NULL, '29-5/S', '1', '1546');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1115, '6195891882', NULL, '30-5/S', '1', '1546');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1116, '1697259627', NULL, '31-5/S', '1', '1546');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1117, '9733348896', NULL, '32-5/S', '1', '1546');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1118, '3172251393', NULL, '33-5/S', '1', '1546');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1119, '5855969737', NULL, '34-5/S', '1', '1546');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1120, '1651812791', NULL, '25-2/S', '1', '110');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1121, '6364835939', NULL, '26-2/S', '1', '110');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1122, '7652531844', NULL, '27-2/S', '1', '110');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1123, '7192221252', NULL, '28-2/S', '1', '110');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1124, '1122881266', NULL, '29-2/S', '1', '110');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1125, '1857623659', NULL, '30-2/S', '1', '110');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1126, '3478943175', NULL, '31-2/S', '1', '110');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1127, '6749626398', NULL, '32-2/S', '1', '110');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1128, '2472469995', NULL, '33-2/S', '1', '110');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1129, '8366964666', NULL, '34-2/S', '1', '110');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1130, '5828847261', NULL, '85', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1131, '2953853824', NULL, '85', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1132, '2459459944', NULL, '85', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1133, '2193786498', NULL, '85', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1134, '3964537398', NULL, '85', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1135, '4348435823', NULL, '85', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1136, '7174497795', NULL, '85', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1137, '7811851792', NULL, '85', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1138, '9977468364', NULL, '89', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1139, '1292884976', NULL, '89', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1140, '7974878756', NULL, '89', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1141, '3415699158', NULL, '89', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1142, '5678528691', NULL, '89', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1143, '6167484321', NULL, '89', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1144, '4769323954', NULL, '68', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1145, '2642811752', NULL, '69', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1146, '8184315275', NULL, '83', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1147, '9653566973', NULL, '83', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1148, '5585359484', NULL, '81', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1149, '1335544713', NULL, '81', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1150, '9752846849', NULL, '88', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1151, '4383556884', NULL, '88', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1152, '4455115599', NULL, '88', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1153, '3342435987', NULL, '92', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1154, '9386647957', NULL, '66', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1155, '2711787948', NULL, '66', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1156, '5138874447', NULL, '66', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1157, '2272485486', NULL, '101', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1158, '9911534463', NULL, '66', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1159, '1321987485', NULL, '85', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1160, '4592412843', NULL, 'RS41/C', '9', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1161, '7225677489', NULL, 'RS41/C', '9', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1162, '9539959593', NULL, 'RS41/C', '9', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1163, '9418169268', NULL, 'RS39/S', '9', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1164, '7517988711', NULL, 'RS39/S', '9', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1165, '4863152272', NULL, 'RS39/S', '9', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1166, '3791186842', NULL, '41-SP', '9', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1167, '3858299354', NULL, '41-SP', '9', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1168, '7985622384', NULL, '41-SP', '9', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1169, '7412459715', NULL, '39-SP', '9', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1170, '6583949531', NULL, '39-SP', '9', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1171, '7835377844', NULL, '39-SP', '9', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1172, '4497742742', NULL, 'E008MF', '9', '3250');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1173, '3548997561', NULL, '18871MF-C', '9', '11500');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1174, '2691194633', NULL, '18871MF-D', '9', '11500');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1175, '2237178833', NULL, 'C02-MFG', '9', '4850');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1176, '4928829745', NULL, 'CT-021MFG', '9', '4850');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1177, '6745717684', NULL, 'Con-102-MFG', '9', '6500');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1178, '4624262663', NULL, 'T-50129-MFG', '9', '7000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1179, '6759281762', NULL, '155224', '1', '12900');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1180, '3174872396', NULL, '15656', '1', '13000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1181, '1146271721', NULL, '15382', '1', '13000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1182, '1713333335', NULL, '15556', '1', '12500');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1183, '8494663583', NULL, '15677', '1', '12500');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1184, '8988135349', NULL, '15661', '1', '13000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1185, '8676981867', NULL, '15665', '1', '12800');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1186, '6811743826', NULL, '15690', '1', '13000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1187, '4574269671', NULL, '15692', '1', '13000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1188, '5956588199', NULL, '15383', '1', '13000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1189, '1534294463', NULL, '15490', '1', '13500');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1190, '9185122328', NULL, '15728', '1', '12000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1191, '5571238348', NULL, '15724', '1', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1192, '2484895937', NULL, '17034', '1', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1193, '5765499598', NULL, '15470', '1', '8000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1194, '9879524591', NULL, 'PF6030', '7', '291');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1195, '7583937422', NULL, 'PF6030', '7', '291');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1196, '8467665281', NULL, 'PF6560', '7', '291');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1197, '9277851744', NULL, 'PF6560', '7', '291');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1198, '5155149131', NULL, 'PF6560', '7', '291');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1199, '8158246558', NULL, 'PF6014', '7', '455');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1200, '1691539213', NULL, 'PF661', '7', '595');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1201, '2194469421', NULL, 'PF6563', '7', '350');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1202, '3166825898', NULL, '20x16', '7', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1203, '2136716257', NULL, '20x16', '7', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1204, '2444375957', NULL, '17.5?12.5', '7', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1205, '5373621956', NULL, '17.5?12.5', '7', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1206, '9888143171', NULL, 'PF-6509', '7', '1435');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1207, '4476791543', NULL, 'PF-6504', '7', '875');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1208, '7226611544', NULL, '215 M', '7', '1050');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1209, '8488836751', NULL, '215 S', '7', '840');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1210, '4226741261', NULL, 'YD1040', '7', '735');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1211, '2828113374', NULL, 'YJ1709/PF', '7', '1050');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1212, '5551395126', NULL, 'J1710/PF', '7', '1050');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1213, '2131591674', NULL, 'YD1028/PF', '7', '1085');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1214, '6936668918', NULL, 'YD1616/PF', '7', '1085');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1215, '1467673574', NULL, 'J1612', '7', '1240');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1216, '9164727733', NULL, 'J1612', '7', '1240');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1217, '9794651139', NULL, 'J1612', '7', '1240');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1218, '4548356736', NULL, 'BH2701/PF', '7', '1240');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1219, '4433777279', NULL, 'Hy2218', '7', '2040');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1220, '8925824388', NULL, 'HB 12-38', '7', '1640');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1221, '3258388546', NULL, '39-18', '7', '2000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1222, '9713213819', NULL, 'Q1609/PF', '7', '1240');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1223, '5879419251', NULL, 'Collage 08', '7', '1240');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1224, '3585464521', NULL, '10', '7', '1240');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1225, '4773434234', NULL, 'Q101-8', '7', '2250');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1226, '7346779949', NULL, 'Q083-8', '7', '3350');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1227, '1957184151', NULL, 'Q031-10', '7', '3350');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1228, '2938327347', NULL, 'Q099-8', '7', '2250');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1229, '1277716582', NULL, 'Q066-5', '7', '2050');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1230, '7896893361', NULL, 'Q087-12', '7', '3850');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1231, '6212575281', NULL, 'Q069', '7', '2850');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1232, '4422765137', NULL, 'Q001', '7', '3850');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1233, '6875878555', NULL, 'Q067', '7', '2750');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1234, '7633491469', NULL, 'Q068', '7', '2750');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1235, '7353839174', NULL, 'RC0011', '7', '6650');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1236, '5842311931', NULL, 'RC0011', '7', '6650');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1237, '7289522218', NULL, '1109', '7', '2660');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1238, '7915499188', NULL, '11011', '7', '1330');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1239, '1329529411', NULL, 'HK17566/PR', '7', '4200');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1240, '7431383816', NULL, '1109', '7', '1750');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1241, '8532186181', NULL, '1633', '7', '2030');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1242, '2261887488', NULL, '2053', '7', '9450');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1243, '2859457853', NULL, NULL, '7', '6650');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1244, '7145564244', NULL, 'E008C', '7', '3500');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1245, '7939192824', NULL, '50006', '7', '10150');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1246, '9236811586', NULL, 'C4-60', '7', '10850');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1247, '3579757246', NULL, 'Lc031B', '7', '12950');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1248, '3335561352', NULL, 'Lc031S', '7', '6650');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1249, '2693787956', NULL, 'VB007', '7', '735');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1250, '6511895879', NULL, 'MS005-1', '7', '7350');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1251, '1461875179', NULL, 'MS005-2', '7', '7350');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1252, '6813625265', NULL, 'AM-1050', '7', '16450');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1253, '9467539879', NULL, 'AM-6046', '7', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1254, '9835273849', NULL, 'AM-093', '7', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1255, '2939685677', NULL, 'DL-3161', '7', '3150');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1256, '7236764785', NULL, 'BM-135', '7', '1890');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1257, '8349827945', NULL, 'BM-01', '7', '2660');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1258, '4951565767', NULL, 'BM-08', '7', '2660');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1259, '7692668699', NULL, 'Dl-28', '7', '4550');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1260, '7684422975', NULL, '18872C', '7', '17500');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1261, '9597751988', NULL, '18873C', '7', '24850');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1262, '1487252893', NULL, 'CT005678', '7', '10850');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1263, '4232348553', NULL, 'D-009', '7', '805');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1264, '5255225115', NULL, 'D-019', '7', '896');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1265, '1243372285', NULL, 'D-03', '7', '875');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1266, '1233978826', NULL, 'D-0011H', '7', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1267, '4344713452', NULL, 'Multi', '7', '1295');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1268, '4725559131', NULL, 'P001091', '7', '1575');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1269, '3675759983', NULL, 'P00109C', '7', '2450');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1270, '1486469175', NULL, 'SC0056', '7', '1050');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1271, '4378669234', NULL, 'T00081', '7', '735');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1272, '7465562718', NULL, '00001SC', '7', '1750');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1273, '2551722652', NULL, NULL, '7', '4200');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1274, '1477847841', NULL, NULL, '7', '2800');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1275, '7924132171', NULL, 'Sp10211', '1', '84');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1276, '5251524968', NULL, 'Sp10212', '1', '105');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1277, '6919878814', NULL, 'Sp10213', '1', '84');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1278, '8754844815', NULL, '1487', '1', '175');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1279, '2125429865', NULL, '1485', '1', '112');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1280, '5868449663', NULL, '1487', '1', '196');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1281, '1387775462', NULL, '1488', '1', '182');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1282, '3177269449', NULL, '1489', '1', '175');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1283, '5967853384', NULL, '1484', '1', '84');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1284, '3518652552', NULL, '1519', '1', '350');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1285, '6269681561', NULL, '1482', '1', '147');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1286, '3758648625', NULL, '1481', '1', '175');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1287, '8654771879', NULL, 'Ox102106', '1', '350');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1288, '3695536287', NULL, 'M102107', '1', '14');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1289, '1959872744', NULL, 'M102108', '1', '140');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1290, '2635624933', NULL, 'A102109', '1', '35');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1291, '1157378533', NULL, 'Psb007', '1', '875');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1292, '8639597642', NULL, 'Psb007', '1', '875');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1293, '9143638799', NULL, 'Ssb001', '1', '875');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1294, '7376246592', NULL, 'Csb009', '1', '1015');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1295, '6969873783', NULL, 'Ssb001', '1', '945');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1296, '8172424837', NULL, 'Ssb001', '1', '875');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1297, '8678583593', NULL, '1aaa3', '1', '1575');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1298, '2184113856', NULL, 'E2cB', '1', '735');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1299, '1283562955', NULL, 'E2cB', '1', '595');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1300, '3424666847', NULL, 'Az003', '1', '140');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1301, '2479478962', NULL, 'Toy-P001', '8', '266');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1302, '2587758837', NULL, 'Toy-P002', '8', '266');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1303, '6597555389', NULL, 'Toy-P003', '8', '266');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1304, '3216147316', NULL, 'Toy-P004', '8', '196');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1305, '9415341859', NULL, 'Toy-P005', '8', '196');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1306, '6154725816', NULL, 'Toy-P006', '8', '336');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1307, '7383239876', NULL, 'Toy-P007', '8', '266');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1308, '2589315856', NULL, 'Toy-P008', '8', '266');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1309, '6383943821', NULL, 'Toy-P009', '8', '406');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1310, '7788187267', NULL, 'Toy-P010', '8', '406');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1311, '9756791793', NULL, 'Toy-P011', '8', '266');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1312, '4688849523', NULL, 'Toy-P012', '8', '406');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1313, '6266441947', NULL, 'Toy-P013', '8', '196');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1314, '8482923715', NULL, 'Toy-P014', '8', '196');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1315, '5355575419', NULL, 'Toy-P015', '8', '266');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1316, '3549868159', NULL, 'Toy-P016', '8', '196');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1317, '5955849994', NULL, 'Toy-P017', '8', '266');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1318, '6172666532', NULL, 'Toy-P018', '8', '266');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1319, '9468354319', NULL, 'Toy-P019', '8', '266');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1320, '3813922592', NULL, 'Toy-P020', '8', '140');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1321, '5611723662', NULL, 'Toy-P021', '8', '112');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1322, '7745565743', NULL, 'Wb/829 ', '1', '266');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1323, '9156948729', NULL, 'Wb/829', '1', '266');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1324, '9871776313', NULL, 'Wb3018', '1', '231');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1325, '9388444748', NULL, 'Wb/1001', '1', '266');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1326, '5479632187', NULL, 'R834', '1', '266');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1327, '6115617324', NULL, 'Wb0182 ', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1328, '6221972843', NULL, 'Wb0182', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1329, '4964122233', NULL, 'Wb0182', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1330, '5649626525', NULL, 'Wb0182', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1331, '9218395129', NULL, 'Yb0368', '1', '245');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1332, '7425752845', NULL, 'Yb0368', '1', '245');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1333, '4276718351', NULL, 'Yb0183', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1334, '6635132871', NULL, 'Wb834', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1335, '5784938689', NULL, 'Wb5', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1336, '8342231862', NULL, 'Sh7058', '1', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1337, '9242553832', NULL, 'Yb0300', '1', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1338, '6971763861', NULL, 'Yb0300', '1', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1339, '3332534123', NULL, 'Wb/2', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1340, '8848744493', NULL, 'Tc1706', '1', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1341, '3657588586', NULL, 'Wb508', '1', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1342, '6653927415', NULL, 'Wb508', '1', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1343, '3716464163', NULL, 'WB/2', '1', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1344, '7187335353', NULL, 'Wb835', '1', '231');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1345, '1438415792', NULL, 'Wb15', '1', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1346, '4211458826', NULL, 'Yb0287', '1', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1347, '6284152458', NULL, 'WB001', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1348, '5747788221', NULL, 'Wb7', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1349, '1847796185', NULL, 'Yb0455', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1350, '2315661252', NULL, 'WB002', '1', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1351, '4894391722', NULL, 'Wb1915', '1', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1352, '7519286336', NULL, '35X35', '7', '1155');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1353, '7254371939', NULL, '33X33', '7', '875');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1354, '5763219292', NULL, '14X18', '7', '1750');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1355, '6718929313', NULL, '40X40', '7', '1750');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1356, '9844574493', NULL, '80X120', '7', '2835');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1357, '1285963571', NULL, '20\"/48\"-04', '7', '4550');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1358, '4791525788', NULL, '33X19', '7', '2450');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1359, '5528939873', NULL, '58X78', '7', '4550');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1360, '3762399187', NULL, '14X35 (Broken)', '7', '3150');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1361, '8784617559', NULL, '55X45', '7', '4550');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1362, '2589545585', NULL, '43X107', '7', '3850');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1363, '4296238496', NULL, '34X20 (Broken)', '7', '3150');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1364, '1712268466', NULL, '14x39', '7', '3150');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1365, '1621461257', NULL, '8362-3', '7', '1560');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1366, '4787973764', NULL, '8449-3', '7', '1480');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1367, '7134861768', NULL, '8380-3', '7', '1640');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1368, '1352551445', NULL, '8285-3', '7', '1560');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1369, '3775968268', NULL, '8428-3', '7', '1480');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1370, '9474167282', NULL, '8389-3', '7', '1480');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1371, '5125953783', NULL, '8673-3', '7', '1480');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1372, '4549311367', NULL, '8449-2', '7', '1200');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1373, '8158978193', NULL, '8285-2', '7', '1320');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1374, '7761151117', NULL, '8389-2', '7', '1160');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1375, '4864344618', NULL, '8673-2', '7', '1160');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1376, '8985563232', NULL, '8380-2', '7', '1200');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1377, '8723996628', NULL, '8362-2', '7', '1160');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1378, '8583743544', NULL, '8428-2', '7', '1160');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1379, '9242191646', NULL, '8380-1', '7', '760');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1380, '8521294725', NULL, '6558-1', '7', '840');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1381, '3572826829', NULL, '6028-1', '7', '840');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1382, '6388377971', NULL, '6559-1', '7', '840');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1383, '5882365983', NULL, '6115-1', '7', '840');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1384, '4678767866', NULL, '6116-1', '7', '840');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1385, '2773128755', NULL, '6033-1', '7', '840');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1386, '7879424624', NULL, '904-1', '7', '1520');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1387, '3811868318', NULL, '6031-1', '7', '840');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1388, '5827294692', NULL, '6010-1', '7', '840');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1389, '1574517465', NULL, '6032-1', '7', '840');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1390, '6336835645', NULL, '1007-1', '7', '1160');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1391, '5691759133', NULL, '6116-1', '7', '1000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1392, '4114291998', NULL, 'SW-1001-2', '7', '1640');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1393, '5923177915', NULL, 'SW-1001-1', '7', '1200');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1394, '4477218242', NULL, 'SW-9607', '7', '2520');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1395, '5938734446', NULL, 'Led 3039', '7', '2000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1396, '6227428345', NULL, 'YMA42702', '7', '2320');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1397, '8736363628', NULL, 'JY934', '7', '1480');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1398, '8247173398', NULL, 'JY834-2', '7', '2000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1399, '5142112254', NULL, '2019 F', '7', '7600');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1400, '9945848631', NULL, '2019 FBK', '7', '7600');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1401, '5671122759', NULL, '2130 WT', '7', '7600');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1402, '3868344125', NULL, 'Rose 247-1', '7', '14800');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1403, '6385372875', NULL, '1007-5', '7', '6600');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1404, '4224577618', NULL, '1007-3', '7', '4550');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1405, '2165964147', NULL, '1638-3', '7', '4550');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1406, '9461194189', NULL, 'Led-KX 3109-5/1', '7', '6650');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1407, '5583132422', NULL, '1001-3', '7', '3639');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1408, '2181578571', NULL, 'HY-702A', '7', '2100');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1409, '8748569214', NULL, '4283C', '7', '3150');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1410, '6791738464', NULL, '4944CD', '7', '2450');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1411, '9332347748', NULL, '419-3', '7', '8050');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1412, '9466527335', NULL, 'YMA409', '7', '5950');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1413, '7728236872', NULL, 'YMA408', '7', '4550');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1414, '7792457193', NULL, 'K-001', '1', '84');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1415, '8683818289', NULL, 'K-001', '1', '84');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1416, '3868715159', NULL, 'K-001', '1', '84');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1417, '8791175712', NULL, 'K-002', '1', '140');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1418, '6792647685', NULL, 'K-003', '1', '140');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1419, '2426449979', NULL, 'K-003', '1', '105');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1420, '4345972137', NULL, 'K-003', '1', '84');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1421, '5383622398', NULL, 'K-004', '1', '105');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1422, '5361976622', NULL, 'K-005', '1', '42');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1423, '6762984372', NULL, 'K-005', '1', '42');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1424, '6478641553', NULL, 'K-005', '1', '42');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1425, '3816715459', NULL, 'K-006', '1', '42');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1426, '1379179656', NULL, 'K-007', '1', '53');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1427, '3788569735', NULL, 'K-008', '1', '70');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1428, '5312398482', NULL, 'K-009', '1', '224');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1429, '2253357798', NULL, 'K-010', '1', '210');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1430, '8374723334', NULL, 'K-011', '1', '126');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1431, '5895833899', NULL, 'K-012', '1', '154');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1432, '8366497845', NULL, 'K-013', '1', '112');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1433, '6943913199', NULL, 'K-014', '1', '63');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1434, '9882333377', NULL, 'K-015', '1', '63');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1435, '1974593592', NULL, 'K-016', '1', '39');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1436, '1691256715', NULL, 'K-017', '1', '105');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1437, '3646169144', NULL, 'PC00101', '7', '455');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1438, '4731656898', NULL, 'PC00101', '7', '455');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1439, '9853979343', NULL, 'PC00101', '7', '455');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1440, '8448297834', NULL, 'PC00102KH', '7', '455');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1441, '3918787797', NULL, 'PC00102KH', '7', '455');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1442, '8194184131', NULL, 'PC00102KH', '7', '455');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1443, '4649489127', NULL, 'PC00102KH', '7', '455');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1444, '6631354956', NULL, 'PC00102KH', '7', '455');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1445, '8431665648', NULL, 'PC00102KH', '7', '455');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1446, '2288429644', NULL, 'PC00103BV', '7', '350');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1447, '1264399497', NULL, 'PC00105BV', '7', '350');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1448, '6778349271', NULL, 'PC00106CH', '7', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1449, '8199936393', NULL, 'PC00106CH', '7', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1450, '2921981377', NULL, 'PC00106CH', '7', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1451, '6927629576', NULL, 'PC00106CH', '7', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1452, '7365286362', NULL, 'PC00106CH', '7', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1453, '3367849784', NULL, 'G9', '7', '84');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1454, '9269547778', NULL, 'Bulb-E14/5W/etLamp', '7', '175');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1455, '4746227998', NULL, 'Bulb-E14/5W/Candle', '7', '175');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1456, '8133447675', NULL, '7W/Mini', '7', '154');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1457, '4214921283', NULL, 'E27/8W', '7', '175');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1458, '1715547117', NULL, 'E27/6W-WW', '7', '140');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1459, '3888923876', NULL, 'E27/6W-WH', '7', '140');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1460, '8173979762', NULL, 'E27/4W-WH', '7', '140');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1461, '3369284916', NULL, 'LED-3W/E27', '7', '130');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1462, '8974832275', NULL, 'LED-5W/E27', '7', '182');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1463, '4959362719', NULL, 'LED-12W/E27', '7', '175');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1464, '1893171162', NULL, 'E27Bulb/5W/WH', '7', '245');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1465, '3748145941', NULL, 'Led panel light 6w', '7', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1466, '6685128291', NULL, 'Led panel light 12w', '7', '490');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1467, '8771958316', NULL, 'Led panel light 18w', '7', '735');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1468, '9676395479', NULL, '119', '7', '875');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1469, '7639184328', NULL, '018 AW', '7', '1015');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1470, '8775659775', NULL, '1611', '7', '1855');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1471, '9936454561', NULL, '1607', '7', '1505');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1472, '8471873817', NULL, '1702', '7', '1225');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1473, '1572784281', NULL, '21146 M', '7', '3673');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1474, '3462185241', NULL, '21146 S', '7', '1495');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1475, '9693356528', NULL, '21150 Big', '7', '3640');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1476, '7729437368', NULL, '21140 S', '7', '1528');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1477, '8775374478', NULL, '21140 M', '7', '1528');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1478, '1877871455', NULL, '21125 B', '7', '3250');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1479, '3355184967', NULL, 'london B', '7', '2048');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1480, '4998541414', NULL, 'london s', '7', '1528');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1481, '7915996729', NULL, 'am 21151 b', '7', '3640');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1482, '6793758677', NULL, 'am 21151 s', '7', '2048');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1483, '1449131818', NULL, 'route us', '7', '1625');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1484, '3537432733', NULL, '1368-1W', '7', '875');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1485, '3411725542', NULL, '1366-1W', '7', '805');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1486, '6156259449', NULL, '1366-2W', '7', '945');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1487, '5893766676', NULL, '1368-2B', '7', '560');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1488, '9958755178', NULL, '1513-2W', '7', '735');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1489, '8314955323', NULL, '804020', '7', '560');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1490, '6576253123', NULL, '4046', '7', '1050');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1491, '7368682344', NULL, '4046-1', '7', '1050');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1492, '1774294894', NULL, 'X1513-2', '7', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1493, '3888573892', NULL, '1506-2B', '7', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1494, '9347183474', NULL, 'X1604-1W', '7', '945');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1495, '7571389961', NULL, '1728-20', '7', '1295');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1496, '7589918791', NULL, 'RXP1760', '7', '1505');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1497, '7963824133', NULL, 'FV42', '7', '595');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1498, '8894121418', NULL, '20266', '7', '2170');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1499, '4272269746', NULL, '1476', '1', '350');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1500, '8156426384', NULL, '1475', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1501, '8639316388', NULL, '1479', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1502, '5151682145', NULL, '1474', '1', '525');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1503, '5736534613', NULL, '1477', '1', '266');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1504, '1225779238', NULL, '1480', '1', '434');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1505, '5147664136', NULL, '57205AB', '1', '945');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1506, '1496864177', NULL, '57014', '1', '1505');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1507, '6411363118', NULL, '55040', '1', '945');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1508, '3636247216', NULL, '57208AB', '1', '1435');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1509, '8276583296', NULL, '55041', '1', '980');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1510, '8581244378', NULL, 'BC001', '1', '70');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1511, '1751913229', NULL, 'FB001', '1', '175');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1512, '9345895741', NULL, 'FB002', '1', '175');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1513, '3179468369', NULL, 'BB001', '1', '126');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1514, '3612586662', NULL, 'Dsp/ht723 h ', '1', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1515, '3661178636', NULL, 'Ht 709', '1', '245');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1516, '1875954849', NULL, '694 mn', '1', '175');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1517, '8386597229', NULL, 'Ht 710', '1', '245');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1518, '2944445477', NULL, 'Ht 746', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1519, '9553824787', NULL, 'Ht 678 694 662', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1520, '4356857726', NULL, '693MNHT', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1521, '2535861418', NULL, 'Ht 716-719', '1', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1522, '7327788284', NULL, 'Ht 678 694 662', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1523, '4171628256', NULL, 'D797', '1', '245');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1524, '7852185389', NULL, '799', '1', '1050');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1525, '8134848378', NULL, '798', '1', '1050');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1526, '2796316243', NULL, '8835', '1', '406');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1527, '7128257135', NULL, 'Doll731', '1', '1085');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1528, '1881141945', NULL, 'DOLL002', '1', '875');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1529, '6146887462', NULL, 'BATH001', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1530, '9157843235', NULL, 'BATH002', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1531, '6916266689', NULL, 'BATH003', '1', '245');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1532, '3261715844', NULL, 'BATH004', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1533, '7387492387', NULL, 'Pb001', '1', '126');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1534, '3943156931', NULL, 'PB002', '1', '84');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1535, '3922464412', NULL, 'PB003', '1', '154');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1536, '7951826655', NULL, 'PB004', '1', '84');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1537, '9817352545', NULL, 'PB005', '1', '175');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1538, '7475574177', NULL, 'Pb49', '1', '175');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1539, '5721956357', NULL, 'Ppb16', '1', '154');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1540, '1758962473', NULL, 'PB006', '1', '175');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1541, '9663334526', NULL, 'PB007', '1', '175');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1542, '2898541134', NULL, 'PB008', '1', '175');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1543, '6355833187', NULL, 'DB001', '1', '25');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1544, '4772357459', NULL, 'KDBAG001', '1', '88');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1545, '7575119292', NULL, 'PB009', '1', '77');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1546, '8772174952', NULL, 'PB009', '1', '77');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1547, '3793446322', NULL, 'PB010', '1', '77');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1548, '7531226315', NULL, 'PB011', '1', '77');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1549, '8299483435', NULL, 'smbl001', '1', '42');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1550, '3174358829', NULL, 'F912115', '1', '1050');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1551, '3598136974', NULL, '172820', '1', '1050');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1552, '4779176332', NULL, '172822', '1', '1050');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1553, '8755342512', NULL, '88033', '1', '1050');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1554, '6492464222', NULL, 'BCAP001', '1', '56');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1555, '2653546847', NULL, 'PF001', '1', '525');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1556, '5783949963', NULL, 'Lb/36', '1', '455');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1557, '3546476262', NULL, 'Lb28', '1', '525');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1558, '8726877253', NULL, 'RXP1760', '1', '1505');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1559, '4356559522', NULL, 'AC986', '1', '525');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1560, '3865799311', NULL, 'SP989', '1', '1505');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1561, '9315293646', NULL, 'GI9867', '1', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1562, '2686964189', NULL, 'A019/dsp', '1', '1750');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1563, '9567358571', NULL, 'Fv 1728-20', '1', '1155');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1564, '8433656227', NULL, 'A306761KK', '1', '1995');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1565, '8889774962', NULL, '1472', '1', '595');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1566, '4945145475', NULL, '1528', '1', '595');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1567, '6245924189', NULL, '1527', '1', '735');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1568, '1794331936', NULL, '1529', '1', '665');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1569, '7778768179', NULL, 'Stk0001', '1', '70');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1570, '2442167486', NULL, '25-5', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1571, '7986643133', NULL, '26-5', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1572, '5993973622', NULL, '27-5', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1573, '3414341841', NULL, '28-5', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1574, '5467658335', NULL, '29-5', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1575, '7349339287', NULL, '30-5', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1576, '2928673471', NULL, '31-5', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1577, '5212751528', NULL, '32-5', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1578, '6168732427', NULL, '33-5', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1579, '8222998136', NULL, '34-5', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1580, '7745722499', NULL, '25-2', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1581, '6657254624', NULL, '26-2', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1582, '4524372291', NULL, '27-2', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1583, '9476132341', NULL, '28-2', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1584, '4276254844', NULL, '29-2', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1585, '8855144362', NULL, '30-2', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1586, '9955473519', NULL, '31-2', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1587, '7913475313', NULL, '32-2', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1588, '4976612786', NULL, '33-2', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1589, '3248677234', NULL, '34-2', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1590, '9763636733', NULL, '25-5/S', '1', '1546');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1591, '3991252413', NULL, '26-5/S', '1', '1546');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1592, '1471322244', NULL, '27-5/S', '1', '1546');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1593, '5434287897', NULL, '28-5/S', '1', '1546');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1594, '4681988277', NULL, '29-5/S', '1', '1546');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1595, '7892264711', NULL, '30-5/S', '1', '1546');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1596, '6346524972', NULL, '31-5/S', '1', '1546');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1597, '6971122634', NULL, '32-5/S', '1', '1546');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1598, '7116399541', NULL, '33-5/S', '1', '1546');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1599, '9158224945', NULL, '34-5/S', '1', '1546');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1600, '5523614964', NULL, '25-2/S', '1', '110');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1601, '7383479178', NULL, '26-2/S', '1', '110');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1602, '1732142261', NULL, '27-2/S', '1', '110');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1603, '1741995785', NULL, '28-2/S', '1', '110');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1604, '1328211823', NULL, '29-2/S', '1', '110');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1605, '2897853159', NULL, '30-2/S', '1', '110');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1606, '8357251975', NULL, '31-2/S', '1', '110');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1607, '2525235115', NULL, '32-2/S', '1', '110');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1608, '9524699664', NULL, '33-2/S', '1', '110');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1609, '7546258442', NULL, '34-2/S', '1', '110');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1610, '3287899614', NULL, '85', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1611, '8948441747', NULL, '85', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1612, '3931264342', NULL, '85', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1613, '8683614675', NULL, '85', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1614, '5211268329', NULL, '85', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1615, '1381994315', NULL, '85', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1616, '3819174196', NULL, '85', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1617, '5176769332', NULL, '85', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1618, '7587773347', NULL, '89', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1619, '7845749193', NULL, '89', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1620, '1146627857', NULL, '89', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1621, '9731453239', NULL, '89', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1622, '1468348889', NULL, '89', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1623, '7515936169', NULL, '89', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1624, '8839958178', NULL, '68', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1625, '1823492816', NULL, '69', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1626, '2492397632', NULL, '83', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1627, '9763679568', NULL, '83', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1628, '7834631769', NULL, '81', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1629, '8778216668', NULL, '81', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1630, '5462987782', NULL, '88', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1631, '5282978954', NULL, '88', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1632, '3685285562', NULL, '88', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1633, '9991268494', NULL, '92', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1634, '8912639169', NULL, '66', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1635, '5467885496', NULL, '66', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1636, '5649248295', NULL, '66', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1637, '9393395465', NULL, '101', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1638, '8293533621', NULL, '66', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1639, '3832526897', NULL, '85', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1640, '9798827582', NULL, 'RS41/C', '9', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1641, '5249532658', NULL, 'RS41/C', '9', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1642, '9178423151', NULL, 'RS41/C', '9', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1643, '4663231855', NULL, 'RS39/S', '9', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1644, '2924997152', NULL, 'RS39/S', '9', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1645, '9686748291', NULL, 'RS39/S', '9', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1646, '9853845729', NULL, '41-SP', '9', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1647, '9363856362', NULL, '41-SP', '9', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1648, '4526328571', NULL, '41-SP', '9', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1649, '2557847498', NULL, '39-SP', '9', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1650, '1541981328', NULL, '39-SP', '9', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1651, '2224148215', NULL, '39-SP', '9', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1652, '5444199685', NULL, 'E008MF', '9', '3250');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1653, '1628887476', NULL, '18871MF-C', '9', '11500');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1654, '4436355768', NULL, '18871MF-D', '9', '11500');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1655, '8286949898', NULL, 'C02-MFG', '9', '4850');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1656, '7187281177', NULL, 'CT-021MFG', '9', '4850');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1657, '8996144858', NULL, 'Con-102-MFG', '9', '6500');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1658, '7561426156', NULL, 'T-50129-MFG', '9', '7000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1659, '1986126866', NULL, '155224', '1', '12900');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1660, '6128654731', NULL, '15656', '1', '13000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1661, '3562776686', NULL, '15382', '1', '13000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1662, '8656269496', NULL, '15556', '1', '12500');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1663, '7762498588', NULL, '15677', '1', '12500');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1664, '3519729629', NULL, '15661', '1', '13000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1665, '4523284842', NULL, '15665', '1', '12800');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1666, '6859215162', NULL, '15690', '1', '13000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1667, '1946125862', NULL, '15692', '1', '13000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1668, '1939281645', NULL, '15383', '1', '13000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1669, '1966586477', NULL, '15490', '1', '13500');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1670, '1661629789', NULL, '15728', '1', '12000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1671, '1784256613', NULL, '15724', '1', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1672, '3343717344', NULL, '17034', '1', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1673, '4543759142', NULL, '15470', '1', '8000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1674, '4677878167', NULL, 'PF6030', '7', '291');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1675, '1388325724', NULL, 'PF6030', '7', '291');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1676, '3878448557', NULL, 'PF6560', '7', '291');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1677, '8115741248', NULL, 'PF6560', '7', '291');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1678, '3894663248', NULL, 'PF6560', '7', '291');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1679, '6599896536', NULL, 'PF6014', '7', '455');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1680, '3932588492', NULL, 'PF661', '7', '595');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1681, '5983835758', NULL, 'PF6563', '7', '350');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1682, '7122375491', NULL, '20x16', '7', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1683, '5456816662', NULL, '20x16', '7', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1684, '5813717826', NULL, '17.5?12.5', '7', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1685, '1688326333', NULL, '17.5?12.5', '7', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1686, '4264563799', NULL, 'PF-6509', '7', '1435');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1687, '8688656421', NULL, 'PF-6504', '7', '875');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1688, '6957691685', NULL, '215 M', '7', '1050');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1689, '5899796879', NULL, '215 S', '7', '840');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1690, '9543494715', NULL, 'YD1040', '7', '735');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1691, '9163913727', NULL, 'YJ1709/PF', '7', '1050');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1692, '3267536235', NULL, 'J1710/PF', '7', '1050');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1693, '3679533331', NULL, 'YD1028/PF', '7', '1085');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1694, '1398457376', NULL, 'YD1616/PF', '7', '1085');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1695, '8265221425', NULL, 'J1612', '7', '1240');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1696, '6732376949', NULL, 'J1612', '7', '1240');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1697, '6492939329', NULL, 'J1612', '7', '1240');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1698, '2575246829', NULL, 'BH2701/PF', '7', '1240');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1699, '4781369396', NULL, 'Hy2218', '7', '2040');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1700, '7951126373', NULL, 'HB 12-38', '7', '1640');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1701, '6548732391', NULL, '39-18', '7', '2000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1702, '2128743831', NULL, 'Q1609/PF', '7', '1240');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1703, '4223845867', NULL, 'Collage 08', '7', '1240');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1704, '5846681256', NULL, '10', '7', '1240');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1705, '7843188642', NULL, 'Q101-8', '7', '2250');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1706, '4525275326', NULL, 'Q083-8', '7', '3350');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1707, '8954925695', NULL, 'Q031-10', '7', '3350');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1708, '6533757282', NULL, 'Q099-8', '7', '2250');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1709, '8834142276', NULL, 'Q066-5', '7', '2050');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1710, '6643536524', NULL, 'Q087-12', '7', '3850');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1711, '1651681596', NULL, 'Q069', '7', '2850');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1712, '3138568759', NULL, 'Q001', '7', '3850');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1713, '2767594443', NULL, 'Q067', '7', '2750');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1714, '8781494983', NULL, 'Q068', '7', '2750');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1715, '7682449616', NULL, 'RC0011', '7', '6650');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1716, '7812968872', NULL, 'RC0011', '7', '6650');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1717, '4748539189', NULL, '1109', '7', '2660');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1718, '7811167136', NULL, '11011', '7', '1330');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1719, '5721973117', NULL, 'HK17566/PR', '7', '4200');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1720, '1657132614', NULL, '1109', '7', '1750');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1721, '1526772696', NULL, '1633', '7', '2030');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1722, '7917978675', NULL, '2053', '7', '9450');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1723, '7713114774', NULL, NULL, '7', '6650');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1724, '5456335791', NULL, 'E008C', '7', '3500');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1725, '4547458858', NULL, '50006', '7', '10150');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1726, '2537356327', NULL, 'C4-60', '7', '10850');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1727, '1774569954', NULL, 'Lc031B', '7', '12950');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1728, '8834689781', NULL, 'Lc031S', '7', '6650');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1729, '7981434196', NULL, 'VB007', '7', '735');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1730, '6485244921', NULL, 'MS005-1', '7', '7350');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1731, '1956122769', NULL, 'MS005-2', '7', '7350');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1732, '5358955219', NULL, 'AM-1050', '7', '16450');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1733, '6594858479', NULL, 'AM-6046', '7', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1734, '5416847952', NULL, 'AM-093', '7', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1735, '4623855639', NULL, 'DL-3161', '7', '3150');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1736, '1616663254', NULL, 'BM-135', '7', '1890');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1737, '8446716235', NULL, 'BM-01', '7', '2660');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1738, '4581288953', NULL, 'BM-08', '7', '2660');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1739, '4852756846', NULL, 'Dl-28', '7', '4550');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1740, '7259649121', NULL, '18872C', '7', '17500');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1741, '1844335223', NULL, '18873C', '7', '24850');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1742, '1951474262', NULL, 'CT005678', '7', '10850');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1743, '7193712679', NULL, 'D-009', '7', '805');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1744, '9676541818', NULL, 'D-019', '7', '896');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1745, '7474567968', NULL, 'D-03', '7', '875');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1746, '3193697553', NULL, 'D-0011H', '7', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1747, '2843448676', NULL, 'Multi', '7', '1295');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1748, '5826215539', NULL, 'P001091', '7', '1575');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1749, '1491295228', NULL, 'P00109C', '7', '2450');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1750, '9497711351', NULL, 'SC0056', '7', '1050');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1751, '7121658263', NULL, 'T00081', '7', '735');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1752, '3897289175', NULL, '00001SC', '7', '1750');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1753, '9354329297', NULL, NULL, '7', '4200');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1754, '8463461973', NULL, NULL, '7', '2800');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1755, '5836937936', NULL, 'Sp10211', '1', '84');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1756, '7179582382', NULL, 'Sp10212', '1', '105');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1757, '1284214894', NULL, 'Sp10213', '1', '84');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1758, '6355455496', NULL, '1487', '1', '175');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1759, '5411449439', NULL, '1485', '1', '112');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1760, '9854484865', NULL, '1487', '1', '196');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1761, '1958542787', NULL, '1488', '1', '182');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1762, '7296885436', NULL, '1489', '1', '175');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1763, '8336613828', NULL, '1484', '1', '84');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1764, '4776353942', NULL, '1519', '1', '350');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1765, '4794145914', NULL, '1482', '1', '147');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1766, '5829632725', NULL, '1481', '1', '175');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1767, '6617772229', NULL, 'Ox102106', '1', '350');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1768, '5153558287', NULL, 'M102107', '1', '14');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1769, '4476986769', NULL, 'M102108', '1', '140');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1770, '2988747547', NULL, 'A102109', '1', '35');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1771, '8149496468', NULL, 'Psb007', '1', '875');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1772, '3387373113', NULL, 'Psb007', '1', '875');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1773, '7163295893', NULL, 'Ssb001', '1', '875');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1774, '9144438525', NULL, 'Csb009', '1', '1015');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1775, '2697847714', NULL, 'Ssb001', '1', '945');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1776, '3152687514', NULL, 'Ssb001', '1', '875');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1777, '1521534753', NULL, '1aaa3', '1', '1575');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1778, '7665475447', NULL, 'E2cB', '1', '735');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1779, '1714734745', NULL, 'E2cB', '1', '595');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1780, '1936192947', NULL, 'Az003', '1', '140');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1781, '7816538598', NULL, 'Toy-P001', '8', '266');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1782, '2364966746', NULL, 'Toy-P002', '8', '266');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1783, '7337128343', NULL, 'Toy-P003', '8', '266');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1784, '5362252491', NULL, 'Toy-P004', '8', '196');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1785, '7856197661', NULL, 'Toy-P005', '8', '196');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1786, '1325945613', NULL, 'Toy-P006', '8', '336');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1787, '4996339558', NULL, 'Toy-P007', '8', '266');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1788, '6775156147', NULL, 'Toy-P008', '8', '266');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1789, '1489974641', NULL, 'Toy-P009', '8', '406');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1790, '2222845374', NULL, 'Toy-P010', '8', '406');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1791, '7821948656', NULL, 'Toy-P011', '8', '266');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1792, '5525529348', NULL, 'Toy-P012', '8', '406');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1793, '7447259756', NULL, 'Toy-P013', '8', '196');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1794, '5986549165', NULL, 'Toy-P014', '8', '196');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1795, '1991925882', NULL, 'Toy-P015', '8', '266');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1796, '1481768323', NULL, 'Toy-P016', '8', '196');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1797, '4951517384', NULL, 'Toy-P017', '8', '266');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1798, '9229714897', NULL, 'Toy-P018', '8', '266');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1799, '7799887744', NULL, 'Toy-P019', '8', '266');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1800, '2687114533', NULL, 'Toy-P020', '8', '140');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1801, '2526361218', NULL, 'Toy-P021', '8', '112');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1802, '7942296147', NULL, 'Wb/829 ', '1', '266');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1803, '5693132226', NULL, 'Wb/829', '1', '266');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1804, '6372232442', NULL, 'Wb3018', '1', '231');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1805, '3214855398', NULL, 'Wb/1001', '1', '266');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1806, '7638847224', NULL, 'R834', '1', '266');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1807, '2154852136', NULL, 'Wb0182 ', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1808, '9514626874', NULL, 'Wb0182', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1809, '2266452431', NULL, 'Wb0182', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1810, '3857446585', NULL, 'Wb0182', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1811, '8681178975', NULL, 'Yb0368', '1', '245');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1812, '8621687264', NULL, 'Yb0368', '1', '245');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1813, '3896241838', NULL, 'Yb0183', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1814, '2239514375', NULL, 'Wb834', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1815, '2454313369', NULL, 'Wb5', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1816, '5871133998', NULL, 'Sh7058', '1', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1817, '8256549476', NULL, 'Yb0300', '1', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1818, '4775217826', NULL, 'Yb0300', '1', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1819, '3365889544', NULL, 'Wb/2', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1820, '7324616845', NULL, 'Tc1706', '1', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1821, '3995889734', NULL, 'Wb508', '1', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1822, '4383295736', NULL, 'Wb508', '1', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1823, '2184223953', NULL, 'WB/2', '1', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1824, '6881522332', NULL, 'Wb835', '1', '231');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1825, '3887149724', NULL, 'Wb15', '1', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1826, '2535481353', NULL, 'Yb0287', '1', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1827, '4723879732', NULL, 'WB001', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1828, '5412862513', NULL, 'Wb7', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1829, '8155155781', NULL, 'Yb0455', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1830, '7184626346', NULL, 'WB002', '1', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1831, '3263825584', NULL, 'Wb1915', '1', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1832, '1659148438', NULL, '35X35', '7', '1155');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1833, '3988659228', NULL, '33X33', '7', '875');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1834, '2497451472', NULL, '14X18', '7', '1750');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1835, '7618891693', NULL, '40X40', '7', '1750');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1836, '7817753546', NULL, '80X120', '7', '2835');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1837, '8539332635', NULL, '20\"/48\"-04', '7', '4550');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1838, '3481128289', NULL, '33X19', '7', '2450');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1839, '3985977837', NULL, '58X78', '7', '4550');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1840, '6419295676', NULL, '14X35 (Broken)', '7', '3150');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1841, '1378574731', NULL, '55X45', '7', '4550');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1842, '3716439677', NULL, '43X107', '7', '3850');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1843, '9149321267', NULL, '34X20 (Broken)', '7', '3150');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1844, '6964693715', NULL, '14x39', '7', '3150');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1845, '5151724583', NULL, '8362-3', '7', '1560');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1846, '5651819871', NULL, '8449-3', '7', '1480');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1847, '6896494472', NULL, '8380-3', '7', '1640');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1848, '9215493686', NULL, '8285-3', '7', '1560');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1849, '4212971687', NULL, '8428-3', '7', '1480');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1850, '3414534497', NULL, '8389-3', '7', '1480');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1851, '3553589333', NULL, '8673-3', '7', '1480');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1852, '7779826915', NULL, '8449-2', '7', '1200');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1853, '9831756442', NULL, '8285-2', '7', '1320');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1854, '1846597589', NULL, '8389-2', '7', '1160');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1855, '4873936963', NULL, '8673-2', '7', '1160');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1856, '9981356769', NULL, '8380-2', '7', '1200');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1857, '2837624626', NULL, '8362-2', '7', '1160');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1858, '9923263575', NULL, '8428-2', '7', '1160');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1859, '5866546642', NULL, '8380-1', '7', '760');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1860, '3882899717', NULL, '6558-1', '7', '840');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1861, '7299719325', NULL, '6028-1', '7', '840');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1862, '2865779358', NULL, '6559-1', '7', '840');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1863, '9391665887', NULL, '6115-1', '7', '840');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1864, '7451229538', NULL, '6116-1', '7', '840');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1865, '2418191618', NULL, '6033-1', '7', '840');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1866, '1172882327', NULL, '904-1', '7', '1520');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1867, '9487586312', NULL, '6031-1', '7', '840');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1868, '1253227124', NULL, '6010-1', '7', '840');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1869, '2733565822', NULL, '6032-1', '7', '840');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1870, '2669515485', NULL, '1007-1', '7', '1160');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1871, '4738345349', NULL, '6116-1', '7', '1000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1872, '2624192221', NULL, 'SW-1001-2', '7', '1640');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1873, '7697457661', NULL, 'SW-1001-1', '7', '1200');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1874, '6851862695', NULL, 'SW-9607', '7', '2520');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1875, '7878344717', NULL, 'Led 3039', '7', '2000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1876, '3984598136', NULL, 'YMA42702', '7', '2320');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1877, '3561426775', NULL, 'JY934', '7', '1480');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1878, '1857455542', NULL, 'JY834-2', '7', '2000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1879, '4844828618', NULL, '2019 F', '7', '7600');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1880, '5798818311', NULL, '2019 FBK', '7', '7600');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1881, '1666121233', NULL, '2130 WT', '7', '7600');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1882, '6179592637', NULL, 'Rose 247-1', '7', '14800');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1883, '4455235728', NULL, '1007-5', '7', '6600');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1884, '9566559758', NULL, '1007-3', '7', '4550');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1885, '4189583223', NULL, '1638-3', '7', '4550');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1886, '7641656141', NULL, 'Led-KX 3109-5/1', '7', '6650');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1887, '4417729634', NULL, '1001-3', '7', '3639');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1888, '6825961727', NULL, 'HY-702A', '7', '2100');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1889, '7142391575', NULL, '4283C', '7', '3150');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1890, '4558643141', NULL, '4944CD', '7', '2450');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1891, '6727547876', NULL, '419-3', '7', '8050');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1892, '9428766439', NULL, 'YMA409', '7', '5950');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1893, '9436493366', NULL, 'YMA408', '7', '4550');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1894, '4389923924', NULL, 'K-001', '1', '84');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1895, '5783743857', NULL, 'K-001', '1', '84');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1896, '8346482515', NULL, 'K-001', '1', '84');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1897, '8522121246', NULL, 'K-002', '1', '140');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1898, '5636143218', NULL, 'K-003', '1', '140');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1899, '3222392792', NULL, 'K-003', '1', '105');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1900, '8162543376', NULL, 'K-003', '1', '84');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1901, '8578649868', NULL, 'K-004', '1', '105');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1902, '1662226141', NULL, 'K-005', '1', '42');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1903, '8881466445', NULL, 'K-005', '1', '42');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1904, '1445643496', NULL, 'K-005', '1', '42');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1905, '8736531684', NULL, 'K-006', '1', '42');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1906, '2193666491', NULL, 'K-007', '1', '53');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1907, '2874348893', NULL, 'K-008', '1', '70');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1908, '1372816443', NULL, 'K-009', '1', '224');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1909, '1926125957', NULL, 'K-010', '1', '210');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1910, '2578464735', NULL, 'K-011', '1', '126');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1911, '7471621818', NULL, 'K-012', '1', '154');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1912, '6239417165', NULL, 'K-013', '1', '112');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1913, '9983826496', NULL, 'K-014', '1', '63');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1914, '3856761377', NULL, 'K-015', '1', '63');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1915, '9635795933', NULL, 'K-016', '1', '39');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1916, '1378334487', NULL, 'K-017', '1', '105');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1917, '7793145261', NULL, 'PC00101', '7', '455');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1918, '5517693943', NULL, 'PC00101', '7', '455');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1919, '9998558999', NULL, 'PC00101', '7', '455');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1920, '3751868175', NULL, 'PC00102KH', '7', '455');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1921, '1251316439', NULL, 'PC00102KH', '7', '455');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1922, '2652429628', NULL, 'PC00102KH', '7', '455');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1923, '3245877483', NULL, 'PC00102KH', '7', '455');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1924, '3569248262', NULL, 'PC00102KH', '7', '455');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1925, '3869428754', NULL, 'PC00102KH', '7', '455');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1926, '1333296735', NULL, 'PC00103BV', '7', '350');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1927, '7749582194', NULL, 'PC00105BV', '7', '350');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1928, '7895532574', NULL, 'PC00106CH', '7', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1929, '4321319594', NULL, 'PC00106CH', '7', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1930, '8485869235', NULL, 'PC00106CH', '7', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1931, '4274772749', NULL, 'PC00106CH', '7', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1932, '5557372831', NULL, 'PC00106CH', '7', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1933, '7596369422', NULL, 'G9', '7', '84');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1934, '6241595384', NULL, 'Bulb-E14/5W/etLamp', '7', '175');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1935, '8534854558', NULL, 'Bulb-E14/5W/Candle', '7', '175');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1936, '7911415376', NULL, '7W/Mini', '7', '154');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1937, '2183232124', NULL, 'E27/8W', '7', '175');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1938, '1343236229', NULL, 'E27/6W-WW', '7', '140');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1939, '6144849587', NULL, 'E27/6W-WH', '7', '140');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1940, '9851863362', NULL, 'E27/4W-WH', '7', '140');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1941, '5485221268', NULL, 'LED-3W/E27', '7', '130');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1942, '5781772792', NULL, 'LED-5W/E27', '7', '182');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1943, '3936475794', NULL, 'LED-12W/E27', '7', '175');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1944, '5763956237', NULL, 'E27Bulb/5W/WH', '7', '245');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1945, '2329112892', NULL, 'Led panel light 6w', '7', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1946, '4443297985', NULL, 'Led panel light 12w', '7', '490');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1947, '5757214967', NULL, 'Led panel light 18w', '7', '735');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1948, '1487884947', NULL, '119', '7', '875');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1949, '7124481721', NULL, '018 AW', '7', '1015');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1950, '1887413326', NULL, '1611', '7', '1855');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1951, '1843648148', NULL, '1607', '7', '1505');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1952, '4666887922', NULL, '1702', '7', '1225');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1953, '4342591831', NULL, '21146 M', '7', '3673');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1954, '5728676635', NULL, '21146 S', '7', '1495');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1955, '9728526156', NULL, '21150 Big', '7', '3640');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1956, '7331556271', NULL, '21140 S', '7', '1528');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1957, '9372648495', NULL, '21140 M', '7', '1528');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1958, '1517366859', NULL, '21125 B', '7', '3250');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1959, '2389957768', NULL, 'london B', '7', '2048');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1960, '1364562818', NULL, 'london s', '7', '1528');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1961, '7932454431', NULL, 'am 21151 b', '7', '3640');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1962, '7186368893', NULL, 'am 21151 s', '7', '2048');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1963, '1619766456', NULL, 'route us', '7', '1625');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1964, '1844587396', NULL, '1368-1W', '7', '875');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1965, '6666142874', NULL, '1366-1W', '7', '805');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1966, '7542482634', NULL, '1366-2W', '7', '945');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1967, '8481695539', NULL, '1368-2B', '7', '560');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1968, '8225767293', NULL, '1513-2W', '7', '735');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1969, '6464738452', NULL, '804020', '7', '560');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1970, '6284919297', NULL, '4046', '7', '1050');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1971, '5498946774', NULL, '4046-1', '7', '1050');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1972, '2374385693', NULL, 'X1513-2', '7', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1973, '3144922158', NULL, '1506-2B', '7', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1974, '5435199534', NULL, 'X1604-1W', '7', '945');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1975, '9115298313', NULL, '1728-20', '7', '1295');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1976, '6514683532', NULL, 'RXP1760', '7', '1505');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1977, '4175136924', NULL, 'FV42', '7', '595');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1978, '1799572612', NULL, '20266', '7', '2170');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1979, '6697712275', NULL, '1476', '1', '350');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1980, '7839515934', NULL, '1475', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1981, '8224271744', NULL, '1479', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1982, '4716351197', NULL, '1474', '1', '525');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1983, '7571517348', NULL, '1477', '1', '266');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1984, '2485718784', NULL, '1480', '1', '434');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1985, '5787774127', NULL, '57205AB', '1', '945');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1986, '6229246634', NULL, '57014', '1', '1505');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1987, '4725412249', NULL, '55040', '1', '945');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1988, '2713124798', NULL, '57208AB', '1', '1435');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1989, '9126929898', NULL, '55041', '1', '980');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1990, '3175263532', NULL, 'BC001', '1', '70');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1991, '5428268415', NULL, 'FB001', '1', '175');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1992, '7573384598', NULL, 'FB002', '1', '175');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1993, '8877713478', NULL, 'BB001', '1', '126');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1994, '5924181755', NULL, 'Dsp/ht723 h ', '1', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1995, '6163156752', NULL, 'Ht 709', '1', '245');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1996, '8789222375', NULL, '694 mn', '1', '175');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1997, '8778515365', NULL, 'Ht 710', '1', '245');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1998, '1324692943', NULL, 'Ht 746', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (1999, '5873941376', NULL, 'Ht 678 694 662', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2000, '3536953423', NULL, '693MNHT', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2001, '3759831119', NULL, 'Ht 716-719', '1', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2002, '9654315483', NULL, 'Ht 678 694 662', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2003, '2672417361', NULL, 'D797', '1', '245');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2004, '6846324277', NULL, '799', '1', '1050');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2005, '3438832339', NULL, '798', '1', '1050');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2006, '6231699692', NULL, '8835', '1', '406');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2007, '5484298565', NULL, 'Doll731', '1', '1085');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2008, '6431464774', NULL, 'DOLL002', '1', '875');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2009, '9824464713', NULL, 'BATH001', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2010, '3325246369', NULL, 'BATH002', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2011, '9345912475', NULL, 'BATH003', '1', '245');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2012, '7739987254', NULL, 'BATH004', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2013, '3761359695', NULL, 'Pb001', '1', '126');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2014, '8896353427', NULL, 'PB002', '1', '84');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2015, '5219625897', NULL, 'PB003', '1', '154');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2016, '1634351268', NULL, 'PB004', '1', '84');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2017, '4645385634', NULL, 'PB005', '1', '175');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2018, '6444171166', NULL, 'Pb49', '1', '175');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2019, '3676924738', NULL, 'Ppb16', '1', '154');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2020, '4226768383', NULL, 'PB006', '1', '175');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2021, '9121145613', NULL, 'PB007', '1', '175');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2022, '8293954983', NULL, 'PB008', '1', '175');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2023, '4124372559', NULL, 'DB001', '1', '25');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2024, '8639395144', NULL, 'KDBAG001', '1', '88');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2025, '5151813647', NULL, 'PB009', '1', '77');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2026, '6965164429', NULL, 'PB009', '1', '77');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2027, '4244846122', NULL, 'PB010', '1', '77');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2028, '6997146924', NULL, 'PB011', '1', '77');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2029, '5575598488', NULL, 'smbl001', '1', '42');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2030, '5699978887', NULL, 'F912115', '1', '1050');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2031, '5731277333', NULL, '172820', '1', '1050');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2032, '4966923351', NULL, '172822', '1', '1050');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2033, '6859476181', NULL, '88033', '1', '1050');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2034, '7171829429', NULL, 'BCAP001', '1', '56');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2035, '6262815988', NULL, 'PF001', '1', '525');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2036, '5779354495', NULL, 'Lb/36', '1', '455');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2037, '4998967445', NULL, 'Lb28', '1', '525');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2038, '6317263135', NULL, 'RXP1760', '1', '1505');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2039, '7223841199', NULL, 'AC986', '1', '525');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2040, '9168196157', NULL, 'SP989', '1', '1505');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2041, '1463512879', NULL, 'GI9867', '1', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2042, '1667574364', NULL, 'A019/dsp', '1', '1750');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2043, '1515445289', NULL, 'Fv 1728-20', '1', '1155');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2044, '2314224973', NULL, 'A306761KK', '1', '1995');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2045, '5798545281', NULL, '1472', '1', '595');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2046, '8516496247', NULL, '1528', '1', '595');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2047, '9552588641', NULL, '1527', '1', '735');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2048, '3389135244', NULL, '1529', '1', '665');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2049, '2768115359', NULL, 'Stk0001', '1', '70');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2050, '6425463512', NULL, '25-5', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2051, '3558149548', NULL, '26-5', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2052, '7946434773', NULL, '27-5', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2053, '5174158416', NULL, '28-5', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2054, '7317496686', NULL, '29-5', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2055, '1849185649', NULL, '30-5', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2056, '5842246869', NULL, '31-5', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2057, '3838232255', NULL, '32-5', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2058, '6876982689', NULL, '33-5', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2059, '2843778891', NULL, '34-5', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2060, '5142157375', NULL, '25-2', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2061, '2122374232', NULL, '26-2', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2062, '7766898454', NULL, '27-2', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2063, '8438144189', NULL, '28-2', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2064, '5484396992', NULL, '29-2', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2065, '9345593756', NULL, '30-2', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2066, '3778472137', NULL, '31-2', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2067, '6394374734', NULL, '32-2', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2068, '5367821272', NULL, '33-2', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2069, '2343854681', NULL, '34-2', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2070, '9934668623', NULL, '25-5/S', '1', '1546');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2071, '7373755685', NULL, '26-5/S', '1', '1546');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2072, '2757335828', NULL, '27-5/S', '1', '1546');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2073, '8547913835', NULL, '28-5/S', '1', '1546');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2074, '6815752239', NULL, '29-5/S', '1', '1546');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2075, '8852486678', NULL, '30-5/S', '1', '1546');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2076, '2887396967', NULL, '31-5/S', '1', '1546');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2077, '5252176423', NULL, '32-5/S', '1', '1546');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2078, '1821615771', NULL, '33-5/S', '1', '1546');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2079, '4927998394', NULL, '34-5/S', '1', '1546');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2080, '1837996795', NULL, '25-2/S', '1', '110');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2081, '5684888817', NULL, '26-2/S', '1', '110');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2082, '1347612189', NULL, '27-2/S', '1', '110');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2083, '5172613575', NULL, '28-2/S', '1', '110');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2084, '2415229724', NULL, '29-2/S', '1', '110');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2085, '6747826198', NULL, '30-2/S', '1', '110');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2086, '3767893999', NULL, '31-2/S', '1', '110');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2087, '6928787948', NULL, '32-2/S', '1', '110');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2088, '4631959943', NULL, '33-2/S', '1', '110');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2089, '8179655319', NULL, '34-2/S', '1', '110');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2090, '2355124382', NULL, '85', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2091, '5131384972', NULL, '85', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2092, '1326268549', NULL, '85', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2093, '9615568621', NULL, '85', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2094, '3563216848', NULL, '85', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2095, '5237871159', NULL, '85', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2096, '9421921725', NULL, '85', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2097, '3814138897', NULL, '85', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2098, '9823778553', NULL, '89', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2099, '7178166115', NULL, '89', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2100, '2562184125', NULL, '89', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2101, '4252849346', NULL, '89', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2102, '5769226667', NULL, '89', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2103, '5941694122', NULL, '89', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2104, '6777715288', NULL, '68', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2105, '2165576857', NULL, '69', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2106, '2967252298', NULL, '83', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2107, '8193199389', NULL, '83', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2108, '6377297747', NULL, '81', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2109, '9811277759', NULL, '81', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2110, '6679443771', NULL, '88', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2111, '4237142449', NULL, '88', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2112, '4588693423', NULL, '88', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2113, '7612959668', NULL, '92', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2114, '9784444923', NULL, '66', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2115, '7941152156', NULL, '66', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2116, '9844728724', NULL, '66', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2117, '9176687338', NULL, '101', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2118, '8587234112', NULL, '66', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2119, '7371149166', NULL, '85', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2120, '7428855969', NULL, 'RS41/C', '9', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2121, '1831515714', NULL, 'RS41/C', '9', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2122, '4497737815', NULL, 'RS41/C', '9', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2123, '2546669992', NULL, 'RS39/S', '9', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2124, '1674536927', NULL, 'RS39/S', '9', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2125, '3123999474', NULL, 'RS39/S', '9', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2126, '5395464996', NULL, '41-SP', '9', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2127, '8749455866', NULL, '41-SP', '9', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2128, '2634598685', NULL, '41-SP', '9', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2129, '3288641143', NULL, '39-SP', '9', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2130, '4264871414', NULL, '39-SP', '9', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2131, '7846543225', NULL, '39-SP', '9', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2132, '4538312742', NULL, 'E008MF', '9', '3250');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2133, '1285625476', NULL, '18871MF-C', '9', '11500');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2134, '3791629816', NULL, '18871MF-D', '9', '11500');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2135, '7669198234', NULL, 'C02-MFG', '9', '4850');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2136, '3235474353', NULL, 'CT-021MFG', '9', '4850');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2137, '1443482733', NULL, 'Con-102-MFG', '9', '6500');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2138, '6982588612', NULL, 'T-50129-MFG', '9', '7000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2139, '8856445163', NULL, '155224', '1', '12900');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2140, '1989467866', NULL, '15656', '1', '13000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2141, '3736876228', NULL, '15382', '1', '13000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2142, '1898499332', NULL, '15556', '1', '12500');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2143, '7148763887', NULL, '15677', '1', '12500');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2144, '3374179868', NULL, '15661', '1', '13000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2145, '3217226293', NULL, '15665', '1', '12800');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2146, '2483765387', NULL, '15690', '1', '13000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2147, '6482793344', NULL, '15692', '1', '13000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2148, '4815195423', NULL, '15383', '1', '13000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2149, '3462687367', NULL, '15490', '1', '13500');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2150, '4891628199', NULL, '15728', '1', '12000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2151, '7963294239', NULL, '15724', '1', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2152, '3261794762', NULL, '17034', '1', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2153, '2213154768', NULL, '15470', '1', '8000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2154, '7224496629', NULL, 'PF6030', '7', '291');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2155, '9942151815', NULL, 'PF6030', '7', '291');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2156, '5867658718', NULL, 'PF6560', '7', '291');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2157, '4888842388', NULL, 'PF6560', '7', '291');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2158, '7317594245', NULL, 'PF6560', '7', '291');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2159, '9498688632', NULL, 'PF6014', '7', '455');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2160, '3154729353', NULL, 'PF661', '7', '595');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2161, '6442867897', NULL, 'PF6563', '7', '350');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2162, '4777764166', NULL, '20x16', '7', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2163, '3654532155', NULL, '20x16', '7', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2164, '6775588642', NULL, '17.5?12.5', '7', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2165, '1311919932', NULL, '17.5?12.5', '7', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2166, '8179115836', NULL, 'PF-6509', '7', '1435');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2167, '8424732977', NULL, 'PF-6504', '7', '875');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2168, '8677351327', NULL, '215 M', '7', '1050');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2169, '5737454855', NULL, '215 S', '7', '840');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2170, '2225732489', NULL, 'YD1040', '7', '735');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2171, '5365258656', NULL, 'YJ1709/PF', '7', '1050');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2172, '5431474879', NULL, 'J1710/PF', '7', '1050');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2173, '1886972498', NULL, 'YD1028/PF', '7', '1085');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2174, '6359923733', NULL, 'YD1616/PF', '7', '1085');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2175, '7749442331', NULL, 'J1612', '7', '1240');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2176, '1183437891', NULL, 'J1612', '7', '1240');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2177, '4514447887', NULL, 'J1612', '7', '1240');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2178, '3659132375', NULL, 'BH2701/PF', '7', '1240');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2179, '4794354872', NULL, 'Hy2218', '7', '2040');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2180, '3228636265', NULL, 'HB 12-38', '7', '1640');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2181, '4594218415', NULL, '39-18', '7', '2000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2182, '5755336128', NULL, 'Q1609/PF', '7', '1240');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2183, '5727678155', NULL, 'Collage 08', '7', '1240');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2184, '6568743479', NULL, '10', '7', '1240');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2185, '8467119699', NULL, 'Q101-8', '7', '2250');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2186, '4234479918', NULL, 'Q083-8', '7', '3350');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2187, '7828483846', NULL, 'Q031-10', '7', '3350');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2188, '8963183121', NULL, 'Q099-8', '7', '2250');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2189, '1212458325', NULL, 'Q066-5', '7', '2050');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2190, '8196988263', NULL, 'Q087-12', '7', '3850');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2191, '8349272182', NULL, 'Q069', '7', '2850');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2192, '7847219483', NULL, 'Q001', '7', '3850');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2193, '4759875469', NULL, 'Q067', '7', '2750');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2194, '1626496825', NULL, 'Q068', '7', '2750');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2195, '3587127326', NULL, 'RC0011', '7', '6650');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2196, '8582662153', NULL, 'RC0011', '7', '6650');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2197, '8852793726', NULL, '1109', '7', '2660');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2198, '9135155155', NULL, '11011', '7', '1330');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2199, '2243598857', NULL, 'HK17566/PR', '7', '4200');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2200, '6472139669', NULL, '1109', '7', '1750');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2201, '9378591696', NULL, '1633', '7', '2030');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2202, '1526761661', NULL, '2053', '7', '9450');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2203, '4835118435', NULL, NULL, '7', '6650');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2204, '9589419567', NULL, 'E008C', '7', '3500');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2205, '5376322783', NULL, '50006', '7', '10150');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2206, '2136568897', NULL, 'C4-60', '7', '10850');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2207, '9121438292', NULL, 'Lc031B', '7', '12950');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2208, '3149167245', NULL, 'Lc031S', '7', '6650');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2209, '8536423886', NULL, 'VB007', '7', '735');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2210, '1371435169', NULL, 'MS005-1', '7', '7350');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2211, '4463728785', NULL, 'MS005-2', '7', '7350');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2212, '3118122274', NULL, 'AM-1050', '7', '16450');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2213, '8452552573', NULL, 'AM-6046', '7', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2214, '8982731319', NULL, 'AM-093', '7', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2215, '6624935854', NULL, 'DL-3161', '7', '3150');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2216, '1615152974', NULL, 'BM-135', '7', '1890');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2217, '1925975442', NULL, 'BM-01', '7', '2660');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2218, '3132169629', NULL, 'BM-08', '7', '2660');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2219, '7618256154', NULL, 'Dl-28', '7', '4550');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2220, '9144294183', NULL, '18872C', '7', '17500');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2221, '8267977982', NULL, '18873C', '7', '24850');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2222, '1283446727', NULL, 'CT005678', '7', '10850');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2223, '3463292923', NULL, 'D-009', '7', '805');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2224, '4114471176', NULL, 'D-019', '7', '896');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2225, '9845841873', NULL, 'D-03', '7', '875');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2226, '7694184248', NULL, 'D-0011H', '7', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2227, '5858151847', NULL, 'Multi', '7', '1295');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2228, '2436514966', NULL, 'P001091', '7', '1575');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2229, '9597525915', NULL, 'P00109C', '7', '2450');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2230, '7612514541', NULL, 'SC0056', '7', '1050');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2231, '8996381951', NULL, 'T00081', '7', '735');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2232, '6714677261', NULL, '00001SC', '7', '1750');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2233, '7461567244', NULL, NULL, '7', '4200');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2234, '9716198359', NULL, NULL, '7', '2800');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2235, '1977448213', NULL, 'Sp10211', '1', '84');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2236, '1515483736', NULL, 'Sp10212', '1', '105');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2237, '6431261545', NULL, 'Sp10213', '1', '84');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2238, '7652276884', NULL, '1487', '1', '175');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2239, '2658413646', NULL, '1485', '1', '112');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2240, '7298374648', NULL, '1487', '1', '196');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2241, '8627757865', NULL, '1488', '1', '182');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2242, '6122315132', NULL, '1489', '1', '175');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2243, '6888663114', NULL, '1484', '1', '84');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2244, '8874823265', NULL, '1519', '1', '350');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2245, '6194799314', NULL, '1482', '1', '147');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2246, '7799472635', NULL, '1481', '1', '175');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2247, '9445925118', NULL, 'Ox102106', '1', '350');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2248, '3995236521', NULL, 'M102107', '1', '14');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2249, '1437768946', NULL, 'M102108', '1', '140');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2250, '6127785281', NULL, 'A102109', '1', '35');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2251, '7241594639', NULL, 'Psb007', '1', '875');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2252, '3149249888', NULL, 'Psb007', '1', '875');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2253, '9727989618', NULL, 'Ssb001', '1', '875');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2254, '2726422212', NULL, 'Csb009', '1', '1015');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2255, '1133939583', NULL, 'Ssb001', '1', '945');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2256, '1551156286', NULL, 'Ssb001', '1', '875');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2257, '1355121364', NULL, '1aaa3', '1', '1575');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2258, '4299422788', NULL, 'E2cB', '1', '735');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2259, '1338678659', NULL, 'E2cB', '1', '595');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2260, '4726527463', NULL, 'Az003', '1', '140');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2261, '5682569265', NULL, 'Toy-P001', '8', '266');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2262, '5188565125', NULL, 'Toy-P002', '8', '266');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2263, '9972353554', NULL, 'Toy-P003', '8', '266');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2264, '7296313292', NULL, 'Toy-P004', '8', '196');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2265, '6184877211', NULL, 'Toy-P005', '8', '196');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2266, '3351233144', NULL, 'Toy-P006', '8', '336');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2267, '3742138861', NULL, 'Toy-P007', '8', '266');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2268, '3819336467', NULL, 'Toy-P008', '8', '266');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2269, '2266776294', NULL, 'Toy-P009', '8', '406');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2270, '1133781785', NULL, 'Toy-P010', '8', '406');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2271, '8293725374', NULL, 'Toy-P011', '8', '266');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2272, '7618745174', NULL, 'Toy-P012', '8', '406');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2273, '6284278432', NULL, 'Toy-P013', '8', '196');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2274, '4167825773', NULL, 'Toy-P014', '8', '196');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2275, '8122679259', NULL, 'Toy-P015', '8', '266');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2276, '7247547612', NULL, 'Toy-P016', '8', '196');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2277, '6193382215', NULL, 'Toy-P017', '8', '266');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2278, '3445342728', NULL, 'Toy-P018', '8', '266');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2279, '7123537379', NULL, 'Toy-P019', '8', '266');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2280, '2836819612', NULL, 'Toy-P020', '8', '140');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2281, '4176934542', NULL, 'Toy-P021', '8', '112');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2282, '9485777721', NULL, 'Wb/829 ', '1', '266');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2283, '2555317787', NULL, 'Wb/829', '1', '266');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2284, '9682615393', NULL, 'Wb3018', '1', '231');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2285, '8174576928', NULL, 'Wb/1001', '1', '266');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2286, '3921937517', NULL, 'R834', '1', '266');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2287, '2289471692', NULL, 'Wb0182 ', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2288, '6879218255', NULL, 'Wb0182', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2289, '3657287671', NULL, 'Wb0182', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2290, '3375778342', NULL, 'Wb0182', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2291, '1464249222', NULL, 'Yb0368', '1', '245');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2292, '6141511361', NULL, 'Yb0368', '1', '245');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2293, '5193169227', NULL, 'Yb0183', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2294, '8322335939', NULL, 'Wb834', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2295, '9738678428', NULL, 'Wb5', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2296, '1914327643', NULL, 'Sh7058', '1', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2297, '7221227795', NULL, 'Yb0300', '1', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2298, '1343762722', NULL, 'Yb0300', '1', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2299, '5647499438', NULL, 'Wb/2', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2300, '3523843678', NULL, 'Tc1706', '1', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2301, '1369728617', NULL, 'Wb508', '1', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2302, '6269988129', NULL, 'Wb508', '1', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2303, '2469231296', NULL, 'WB/2', '1', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2304, '6866316533', NULL, 'Wb835', '1', '231');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2305, '4678489696', NULL, 'Wb15', '1', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2306, '5268385793', NULL, 'Yb0287', '1', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2307, '5935997372', NULL, 'WB001', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2308, '9465192556', NULL, 'Wb7', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2309, '8651434296', NULL, 'Yb0455', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2310, '8124538834', NULL, 'WB002', '1', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2311, '9315375456', NULL, 'Wb1915', '1', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2312, '1642597336', NULL, '35X35', '7', '1155');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2313, '5658277973', NULL, '33X33', '7', '875');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2314, '6492815323', NULL, '14X18', '7', '1750');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2315, '1997577644', NULL, '40X40', '7', '1750');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2316, '8211431317', NULL, '80X120', '7', '2835');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2317, '4886852242', NULL, '20\"/48\"-04', '7', '4550');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2318, '5937264395', NULL, '33X19', '7', '2450');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2319, '6689783155', NULL, '58X78', '7', '4550');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2320, '4178612719', NULL, '14X35 (Broken)', '7', '3150');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2321, '4112838943', NULL, '55X45', '7', '4550');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2322, '9664823956', NULL, '43X107', '7', '3850');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2323, '5264627535', NULL, '34X20 (Broken)', '7', '3150');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2324, '2241887926', NULL, '14x39', '7', '3150');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2325, '9234843263', NULL, '8362-3', '7', '1560');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2326, '9813645214', NULL, '8449-3', '7', '1480');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2327, '1599592615', NULL, '8380-3', '7', '1640');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2328, '9293922918', NULL, '8285-3', '7', '1560');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2329, '4399692995', NULL, '8428-3', '7', '1480');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2330, '6757529531', NULL, '8389-3', '7', '1480');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2331, '6254666543', NULL, '8673-3', '7', '1480');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2332, '8573978254', NULL, '8449-2', '7', '1200');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2333, '1393335883', NULL, '8285-2', '7', '1320');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2334, '6164659818', NULL, '8389-2', '7', '1160');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2335, '5142918329', NULL, '8673-2', '7', '1160');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2336, '3228958419', NULL, '8380-2', '7', '1200');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2337, '7763637231', NULL, '8362-2', '7', '1160');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2338, '6664354262', NULL, '8428-2', '7', '1160');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2339, '5825128652', NULL, '8380-1', '7', '760');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2340, '6614517796', NULL, '6558-1', '7', '840');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2341, '7327344927', NULL, '6028-1', '7', '840');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2342, '5893467812', NULL, '6559-1', '7', '840');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2343, '8152911686', NULL, '6115-1', '7', '840');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2344, '8182484757', NULL, '6116-1', '7', '840');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2345, '4773972578', NULL, '6033-1', '7', '840');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2346, '8776349446', NULL, '904-1', '7', '1520');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2347, '5482682719', NULL, '6031-1', '7', '840');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2348, '8227168468', NULL, '6010-1', '7', '840');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2349, '5788597848', NULL, '6032-1', '7', '840');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2350, '6972654384', NULL, '1007-1', '7', '1160');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2351, '4663668836', NULL, '6116-1', '7', '1000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2352, '8372277289', NULL, 'SW-1001-2', '7', '1640');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2353, '1677863645', NULL, 'SW-1001-1', '7', '1200');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2354, '4661876763', NULL, 'SW-9607', '7', '2520');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2355, '9143837639', NULL, 'Led 3039', '7', '2000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2356, '6924386534', NULL, 'YMA42702', '7', '2320');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2357, '2873623751', NULL, 'JY934', '7', '1480');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2358, '8647912448', NULL, 'JY834-2', '7', '2000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2359, '4218367371', NULL, '2019 F', '7', '7600');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2360, '4659353563', NULL, '2019 FBK', '7', '7600');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2361, '8129289115', NULL, '2130 WT', '7', '7600');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2362, '2557544739', NULL, 'Rose 247-1', '7', '14800');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2363, '6443812681', NULL, '1007-5', '7', '6600');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2364, '3877289723', NULL, '1007-3', '7', '4550');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2365, '6322866242', NULL, '1638-3', '7', '4550');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2366, '2969867974', NULL, 'Led-KX 3109-5/1', '7', '6650');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2367, '4122681459', NULL, '1001-3', '7', '3639');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2368, '7824836744', NULL, 'HY-702A', '7', '2100');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2369, '8199623854', NULL, '4283C', '7', '3150');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2370, '4444597967', NULL, '4944CD', '7', '2450');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2371, '3593229238', NULL, '419-3', '7', '8050');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2372, '8643554233', NULL, 'YMA409', '7', '5950');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2373, '3661518737', NULL, 'YMA408', '7', '4550');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2374, '1689629666', NULL, 'K-001', '1', '84');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2375, '4181765836', NULL, 'K-001', '1', '84');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2376, '1633176899', NULL, 'K-001', '1', '84');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2377, '7754674945', NULL, 'K-002', '1', '140');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2378, '8431444643', NULL, 'K-003', '1', '140');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2379, '2184864656', NULL, 'K-003', '1', '105');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2380, '5263339985', NULL, 'K-003', '1', '84');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2381, '2479252842', NULL, 'K-004', '1', '105');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2382, '9591665577', NULL, 'K-005', '1', '42');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2383, '4465947514', NULL, 'K-005', '1', '42');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2384, '4636499111', NULL, 'K-005', '1', '42');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2385, '4575773197', NULL, 'K-006', '1', '42');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2386, '5829224543', NULL, 'K-007', '1', '53');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2387, '4766825497', NULL, 'K-008', '1', '70');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2388, '2671446963', NULL, 'K-009', '1', '224');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2389, '7734692144', NULL, 'K-010', '1', '210');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2390, '8168766651', NULL, 'K-011', '1', '126');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2391, '3917361722', NULL, 'K-012', '1', '154');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2392, '8334624137', NULL, 'K-013', '1', '112');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2393, '7115416156', NULL, 'K-014', '1', '63');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2394, '9143336864', NULL, 'K-015', '1', '63');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2395, '6783437742', NULL, 'K-016', '1', '39');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2396, '7661796342', NULL, 'K-017', '1', '105');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2397, '5726696415', NULL, 'PC00101', '7', '455');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2398, '7331199978', NULL, 'PC00101', '7', '455');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2399, '4279166447', NULL, 'PC00101', '7', '455');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2400, '3932348661', NULL, 'PC00102KH', '7', '455');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2401, '6419726749', NULL, 'PC00102KH', '7', '455');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2402, '6516855892', NULL, 'PC00102KH', '7', '455');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2403, '2155311468', NULL, 'PC00102KH', '7', '455');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2404, '3448582281', NULL, 'PC00102KH', '7', '455');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2405, '3465488246', NULL, 'PC00102KH', '7', '455');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2406, '4173247848', NULL, 'PC00103BV', '7', '350');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2407, '4132874523', NULL, 'PC00105BV', '7', '350');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2408, '4956841133', NULL, 'PC00106CH', '7', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2409, '5868111959', NULL, 'PC00106CH', '7', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2410, '4399717474', NULL, 'PC00106CH', '7', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2411, '9227227134', NULL, 'PC00106CH', '7', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2412, '4289846559', NULL, 'PC00106CH', '7', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2413, '1415936189', NULL, 'G9', '7', '84');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2414, '5765132852', NULL, 'Bulb-E14/5W/etLamp', '7', '175');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2415, '3528374757', NULL, 'Bulb-E14/5W/Candle', '7', '175');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2416, '6367581759', NULL, '7W/Mini', '7', '154');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2417, '3799284711', NULL, 'E27/8W', '7', '175');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2418, '7224364587', NULL, 'E27/6W-WW', '7', '140');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2419, '5124123352', NULL, 'E27/6W-WH', '7', '140');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2420, '3678314173', NULL, 'E27/4W-WH', '7', '140');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2421, '2683461978', NULL, 'LED-3W/E27', '7', '130');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2422, '4177189232', NULL, 'LED-5W/E27', '7', '182');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2423, '3649441897', NULL, 'LED-12W/E27', '7', '175');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2424, '4371616783', NULL, 'E27Bulb/5W/WH', '7', '245');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2425, '5426838813', NULL, 'Led panel light 6w', '7', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2426, '2993597476', NULL, 'Led panel light 12w', '7', '490');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2427, '2316815174', NULL, 'Led panel light 18w', '7', '735');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2428, '3154671345', NULL, '119', '7', '875');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2429, '2379173567', NULL, '018 AW', '7', '1015');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2430, '3136747942', NULL, '1611', '7', '1855');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2431, '3114273356', NULL, '1607', '7', '1505');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2432, '8872286654', NULL, '1702', '7', '1225');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2433, '8486788282', NULL, '21146 M', '7', '3673');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2434, '4373433828', NULL, '21146 S', '7', '1495');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2435, '9745138586', NULL, '21150 Big', '7', '3640');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2436, '7225662872', NULL, '21140 S', '7', '1528');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2437, '6711161544', NULL, '21140 M', '7', '1528');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2438, '3169783217', NULL, '21125 B', '7', '3250');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2439, '1612713752', NULL, 'london B', '7', '2048');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2440, '1226439552', NULL, 'london s', '7', '1528');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2441, '7796896466', NULL, 'am 21151 b', '7', '3640');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2442, '4981317513', NULL, 'am 21151 s', '7', '2048');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2443, '4163898641', NULL, 'route us', '7', '1625');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2444, '1382276571', NULL, '1368-1W', '7', '875');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2445, '1666517699', NULL, '1366-1W', '7', '805');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2446, '4498161449', NULL, '1366-2W', '7', '945');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2447, '3648838795', NULL, '1368-2B', '7', '560');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2448, '5238637613', NULL, '1513-2W', '7', '735');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2449, '3516953885', NULL, '804020', '7', '560');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2450, '4561432618', NULL, '4046', '7', '1050');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2451, '5551712813', NULL, '4046-1', '7', '1050');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2452, '6993117715', NULL, 'X1513-2', '7', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2453, '6984526491', NULL, '1506-2B', '7', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2454, '7481498517', NULL, 'X1604-1W', '7', '945');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2455, '4627584746', NULL, '1728-20', '7', '1295');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2456, '2938397913', NULL, 'RXP1760', '7', '1505');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2457, '4686872838', NULL, 'FV42', '7', '595');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2458, '1891715235', NULL, '20266', '7', '2170');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2459, '9523344271', NULL, '1476', '1', '350');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2460, '6476517399', NULL, '1475', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2461, '6995522634', NULL, '1479', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2462, '2775698992', NULL, '1474', '1', '525');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2463, '9163154224', NULL, '1477', '1', '266');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2464, '8887581687', NULL, '1480', '1', '434');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2465, '8278758237', NULL, '57205AB', '1', '945');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2466, '9357558184', NULL, '57014', '1', '1505');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2467, '1723481466', NULL, '55040', '1', '945');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2468, '8871927794', NULL, '57208AB', '1', '1435');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2469, '6288482186', NULL, '55041', '1', '980');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2470, '2688113762', NULL, 'BC001', '1', '70');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2471, '5949798579', NULL, 'FB001', '1', '175');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2472, '8654242688', NULL, 'FB002', '1', '175');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2473, '4496628177', NULL, 'BB001', '1', '126');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2474, '7642689723', NULL, 'Dsp/ht723 h ', '1', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2475, '7294779331', NULL, 'Ht 709', '1', '245');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2476, '2136578732', NULL, '694 mn', '1', '175');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2477, '5584386111', NULL, 'Ht 710', '1', '245');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2478, '3447415974', NULL, 'Ht 746', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2479, '5159483961', NULL, 'Ht 678 694 662', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2480, '1297173114', NULL, '693MNHT', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2481, '5993772874', NULL, 'Ht 716-719', '1', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2482, '8536347239', NULL, 'Ht 678 694 662', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2483, '6999578536', NULL, 'D797', '1', '245');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2484, '4131258292', NULL, '799', '1', '1050');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2485, '7615942985', NULL, '798', '1', '1050');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2486, '9274665581', NULL, '8835', '1', '406');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2487, '1621414131', NULL, 'Doll731', '1', '1085');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2488, '8864286674', NULL, 'DOLL002', '1', '875');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2489, '3335921768', NULL, 'BATH001', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2490, '9596359717', NULL, 'BATH002', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2491, '3311364174', NULL, 'BATH003', '1', '245');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2492, '8286415843', NULL, 'BATH004', '1', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2493, '8493122175', NULL, 'Pb001', '1', '126');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2494, '8133658663', NULL, 'PB002', '1', '84');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2495, '8232591272', NULL, 'PB003', '1', '154');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2496, '8879838376', NULL, 'PB004', '1', '84');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2497, '6783952659', NULL, 'PB005', '1', '175');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2498, '4845433841', NULL, 'Pb49', '1', '175');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2499, '3532977797', NULL, 'Ppb16', '1', '154');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2500, '2846892953', NULL, 'PB006', '1', '175');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2501, '2366214367', NULL, 'PB007', '1', '175');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2502, '8269366591', NULL, 'PB008', '1', '175');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2503, '1814711947', NULL, 'DB001', '1', '25');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2504, '3795364284', NULL, 'KDBAG001', '1', '88');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2505, '1334312638', NULL, 'PB009', '1', '77');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2506, '7533566727', NULL, 'PB009', '1', '77');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2507, '8312758428', NULL, 'PB010', '1', '77');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2508, '4786681318', NULL, 'PB011', '1', '77');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2509, '2648741825', NULL, 'smbl001', '1', '42');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2510, '7127319519', NULL, 'F912115', '1', '1050');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2511, '1381671184', NULL, '172820', '1', '1050');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2512, '9881852484', NULL, '172822', '1', '1050');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2513, '1828416556', NULL, '88033', '1', '1050');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2514, '2186773894', NULL, 'BCAP001', '1', '56');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2515, '4558354343', NULL, 'PF001', '1', '525');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2516, '7688373546', NULL, 'Lb/36', '1', '455');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2517, '8687648234', NULL, 'Lb28', '1', '525');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2518, '9223287718', NULL, 'RXP1760', '1', '1505');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2519, '8588643632', NULL, 'AC986', '1', '525');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2520, '3261492724', NULL, 'SP989', '1', '1505');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2521, '3354473576', NULL, 'GI9867', '1', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2522, '1348829161', NULL, 'A019/dsp', '1', '1750');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2523, '6439826796', NULL, 'Fv 1728-20', '1', '1155');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2524, '1736991366', NULL, 'A306761KK', '1', '1995');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2525, '3632451491', NULL, '1472', '1', '595');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2526, '1248391633', NULL, '1528', '1', '595');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2527, '6752879123', NULL, '1527', '1', '735');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2528, '3795334742', NULL, '1529', '1', '665');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2529, '9515738226', NULL, 'Stk0001', '1', '70');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2530, '4929566337', NULL, '25-5', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2531, '4954431575', NULL, '26-5', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2532, '6799433219', NULL, '27-5', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2533, '7672785731', NULL, '28-5', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2534, '3619154667', NULL, '29-5', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2535, '5824171538', NULL, '30-5', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2536, '5757254885', NULL, '31-5', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2537, '7726842846', NULL, '32-5', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2538, '9495353871', NULL, '33-5', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2539, '3234388467', NULL, '34-5', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2540, '8766438113', NULL, '25-2', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2541, '4499338374', NULL, '26-2', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2542, '8193868729', NULL, '27-2', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2543, '7522682252', NULL, '28-2', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2544, '2135561356', NULL, '29-2', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2545, '6374515937', NULL, '30-2', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2546, '6357659631', NULL, '31-2', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2547, '6268319252', NULL, '32-2', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2548, '7739387926', NULL, '33-2', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2549, '2589376466', NULL, '34-2', '1', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2550, '4944798515', NULL, '25-5/S', '1', '1546');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2551, '8277423822', NULL, '26-5/S', '1', '1546');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2552, '2882939249', NULL, '27-5/S', '1', '1546');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2553, '6516318472', NULL, '28-5/S', '1', '1546');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2554, '1658799382', NULL, '29-5/S', '1', '1546');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2555, '5672566491', NULL, '30-5/S', '1', '1546');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2556, '3553582493', NULL, '31-5/S', '1', '1546');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2557, '8928525631', NULL, '32-5/S', '1', '1546');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2558, '2333128419', NULL, '33-5/S', '1', '1546');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2559, '9257933512', NULL, '34-5/S', '1', '1546');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2560, '7979517762', NULL, '25-2/S', '1', '110');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2561, '2858735567', NULL, '26-2/S', '1', '110');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2562, '8171749899', NULL, '27-2/S', '1', '110');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2563, '1364283113', NULL, '28-2/S', '1', '110');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2564, '8629328848', NULL, '29-2/S', '1', '110');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2565, '8244899722', NULL, '30-2/S', '1', '110');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2566, '6163722469', NULL, '31-2/S', '1', '110');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2567, '2576679269', NULL, '32-2/S', '1', '110');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2568, '2422233132', NULL, '33-2/S', '1', '110');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2569, '7765193511', NULL, '34-2/S', '1', '110');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2570, '7298286636', NULL, '85', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2571, '2183865264', NULL, '85', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2572, '9585862631', NULL, '85', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2573, '7736179734', NULL, '85', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2574, '6838635467', NULL, '85', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2575, '8918982923', NULL, '85', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2576, '1363774993', NULL, '85', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2577, '3714939358', NULL, '85', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2578, '7573971765', NULL, '89', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2579, '7792733572', NULL, '89', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2580, '8689928297', NULL, '89', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2581, '6763654778', NULL, '89', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2582, '5785898489', NULL, '89', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2583, '1389747639', NULL, '89', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2584, '6694467762', NULL, '68', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2585, '9946417648', NULL, '69', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2586, '5367112633', NULL, '83', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2587, '3775981517', NULL, '83', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2588, '1827131347', NULL, '81', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2589, '5469452698', NULL, '81', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2590, '7841558593', NULL, '88', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2591, '2687887415', NULL, '88', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2592, '1542369338', NULL, '88', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2593, '2734638589', NULL, '92', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2594, '6594332761', NULL, '66', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2595, '3946235536', NULL, '66', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2596, '2167664127', NULL, '66', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2597, '2259159753', NULL, '101', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2598, '6353298229', NULL, '66', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2599, '3455986864', NULL, '85', '9', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2600, '5259146981', NULL, 'RS41/C', '9', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2601, '1545985152', NULL, 'RS41/C', '9', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2602, '2767977638', NULL, 'RS41/C', '9', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2603, '1629685413', NULL, 'RS39/S', '9', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2604, '6318392756', NULL, 'RS39/S', '9', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2605, '9865897541', NULL, 'RS39/S', '9', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2606, '2341465626', NULL, '41-SP', '9', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2607, '6728723383', NULL, '41-SP', '9', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2608, '2835478542', NULL, '41-SP', '9', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2609, '9642551837', NULL, '39-SP', '9', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2610, '9338528196', NULL, '39-SP', '9', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2611, '6767151483', NULL, '39-SP', '9', NULL);
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2612, '3619618825', NULL, 'E008MF', '9', '3250');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2613, '7789493957', NULL, '18871MF-C', '9', '11500');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2614, '9578471187', NULL, '18871MF-D', '9', '11500');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2615, '5521552965', NULL, 'C02-MFG', '9', '4850');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2616, '8686268792', NULL, 'CT-021MFG', '9', '4850');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2617, '2462851536', NULL, 'Con-102-MFG', '9', '6500');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2618, '2123761113', NULL, 'T-50129-MFG', '9', '7000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2619, '1649668715', NULL, '155224', '1', '12900');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2620, '9189989791', NULL, '15656', '1', '13000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2621, '5541739471', NULL, '15382', '1', '13000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2622, '8741342784', NULL, '15556', '1', '12500');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2623, '1274637222', NULL, '15677', '1', '12500');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2624, '2121412514', NULL, '15661', '1', '13000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2625, '3119195356', NULL, '15665', '1', '12800');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2626, '5144785188', NULL, '15690', '1', '13000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2627, '2467259982', NULL, '15692', '1', '13000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2628, '3837765186', NULL, '15383', '1', '13000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2629, '7971541618', NULL, '15490', '1', '13500');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2630, '2441359192', NULL, '15728', '1', '12000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2631, '1541878593', NULL, '15724', '1', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2632, '5324549469', NULL, '17034', '1', '9000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2633, '7895373199', NULL, '15470', '1', '8000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2634, '8971916195', NULL, 'PF6030', '7', '291');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2635, '9263373953', NULL, 'PF6030', '7', '291');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2636, '5234217299', NULL, 'PF6560', '7', '291');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2637, '2283988985', NULL, 'PF6560', '7', '291');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2638, '5572273128', NULL, 'PF6560', '7', '291');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2639, '4699672938', NULL, 'PF6014', '7', '455');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2640, '3357826885', NULL, 'PF661', '7', '595');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2641, '7273114414', NULL, 'PF6563', '7', '350');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2642, '2343149257', NULL, '20x16', '7', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2643, '6324281142', NULL, '20x16', '7', '385');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2644, '9431893965', NULL, '17.5?12.5', '7', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2645, '2759426587', NULL, '17.5?12.5', '7', '315');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2646, '9755436792', NULL, 'PF-6509', '7', '1435');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2647, '2993548917', NULL, 'PF-6504', '7', '875');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2648, '4778981186', NULL, '215 M', '7', '1050');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2649, '1843693618', NULL, '215 S', '7', '840');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2650, '8316465758', NULL, 'YD1040', '7', '735');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2651, '9474839141', NULL, 'YJ1709/PF', '7', '1050');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2652, '2464385893', NULL, 'J1710/PF', '7', '1050');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2653, '6951417553', NULL, 'YD1028/PF', '7', '1085');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2654, '3734712649', NULL, 'YD1616/PF', '7', '1085');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2655, '1447692827', NULL, 'J1612', '7', '1240');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2656, '2941818645', NULL, 'J1612', '7', '1240');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2657, '8776478875', NULL, 'J1612', '7', '1240');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2658, '7532316494', NULL, 'BH2701/PF', '7', '1240');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2659, '6255682799', NULL, 'Hy2218', '7', '2040');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2660, '2772728183', NULL, 'HB 12-38', '7', '1640');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2661, '2392633649', NULL, '39-18', '7', '2000');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2662, '9676424223', NULL, 'Q1609/PF', '7', '1240');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2663, '3321343918', NULL, 'Collage 08', '7', '1240');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2664, '9868469269', NULL, '10', '7', '1240');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2665, '7595395785', NULL, 'Q101-8', '7', '2250');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2666, '6538199974', NULL, 'Q083-8', '7', '3350');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2667, '3158624686', NULL, 'Q031-10', '7', '3350');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2668, '6542179447', NULL, 'Q099-8', '7', '2250');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2669, '2813366298', NULL, 'Q066-5', '7', '2050');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2670, '4315461616', NULL, 'Q087-12', '7', '3850');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2671, '7664888412', NULL, 'Q069', '7', '2850');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2672, '7535419431', NULL, 'Q001', '7', '3850');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2673, '3721431999', NULL, 'Q067', '7', '2750');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2674, '1957656253', NULL, 'Q068', '7', '2750');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2677, '74144469', NULL, NULL, '7', '200');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2678, '76712517', NULL, NULL, '8', '150');
INSERT INTO `supplier_product` (`supplier_pr_id`, `product_id`, `product_id_two`, `products_model`, `supplier_id`, `supplier_price`) VALUES (2679, '12312312', NULL, '88191', '7', '20');


#
# TABLE STRUCTURE FOR: synchronizer_setting
#

DROP TABLE IF EXISTS `synchronizer_setting`;

CREATE TABLE `synchronizer_setting` (
  `id` int(11) NOT NULL,
  `hostname` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `port` varchar(10) NOT NULL,
  `debug` varchar(10) NOT NULL,
  `project_root` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tax_collection
#

DROP TABLE IF EXISTS `tax_collection`;

CREATE TABLE `tax_collection` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `customer_id` varchar(30) NOT NULL,
  `relation_id` varchar(30) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `customer_id` (`customer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=262 DEFAULT CHARSET=utf8;

INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (1, '2021-09-14', '1', '9795846277');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (2, '2021-09-14', '1', '3954846297');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (3, '2021-09-14', '1', '1456636723');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (4, '2021-09-14', '1', '3375747945');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (5, '2021-09-14', '1', '2679818326');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (6, '2021-09-14', '1', '8488243816');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (7, '2021-09-14', '1', '9924611285');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (8, '2021-09-14', '1', '9866925438');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (9, '2021-09-14', '1', '4823167796');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (10, '2021-09-18', '1', '2713252242');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (11, '2021-09-18', '1', '4884395561');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (12, '2021-09-18', '1', '4487249354');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (13, '2021-09-19', '1', '9176823469');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (14, '2021-09-20', '1', '5719549188');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (15, '2021-09-21', '1', '9531274869');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (16, '2021-09-21', '1', '3924326988');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (17, '2021-09-21', '1', '1456868266');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (18, '2021-09-21', '1', '7552924527');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (19, '2021-09-21', '1', '3744738977');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (20, '2021-09-21', '1', '6259851326');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (21, '2021-09-21', '1', '8586188481');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (22, '2021-09-21', '1', '9279156935');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (23, '2021-09-21', '1', '7574459566');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (24, '2021-09-21', '1', '9546461417');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (25, '2021-09-21', '1', '9984636231');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (26, '2021-09-21', '1', '8231495671');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (27, '2021-09-21', '1', '1596992675');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (28, '2021-09-21', '1', '6879718426');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (29, '2021-09-21', '1', '1589453686');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (30, '2021-09-22', '1', '1224746424');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (31, '2021-09-22', '1', '4567567144');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (32, '2021-09-22', '1', '6546452445');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (33, '2021-09-22', '1', '5297791199');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (34, '2021-09-22', '1', '6149632438');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (35, '2021-09-22', '1', '4223657133');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (36, '2021-09-25', '1', '4887742916');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (37, '2021-09-25', '1', '7224362971');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (38, '2021-09-25', '1', '8785715568');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (39, '2021-09-25', '1', '5534548724');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (40, '2021-09-25', '1', '7269234577');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (41, '2021-09-25', '1', '3816616261');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (42, '2021-09-25', '1', '1767964913');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (43, '2021-09-25', '1', '4873776141');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (44, '2021-09-25', '1', '8442386436');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (45, '2021-09-25', '1', '1899512694');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (46, '2021-09-25', '1', '1133536335');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (47, '2021-09-25', '1', '8134594136');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (48, '2021-09-25', '1', '7748731499');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (49, '2021-09-25', '1', '3324978348');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (50, '2021-09-25', '1', '7626567671');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (51, '2021-09-26', '1', '8546965667');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (52, '2021-09-26', '1', '1985363758');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (53, '2021-09-26', '1', '5151267149');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (54, '2021-09-26', '1', '7255959362');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (55, '2021-09-26', '1', '2891393147');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (56, '2021-09-26', '1', '3345341196');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (57, '2021-09-26', '1', '1179224959');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (58, '2021-09-27', '1', '5574869882');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (59, '2021-09-27', '1', '1535843265');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (60, '2021-09-27', '1', '3487125549');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (61, '2021-09-27', '1', '2334295866');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (62, '2021-09-27', '1', '9876752185');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (63, '2021-09-27', '1', '4426946553');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (64, '2021-09-27', '1', '2124762784');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (65, '2021-09-27', '1', '6717558216');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (66, '2021-09-27', '1', '9397131633');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (67, '2021-09-27', '1', '8371885359');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (68, '2021-09-27', '1', '3298232541');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (69, '2021-09-27', '1', '2998443152');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (70, '2021-09-27', '1', '5633678557');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (71, '2021-09-27', '1', '9434885354');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (72, '2021-09-27', '1', '9679769513');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (73, '2021-09-27', '1', '9228416898');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (74, '2021-09-27', '1', '2797247463');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (75, '2021-09-27', '1', '4694575384');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (76, '2021-09-27', '1', '2281166466');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (77, '2021-09-27', '1', '8695474341');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (78, '2021-09-27', '1', '6399548468');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (79, '2021-09-27', '1', '6915381773');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (80, '2021-09-27', '1', '3574551663');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (81, '2021-09-27', '1', '1165543224');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (82, '2021-09-27', '1', '4139242779');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (83, '2021-09-27', '1', '2476374175');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (84, '2021-09-27', '1', '9593396553');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (85, '2021-09-27', '1', '7264348361');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (86, '2021-09-27', '1', '2143794166');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (87, '2021-09-27', '1', '7295635591');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (88, '2021-09-27', '1', '1356326626');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (89, '2021-09-27', '1', '3291134883');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (90, '2021-09-27', '1', '7228837713');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (91, '2021-09-27', '1', '1246959843');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (92, '2021-09-27', '1', '3243447798');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (93, '2021-09-27', '1', '5659149151');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (94, '2021-09-27', '1', '7759377878');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (95, '2021-09-27', '1', '4168215814');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (96, '2021-09-27', '1', '3445484721');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (97, '2021-09-27', '1', '5179255698');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (98, '2021-09-27', '1', '1589418321');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (99, '2021-09-27', '1', '4619326693');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (100, '2021-09-27', '1', '4991846711');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (101, '2021-09-27', '1', '1337377915');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (102, '2021-09-27', '1', '7991456539');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (103, '2021-09-27', '1', '1716871242');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (104, '2021-09-27', '1', '1597371556');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (105, '2021-09-27', '1', '6249766937');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (106, '2021-09-27', '1', '1293839947');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (107, '2021-09-27', '1', '5199592352');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (108, '2021-09-27', '1', '2266413999');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (109, '2021-09-27', '1', '9771577635');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (110, '2021-09-27', '1', '2493128687');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (111, '2021-09-27', '1', '7261712518');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (112, '2021-09-27', '1', '2269276928');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (113, '2021-09-27', '1', '7256484624');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (114, '2021-09-27', '1', '2662169873');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (115, '2021-09-27', '1', '6568881238');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (116, '2021-09-27', '1', '5269114852');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (117, '2021-09-27', '1', '3274373939');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (118, '2021-09-27', '1', '3281643493');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (119, '2021-09-28', '1', '7311947332');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (120, '2021-09-28', '1', '3697834985');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (121, '2021-09-28', '1', '5575342875');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (122, '2021-09-28', '1', '1169765228');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (123, '2021-09-28', '1', '8874111519');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (124, '2021-09-28', '1', '5473137999');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (125, '2021-09-28', '1', '3679455674');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (126, '2021-09-28', '1', '9689339447');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (127, '2021-09-28', '1', '9289823197');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (128, '2021-09-28', '1', '7655651378');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (129, '2021-09-28', '1', '6934325351');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (130, '2021-09-28', '1', '5691341295');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (131, '2021-09-28', '1', '1912434626');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (132, '2021-09-28', '1', '9639488916');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (133, '2021-09-28', '1', '6939164518');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (134, '2021-09-28', '1', '5245241791');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (135, '2021-09-28', '1', '6113338235');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (136, '2021-09-28', '1', '7184338464');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (137, '2021-09-28', '1', '4115859154');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (138, '2021-09-28', '1', '3798875669');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (139, '2021-09-28', '1', '9958464543');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (140, '2021-09-28', '1', '9514271136');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (141, '2021-09-28', '1', '1264369849');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (142, '2021-09-28', '1', '4728175235');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (143, '2021-09-28', '1', '2671179858');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (144, '2021-09-28', '1', '4255643625');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (145, '2021-09-28', '1', '2633659316');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (146, '2021-09-28', '1', '1811423738');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (147, '2021-09-28', '1', '2586788612');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (148, '2021-09-28', '1', '9731946978');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (149, '2021-09-28', '1', '2662274227');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (150, '2021-09-28', '1', '4699979295');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (151, '2021-09-28', '1', '8454588334');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (152, '2021-09-28', '1', '3392949536');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (153, '2021-09-28', '1', '2235512787');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (154, '2021-09-28', '1', '8941897653');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (155, '2021-09-28', '1', '5546456748');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (156, '2021-09-28', '1', '2716248914');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (157, '2021-09-28', '1', '9418293519');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (158, '2021-09-28', '1', '2729544794');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (159, '2021-09-28', '1', '6574154332');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (160, '2021-09-28', '1', '5692489448');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (161, '2021-09-28', '1', '1239415459');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (162, '2021-09-28', '1', '5493832986');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (163, '2021-09-28', '1', '1641347524');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (164, '2021-09-28', '1', '8921979948');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (165, '2021-09-28', '1', '8848685961');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (166, '2021-09-28', '1', '2671372568');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (167, '2021-09-28', '1', '6243571185');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (168, '2021-09-28', '1', '7926792879');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (169, '2021-09-28', '1', '4967638863');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (170, '2021-09-28', '1', '5923994255');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (171, '2021-09-28', '1', '5141741827');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (172, '2021-09-28', '1', '9614898944');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (173, '2021-09-29', '1', '2869373261');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (174, '2021-09-29', '1', '7776332558');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (175, '2021-09-29', '1', '3768652251');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (176, '2021-09-29', '1', '5679324697');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (177, '2021-09-29', '1', '3345641243');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (178, '2021-09-29', '1', '8286382841');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (179, '2021-09-29', '1', '8568932142');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (180, '2021-10-02', '1', '9894457289');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (181, '2021-10-02', '1', '4137141578');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (182, '2021-10-03', '1', '1662823526');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (183, '2021-10-03', '1', '4553489624');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (184, '2021-10-03', '1', '4463318214');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (185, '2021-10-03', '1', '7932922575');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (186, '2021-10-03', '1', '8927694685');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (187, '2021-10-03', '1', '3148932138');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (188, '2021-10-04', '1', '5824748236');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (189, '2021-10-04', '1', '2443669179');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (190, '2021-10-04', '1', '2428192199');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (191, '2021-10-05', '1', '7857945718');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (192, '2021-10-06', '1', '2173664314');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (193, '2021-10-06', '1', '2395972251');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (194, '2021-10-06', '1', '2329539632');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (195, '2021-10-06', '1', '6466715362');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (196, '2021-10-06', '1', '4531946681');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (197, '2021-10-06', '1', '7442826814');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (198, '2021-10-06', '1', '6924364716');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (199, '2021-10-06', '1', '3251467152');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (200, '2021-10-10', '1', '2732116734');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (201, '2021-10-10', '1', '7317588883');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (202, '2021-10-10', '1', '9877281346');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (203, '2021-10-10', '1', '7645196398');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (204, '2021-10-10', '1', '5967357941');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (205, '2021-10-10', '1', '4644194978');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (206, '2021-10-10', '1', '4834799688');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (207, '2021-10-10', '1', '5766322551');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (208, '2021-10-10', '1', '9433984166');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (209, '2021-10-10', '1', '4627239834');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (210, '2021-10-11', '1', '6686897851');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (211, '2021-10-11', '1', '2943195425');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (212, '2021-10-12', '1', '1892375364');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (213, '2021-10-13', '1', '2961432683');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (214, '2021-10-19', '1', '1827439112');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (215, '2021-10-19', '1', '4956446312');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (216, '2021-10-19', '1', '2421721743');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (217, '2021-10-19', '1', '3342967699');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (218, '2021-10-19', '1', '8397221711');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (219, '2021-10-19', '1', '6413529188');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (220, '2021-10-19', '1', '3997218451');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (221, '2021-10-19', '1', '9971822295');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (222, '2021-10-19', '1', '9338679485');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (223, '2021-10-19', '1', '1637486295');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (225, '2021-10-21', '1', '2928698325');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (226, '2021-10-21', '1', '7363758319');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (227, '2021-10-21', '1', '1219511489');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (228, '2021-10-21', '1', '6159747935');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (229, '2021-10-23', '1', '8164926888');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (230, '2021-10-23', '1', '8724494968');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (231, '2021-10-23', '1', '7656339839');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (232, '2021-10-23', '1', '1436841947');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (233, '2021-10-23', '1', '4944234958');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (234, '2021-10-23', '1', '1457426431');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (235, '2021-10-23', '1', '9879511159');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (236, '2021-10-23', '1', '3785187489');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (237, '2021-10-23', '1', '4419649786');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (238, '2021-10-24', '1', '9712198898');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (239, '2021-10-24', '1', '1752397973');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (240, '2021-10-27', '1', '6383717156');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (241, '2021-11-01', '1', '6456176272');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (242, '2021-11-03', '1', '2619712578');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (243, '2021-11-03', '1', '1737823266');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (245, '2021-11-06', '1', '8732594423');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (246, '2021-11-06', '1', '3836394929');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (247, '2021-11-07', '1', '1584819626');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (248, '2021-11-10', '1', '6922388115');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (249, '2021-11-11', '1', '4979218373');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (250, '2021-11-13', '1', '9382931571');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (251, '2021-11-15', '1', '5841248653');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (252, '2021-11-15', '1', '2497129582');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (253, '2021-11-15', '1', '2473414626');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (254, '2021-11-16', '1', '3656251882');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (255, '2021-11-16', '1', '2611189914');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (256, '2021-11-16', '1', '7236121756');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (257, '2021-11-17', '1', '9971273911');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (258, '2021-11-18', '1', '2592561728');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (259, '2021-11-18', '1', '2525468222');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (260, '2021-11-18', '1', '9262689575');
INSERT INTO `tax_collection` (`id`, `date`, `customer_id`, `relation_id`) VALUES (261, '2021-11-18', '1', '1742668722');


#
# TABLE STRUCTURE FOR: tax_settings
#

DROP TABLE IF EXISTS `tax_settings`;

CREATE TABLE `tax_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `default_value` float NOT NULL,
  `tax_name` varchar(250) NOT NULL,
  `nt` int(11) NOT NULL,
  `reg_no` varchar(100) NOT NULL,
  `is_show` tinyint(4) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: units
#

DROP TABLE IF EXISTS `units`;

CREATE TABLE `units` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `unit_id` varchar(255) CHARACTER SET latin1 NOT NULL,
  `unit_name` varchar(255) CHARACTER SET latin1 NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `units` (`id`, `unit_id`, `unit_name`, `status`) VALUES (1, 'J1LJ9N172UBWTET', 'Dozen', 1);
INSERT INTO `units` (`id`, `unit_id`, `unit_name`, `status`) VALUES (2, 'YUYJIXI3SXKF3ZA', 'Pcs', 1);


#
# TABLE STRUCTURE FOR: user_login
#

DROP TABLE IF EXISTS `user_login`;

CREATE TABLE `user_login` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(15) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `user_type` int(2) DEFAULT NULL,
  `security_code` varchar(255) DEFAULT NULL,
  `status` int(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

INSERT INTO `user_login` (`id`, `user_id`, `username`, `password`, `user_type`, `security_code`, `status`) VALUES (1, '2', 'gmebd@yahoo.com', '08e7d644d6334b55ba924f343e3b824d', 1, NULL, 0);
INSERT INTO `user_login` (`id`, `user_id`, `username`, `password`, `user_type`, `security_code`, `status`) VALUES (2, '1', 'sonicictbd@gmail.com', '41d99b369894eb1ec3f461135132d8bb', 1, '200904082142', 1);
INSERT INTO `user_login` (`id`, `user_id`, `username`, `password`, `user_type`, `security_code`, `status`) VALUES (3, '1', 'sonicictbd@gmail.com', '41d99b369894eb1ec3f461135132d8bb', 1, '200904082142', 1);
INSERT INTO `user_login` (`id`, `user_id`, `username`, `password`, `user_type`, `security_code`, `status`) VALUES (4, '2', 'gmebd@yahoo.com', '08e7d644d6334b55ba924f343e3b824d', 1, '200905071406', 0);
INSERT INTO `user_login` (`id`, `user_id`, `username`, `password`, `user_type`, `security_code`, `status`) VALUES (5, 'OpSoxJvBbbS8Rws', 'touhidalm82@gmail.com', '04c5a7b79f55a5df65f2610f436d5c47', 1, '201030122448', 1);
INSERT INTO `user_login` (`id`, `user_id`, `username`, `password`, `user_type`, `security_code`, `status`) VALUES (10, 'HLJq42qHAlAHg4T', 'dell@gmail.com', '41d99b369894eb1ec3f461135132d8bb', 2, NULL, 1);
INSERT INTO `user_login` (`id`, `user_id`, `username`, `password`, `user_type`, `security_code`, `status`) VALUES (11, '3k5AW5cU8RAFqXC', 'dell.g@dellarte.info', '41d99b369894eb1ec3f461135132d8bb', 2, NULL, 1);
INSERT INTO `user_login` (`id`, `user_id`, `username`, `password`, `user_type`, `security_code`, `status`) VALUES (12, 'ksTbB7kJWrAf5QU', 'dhaka@gmail.com', '41d99b369894eb1ec3f461135132d8bb', 2, NULL, 1);
INSERT INTO `user_login` (`id`, `user_id`, `username`, `password`, `user_type`, `security_code`, `status`) VALUES (13, 'Gnmg56BnUYfl3aL', 'shoaibelias9@gmail.com', '41d99b369894eb1ec3f461135132d8bb', 2, NULL, 1);
INSERT INTO `user_login` (`id`, `user_id`, `username`, `password`, `user_type`, `security_code`, `status`) VALUES (14, 'Pd83SDt3dHonmpi', 'mishoel344@gmail.com', '41d99b369894eb1ec3f461135132d8bb', 2, NULL, 1);
INSERT INTO `user_login` (`id`, `user_id`, `username`, `password`, `user_type`, `security_code`, `status`) VALUES (15, 'Yg4Pwdbua6LOpkx', 'shoaibelias9@gmail.com', '41d99b369894eb1ec3f461135132d8bb', 2, NULL, 1);
INSERT INTO `user_login` (`id`, `user_id`, `username`, `password`, `user_type`, `security_code`, `status`) VALUES (16, 'UdHY3b7n5EdMU35', 'shoaibelias9@gmail.com', '41d99b369894eb1ec3f461135132d8bb', 2, NULL, 1);
INSERT INTO `user_login` (`id`, `user_id`, `username`, `password`, `user_type`, `security_code`, `status`) VALUES (17, 'KNmrMhXdbnd0erU', 'accounts@gmail.com', '41d99b369894eb1ec3f461135132d8bb', 2, NULL, 1);


#
# TABLE STRUCTURE FOR: users
#

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(15) NOT NULL,
  `outlet_id` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `company_name` varchar(250) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `gender` int(2) DEFAULT NULL,
  `date_of_birth` varchar(255) DEFAULT NULL,
  `logo` varchar(250) DEFAULT NULL,
  `status` int(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

INSERT INTO `users` (`id`, `user_id`, `outlet_id`, `last_name`, `first_name`, `company_name`, `address`, `phone`, `gender`, `date_of_birth`, `logo`, `status`) VALUES (1, '2', NULL, 'Engineering', 'Global Medical', NULL, NULL, NULL, NULL, NULL, 'http://erp.devenport.co/assets/dist/img/profile_picture/b4d9b0776d8f1b9d214c9005be86a5cb.png', 0);
INSERT INTO `users` (`id`, `user_id`, `outlet_id`, `last_name`, `first_name`, `company_name`, `address`, `phone`, `gender`, `date_of_birth`, `logo`, `status`) VALUES (2, '1', NULL, 'User', 'Admin', NULL, NULL, NULL, NULL, NULL, 'http://knight-rider.co/assets/dist/img/profile_picture/profile.jpg', 1);
INSERT INTO `users` (`id`, `user_id`, `outlet_id`, `last_name`, `first_name`, `company_name`, `address`, `phone`, `gender`, `date_of_birth`, `logo`, `status`) VALUES (3, 'OpSoxJvBbbS8Rws', NULL, 'Alam', 'Touhid', NULL, NULL, NULL, NULL, NULL, 'http://erp.devenport.co/assets/dist/img/profile_picture/profile.jpg', 1);
INSERT INTO `users` (`id`, `user_id`, `outlet_id`, `last_name`, `first_name`, `company_name`, `address`, `phone`, `gender`, `date_of_birth`, `logo`, `status`) VALUES (8, 'HLJq42qHAlAHg4T', NULL, 'Dellarte', 'Dellarte', NULL, NULL, NULL, NULL, NULL, 'https://dellarte.info/erp/assets/dist/img/profile_picture/ebdb8d73bc27fef22e9fd675b8d87b1c.jpeg', 1);
INSERT INTO `users` (`id`, `user_id`, `outlet_id`, `last_name`, `first_name`, `company_name`, `address`, `phone`, `gender`, `date_of_birth`, `logo`, `status`) VALUES (9, '3k5AW5cU8RAFqXC', NULL, 'Golpahar', 'Dell Arte ', NULL, NULL, NULL, NULL, NULL, 'https://dellarte.info/erp/assets/dist/img/profile_picture/profile.jpg', 1);
INSERT INTO `users` (`id`, `user_id`, `outlet_id`, `last_name`, `first_name`, `company_name`, `address`, `phone`, `gender`, `date_of_birth`, `logo`, `status`) VALUES (10, 'ksTbB7kJWrAf5QU', NULL, 'Dhaka', 'Dell', NULL, NULL, NULL, NULL, NULL, 'https://erp_dell.test\\/assets/dist/img/profile_picture/profile.jpg', 1);
INSERT INTO `users` (`id`, `user_id`, `outlet_id`, `last_name`, `first_name`, `company_name`, `address`, `phone`, `gender`, `date_of_birth`, `logo`, `status`) VALUES (14, 'UdHY3b7n5EdMU35', 'M8A64F8GG9QQL57', 'Elias', 'Shoaib', NULL, NULL, NULL, NULL, NULL, 'https://erp_dell.test\\/assets/dist/img/profile_picture/profile.jpg', 1);
INSERT INTO `users` (`id`, `user_id`, `outlet_id`, `last_name`, `first_name`, `company_name`, `address`, `phone`, `gender`, `date_of_birth`, `logo`, `status`) VALUES (15, 'KNmrMhXdbnd0erU', NULL, 'Accounts', 'IOL', NULL, NULL, NULL, NULL, NULL, 'https://dubaivapepayel.com/iol/assets/dist/img/profile_picture/cbe8d42a6733406beaa928aa49d5931f.png', 1);


#
# TABLE STRUCTURE FOR: warrenty_return
#

DROP TABLE IF EXISTS `warrenty_return`;

CREATE TABLE `warrenty_return` (
  `return_id` varchar(30) CHARACTER SET latin1 NOT NULL,
  `product_id` varchar(30) CHARACTER SET latin1 NOT NULL,
  `invoice_id` varchar(30) CHARACTER SET latin1 NOT NULL,
  `invoice_details_id` varchar(30) CHARACTER SET latin1 NOT NULL,
  `purchase_id` varchar(30) CHARACTER SET latin1 NOT NULL,
  `date_purchase` varchar(30) CHARACTER SET latin1 NOT NULL,
  `date_return` varchar(30) CHARACTER SET latin1 NOT NULL,
  `byy_qty` float NOT NULL,
  `ret_qty` float NOT NULL,
  `was_qty` float NOT NULL,
  `customer_id` varchar(30) CHARACTER SET latin1 NOT NULL,
  `supplier_id` varchar(30) CHARACTER SET latin1 NOT NULL,
  `product_rate` decimal(10,2) DEFAULT NULL,
  `deduction` float DEFAULT NULL,
  `total_deduct` decimal(10,2) DEFAULT NULL,
  `total_tax` decimal(10,2) DEFAULT NULL,
  `service_charge` decimal(10,2) NOT NULL,
  `total_ret_amount` decimal(10,2) DEFAULT NULL,
  `net_total_amount` decimal(10,2) DEFAULT NULL,
  `reason` text CHARACTER SET latin1 NOT NULL,
  `usablity` int(5) NOT NULL,
  PRIMARY KEY (`return_id`),
  KEY `product_id` (`product_id`),
  KEY `invoice_id` (`invoice_id`),
  KEY `purchase_id` (`purchase_id`),
  KEY `customer_id` (`customer_id`),
  KEY `supplier_id` (`supplier_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: web_setting
#

DROP TABLE IF EXISTS `web_setting`;

CREATE TABLE `web_setting` (
  `setting_id` int(11) NOT NULL AUTO_INCREMENT,
  `logo` varchar(255) DEFAULT NULL,
  `invoice_logo` varchar(255) DEFAULT NULL,
  `favicon` varchar(255) DEFAULT NULL,
  `currency` varchar(10) DEFAULT NULL,
  `timezone` varchar(150) NOT NULL,
  `currency_position` varchar(10) DEFAULT NULL,
  `footer_text` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `rtr` varchar(255) DEFAULT NULL,
  `captcha` int(11) DEFAULT 1 COMMENT '0=active,1=inactive',
  `site_key` varchar(250) DEFAULT NULL,
  `secret_key` varchar(250) DEFAULT NULL,
  `discount_type` int(11) DEFAULT 1,
  PRIMARY KEY (`setting_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `web_setting` (`setting_id`, `logo`, `invoice_logo`, `favicon`, `currency`, `timezone`, `currency_position`, `footer_text`, `language`, `rtr`, `captcha`, `site_key`, `secret_key`, `discount_type`) VALUES (1, 'https://dubaivapepayel.com/iol/./my-assets/image/logo/e8c1264359c31b71f6ccab88cb0f3604.png', 'https://dubaivapepayel.com/iol/./my-assets/image/logo/7fe8d58084aa897950dcaf5617f1b5ca.png', 'https://dubaivapepayel.com/iol/my-assets/image/logo/5607d095e866d5fb938d5f233a360933.png', 'Tk', 'Asia/Dhaka', '0', 'Copyright© 2021-IOL', 'english', '0', 1, '', '', 1);


