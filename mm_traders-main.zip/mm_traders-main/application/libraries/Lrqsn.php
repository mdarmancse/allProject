<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Lrqsn
{



    public function stock_report_outlet_item()
    {
        $CI = &get_instance();
        $CI->load->model('Rqsn');
        $CI->load->model('Web_settings');
        $CI->load->model('Reports');
        $outlet_list    = $CI->Rqsn->outlet_list();
        $cw_list    = $CI->Rqsn->cw_list();
        $currency_details = $CI->Web_settings->retrieve_setting_editdata();
        $taxfield = $CI->db->select('tax_name,default_value')
            ->from('tax_settings')
            ->get()
            ->result_array();
        $data = array(
            'title'         => "Outlet Stock",
            'outlet_list' => $outlet_list,
            'cw_list' => $cw_list,
            'discount_type' => $currency_details[0]['discount_type'],
            'currency' => $currency_details[0]['currency'],
            'totalnumber' => $CI->Reports->totalnumberof_product(),
            'taxes'         => $taxfield,
        );


        //        echo print_r($data);
        //        die();
        $invoiceForm = $CI->parser->parse('rqsn/outlet_stock', $data, true);
        return $invoiceForm;
    }

    public function rqsn_add_form()
    {
        $CI = &get_instance();
        $CI->load->model('Rqsn');
        $CI->load->model('Web_settings');
        $CI->load->model('Warehouse');
        $outlet_list    = $CI->Rqsn->outlet_list();
        $outlet_list_to    = $CI->Rqsn->outlet_list_to();
        $cw_list    = $CI->Rqsn->cw_list();
        $currency_details = $CI->Web_settings->retrieve_setting_editdata();
        $CI->load->model('Accounts');
        $pro_expenses = $CI->Accounts->get_data_by_headcode(40105);
        $sub_warehouse_list = $CI->Warehouse->sub_warehouse_list();

        $taxfield = $CI->db->select('tax_name,default_value')
            ->from('tax_settings')
            ->get()
            ->result_array();
        $data = array(
            'title'         => "Stock Transfer",
            'outlet_list' => $outlet_list,
            'outlet_list_to' => $outlet_list_to,
            'cw_list' => $cw_list,
            'discount_type' => $currency_details[0]['discount_type'],
            'taxes'         => $taxfield,
            'pro_expenses'  => $pro_expenses,
            'sub_warehouse_list' => $sub_warehouse_list,
        );

        // echo '<pre';
        //  print_r($sub_warehouse_list);
        //  exit();
          
        $invoiceForm = $CI->parser->parse('rqsn/rqsn_form', $data, true);
        return $invoiceForm;
    }
    public function outlet_rqsn_add_form()
    {
        $CI = &get_instance();
        $CI->load->model('Rqsn');
        $CI->load->model('Web_settings');
        $CI->load->model('Accounts');
        $pro_expenses = $CI->Accounts->get_data_by_headcode(40105);

        $outlet_list    = $CI->Rqsn->outlet_to_outlet_list();
        $outlet_list_to    = $CI->Rqsn->outlet_list_to();
        $cw_list    = $CI->Rqsn->cw_list();
        $currency_details = $CI->Web_settings->retrieve_setting_editdata();
        $taxfield = $CI->db->select('tax_name,default_value')
            ->from('tax_settings')
            ->get()
            ->result_array();
        $data = array(
            'title'         => "Stock Transfer",
            'outlet_list' => $outlet_list,
            'outlet_list_to' => $outlet_list_to,
            'cw_list' => $cw_list,
            'discount_type' => $currency_details[0]['discount_type'],
            'taxes'         => $taxfield,
            'pro_expenses'  => $pro_expenses
        );

        // echo "<pre>";
        // print_r($data);
        // exit();
        $invoiceForm = $CI->parser->parse('rqsn/outlet_rqsn_form', $data, true);
        return $invoiceForm;
    }

    public function purchase_rqsn_form()
    {
        $CI = &get_instance();
        $CI->load->model('Rqsn');
        $CI->load->model('Web_settings');
        $CI->load->model('Purchases');
        $outlet_list    = $CI->Rqsn->outlet_list();
        $cw_list    = $CI->Rqsn->cw_list();
        $po_no = $CI->Purchases->number_generator();
        $currency_details = $CI->Web_settings->retrieve_setting_editdata();
        $taxfield = $CI->db->select('tax_name,default_value')
            ->from('tax_settings')
            ->get()
            ->result_array();
        $data = array(
            'title'         => "Central Warehouse Requisition",
            'outlet_list' => $outlet_list,
            'cw_list' => $cw_list,
            'po_no'    => $po_no,
            'discount_type' => $currency_details[0]['discount_type'],
            'taxes'         => $taxfield,
        );

        // echo '<pre'; print_r($cw_list);exit();
        //    die();
        $invoiceForm = $CI->parser->parse('rqsn/cw_purchase', $data, true);
        return $invoiceForm;
    }

    // public function purchase_rqsn_form_reserved()
    // {
    //     $CI = &get_instance();
    //     $CI->load->model('Purchases');
    //     $CI->load->model('Web_settings');
    //     $CI->load->model('Warehouse');
    //     $CI->load->model('Settings');
    //     $CI->load->model('Courier');

    //     $cw_list    = $CI->Rqsn->cw_list();
    //     $all_supplier = $CI->Purchases->select_all_supplier();
    //     $currency_details = $CI->Web_settings->retrieve_setting_editdata();
    //     $bank_list        = $CI->Web_settings->bank_list();
    //     $outlet_list = $CI->Warehouse->branch_list_product();
    //     $po_no = $CI->Purchases->number_generator();

    //     $card_list = $CI->Settings->read_all_card();
    //     $bank_list          = $CI->Web_settings->bank_list();
    //     $bkash_list        = $CI->Web_settings->bkash_list();
    //     $nagad_list        = $CI->Web_settings->nagad_list();
    //     $branch_list        = $CI->Courier->get_branch_list();
    //     $data = array(
    //         'title'         => 'Add requisition',
    //         'all_supplier'  => $all_supplier,
    //         'cw'            => $cw_list[0],
    //         'invoice_no'    => $CI->auth->generator(10),
    //         'discount_type' => $currency_details[0]['discount_type'],
    //         'po_no'         => $po_no,
    //         'bank_list'     => $bank_list,
    //         'outlet_list'   => $outlet_list,
    //         'card_list'     => $card_list,
    //         'bank_list'     => $bank_list,
    //         'bkash_list'     => $bkash_list,
    //         'nagad_list'     => $nagad_list,
    //         'branch_list'     => $branch_list,
    //     );

    //     // echo '<pre'; print_r($cw_list);exit();
    //     //    die();
    //     $invoiceForm = $CI->parser->parse('rqsn/cw_purchase', $data, true);
    //     return $invoiceForm;
    // }

    public function rqsn_report_form()
    {
        $CI = &get_instance();
        $CI->load->model('Rqsn');
        $CI->load->model('Warehouse');
        $rqsn_list = $CI->Rqsn->get_purhcase_rqsn();
        $new_rq = [];
        $sl = 1;
        foreach ($rqsn_list as $rq) {
            // echo '<pre>';
            // $rq['haha'] = 'aaha';
            // print_r($rq);
            $rq['sl'] = $sl;
            $rq['from'] = $rq['central_warehouse'];
            $rq['to']   = 'Purchase';

            switch ($rq['st']) {
                case '1':
                    $rq['st'] = 'Pending for approval';
                    break;
                case '4':
                    $rq['st'] = 'Approved for purchase';
                    break;
                case '5':
                    $rq['st'] = 'Purchased';
                    break;
            }

            $new_rq[] = $rq;
            $sl++;
        }

        $data = array(
            'title'     => 'Requsition Report',
            'rqsn_list' => $new_rq
        );

        // echo '<pre>';
        // print_r($data);
        // exit();

        $view = $CI->parser->parse('rqsn/rqsn_report_form', $data, true);
        return $view;
    }

    public function view_purchase_rqsn_form($rqsn_id)
    {
        $CI = &get_instance();
        $CI->load->model('Rqsn');

        $rqsn_details = $CI->Rqsn->get_rqsn_details($rqsn_id);

        $sl = 1;
        foreach ($rqsn_details as $k => $v) {
            $rqsn_details[$k]['sl'] = $sl;
            $sl++;
        }

        $data = array(
            'title'     => 'Purchase Requsition Details',
            'rqsn_details' => $rqsn_details,
        );

        // echo '<pre>';
        // print_r($data);
        // exit();

        $view = $CI->parser->parse('rqsn/view_purchase_rqsn_form', $data, true);
        return $view;
    }

    public function outlet_rqsn_report_form()
    {
        $CI = &get_instance();
        $CI->load->model('Rqsn');
        $CI->load->model('Warehouse');
        $rqsn_list = $CI->Rqsn->get_outlet_rqsn();
        $new_rq = [];
        $sl = 1;
        foreach ($rqsn_list as $rq) {
            // echo '<pre>';
            // $rq['haha'] = 'aaha';
            // print_r($rq);
            $rq['sl'] = $sl;
            $rq['from'] = $rq['outlet_name'];
            $rq['to']   = ($CI->db->select('central_warehouse')->from('central_warehouse')->get()->result_array())[0]['central_warehouse'];


            $new_rq[] = $rq;
            $sl++;
        }

        $data = array(
            'title'     => 'Requsition Report',
            'rqsn_list' => $new_rq
        );

        // echo '<pre>';
        // print_r($data);
        // exit();

        $view = $CI->parser->parse('rqsn/outlet_rqsn_report_form', $data, true);
        return $view;
    }

    public function view_outlet_rqsn_form($rqsn_id)
    {
        $CI = &get_instance();
        $CI->load->model('Rqsn');

        $rqsn_details = $CI->Rqsn->get_outlet_rqsn_details($rqsn_id);

        $sl = 1;
        foreach ($rqsn_details as $k => $v) {
            $rqsn_details[$k]['sl'] = $sl;
            if ($rqsn_details[$k]['item_status'] == 1) {
                $rqsn_details[$k]['status'] = 'Pending for approval';
            } elseif ($rqsn_details[$k]['item_status'] == 2) {
                $rqsn_details[$k]['status'] = 'Approved (Not received yet)';
            } else {
                $rqsn_details[$k]['status'] = 'Recieved by outlet';
            }
            $sl++;
        }

        $data = array(
            'title'     => 'Purchase Requsition Details',
            'rqsn_details' => $rqsn_details,
        );

        // echo '<pre>';
        // print_r($data);
        // exit();

        $view = $CI->parser->parse('rqsn/view_outlet_rqsn_form', $data, true);
        return $view;
    }

    public function outlet_to_dealer_transfer_form()
    {
        $CI = &get_instance();
        $CI->load->model('customers');
        $CI->load->model('Accounts');
        // $outlet_list    = $CI->Rqsn->outlet_list();
        $outlet_list_to    = $CI->customers->customer_list();
        // $cw_list    = $CI->Rqsn->cw_list();
        $pro_expenses = $CI->Accounts->get_data_by_headcode(40105);

        $data = array(
            'title'         => "Stock Transfer from Outlet to" . display('dealer'),
            // 'outlet_list' => $outlet_list,
            'outlet_list_to' => $outlet_list_to,
            'pro_expenses'  => $pro_expenses
            // 'cw_list' => $cw_list,
        );

        // echo '<pre'; print_r($cw_list);exit();
        //    die();
        $invoiceForm = $CI->parser->parse('rqsn/out_to_dealer_form', $data, true);
        return $invoiceForm;
    }

    public function dealer_stock_report_form()
    {
        $CI = &get_instance();
        $CI->load->model('Rqsn');
        $CI->load->model('Reports');
        $dealer_list    = $CI->Rqsn->outlet_dealers_list();
        $cw_list    = $CI->Rqsn->cw_list();
        $data = array(
            'title'         => display('dealer') . " Stock",
            'dealer_list' => $dealer_list,
            'cw_list' => $cw_list,
            'totalnumber' => $CI->Reports->totalnumberof_product(),
        );

        // echo print_r($data);
        // die();
        $invoiceForm = $CI->parser->parse('rqsn/dealer_stock_form', $data, true);
        return $invoiceForm;
    }

    public function warehouse_stock_report_form()
    {
        $CI = &get_instance();
        $CI->load->model('Reports');
        $CI->load->model('Web_settings');
        $data['title'] = 'Stock Report';
        $company_info = $CI->Reports->retrieve_company();
        $currency_details = $CI->Web_settings->retrieve_setting_editdata();
        $data['currency'] = $currency_details[0]['currency'];
        $data['totalnumber'] = $CI->Reports->totalnumberof_product();
        $data['company_info'] = $company_info;
        $data['pr_status'] = 1;
        $data['heading_text'] = "Stock Report";
        $CI->load->model('Warehouse');
        $sub_warehouse_list = $CI->Warehouse->sub_warehouse_list();
        $data['dealer_list'] = $sub_warehouse_list;
        // echo "<pre>";
        // print_r($data);
        // exit();


        $reportList = $CI->parser->parse('warehouse/warehouse_stock', $data, true);
        return $reportList;
    }

    //Stock Transfer Edit Data
    public function stock_transfer_edit_data($rqsn_id , $isreport)
    {
        $CI = &get_instance();
        $CI->load->model('Rqsn');
        $CI->load->model('Warehouse');
        $CI->load->model('Accounts');
        $sub_warehouse_list = $CI->Warehouse->sub_warehouse_list();
        $transfered_data = $CI->Rqsn->stock_transfer_update_data($rqsn_id);
        $pro_expenses = $CI->Accounts->get_data_by_headcode(40105);
        if (!empty($transfered_data)) {
            $i = 0;
            foreach ($transfered_data as $k => $v) {
                $i++;
                $transfered_data[$k]['sl'] = $i;
            }
        }
        $data = array(
            'transfered_data' => $transfered_data,
            'sub_warehouse_list' => $sub_warehouse_list,
            'isreport' => $isreport,
            'pro_expenses'=> $pro_expenses
            
        );

        // echo "<pre>";
        // print_r($data);
        // exit();
        $chapterList = $CI->parser->parse('rqsn/stock_transfer_edit', $data, true);
        return $chapterList;
    }
    //Stock Transfer Edit Data
    public function stock_transfer_view_data($rqsn_id, $isreport)
    {
        $CI = &get_instance();
        $CI->load->model('Rqsn');
        $CI->load->model('Warehouse');
        $CI->load->model('Accounts');
        $sub_warehouse_list = $CI->Warehouse->sub_warehouse_list();
        $transfered_data = $CI->Rqsn->stock_transfer_update_data($rqsn_id);
        $pro_expenses = $CI->Accounts->get_data_by_headcode(40105);
        if (!empty($transfered_data)) {
            $i = 0;
            foreach ($transfered_data as $k => $v) {
                $i++;
                $transfered_data[$k]['sl'] = $i;
            }
        }
        $data = array(
            'transfered_data' => $transfered_data,
            'sub_warehouse_list' => $sub_warehouse_list,
            'isreport' => $isreport,
            'pro_expenses' => $pro_expenses

        );

        // echo "<pre>";
        // print_r($data);
        // exit();
        $chapterList = $CI->parser->parse('report/stock_transfer_report', $data, true);
        return $chapterList;
    }
    //Stock Transfer Edit Data
    public function outlet_transfer_edit_data($rqsn_id, $isreport)
    {
        $CI = &get_instance();
        $CI->load->model('Rqsn');
        $CI->load->model('Warehouse');
        $sub_warehouse_list = $CI->Warehouse->sub_warehouse_list();
        $transfered_data = $CI->Rqsn->outlet_transfer_update_data($rqsn_id);
        //   echo "<pre>";
        // print_r($transfered_data);
        // exit();
        if (!empty($transfered_data)) {
            $i = 0;
            foreach ($transfered_data as $k => $v) {
                $i++;
                $transfered_data[$k]['sl'] = $i;
            }
        }
        $data = array(
            'transfered_data' => $transfered_data,
            'sub_warehouse_list' => $sub_warehouse_list,
            'isreport' => $isreport

        );
        //   echo "<pre>";
        // print_r($data);
        // exit();

        $chapterList = $CI->parser->parse('rqsn/outlet_to_dealer_manage', $data, true);
        return $chapterList;
    }
}
