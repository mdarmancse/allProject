<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Cproduction extends CI_Controller {

    public $menu;
       public $production_id;

    function __construct() {
        parent::__construct();
        $this->load->library('auth');
        $this->load->library('lproduction');
        $this->load->library('session');
        $this->load->model('Production');
        $this->auth->check_admin_auth();
    }

    //Default loading for service system.
    public function index() {
        $content = $this->lproduction->rqsn_add_form();
        $this->template->full_admin_html_view($content);
    }
    public function autocompleteprsearch(){
        $CI =& get_instance();
        $this->auth->check_admin_auth();
        $CI->load->model('Production');
        $product_name   = $this->input->post('product_name',TRUE);
        $product_info   = $CI->Production->autocompletprdata($product_name);

        if(!empty($product_info)){
            $list[''] = '';
            foreach ($product_info as $value) {
                $json_product[] = array('label'=>$value['product_name'],'value'=>$value['product_id']);
            }
        }else{
            $json_product[] = 'No Product Found';
        }
        echo json_encode($json_product);

    }

    public function autocompleteproductsearch(){
        $CI =& get_instance();
        $this->auth->check_admin_auth();
        $CI->load->model('Production');
        $product_name   = $this->input->post('product_name',TRUE);
        $product_info   = $CI->Production->autocompletproductdata($product_name);

        if(!empty($product_info)){
            $list[''] = '';
            foreach ($product_info as $value) {
                $json_product[] = array('label'=>$value['product_name'],'value'=>$value['product_id']);
            }
        }else{
            $json_product[] = 'No Product Found';
        }
        echo json_encode($json_product);

    }

    public function autocompleteitemsearch(){
        $CI =& get_instance();
        $this->auth->check_admin_auth();
        $CI->load->model('Production');
        $product_name   = $this->input->post('item_name',TRUE);
        $product_info   = $CI->Production->autocompletitemdata($product_name);

        if(!empty($product_info)){
            $list[''] = '';
            foreach ($product_info as $value) {
                $json_product[] = array('label'=>$value['product_name'],'value'=>$value['product_id']);
            }
        }else{
            $json_product[] = 'No Product Found';
        }
        echo json_encode($json_product);

    }

    public function retrieve_product_data_inv() {
        $CI = & get_instance();
        $this->auth->check_admin_auth();
        $CI->load->model('Production');
        $product_id = $this->input->post('product_id',TRUE);
        $customer_id = $this->input->post('customer_id',TRUE);


        $product_info = $CI->Production->get_total_product_invoic($product_id,$customer_id);

        echo json_encode($product_info);
    }

    public function retrieve_product_data_production() {
        $CI = & get_instance();
        $this->auth->check_admin_auth();
        $CI->load->model('Production');
        $product_id = $this->input->post('product_id',TRUE);
        $customer_id = $this->input->post('customer_id',TRUE);


        $product_info = $CI->Production->get_total_product_production($product_id,$customer_id);

        echo json_encode($product_info);
    }




    public function production_mix() {
        $CI = & get_instance();
        $CI->auth->check_admin_auth();
        $CI->load->library('lproduction');
        $content = $CI->lproduction->production_mix_form();
        $this->template->full_admin_html_view($content);
    }

    public function production() {
        $CI = & get_instance();
        $CI->auth->check_admin_auth();
        $CI->load->library('lproduction');
        $content = $CI->lproduction->production_form();
        $this->template->full_admin_html_view($content);
    }

      public function cw_purchase() {
        $CI = & get_instance();
        $CI->auth->check_admin_auth();
        $CI->load->library('lproduction');
        $content = $CI->lproduction->purchase_rqsn_form();
        $this->template->full_admin_html_view($content);
    }

    public function insert_mix(){
        $CI = & get_instance();

        //echo "Ok";exit();

        $CI->auth->check_admin_auth();
        $CI->load->model('Production');

        $rqsn = $CI->Production->mix_entry();



     //   echo "ok";exit();

        if ($rqsn == TRUE) {
            $this->session->set_userdata(array('message' => display('successfully_added')));

            redirect(base_url('Cproduction/production_mix'));

        } else {
            $this->session->set_userdata(array('error_message' => display('please_try_again')));
            redirect(base_url('Cproduction/production_mix'));
        }


}
 public function manage_production()
    {   
     
        $CI =& get_instance();
        $this->auth->check_admin_auth();
        $CI->load->library('lproduction');
        $CI->load->model('Production');
        $content =$this->lproduction->production_list();
        $this->template->full_admin_html_view($content);  
    }
    
        public function production_delete($production_id) {
        $CI = & get_instance();
        $this->auth->check_admin_auth();
        $CI->load->model('Production');
        // $check_calculation = $CI->Production->check_calculaton($production_id);
        // if($check_calculation > 0){
        //     $this->session->set_userdata(array('error_message' => display('you_cant_delete_this_product')));
        //     redirect(base_url('Cproduction/manage_production'));

        // }else{
        $result = $CI->Production->delete_production($production_id);
         $this->session->set_userdata(array('message' => display('successfully_delete')));
        redirect(base_url('Cproduction/manage_production'));
    // }
    }
        public function production_update_form($production_id) {
        $CI = & get_instance();
        $CI->auth->check_admin_auth();
        $CI->load->library('lproduction');
        $content = $CI->lproduction->production_edit_data($production_id);
        $this->template->full_admin_html_view($content);
    }
public function production_update() {
        $CI = & get_instance();
        $CI->auth->check_admin_auth(); 
        $CI->load->model('Production');

        $production_id = $this->input->post('production_id',TRUE);
        // $product_id_two = $this->input->post('product_id_two',TRUE);
        $this->db->where('production_id', $production_id);
        $this->db->delete('production_mix_details');
        // $sup_price = $this->input->post('supplier_price',TRUE);
        // $s_id = $this->input->post('supplier_id',TRUE);
        // for ($i = 0, $n = count($s_id); $i < $n; $i++) {
        //     $supplier_price = $sup_price[$i];
        //     $supp_id = $s_id[$i];

        //     $supp_prd = array(
        //         'product_id'     => $product_id,
        //         'product_id_two'     => $product_id_two,
        //         'supplier_id'    => $supp_id,
        //         'supplier_price' => $supplier_price
        //     );

        //     $this->db->insert('supplier_product', $supp_prd);
        // }
        // configure for upload 
        // $config = array(
        //     'upload_path'   => "./my-assets/image/product/",
        //     'allowed_types' => "png|jpg|jpeg|gif|bmp|tiff",
        //     'overwrite'     => TRUE,
        //      'encrypt_name' => TRUE,
        //     'max_size'      => '0',
        // );
        // $image_data = array();
        // $this->load->library('upload', $config);
        // $this->upload->initialize($config);
        // if ($this->upload->do_upload('image')) {
        //     $image_data = $this->upload->data();
        //     $image_name = base_url() . "my-assets/image/product/" . $image_data['file_name'];
        //     $config['image_library'] = 'gd2';
        //     $config['source_image'] = $image_data['full_path']; 
        //     $config['maintain_ratio'] = TRUE;
        //     $config['height'] = '100';
        //     $config['width'] = '100';
        //     $this->load->library('image_lib', $config);
        //     $this->image_lib->clear();
        //     $this->image_lib->initialize($config);
        //     if (!$this->image_lib->resize()) {
        //         echo $this->image_lib->display_errors();
        //     }
        // } else {
        //     $image_name = $this->input->post('old_image',TRUE);
        // }


    //     $price = $this->input->post('price',TRUE);
       
    //     $tablecolumn = $this->db->list_fields('tax_collection');
    //     $num_column = count($tablecolumn)-4;
    //     if($num_column > 0){
    //    $taxfield = [];
    //    for($i=0;$i<$num_column;$i++){
    //     $taxfield[$i] = 'tax'.$i;
    //    }
    //    foreach ($taxfield as $key => $value) {
    //     $data[$value] = $this->input->post($value)/100;
    //    }
    // }
            $data['product_name']   = $this->input->post('product_name',TRUE);
            $data['category_id']    = $this->input->post('category_id',TRUE);
            $data['product_id_two']    = $this->input->post('product_id_two',TRUE);
            // $data['brand_id']    = $this->input->post('brand_id',TRUE);
            $data['ptype_id']    = $this->input->post('ptype_id',TRUE);
            $data['price']          = $price;
            $data['serial_no']      = $this->input->post('serial_no',TRUE);
            $data['re_order_level']      = $this->input->post('re_order_level',TRUE);
            // $data['product_model']  = $this->input->post('model',TRUE);
            $data['product_details']= $this->input->post('description',TRUE);
            $data['unit']           = $this->input->post('unit',TRUE);
             $data['multiplier']           = $this->input->post('multiplier',TRUE);
             $data['trans_unit']           = $this->input->post('trans_unit',TRUE);
            $data['tax']            = 0;
            $data['image']          = $image_name;
       
        $result = $CI->Products->update_product($data, $product_id);
        if ($result == true) {
            $this->session->set_userdata(array('message' => display('successfully_updated')));
            redirect(base_url('Cproduct/manage_product'));
        } else {
            $this->session->set_userdata(array('error_message' => display('product_model_already_exist')));
            redirect(base_url('Cproduct/manage_product'));
        }
    }
 public function CheckProductionList(){
        // GET data
        $this->load->model('Production');
        $postData = $this->input->post();
        $data = $this->Production->getProductionList($postData);
        echo json_encode($data);
    } 
        public function production_details($production_id) {
        $this->product_id = $production_id;
        $CI = & get_instance();
        $this->auth->check_admin_auth();
        $CI->load->library('lproduction');
        $content = $CI->lproduction->production_details($product_id);
        $this->template->full_admin_html_view($content);
    }
    public function insert_goods(){
        $CI = & get_instance();

        //echo "Ok";exit();

        $CI->auth->check_admin_auth();
        $CI->load->model('Production');

        $rqsn = $CI->Production->goods_entry();



     //   echo "ok";exit();

        if ($rqsn == TRUE) {
            $this->session->set_userdata(array('message' => display('successfully_added')));

            redirect(base_url('Cproduction/production_mix'));

        } else {
            $this->session->set_userdata(array('error_message' => display('please_try_again')));
            redirect(base_url('Cproduction/production_mix'));
        }


}

    public function insert_rqsn_cw(){
        $CI = & get_instance();

        //echo "Ok";exit();

        $CI->auth->check_admin_auth();
        $CI->load->model('Production');

        $rqsn = $CI->Rqsn->rqsn_entry_cw();



     //   echo "ok";exit();

        if ($rqsn == TRUE) {
            $this->session->set_userdata(array('message' => display('successfully_added')));

            redirect(base_url('Cproduction/cw_purchase'));

        } else {
            $this->session->set_userdata(array('error_message' => display('please_try_again')));
            redirect(base_url('Cproduction/cw_purchase'));
        }


}

    //Aprove voucher
    public function aprove_rqsn(){
        $CI = & get_instance();
        $this->auth->check_admin_auth();
        $CI->load->model('Production');
        $CI->load->model('Reports');
        $data['title'] = 'Approve Reacquisition';
        $data['t'] = $this->Rqsn->approve_rqsn();
        //$data['t'] = $this->Reports->getCheckList_rqsn();
       // $data = $this->Reports->getCheckLi st_rqsn();


      //  echo '<pre>';print_r($data);exit();
        $content = $this->parser->parse('production/rqsn_approve', $data, true);
        $this->template->full_admin_html_view($content);
    }

    public function aprove_rqsn_outlet(){
        $CI = & get_instance();
        $this->auth->check_admin_auth();
        $CI->load->model('Production');
        $CI->load->model('Reports');
        $data['title'] = 'Approve Reacquisition';
        $data['t'] = $this->Rqsn->approve_rqsn_outlet();
        //$data['t'] = $this->Reports->getCheckList_rqsn();
       // $data = $this->Reports->getCheckLi st_rqsn();


      //  echo '<pre>';print_r($data);exit();
        $content = $this->parser->parse('production/outlet_rqsn_approve', $data, true);
        $this->template->full_admin_html_view($content);
    }

    public function aprove_chalan(){
        $CI = & get_instance();
        $this->auth->check_admin_auth();
        $CI->load->model('Production');
        $data['title'] = 'Chalan Approve';
        $data['aprrove'] = $this->Rqsn->approve_chalan();

       // echo '<pre>';print_r($data);exit();
        $content = $this->parser->parse('production/approve_chalan', $data, true);
        $this->template->full_admin_html_view($content);
    }


    public function rqsn_list(){
        $CI = & get_instance();
        $this->auth->check_admin_auth();
        $CI->load->model('Production');
        $data['title'] = 'Reacquisition List';
        $data['aprrove'] = $this->Rqsn->rqsn_list();

       //echo '<pre>';print_r($data);exit();
        $content = $this->parser->parse('production/rqsn_list', $data, true);
        $this->template->full_admin_html_view($content);
    }

    public function rqsn_list_outlet(){
        $CI = & get_instance();
        $this->auth->check_admin_auth();
        $CI->load->model('Production');
        $data['title'] = 'Stock Transferred Outlet';
        $data['aprrove'] = $this->Rqsn->rqsn_list_outlet();

       //echo '<pre>';print_r($data);exit();
        $content = $this->parser->parse('production/rqsn_list_outlet', $data, true);
        $this->template->full_admin_html_view($content);
    }



    public function aprove_rqsn_purchase(){
        $CI = & get_instance();
        $this->auth->check_admin_auth();
        $CI->load->model('Production');
        $data['title'] = 'Approve Reacquisition CW';
        $data['aprrove'] = $this->Rqsn->approve_rqsn_purchase();

        //echo '<pre>';print_r($data);exit();
        $content = $this->parser->parse('production/rqsn_approve_purchase', $data, true);
        $this->template->full_admin_html_view($content);
    }



    public function outlet_approve(){
        $CI = & get_instance();
        $this->auth->check_admin_auth();
        $CI->load->model('Production');
        $data['title'] = 'Outlet Approve';
        $data['t'] = $this->Rqsn->approve_outlet();

     //echo '<pre>';print_r($data);exit();
        $content = $this->parser->parse('production/rqsn_approve_outlet', $data, true);
        $this->template->full_admin_html_view($content);
    }

    public function isactive($id = null, $action = null,$value=null)
    {
        $CI = & get_instance();
        $CI->load->model('Production');
        $action = ($action=='active'?2:1);
        $postData = array(
            'rqsn_detail_id'     => $id,
            'a_qty'=>$value,
            'status' => $action,
            'isaprv' =>1,
            'iscw' =>1
        );

//        print_r($postData);
//        die();

       // echo '<script>alert("Welcome to Geeks for Geeks")</script>';

        if ($this->Rqsn->approved($postData)) {
            $this->session->set_flashdata('message', display('successfully_approved'));
        } else {
            $this->session->set_flashdata('error_message', display('please_try_again'));
        }

        redirect($_SERVER['HTTP_REFERER']);
    }
    public function ischalan($id = null, $action = null,$value=null)
    {
        $CI = & get_instance();
        $CI->load->model('Production');
        $action = ($action=='active'?1:2);
        $expiry_date=date('Y-m-d',strtotime(' +7 day'));
        $postData = array(
            'chalan_id'     => $id,
            'barcode'=>$value,
            'expired_date'=>$expiry_date,
            'status' => $action
        );

//        print_r($postData);
//        die();

       // echo '<script>alert("Welcome to Geeks for Geeks")</script>';

        if ($this->Rqsn->chalan_received($postData)) {
            $this->session->set_flashdata('message', display('successfully_approved'));
        } else {
            $this->session->set_flashdata('error_message', display('please_try_again'));
        }

        redirect($_SERVER['HTTP_REFERER']);
    }
    public function isapporve_purchase($id = null, $action = null,$value=null)
    {
        $CI = & get_instance();
        $CI->load->model('Production');
        $action = ($action=='active'?4:1);
        $postData = array(
            'rqsn_detail_id'     => $id,
            'a_qty'=>$value,
            'status' => $action
        );

//        print_r($postData);
//        die();

       // echo '<script>alert("Welcome to Geeks for Geeks")</script>';

        if ($this->Rqsn->approved($postData)) {
            $this->session->set_flashdata('message', display('successfully_approved'));
        } else {
            $this->session->set_flashdata('error_message', display('please_try_again'));
        }

        redirect($_SERVER['HTTP_REFERER']);
    }

    public function rqsn_delete($rqsn_id){
        if ($this->Rqsn->delete_rqsn($rqsn_id)) {
            $this->session->set_flashdata('message', display('successfully_delete'));
        } else {
            $this->session->set_flashdata('error_message', display('please_try_again'));
        }

        redirect($_SERVER['HTTP_REFERER']);

    }


    public function r_rqsn_delete($rqsn_id){
        if ($this->Rqsn->r_delete_rqsn($rqsn_id)) {
            $this->session->set_flashdata('message', display('successfully_delete'));
        } else {
            $this->session->set_flashdata('error_message', display('please_try_again'));
        }

        redirect($_SERVER['HTTP_REFERER']);

    }


    public function isreceive($id = null, $action = null)
    {
        $CI = & get_instance();
        $CI->load->model('Production');
        $action = ($action=='active'?3:2);
        $postData = array(
            'rqsn_detail_id'     => $id,
            'status' => $action,
            'isrcv' =>1
        );

//        print_r($postData);
//        die();

        // echo '<script>alert("Welcome to Geeks for Geeks")</script>';

        if ($this->Rqsn->received($postData)) {
            $this->session->set_flashdata('message', display('successfully_approved'));
        } else {
            $this->session->set_flashdata('error_message', display('please_try_again'));
        }

        redirect($_SERVER['HTTP_REFERER']);
    }

    public function outlet_rqsn_delete($rqsn_id){
        if ($this->Rqsn->delete_rqsn($rqsn_id)) {
            $this->session->set_flashdata('message', display('successfully_delete'));
        } else {
            $this->session->set_flashdata('error_message', display('please_try_again'));
        }

        redirect($_SERVER['HTTP_REFERER']);


    }
    public function stock(){

     //   echo 'Okay';die();

        $content = $this->lproduction->stock_report_outlet_item();
       // echo 'Okay';die();
        $this->template->full_admin_html_view($content);
    }

    public function outlet_stock(){
        $this->load->model('Production');
        $postData = $this->input->post();
        $data = $this->Rqsn->outlet_stock($postData);
        echo json_encode($data);
    }

}
