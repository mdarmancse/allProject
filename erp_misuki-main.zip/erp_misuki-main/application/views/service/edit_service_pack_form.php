<!-- Add new Service start -->
<div class="content-wrapper">
    <section class="content-header">
        <div class="header-icon">
            <i class="pe-7s-note2"></i>
        </div>
        <div class="header-title">
            <h1>Edit Service Package</h1>
            <small>Edit Service Package</small>
            <ol class="breadcrumb">
                <li><a href="#"><i class="pe-7s-home"></i> <?php echo display('home') ?></a></li>
                <li><a href="#"><?php echo display('service') ?></a></li>
                <li class="active">Edit Service Package</li>
            </ol>
        </div>
    </section>

    <section class="content">

        <!-- Alert Message -->
        <?php
        $message = $this->session->userdata('message');
        if (isset($message)) {
            ?>
            <div class="alert alert-info alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <?php echo $message ?>                    
            </div>
            <?php
            $this->session->unset_userdata('message');
        }
        $error_message = $this->session->userdata('error_message');
        if (isset($error_message)) {
            ?>
            <div class="alert alert-danger alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <?php echo $error_message ?>                    
            </div>
            <?php
            $this->session->unset_userdata('error_message');
        }
        ?>

        <div class="row">
            <div class="col-sm-12">
              
  <?php if($this->permission1->method('manage_service','read')->access()){ ?>
                    <a href="<?php echo base_url('Cservice/manage_service') ?>" class="btn btn-info m-b-5 m-r-2"><i class="ti-align-justify"> </i> <?php echo display('manage_service') ?> </a>
                <?php }?>
                 <?php if($this->permission1->method('create_service','create')->access()){ ?>
                <button type="button" class="btn btn-info m-b-5 m-r-2" data-toggle="modal" data-target="#service_csv"><?php echo display('service_csv_upload')?></button>
                <?php }?>
              
            </div>
        </div>

        <!-- New customer -->
        <div class="row">
            <div class="col-sm-12">
                <div class="panel panel-bd lobidrag">
                    <div class="panel-heading">
                        <div class="panel-title">
                            <h4>Add Service Package</h4>
                        </div>
                    </div>
                    <?php echo form_open('Cservice/update_service_pack', array('class' => 'form-vertical', 'id' => 'insert_service')) ?>
                    <div class="panel-body">

                        <div class="form-group row">
                            <label for="service_name" class="col-sm-3 col-form-label">Package Name<i class="text-danger">*</i></label>
                            <div class="col-sm-4">
                                <input autocomplete="off" class="form-control" value="<?php echo $selected_service[0]['package_name']?>" name ="package_name" id="package_name" type="text" placeholder="Package Name" >
                                <input autocomplete="off" class="form-control" value="<?php echo $selected_service[0]['package_id']?>" name ="package_id" id="package_id" type="hidden" placeholder="Package Name"  >
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="service_name" class="col-sm-3 col-form-label">Package Price<i class="text-danger">*</i></label>
                            <div class="col-sm-4">
                                <input autocomplete="off" class="form-control" value="<?php echo $selected_service[0]['package_price']?>" name ="package_price" id="package_price" type="text" placeholder="Package Price" readonly>

                            </div>
                        </div>

                   <div class="form-group row">
                            <label for="charge" class="col-sm-3 col-form-label">Selected Service </label>
                            <div class="col-sm-6">
                                {selected_service}
                                <div class="form-check" style="margin-bottom: 5px">
<!--                                    <input  class="service_id_{service_id}" name="service_id[]" type="checkbox" data-id="{service_id}" value='' id="service_id "  onclick="get_value('{service_id}')"/>-->

                                    <input class="form-check-input" type="checkbox" value="" id="flexCheckChecked" checked disabled>

                                    <label class="form-check-label text-info" for="flexCheckDefault">
                                      {service_name}
                                        <input autocomplete="off" class="form-control service_price" name ="service_price[]" id="service_price_{service_id}" type="text" placeholder="Price" value="{service_price}" onchange="get_price('{service_id}')" onkeyup="get_price('{service_id}')">
                                        <input autocomplete="off" class="form-control package_details_id" name ="package_details_id[]" id="" type="hidden" value="{package_details_id}" >
                                    </label>
                                </div>
                                {/selected_service}
                            </div>
                   </div>

<!--                        <div class="form-group row">-->
<!--                            <label for="charge" class="col-sm-3 col-form-label">Add Service </label>-->
<!--                            <div class="col-sm-6">-->
<!--                                {service}-->
<!--                                <div class="form-check">-->
<!---->
<!--                                    <input  class="main_id_{service_id}" name="main_id[]" type="hidden"  value='' id="main_id"  />-->
<!--                                    <input class="form-check-input" type="checkbox" value="" id="flexCheckChecked" >-->
<!---->
<!--                                    <label class="form-check-label text-info" for="flexCheckDefault">-->
<!--                                        {service_name}-->
<!--                                    </label>-->
<!--                                </div>-->
<!--                                {/service}-->
<!--                            </div>-->
<!--                        </div>-->

                        <div class="form-group row">
                            <label for="charge" class="col-sm-3 col-form-label">Status</label>
                            <div class="col-sm-6">
                                <input  class="status" name="status" type="hidden"  value='<?php echo $selected_service[0]['st']?>' id="status"/>
                                <label class="switch">


                                    <input  id='switch' type="checkbox" checked>
                                    <span class="slider round" style="height: 26px;width: 52px"></span>
                                </label>

                            </div>
                   </div>




                        <div class="form-group row">
                            <label for="example-text-input" class="col-sm-4 col-form-label"></label>
                            <div class="col-sm-6">
                                <input type="submit" id="add-service" class="btn btn-success btn-large" name="add-service" value="<?php echo display('save') ?>" />
                            </div>
                        </div>
                    </div>
                    <?php echo form_close() ?>
                </div>
            </div>
                  <div id="service_csv" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title"><?php echo display('service_csv_upload'); ?></h4>
      </div>
      <div class="modal-body">

                <div class="panel">
                    <div class="panel-heading">
                        
                            <div><a href="<?php echo base_url('assets/data/csv/service_csv_sample.csv') ?>" class="btn btn-primary pull-right"><i class="fa fa-download"></i><?php echo display('download_sample_file')?> </a> </div>
                       
                    </div>
                    
                    <div class="panel-body">
                       
                      <?php echo form_open_multipart('Cservice/uploadCsv_service',array('class' => 'form-vertical', 'id' => 'validate','name' => 'insert_service'))?>
                            <div class="col-sm-12">
                                <div class="form-group row">
                                    <label for="upload_csv_file" class="col-sm-4 col-form-label"><?php echo display('upload_csv_file') ?> <i class="text-danger">*</i></label>
                                    <div class="col-sm-8">
                                        <input class="form-control" name="upload_csv_file" type="file" id="upload_csv_file" placeholder="<?php echo display('upload_csv_file') ?>" required>
                                    </div>
                                </div>
                            </div>
                        
                       <div class="col-sm-12">
                        <div class="form-group row">
                            <div class="col-sm-12 text-right">
                                <input type="submit" id="add-product" class="btn btn-primary btn-large" name="add-product" value="<?php echo display('submit') ?>" />
                                  <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                               
                            </div>
                        </div>
                        </div>
                          <?php echo form_close()?>
                    </div>
                    </div>
                  
               
     
      </div>
     
    </div>

  </div>
</div>
        </div>
    </section>
</div>
<!-- Add new Service end -->

<script type="text/javascript">
    $(document).ready(function() {


        var hidden_status=$('#status').val()

        if (hidden_status == 2){

         $("#switch").removeAttr('checked');
        }

        $('#switch').change(function(){
            if($(this).prop('checked'))
            {
                $('#status').val('1');
            }
            else
            {
                $('#status').val('2');
            }
        });


       //  var hidden_status=parseInt($('#status').val());
       //  var status=$('#switch').val();
       //
       // // alert(hidden_status)
       //
       //  if (hidden_status == 2){
       //
       //
       //
       //      alert(hidden_status)
       //      //status.val('1')
       //  }

    });


function change_status() {



}

    function get_value(sl) {

        var service_id=$('.service_id_'+sl).data('id');
        var main_id=$('.main_id_'+sl).val(service_id);





       // alert(service_id)

    }

    function get_price(sl) {


        var service_price=parseFloat($('#service_price_'+sl).val());


        var t = 0,
            e=0

        $(".service_price").each(function () {
            isNaN(this.value) || 0 == this.value.length || (t += parseFloat(this.value))
        })
        e = t.toFixed(2, 2);

// console.log(t)

    //   $('#package_price').val('0');
        $('#package_price').val(e);


    }



</script>




